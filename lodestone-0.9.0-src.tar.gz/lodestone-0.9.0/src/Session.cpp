/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Session.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"

namespace lode
{
using namespace juce;

//==============================================================================
ViewState::ViewState (te::Edit& edit)
{
    state = edit.state.getOrCreateChildWithName ("LODEVIEW", nullptr);
    pixelsPerBeat.referTo (state, "pixelsPerBeat", nullptr, 32.0);
    scrollBeat.referTo (state, "scrollBeat", nullptr, 0.0);
    scrollY.referTo (state, "scrollY", nullptr, 0.0);
    snapOn.referTo (state, "snapOn", nullptr, true);
    snapDivision.referTo (state, "snapDivision", nullptr, 0.25);
    keyRoot.referTo (state, "keyRoot", nullptr, 0);
    scaleName.referTo (state, "scaleName", nullptr, "Major");
    scaleLock.referTo (state, "scaleLock", nullptr, false);
    bottomPanelHeight.referTo (state, "bottomPanelHeight", nullptr, 360);
    defaultTrackHeight.referTo (state, "trackHeight", nullptr, 64);
}

//==============================================================================
InputRouter::InputRouter (te::Engine& e) : engine (e) {}

PropertiesFile& InputRouter::props()
{
    return engine.getPropertyStorage().getPropertiesFile();
}

void InputRouter::attachToEdit (te::Edit* e)
{
    edit = e;
    followTrack = nullptr;
}

static bool isUserMidiDevice (const te::MidiInputDevice& m)
{
    auto type = m.getDeviceType();
    return type == te::InputDevice::physicalMidiDevice
        || (type == te::InputDevice::virtualMidiDevice && m.getDeviceID() != "all_midi_in");
}

void InputRouter::enableAllDevices()
{
    auto& dm = engine.getDeviceManager();

    for (auto& m : dm.getMidiInDevices())
    {
        if (! isUserMidiDevice (*m))
            continue;

        if (! m->isEnabled())
            m->setEnabled (true);

        m->setMonitorMode (te::InputDevice::MonitorMode::on);
    }

    for (auto* w : dm.getWaveInputDevices())
        w->setMonitorMode (te::InputDevice::MonitorMode::automatic);
}

te::InputDeviceInstance* InputRouter::findInstance (const String& deviceID)
{
    if (edit == nullptr)
        return nullptr;

    for (auto* inst : edit->getAllInputDevices())
        if (inst->getInputDevice().getDeviceID() == deviceID)
            return inst;

    return nullptr;
}

bool InputRouter::isFollowing (const String& deviceID) const
{
    return const_cast<InputRouter*> (this)->props().getBoolValue ("midiFollow_" + deviceID, true);
}

void InputRouter::setFollow (const String& deviceID, bool follow)
{
    props().setValue ("midiFollow_" + deviceID, follow);

    if (follow)
        selectedTrackChanged (followTrack.get());
}

Array<InputRouter::DeviceInfo> InputRouter::getMidiDevices()
{
    Array<DeviceInfo> result;

    for (auto& m : engine.getDeviceManager().getMidiInDevices())
    {
        if (! isUserMidiDevice (*m) || ! m->isEnabled())
            continue;

        DeviceInfo d;
        d.id = m->getDeviceID();
        d.name = m->getAliasOrName();
        d.isMidi = true;
        d.follows = isFollowing (d.id);

        if (auto* inst = findInstance (d.id))
            if (edit != nullptr)
                for (auto t : te::getAudioTracks (*edit))
                    if (te::isOnTargetTrack (*inst, *t, 0))
                        d.pinnedTrack = t;

        result.add (d);
    }

    return result;
}

Array<InputRouter::DeviceInfo> InputRouter::getAudioDevices()
{
    Array<DeviceInfo> result;

    for (auto* w : engine.getDeviceManager().getWaveInputDevices())
    {
        if (! w->isEnabled())
            continue;

        DeviceInfo d;
        d.id = w->getDeviceID();
        d.name = w->getAliasOrName();
        d.isMidi = false;
        d.follows = false;
        result.add (d);
    }

    return result;
}

void InputRouter::pinDevice (const String& deviceID, te::AudioTrack* track)
{
    if (edit == nullptr)
        return;

    if (track == nullptr)
    {
        setFollow (deviceID, true);
        return;
    }

    props().setValue ("midiFollow_" + deviceID, false);

    edit->getTransport().ensureContextAllocated();

    if (auto* inst = findInstance (deviceID))
    {
        [[maybe_unused]] auto res = inst->setTarget (track->itemID, true, nullptr, 0);
    }

    edit->restartPlayback();
}

void InputRouter::selectedTrackChanged (te::AudioTrack* t)
{
    if (edit == nullptr)
        return;

    if (t != nullptr && getTrackKind (*t) == TrackKind::audio)
        return;   // keep MIDI where it was when an audio track is selected

    followTrack = t;

    if (t == nullptr)
        return;

    edit->getTransport().ensureContextAllocated();
    bool changed = false;

    for (auto& m : engine.getDeviceManager().getMidiInDevices())
    {
        if (! isUserMidiDevice (*m) || ! m->isEnabled())
            continue;

        if (! isFollowing (m->getDeviceID()))
            continue;

        if (auto* inst = findInstance (m->getDeviceID()))
        {
            if (! te::isOnTargetTrack (*inst, *t, 0))
            {
                const bool wasArmed = [&]
                {
                    for (auto id : inst->getTargets())
                        if (inst->isRecordingEnabled (id))
                            return true;
                    return false;
                }();

                [[maybe_unused]] auto res = inst->setTarget (t->itemID, true, nullptr, 0);

                if (wasArmed)
                    inst->setRecordingEnabled (t->itemID, true);

                changed = true;
            }
        }
    }

    if (changed)
        edit->restartPlayback();
}

void InputRouter::setAudioInput (te::AudioTrack& track, const String& deviceID)
{
    if (edit == nullptr)
        return;

    edit->getTransport().ensureContextAllocated();

    // remove any existing wave inputs from this track
    for (auto* inst : edit->getAllInputDevices())
        if (inst->getInputDevice().getDeviceType() == te::InputDevice::waveDevice
             && te::isOnTargetTrack (*inst, track, 0))
            [[maybe_unused]] auto r = inst->removeTarget (track.itemID, nullptr);

    if (deviceID.isNotEmpty())
        if (auto* inst = findInstance (deviceID))
            [[maybe_unused]] auto r = inst->setTarget (track.itemID, false, nullptr, 0);

    edit->restartPlayback();
}

String InputRouter::getAudioInput (te::AudioTrack& track)
{
    if (edit == nullptr)
        return {};

    for (auto* inst : edit->getAllInputDevices())
        if (inst->getInputDevice().getDeviceType() == te::InputDevice::waveDevice
             && te::isOnTargetTrack (*inst, track, 0))
            return inst->getInputDevice().getDeviceID();

    return {};
}

void InputRouter::setAudioMonitoring (te::AudioTrack& track, bool on)
{
    if (edit == nullptr)
        return;

    for (auto* inst : edit->getAllInputDevices())
        if (inst->getInputDevice().getDeviceType() == te::InputDevice::waveDevice
             && te::isOnTargetTrack (*inst, track, 0))
            inst->getInputDevice().setMonitorMode (on ? te::InputDevice::MonitorMode::on
                                                      : te::InputDevice::MonitorMode::automatic);
}

bool InputRouter::getAudioMonitoring (te::AudioTrack& track)
{
    if (edit == nullptr)
        return false;

    for (auto* inst : edit->getAllInputDevices())
        if (inst->getInputDevice().getDeviceType() == te::InputDevice::waveDevice
             && te::isOnTargetTrack (*inst, track, 0))
            return inst->getInputDevice().getMonitorMode() == te::InputDevice::MonitorMode::on;

    return false;
}

StringArray InputRouter::getDevicesTargeting (te::AudioTrack& track, bool midi)
{
    StringArray names;

    if (edit == nullptr)
        return names;

    for (auto* inst : edit->getAllInputDevices())
    {
        auto& dev = inst->getInputDevice();
        auto type = dev.getDeviceType();

        if (midi && type != te::InputDevice::physicalMidiDevice && type != te::InputDevice::virtualMidiDevice)
            continue;

        if (! midi && type != te::InputDevice::waveDevice)
            continue;

        if (te::isOnTargetTrack (*inst, track, 0))
            names.add (dev.getAliasOrName());
    }

    return names;
}

void InputRouter::armTrack (te::AudioTrack& track, bool arm)
{
    if (edit == nullptr)
        return;

    edit->getTransport().ensureContextAllocated();

    for (auto* inst : edit->getAllInputDevices())
        if (te::isOnTargetTrack (*inst, track, 0))
            inst->setRecordingEnabled (track.itemID, arm);
}

bool InputRouter::isTrackArmed (te::AudioTrack& track)
{
    if (edit == nullptr)
        return false;

    for (auto* inst : edit->getAllInputDevices())
        if (te::isOnTargetTrack (*inst, track, 0) && inst->isRecordingEnabled (track.itemID))
            return true;

    return false;
}

//==============================================================================
Session::Session (te::Engine& e)
    : engine (e), inputRouter (e)
{
    selectionManager.addChangeListener (this);
    startTimer (60 * 1000);
}

Session::~Session()
{
    stopTimer();
    selectionManager.removeChangeListener (this);
    selectionManager.deselectAll();

    if (edit != nullptr)
        edit->getTransport().stop (false, true);

    inputRouter.attachToEdit (nullptr);
    view.reset();
    edit.reset();
}

String Session::getProjectName() const
{
    return projectFile.getFileNameWithoutExtension();
}

bool Session::hasUnsavedChanges() const
{
    return edit != nullptr && edit->hasChangedSinceSaved();
}

File Session::createUntitledProjectFile (const String& baseName)
{
    auto root = getDefaultProjectsDir();
    auto name = baseName;

    for (int i = 1; i < 10000; ++i)
    {
        name = i == 1 ? baseName : baseName + " " + String (i);
        if (! root.getChildFile (name).exists())
            break;
    }

    auto dir = root.getChildFile (name);
    dir.createDirectory();
    return dir.getChildFile (name + projectExtension());
}

std::unique_ptr<te::Edit> Session::createBlankEdit (const File& file)
{
    auto newEdit = te::createEmptyEdit (engine, file);

    // createEmptyEdit gives us one plain track; we'd rather build our own
    for (auto t : te::getAudioTracks (*newEdit))
        newEdit->deleteTrack (t);

    newEdit->ensureMasterTrack();
    newEdit->tempoSequence.getTempo (0)->setBpm (120.0);
    newEdit->clickTrackEnabled = false;
    newEdit->setCountInMode (te::Edit::CountIn::none);
    return newEdit;
}

void Session::newProject (bool withStarterTracks)
{
    auto file = createUntitledProjectFile();
    auto newEdit = createBlankEdit (file);
    adoptEdit (std::move (newEdit), file, true);

    if (withStarterTracks)
        addStarterTracks();

    edit->getUndoManager().clearUndoHistory();
    save();
}

void Session::addStarterTracks()
{
    auto drums = addTrackWithInstrument (InstrumentSpec::drums(), "Drums");
    addTrackWithInstrument (InstrumentSpec::gm (0), "Grand Piano");
    addTrackWithInstrument (InstrumentSpec::synth ("Sub Bass"), "Bass");
    addTrack (TrackKind::audio, "Audio 1");

    // the pad controller (if any) gets pinned to the drums; keyboards follow selection
    for (auto& d : inputRouter.getMidiDevices())
    {
        auto n = d.name.toLowerCase();
        if (drums != nullptr && (n.contains ("mpd") || n.contains ("pad") || n.contains ("drum") || n.contains ("mpc")))
            inputRouter.pinDevice (d.id, drums);
    }

    if (auto first = te::getAudioTracks (*edit)[1])
        selectTrack (first);
}

bool Session::openProject (const File& f)
{
    if (! f.existsAsFile())
        return false;

    auto loaded = te::loadEditFromFile (engine, f);
    if (loaded == nullptr)
        return false;

    adoptEdit (std::move (loaded), f, false);
    addRecentFile (f);

    // offer the autosave if it's newer
    auto autosave = getAutosaveFile();
    if (autosave.existsAsFile() && autosave.getLastModificationTime() > f.getLastModificationTime())
    {
        auto options = MessageBoxOptions()
                           .withIconType (MessageBoxIconType::QuestionIcon)
                           .withTitle ("Recover unsaved work?")
                           .withMessage ("Lodestone found an autosave of \"" + getProjectName()
                                          + "\" that is newer than the saved project. Recover it?")
                           .withButton ("Recover", 1)
                           .withButton ("Ignore", 0);

        AlertWindow::showAsync (options, [this, autosave, f] (int result)
        {
            if (result == 1)
                if (auto recovered = te::loadEditFromFile (engine, autosave))
                {
                    recovered->editFileRetriever = [f] { return f; };
                    adoptEdit (std::move (recovered), f, false);
                    status ("Recovered autosave - save to keep it");
                }
        });
    }

    return true;
}

void Session::adoptEdit (std::unique_ptr<te::Edit> newEdit, const File& file, bool isUntitled)
{
    selectionManager.deselectAll();

    if (edit != nullptr && onBeforeEditReplaced)
        onBeforeEditReplaced();

    if (edit != nullptr)
        edit->getTransport().stop (false, true);

    inputRouter.attachToEdit (nullptr);
    view.reset();
    edit = std::move (newEdit);
    projectFile = file;
    untitled = isUntitled;

    edit->editFileRetriever = [file] { return file; };
    edit->playInStopEnabled = true;
    edit->getTransport().ensureContextAllocated();
    view = std::make_unique<ViewState> (*edit);

    for (auto t : te::getAudioTracks (*edit))
        if (! t->state.hasProperty (kindProp))
            setTrackKind (*t, getInstrument (*t) != nullptr ? (getDrumMachine (*t) != nullptr ? TrackKind::drums : TrackKind::instrument)
                                                            : (t->containsAnyMIDIClips() ? TrackKind::instrument : TrackKind::audio));

    editReplaced();
}

void Session::editReplaced()
{
    inputRouter.attachToEdit (edit.get());
    inputRouter.enableAllDevices();
    colourCounter = te::getAudioTracks (*edit).size();
    sendSynchronousChangeMessage();
}

bool Session::save()
{
    if (edit == nullptr)
        return false;

    projectFile.getParentDirectory().createDirectory();
    te::EditFileOperations ops (*edit);
    auto ok = ops.writeToFile (projectFile, false);

    if (ok)
    {
        edit->resetChangedStatus();
        getAutosaveFile().deleteFile();

        if (! untitled)
            addRecentFile (projectFile);

        status ("Saved " + projectFile.getFileName());
    }
    else
    {
        status ("Couldn't save to " + projectFile.getFullPathName());
    }

    sendChangeMessage();
    return ok;
}

bool Session::saveAs (const File& requested)
{
    if (edit == nullptr)
        return false;

    auto f = requested.withFileExtension (projectExtension());

    // every project gets its own folder (recordings and samples land next to it)
    if (f.getParentDirectory().getFileName() != f.getFileNameWithoutExtension())
    {
        auto dir = f.getParentDirectory().getChildFile (f.getFileNameWithoutExtension());
        dir.createDirectory();
        f = dir.getChildFile (f.getFileName());
    }

    projectFile = f;
    untitled = false;
    edit->editFileRetriever = [f] { return f; };
    return save();
}

File Session::getAutosaveFile() const
{
    return projectFile.getSiblingFile ("." + projectFile.getFileName() + ".autosave");
}

void Session::timerCallback()
{
    if (edit != nullptr && edit->hasChangedSinceSaved() && ! edit->getTransport().isRecording())
    {
        te::EditFileOperations ops (*edit);
        ops.writeToFile (getAutosaveFile(), false);
    }
}

StringArray Session::getRecentFiles()
{
    StringArray list;
    list.addTokens (engine.getPropertyStorage().getPropertiesFile().getValue ("recentFiles"), "\n", {});
    list.removeEmptyStrings();

    StringArray existing;
    for (auto& s : list)
        if (File (s).existsAsFile())
            existing.add (s);

    return existing;
}

void Session::addRecentFile (const File& f)
{
    auto list = getRecentFiles();
    list.removeString (f.getFullPathName());
    list.insert (0, f.getFullPathName());

    while (list.size() > 12)
        list.remove (list.size() - 1);

    engine.getPropertyStorage().getPropertiesFile().setValue ("recentFiles", list.joinIntoString ("\n"));
}

//==============================================================================
String Session::makeUniqueTrackName (const String& base)
{
    StringArray names;
    for (auto t : te::getAudioTracks (*edit))
        names.add (t->getName());

    if (! names.contains (base))
        return base;

    for (int i = 2;; ++i)
        if (! names.contains (base + " " + String (i)))
            return base + " " + String (i);
}

Colour Session::nextTrackColour()
{
    return Col::trackPalette (colourCounter++);
}

te::AudioTrack* Session::addTrack (TrackKind kind, const String& name, te::Track* after)
{
    if (edit == nullptr)
        return nullptr;

    te::TrackInsertPoint ip = after != nullptr ? te::TrackInsertPoint (*after, false)
                                               : te::TrackInsertPoint::getEndOfTracks (*edit);

    auto track = edit->insertNewAudioTrack (ip, nullptr, true);
    if (track == nullptr)
        return nullptr;

    setTrackKind (*track, kind);
    track->setColour (nextTrackColour());

    auto defaultName = kind == TrackKind::drums ? "Drums" : (kind == TrackKind::audio ? "Audio" : "Instrument");
    track->setName (makeUniqueTrackName (name.isNotEmpty() ? name : String (defaultName)));

    return track.get();
}

te::AudioTrack* Session::addTrackWithInstrument (const InstrumentSpec& spec, const String& name, te::Track* after)
{
    auto kind = spec.type == InstrumentSpec::Type::drums || (spec.type == InstrumentSpec::Type::soundfont && spec.bank == 128)
                    ? TrackKind::drums : TrackKind::instrument;

    auto trackName = name;
    if (trackName.isEmpty())
    {
        switch (spec.type)
        {
            case InstrumentSpec::Type::soundfont:   trackName = spec.bank == 128 ? String ("Drums") : SoundFonts::gmProgramName (spec.program); break;
            case InstrumentSpec::Type::synth:       trackName = spec.preset; break;
            case InstrumentSpec::Type::drums:       trackName = "Drums"; break;
            case InstrumentSpec::Type::sampler:     trackName = spec.file.getFileNameWithoutExtension(); break;
            case InstrumentSpec::Type::external:    trackName = spec.description.name; break;
            case InstrumentSpec::Type::none:        break;
        }
    }

    auto track = addTrack (kind, trackName, after);
    if (track != nullptr)
        setInstrument (*track, spec);

    return track;
}

te::Plugin* Session::getInstrument (te::AudioTrack& t)
{
    for (auto p : t.pluginList)
        if (p->isSynth())
            return p;

    return nullptr;
}

DrumMachinePlugin* Session::getDrumMachine (te::AudioTrack& t)
{
    for (auto p : t.pluginList)
        if (auto d = dynamic_cast<DrumMachinePlugin*> (p))
            return d;

    return nullptr;
}

SoundFontPlugin* Session::getSoundFont (te::AudioTrack& t)
{
    for (auto p : t.pluginList)
        if (auto s = dynamic_cast<SoundFontPlugin*> (p))
            return s;

    return nullptr;
}

te::Plugin::Ptr Session::createPlugin (const String& xmlType, const PluginDescription& desc)
{
    if (edit == nullptr)
        return {};

    return edit->getPluginCache().createNewPlugin (xmlType, desc);
}

te::Plugin* Session::setInstrument (te::AudioTrack& track, const InstrumentSpec& spec)
{
    if (auto old = getInstrument (track))
        old->deleteFromParent();

    te::Plugin::Ptr plugin;

    switch (spec.type)
    {
        case InstrumentSpec::Type::drums:
        {
            plugin = createPlugin (DrumMachinePlugin::xmlTypeName);
            if (auto dm = dynamic_cast<DrumMachinePlugin*> (plugin.get()))
                if (spec.file.isDirectory())
                    dm->loadKit (spec.file);
            setTrackKind (track, TrackKind::drums);
            break;
        }

        case InstrumentSpec::Type::soundfont:
        {
            plugin = createPlugin (SoundFontPlugin::xmlTypeName);
            if (auto sf = dynamic_cast<SoundFontPlugin*> (plugin.get()))
            {
                if (spec.file.existsAsFile())
                    sf->setSoundFont (spec.file);
                sf->setProgram (spec.bank, spec.program);
            }
            setTrackKind (track, spec.bank == 128 ? TrackKind::drums : TrackKind::instrument);
            break;
        }

        case InstrumentSpec::Type::synth:
        {
            plugin = createPlugin (te::FourOscPlugin::xmlTypeName);
            if (plugin != nullptr)
                SynthPresets::apply (*plugin, spec.preset.isNotEmpty() ? spec.preset : String ("Saw Lead"));
            setTrackKind (track, TrackKind::instrument);
            break;
        }

        case InstrumentSpec::Type::sampler:
        {
            plugin = createPlugin (te::SamplerPlugin::xmlTypeName);
            if (auto sp = dynamic_cast<te::SamplerPlugin*> (plugin.get()))
            {
                if (spec.file.existsAsFile())
                {
                    auto err = sp->addSound (spec.file.getFullPathName(), spec.file.getFileNameWithoutExtension(), 0.0, 0.0, 0.0f);
                    if (err.isEmpty())
                        sp->setSoundParams (0, spec.rootNote, 0, 127);
                }
            }
            setTrackKind (track, TrackKind::instrument);
            break;
        }

        case InstrumentSpec::Type::external:
        {
            plugin = createPlugin (te::ExternalPlugin::xmlTypeName, spec.description);
            setTrackKind (track, TrackKind::instrument);
            break;
        }

        case InstrumentSpec::Type::none:
            setTrackKind (track, TrackKind::audio);
            return nullptr;
    }

    if (plugin == nullptr)
        return nullptr;

    track.pluginList.insertPlugin (plugin, 0, nullptr);
    return plugin.get();
}

int Session::getFirstEffectIndex (te::AudioTrack& t)
{
    int i = 0;
    for (auto p : t.pluginList)
    {
        if (! p->isSynth())
            return i;
        ++i;
    }
    return i;
}

int Session::getVolumePluginIndex (te::AudioTrack& t)
{
    int i = 0;
    for (auto p : t.pluginList)
    {
        if (dynamic_cast<te::VolumeAndPanPlugin*> (p) != nullptr)
            return i;
        ++i;
    }
    return t.pluginList.size();
}

te::Plugin::Ptr Session::insertEffect (te::AudioTrack& track, te::Plugin::Ptr plugin, int index)
{
    if (plugin == nullptr)
        return {};

    if (plugin->isSynth())
    {
        if (auto old = getInstrument (track))
            old->deleteFromParent();

        track.pluginList.insertPlugin (plugin, 0, nullptr);

        if (getTrackKind (track) == TrackKind::audio)
            setTrackKind (track, TrackKind::instrument);

        return plugin;
    }

    if (index < 0)
        index = getVolumePluginIndex (track);   // effects go before the fader

    track.pluginList.insertPlugin (plugin, index, nullptr);
    return plugin;
}

void Session::deleteTrack (te::AudioTrack& track)
{
    selectionManager.deselectAll();
    edit->deleteTrack (&track);
}

te::AudioTrack* Session::duplicateTrack (te::AudioTrack& track)
{
    auto copy = edit->copyTrack (&track, te::TrackInsertPoint (track, false));

    if (auto at = dynamic_cast<te::AudioTrack*> (copy.get()))
    {
        at->setName (makeUniqueTrackName (track.getName()));
        return at;
    }

    return nullptr;
}

te::AudioTrack* Session::getSelectedTrack()
{
    if (auto t = selectionManager.getFirstItemOfType<te::AudioTrack>())
        return t;

    if (auto c = selectionManager.getFirstItemOfType<te::Clip>())
        return dynamic_cast<te::AudioTrack*> (c->getTrack());

    return inputRouter.getFollowTrack();
}

void Session::selectTrack (te::AudioTrack* t)
{
    if (t == nullptr)
        selectionManager.deselectAll();
    else
        selectionManager.selectOnly (t);
}

te::Clip* Session::getSelectedClip()
{
    return selectionManager.getFirstItemOfType<te::Clip>();
}

Array<te::Clip*> Session::getSelectedClips()
{
    Array<te::Clip*> clips;
    for (auto c : selectionManager.getItemsOfType<te::Clip>())
        clips.add (c);
    return clips;
}

void Session::changeListenerCallback (ChangeBroadcaster*)
{
    if (auto t = getSelectedTrack())
        if (t != inputRouter.getFollowTrack())
            inputRouter.selectedTrackChanged (t);
}

te::MidiClip* Session::createMidiClip (te::AudioTrack& track, double startBeat, double lengthBeats, bool select)
{
    te::TimeRange range (beatToTime (*edit, startBeat), beatToTime (*edit, startBeat + lengthBeats));
    auto clip = track.insertMIDIClip (range, select ? &selectionManager : nullptr);

    if (clip != nullptr)
    {
        clip->setName (track.getName());
        clip->setColour (track.getColour());
    }

    return clip.get();
}

te::WaveAudioClip* Session::addAudioFile (te::AudioTrack& track, const File& file, double startBeat)
{
    // Tracktion stores media paths relative to the project file - but only resolves them
    // correctly if that file already exists when the clip is made, so make sure it does
    if (! projectFile.existsAsFile())
        save();

    te::AudioFile af (engine, file);
    if (! af.isValid())
        return nullptr;

    auto start = beatToTime (*edit, startBeat);
    auto clip = track.insertWaveClip (file.getFileNameWithoutExtension(), file,
                                      { { start, start + TD (af.getLength()) }, {} }, false);

    if (clip != nullptr)
        clip->setColour (track.getColour());

    return clip.get();
}

//==============================================================================
void Session::togglePlay()
{
    auto& tc = edit->getTransport();

    if (tc.isPlaying())
        tc.stop (false, false);
    else
        tc.play (false);
}

void Session::stop()
{
    auto& tc = edit->getTransport();

    if (tc.isPlaying() || tc.isRecording())
        tc.stop (false, false);
    else
        tc.setPosition (te::TimePosition());
}

void Session::toggleRecord()
{
    auto& tc = edit->getTransport();

    if (tc.isRecording())
    {
        tc.stop (false, false);
        return;
    }

    // nothing armed? arm the selected track, like GarageBand does
    bool anyArmed = false;
    for (auto t : te::getAudioTracks (*edit))
        if (inputRouter.isTrackArmed (*t))
            anyArmed = true;

    if (! anyArmed)
        if (auto t = getSelectedTrack())
        {
            if (getTrackKind (*t) == TrackKind::audio && inputRouter.getAudioInput (*t).isEmpty())
            {
                auto audioIns = inputRouter.getAudioDevices();
                if (! audioIns.isEmpty())
                    inputRouter.setAudioInput (*t, audioIns.getFirst().id);
            }

            inputRouter.armTrack (*t, true);
        }

    tc.record (false, false);
}

void Session::goToStart()
{
    edit->getTransport().setPosition (te::TimePosition());
}

void Session::setTempo (double bpm)
{
    bpm = jlimit (20.0, 400.0, bpm);
    edit->tempoSequence.getTempo (0)->setBpm (bpm);
}

double Session::getTempo()
{
    return edit->tempoSequence.getTempo (0)->getBpm();
}

void Session::setTimeSignature (int num, int den)
{
    if (auto ts = edit->tempoSequence.getTimeSig (0))
    {
        ts->numerator = jlimit (1, 32, num);
        ts->denominator = jlimit (1, 32, den);
    }
}

void Session::tapTempo()
{
    auto now = Time::getMillisecondCounterHiRes() / 1000.0;

    if (! tapTimes.isEmpty() && now - tapTimes.getLast() > 2.0)
        tapTimes.clear();

    tapTimes.add (now);
    while (tapTimes.size() > 8)
        tapTimes.remove (0);

    if (tapTimes.size() >= 3)
    {
        auto avg = (tapTimes.getLast() - tapTimes.getFirst()) / (tapTimes.size() - 1);
        if (avg > 0.0)
        {
            setTempo (std::round (60.0 / avg * 10.0) / 10.0);
            status ("Tap tempo: " + String (getTempo(), 1) + " BPM");
        }
    }
}

double Session::getPlayheadBeat()
{
    return timeToBeat (*edit, edit->getTransport().getPosition());
}

void Session::setPlayheadBeat (double b)
{
    edit->getTransport().setPosition (beatToTime (*edit, jmax (0.0, b)));
}

} // namespace lode
