/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    A friendly open-source DAW for Linux, built on Tracktion Engine + JUCE.
*/
#include "MainWindow.h"
#include "InstrumentPanel.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"
#include "ProjectIO.h"

namespace lode
{
    class LodeEngineBehaviour : public te::EngineBehaviour
    {
    public:
        // a crashing plugin during a scan takes down a child process, not the DAW
        bool canScanPluginsOutOfProcess() override     { return true; }
    };

    /** JUCE's default plugin folders miss Debian's multiarch locations and LADSPA_PATH, so
        add any of those that exist to the per-format scan paths (keeping the user's own edits). */
    static void seedPluginSearchPaths (te::Engine& engine)
    {
        auto& props = engine.getPropertyStorage().getPropertiesFile();
        auto home = juce::File::getSpecialLocation (juce::File::userHomeDirectory);

        for (auto* format : engine.getPluginManager().pluginFormatManager.getFormats())
        {
            auto key = "lastPluginScanPath_" + format->getName();
            auto path = juce::FileSearchPath (props.getValue (key, format->getDefaultLocationsToSearch().toString()));
            auto addDir = [&path] (const juce::File& d) { if (d.isDirectory()) path.addIfNotAlreadyThere (d); };
            auto addEnv = [&addDir] (const char* var)
            {
                if (auto* v = std::getenv (var))
                    for (auto& p : juce::StringArray::fromTokens (v, ":", ""))
                        if (p.isNotEmpty())
                            addDir (juce::File (p));
            };

            auto name = format->getName();
            if (name == "VST3")
            {
                addDir (juce::File ("/usr/lib/x86_64-linux-gnu/vst3"));
                addDir (juce::File ("/usr/lib/aarch64-linux-gnu/vst3"));
                addDir (home.getChildFile (".vst3"));
            }
            else if (name == "LV2")
            {
                addDir (juce::File ("/usr/lib/x86_64-linux-gnu/lv2"));
                addDir (juce::File ("/usr/lib/aarch64-linux-gnu/lv2"));
                addEnv ("LV2_PATH");
            }
            else if (name == "LADSPA")
            {
                addDir (juce::File ("/usr/lib/x86_64-linux-gnu/ladspa"));
                addDir (juce::File ("/usr/lib/aarch64-linux-gnu/ladspa"));
                addEnv ("LADSPA_PATH");
            }

            props.setValue (key, path.toString());
        }
    }

    static juce::File fileFromCommandLine (const juce::StringArray& args)
    {
        for (auto arg : args)
        {
            arg = arg.unquoted();

            if (arg.startsWith ("file://"))
                arg = juce::URL (arg).getLocalFile().getFullPathName();

            if (arg.isEmpty() || arg.startsWith ("-"))
                continue;

            auto f = juce::File::isAbsolutePath (arg) ? juce::File (arg)
                                                      : juce::File::getCurrentWorkingDirectory().getChildFile (arg);
            if (f.exists())
                return f;
        }

        return {};
    }
}

//==============================================================================
class LodestoneApplication : public juce::JUCEApplication
{
public:
    const juce::String getApplicationName() override       { return "Lodestone"; }
    const juce::String getApplicationVersion() override    { return LODESTONE_VERSION; }

    // JUCE can't forward a second launch's file to the first instance on Linux,
    // so each launch is its own window (PipeWire/JACK let them share the audio device).
    bool moreThanOneInstanceAllowed() override             { return true; }

    void initialise (const juce::String& commandLine) override
    {
        if (te::PluginManager::startChildProcessPluginScan (commandLine))
            return;

        // the raw argv: file names with spaces stay in one piece
        auto args = juce::JUCEApplicationBase::getCommandLineParameterArray();

        if (args.contains ("--version"))
        {
            std::cout << "Lodestone " << LODESTONE_VERSION << std::endl;
            quit();
            return;
        }

        if (args.contains ("--help") || args.contains ("-h"))
        {
            std::cout << "Lodestone " << LODESTONE_VERSION << " - a friendly open-source DAW\n\n"
                         "Usage:\n"
                         "  lodestone [project]              open a .lodestone project, or import LMMS (.mmp/.mmpz),\n"
                         "                                   FL Studio (.flp), GarageBand (.band), Logic (.logicx),\n"
                         "                                   DAWproject or MIDI files\n"
                         "  lodestone --render IN OUT.wav    open/import IN and render it to OUT (.wav/.flac/.ogg)\n"
                         "  lodestone --scan-plugins         find VST3/LV2/LADSPA plugins and list them\n"
                         "  lodestone --version\n";
            quit();
            return;
        }

        juce::LookAndFeel::setDefaultLookAndFeel (&lookAndFeel);

        auto ui = std::make_unique<lode::LodeUIBehaviour>();
        uiBehaviour = ui.get();

        engine = std::make_unique<te::Engine> (std::make_unique<te::PropertyStorage> ("Lodestone"),
                                               std::move (ui),
                                               std::make_unique<lode::LodeEngineBehaviour>());

        engine->getPluginManager().initialiseAirWindows();      // TE registers the 186 Airwindows only on request
        engine->getPluginManager().createBuiltInType<lode::DrumMachinePlugin>();
        engine->getPluginManager().createBuiltInType<lode::SoundFontPlugin>();

        session = std::make_unique<lode::Session> (*engine);
        lode::seedPluginSearchPaths (*engine);

        if (auto r = args.indexOf ("--render"); r >= 0)
        {
            renderAndQuit (args[r + 1], args[r + 2]);
            return;
        }

        if (args.contains ("--scan-plugins"))
        {
            scanPluginsAndQuit();
            return;
        }

        auto file = lode::fileFromCommandLine (args);

        if (file.getFileExtension() == ".lodestone" && session->openProject (file))
            file = juce::File();

        if (session->getEdit() == nullptr)
            session->newProject();

        window = std::make_unique<lode::MainWindow> (*session, *uiBehaviour);

        if (file != juce::File())
            window->getMainComponent().openFile (file);
    }

    void shutdown() override
    {
        window.reset();
        session.reset();
        engine.reset();
        juce::LookAndFeel::setDefaultLookAndFeel (nullptr);
    }

    void systemRequestedQuit() override
    {
        if (window == nullptr || session == nullptr)
        {
            quit();
            return;
        }

        window->getMainComponent().confirmCloseIfUnsaved ([] { juce::JUCEApplication::getInstance()->quit(); });
    }

    void anotherInstanceStarted (const juce::String& commandLine) override
    {
        if (window != nullptr)
            if (auto f = lode::fileFromCommandLine (juce::StringArray::fromTokens (commandLine, true)); f.exists())
                window->getMainComponent().openFile (f);
    }

private:
    void renderAndQuit (const juce::String& inPath, const juce::String& outPath)
    {
        lode::headlessMode() = true;
        auto cwd = juce::File::getCurrentWorkingDirectory();
        auto in = juce::File::isAbsolutePath (inPath) ? juce::File (inPath) : cwd.getChildFile (inPath);
        auto out = juce::File::isAbsolutePath (outPath) ? juce::File (outPath) : cwd.getChildFile (outPath);

        if (! in.exists() || outPath.isEmpty())
        {
            std::cerr << "usage: lodestone --render IN OUT.wav" << std::endl;
            setApplicationReturnValue (2);
            quit();
            return;
        }

        if (in.getFileExtension() == ".lodestone")
            session->openProject (in);
        else
            lode::ProjectIO::openAnyFile (*session, in);

        bool ok = false;
        if (session->getEdit() != nullptr)
        {
            lode::ProjectIO::AudioExportOptions o;
            auto ext = out.getFileExtension().toLowerCase();
            o.format = ext == ".flac" ? "flac" : (ext == ".ogg" ? "ogg" : "wav");
            ok = lode::ProjectIO::exportMixdown (*session, out, o);
            std::cout << (ok ? "Rendered " : "Render failed: ") << out.getFullPathName()
                      << "  (" << session->getProjectFile().getFullPathName() << ")" << std::endl;
        }

        setApplicationReturnValue (ok ? 0 : 1);
        quit();
    }

    void scanPluginsAndQuit()
    {
        lode::headlessMode() = true;
        auto& pm = engine->getPluginManager();
        auto& list = pm.knownPluginList;
        auto pedal = engine->getPropertyStorage().getAppPrefsFolder().getChildFile ("PluginScanDeadMansPedal");

        for (auto* format : pm.pluginFormatManager.getFormats())
        {
            auto paths = juce::PluginListComponent::getLastSearchPath (engine->getPropertyStorage().getPropertiesFile(), *format);
            std::cout << "Scanning " << format->getName() << " (" << paths.toString() << ")" << std::endl;
            juce::PluginDirectoryScanner scanner (list, *format, paths, true, pedal, true);
            juce::String name;
            while (scanner.scanNextFile (true, name)) {}

            for (auto& f : scanner.getFailedFiles())
                std::cout << "  failed: " << f << std::endl;
        }

        for (auto& t : list.getTypes())
            std::cout << "  " << t.pluginFormatName << "  " << t.name << (t.isInstrument ? "  [instrument]" : "")
                      << "  (" << t.manufacturerName << ")" << std::endl;

        std::cout << list.getNumTypes() << " plugins known" << std::endl;
        engine->getPropertyStorage().setXmlProperty (te::SettingID::knownPluginList64, *list.createXml());
        quit();
    }

    lode::LodeLookAndFeel lookAndFeel;
    std::unique_ptr<te::Engine> engine;
    lode::LodeUIBehaviour* uiBehaviour = nullptr;
    std::unique_ptr<lode::Session> session;
    std::unique_ptr<lode::MainWindow> window;
};

START_JUCE_APPLICATION (LodestoneApplication)
