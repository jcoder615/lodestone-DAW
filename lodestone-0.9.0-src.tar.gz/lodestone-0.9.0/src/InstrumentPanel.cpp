/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "InstrumentPanel.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"
#include "Browser.h"
#include "AirWindowsList.h"
#include "ProjectIO.h"

namespace lode
{
using namespace juce;

//==============================================================================
// ParamKnob / PropertyKnob
//==============================================================================
ParamKnob::ParamKnob (te::AutomatableParameter::Ptr p, const String& l, Colour c)
    : param (p), label (l.isNotEmpty() ? l : p->getParameterName())
{
    addAndMakeVisible (slider);
    slider.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    slider.setRange (0.0, 1.0);
    slider.setColour (Slider::rotarySliderFillColourId, c);
    slider.setValue (param->getCurrentNormalisedValue(), dontSendNotification);

    if (auto def = param->getDefaultValue())
    {
        auto r = param->getValueRange();
        slider.setDoubleClickReturnValue (true, r.getLength() > 0 ? (*def - r.getStart()) / r.getLength() : 0.0);
    }

    slider.onDragStart = [this] { param->getEdit().getUndoManager().beginNewTransaction (label); };
    slider.onValueChange = [this]
    {
        param->setNormalisedParameter ((float) slider.getValue(), sendNotification);
        repaint();
    };

    slider.setPopupDisplayEnabled (true, true, nullptr);
    slider.textFromValueFunction = [this] (double) { return param->getCurrentValueAsStringWithLabel(); };
    startTimerHz (15);
}

ParamKnob::~ParamKnob() = default;

void ParamKnob::timerCallback()
{
    if (! slider.isMouseButtonDown())
    {
        auto v = param->getCurrentNormalisedValue();
        if (std::abs (v - slider.getValue()) > 0.0005)
        {
            slider.setValue (v, dontSendNotification);
            repaint();
        }
    }
}

void ParamKnob::resized()
{
    auto r = getLocalBounds();
    r.removeFromBottom (28);
    slider.setBounds (r.reduced (2));
}

void ParamKnob::paint (Graphics& g)
{
    auto r = getLocalBounds().removeFromBottom (28);
    g.setColour (Col::textDim);
    g.setFont (LodeLookAndFeel::font (11.0f));
    g.drawFittedText (label, r.removeFromTop (14), Justification::centred, 1, 0.7f);
    g.setColour (Col::text);
    g.drawFittedText (param->getCurrentValueAsStringWithLabel(), r, Justification::centred, 1, 0.7f);
}

PropertyKnob::PropertyKnob (const String& l, double min, double max, double def,
                            std::function<double()> g, std::function<void (double)> s,
                            std::function<String (double)> f)
    : label (l), getter (std::move (g)), setter (std::move (s)), formatter (std::move (f))
{
    addAndMakeVisible (slider);
    slider.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    slider.setRange (min, max);
    slider.setDoubleClickReturnValue (true, def);
    slider.setValue (getter(), dontSendNotification);
    slider.onValueChange = [this] { setter (slider.getValue()); repaint(); };
}

void PropertyKnob::refresh()
{
    slider.setValue (getter(), dontSendNotification);
    repaint();
}

void PropertyKnob::resized()
{
    auto r = getLocalBounds();
    r.removeFromBottom (28);
    slider.setBounds (r.reduced (2));
}

void PropertyKnob::paint (Graphics& g)
{
    auto r = getLocalBounds().removeFromBottom (28);
    g.setColour (Col::textDim);
    g.setFont (LodeLookAndFeel::font (11.0f));
    g.drawFittedText (label, r.removeFromTop (14), Justification::centred, 1, 0.7f);
    g.setColour (Col::text);
    auto v = slider.getValue();
    g.drawFittedText (formatter ? formatter (v) : String (v, 2), r, Justification::centred, 1, 0.7f);
}

//==============================================================================
// GenericPluginEditor
//==============================================================================
GenericPluginEditor::GenericPluginEditor (te::Plugin& p)
    : plugin (&p)
{
    addAndMakeVisible (viewport);
    viewport.setViewedComponent (&content, false);
    viewport.setScrollBarsShown (true, false);

    int i = 0;
    for (auto param : p.getAutomatableParameters())
    {
        if (param == nullptr)
            continue;

        auto k = knobs.add (new ParamKnob (param, {}, Col::trackPalette (i++ / 4)));
        content.addAndMakeVisible (k);

        if (knobs.size() >= 256)
            break;
    }
}

int GenericPluginEditor::getIdealHeight (int width) const
{
    auto cols = jmax (1, (width - 20) / 84);
    auto rows = (knobs.size() + cols - 1) / cols;
    return jmax (120, rows * 96 + 16);
}

void GenericPluginEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    if (knobs.isEmpty())
    {
        g.setColour (Col::textDim);
        g.drawText ("This device has no adjustable parameters.", getLocalBounds(), Justification::centred);
    }
}

void GenericPluginEditor::resized()
{
    viewport.setBounds (getLocalBounds());
    auto w = getWidth() - viewport.getScrollBarThickness();
    auto cols = jmax (1, (w - 20) / 84);
    content.setSize (w, getIdealHeight (getWidth()));

    for (int i = 0; i < knobs.size(); ++i)
        knobs[i]->setBounds (10 + (i % cols) * 84, 8 + (i / cols) * 96, 80, 92);
}

//==============================================================================
// SampleRecorder
//==============================================================================
SampleRecorder::SampleRecorder (te::Engine& e) : engine (e)
{
    engine.getDeviceManager().deviceManager.addAudioCallback (this);
}

SampleRecorder::~SampleRecorder()
{
    engine.getDeviceManager().deviceManager.removeAudioCallback (this);
}

void SampleRecorder::audioDeviceAboutToStart (AudioIODevice* d)
{
    sampleRate = d != nullptr ? d->getCurrentSampleRate() : 44100.0;
}

void SampleRecorder::start()
{
    recording = false;
    buffer.setSize (2, (int) (sampleRate * 30.0));
    buffer.clear();
    writePos = 0;
    recording = true;
}

void SampleRecorder::audioDeviceIOCallbackWithContext (const float* const* in, int numIn, float* const* out, int numOut,
                                                       int numSamples, const AudioIODeviceCallbackContext&)
{
    for (int ch = 0; ch < numOut; ++ch)
        if (out[ch] != nullptr)
            FloatVectorOperations::clear (out[ch], numSamples);

    if (! recording.load() || numIn == 0)
        return;

    auto pos = writePos.load();
    auto toCopy = jmin (numSamples, buffer.getNumSamples() - pos);
    float peak = 0.0f;

    if (toCopy > 0)
    {
        for (int ch = 0; ch < 2; ++ch)
        {
            auto src = in[jmin (ch, numIn - 1)];
            if (src != nullptr)
            {
                buffer.copyFrom (ch, pos, src, toCopy);
                peak = jmax (peak, FloatVectorOperations::findMaximum (src, toCopy), -FloatVectorOperations::findMinimum (src, toCopy));
            }
        }

        writePos = pos + toCopy;
    }

    level = jmax (peak, level.load() * 0.9f);
}

File SampleRecorder::stopAndSave (const File& folder, const String& baseName)
{
    recording = false;
    auto len = writePos.load();
    if (len < 256)
        return {};

    // trim silence from both ends
    auto threshold = Decibels::decibelsToGain (-48.0f);
    int start = 0, end = len;
    auto isLoud = [&] (int i) { return std::abs (buffer.getSample (0, i)) > threshold || std::abs (buffer.getSample (1, i)) > threshold; };
    while (start < len && ! isLoud (start)) ++start;
    while (end > start && ! isLoud (end - 1)) --end;
    start = jmax (0, start - (int) (0.002 * sampleRate));
    end = jmin (len, end + (int) (0.05 * sampleRate));

    if (end - start < 64)
        return {};

    AudioBuffer<float> out (2, end - start);
    for (int ch = 0; ch < 2; ++ch)
        out.copyFrom (ch, 0, buffer, ch, start, end - start);

    // normalise to -1 dBFS with tiny fades
    auto mag = out.getMagnitude (0, out.getNumSamples());
    if (mag > 0.0001f)
        out.applyGain (Decibels::decibelsToGain (-1.0f) / mag);

    auto fade = jmin (out.getNumSamples() / 4, (int) (0.003 * sampleRate));
    out.applyGainRamp (0, fade, 0.0f, 1.0f);
    out.applyGainRamp (out.getNumSamples() - fade, fade, 1.0f, 0.0f);

    folder.createDirectory();
    auto file = folder.getNonexistentChildFile (File::createLegalFileName (baseName), ".wav", false);

    std::unique_ptr<OutputStream> stream = std::make_unique<FileOutputStream> (file);
    WavAudioFormat wav;
    auto writer = wav.createWriterFor (stream, AudioFormatWriterOptions().withSampleRate (sampleRate)
                                                                         .withNumChannels (2)
                                                                         .withBitsPerSample (24));
    if (writer == nullptr)
        return {};

    writer->writeFromAudioSampleBuffer (out, 0, out.getNumSamples());
    return file;
}

//==============================================================================
// DrumMachineEditor
//==============================================================================
class DrumMachineEditor::Pad : public Component,
                               public FileDragAndDropTarget,
                               public DragAndDropTarget
{
public:
    Pad (DrumMachineEditor& o, int i) : owner (o), index (i) {}

    void paint (Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (3.0f);
        auto& d = owner.drums;
        auto hasSample = d.padHasSample (index);
        auto selected = owner.selectedPad == index;
        auto col = Col::trackPalette (index / 4 * 3 + 1);

        auto base = hasSample ? Col::bg3 : Col::bg2;
        g.setColour (base.interpolatedWith (col, flash * 0.75f));
        g.fillRoundedRectangle (r, 6.0f);

        if (selected)
        {
            g.setColour (Col::south);
            g.drawRoundedRectangle (r, 6.0f, 2.0f);
        }
        else if (dragOver)
        {
            g.setColour (Col::green);
            g.drawRoundedRectangle (r, 6.0f, 2.0f);
        }

        if (d.getLearnPad() == index)
        {
            g.setColour (Col::yellow);
            g.drawRoundedRectangle (r.reduced (2.0f), 5.0f, 2.0f);
        }

        g.setColour (hasSample ? Col::text : Col::textFaint);
        g.setFont (LodeLookAndFeel::font (12.5f, true));
        g.drawFittedText (d.getPadName (index), r.reduced (6.0f, 4.0f).toNearestInt(), Justification::centredTop, 2);

        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (10.5f));
        auto note = d.getPadNote (index);
        auto noteText = noteName (note) + (r.getWidth() > 92.0f ? " (" + String (note) + ")" : String());
        auto bottom = r.reduced (6.0f, 4.0f).removeFromBottom (14.0f);
        auto numberWidth = GlyphArrangement::getStringWidth (g.getCurrentFont(), String (index + 1)) + 4.0f;

        if (bottom.getWidth() > numberWidth + GlyphArrangement::getStringWidth (g.getCurrentFont(), noteText) + 4.0f)
            g.drawText (String (index + 1), bottom.removeFromLeft (numberWidth), Justification::centredLeft);

        g.drawText (noteText, bottom, Justification::centredRight);
    }

    void mouseDown (const MouseEvent& e) override
    {
        owner.selectPad (index);

        if (e.mods.isPopupMenu())
        {
            showMenu();
            return;
        }

        // hit harder towards the top of the pad
        auto vel = jlimit (0.15f, 1.0f, 1.0f - (float) e.y / (float) getHeight() * 0.85f);
        owner.drums.triggerPad (index, vel);
    }

    void showMenu()
    {
        PopupMenu m;
        auto& d = owner.drums;
        m.addItem ("Load sample...", [this] { owner.loadSampleIntoPad (index); });
        m.addItem ("Learn MIDI note (hit a pad on your controller)", [this] { owner.drums.startLearn (index); repaint(); });
        m.addItem ("Clear pad", [this] { owner.drums.clearPad (index); });

        PopupMenu swap;
        for (int i = 0; i < DrumMachinePlugin::numPads; ++i)
            if (i != index)
                swap.addItem (String (i + 1) + ": " + d.getPadName (i), [this, i] { owner.drums.swapPads (index, i); });
        m.addSubMenu ("Swap sound with", swap);

        PopupMenu notes;
        for (int n = 35; n <= 81; ++n)
            notes.addItem (String (n) + "  " + noteName (n) + "  " + DrumKits::gmDrumName (n), true, d.getPadNote (index) == n,
                           [this, n] { owner.drums.setPadProperty (index, DrumMachinePlugin::noteProp, n); });
        m.addSubMenu ("MIDI note", notes);
        m.showMenuAsync ({});
    }

    bool isInterestedInFileDrag (const StringArray& files) override     { return files.size() == 1; }
    void fileDragEnter (const StringArray&, int, int) override          { dragOver = true; repaint(); }
    void fileDragExit (const StringArray&) override                     { dragOver = false; repaint(); }
    void filesDropped (const StringArray& files, int, int) override
    {
        dragOver = false;
        owner.drums.setPadSample (index, File (files[0]));
        owner.selectPad (index);
    }

    bool isInterestedInDragSource (const SourceDetails& s) override
    {
        return dynamic_cast<FileTreeComponent*> (s.sourceComponent.get()) != nullptr;
    }

    void itemDropped (const SourceDetails& s) override
    {
        dragOver = false;
        if (auto* ft = dynamic_cast<FileTreeComponent*> (s.sourceComponent.get()))
            if (ft->getSelectedFile().existsAsFile())
            {
                owner.drums.setPadSample (index, ft->getSelectedFile());
                owner.selectPad (index);
            }
    }

    void itemDragEnter (const SourceDetails&) override  { dragOver = true; repaint(); }
    void itemDragExit (const SourceDetails&) override   { dragOver = false; repaint(); }

    DrumMachineEditor& owner;
    const int index;
    float flash = 0.0f;
    juce::uint32 lastHits = 0;
    bool dragOver = false;
};

DrumMachineEditor::DrumMachineEditor (DrumMachinePlugin& d, Session* s)
    : drums (d), session (s)
{
    for (int i = 0; i < DrumMachinePlugin::numPads; ++i)
        addAndMakeVisible (pads.add (new Pad (*this, i)));

    addAndMakeVisible (kitBox);
    kitBox.setTextWhenNothingSelected ("Choose a kit...");
    kitBox.onChange = [this]
    {
        auto kits = DrumKits::findAll();
        auto idx = kitBox.getSelectedId() - 1;
        if (isPositiveAndBelow (idx, kits.size()))
        {
            drums.getUndoManager()->beginNewTransaction ("Load kit");
            auto err = drums.loadKit (kits[idx].location);
            if (err.isNotEmpty() && session != nullptr)
                session->status (err);
            refreshPadDetails();
        }
    };
    rebuildKitBox();

    addAndMakeVisible (saveKitButton);
    saveKitButton.onClick = [this] { saveKit(); };

    addAndMakeVisible (padTitle);
    padTitle.setFont (LodeLookAndFeel::font (15.0f, true));

    auto padProp = [this] (const Identifier& id, double def)
    {
        return [this, id, def] { return (double) drums.getPadState (selectedPad).getProperty (id, def); };
    };
    auto setPadProp = [this] (const Identifier& id)
    {
        return [this, id] (double v) { drums.setPadProperty (selectedPad, id, (float) v); };
    };

    padKnobs.add (new PropertyKnob ("Volume", -36.0, 12.0, 0.0, padProp (DrumMachinePlugin::gainProp, 0.0), setPadProp (DrumMachinePlugin::gainProp),
                                    [] (double v) { return String (v, 1) + " dB"; }));
    padKnobs.add (new PropertyKnob ("Pan", -1.0, 1.0, 0.0, padProp (DrumMachinePlugin::panProp, 0.0), setPadProp (DrumMachinePlugin::panProp),
                                    [] (double v) { return std::abs (v) < 0.01 ? String ("C") : (v < 0 ? "L" + String (roundToInt (-v * 100)) : "R" + String (roundToInt (v * 100))); }));
    padKnobs.add (new PropertyKnob ("Tune", -24.0, 24.0, 0.0, padProp (DrumMachinePlugin::tuneProp, 0.0), setPadProp (DrumMachinePlugin::tuneProp),
                                    [] (double v) { return String (v, 1) + " st"; }));
    padKnobs.add (new PropertyKnob ("Decay", 0.0, 1.0, 1.0, padProp (DrumMachinePlugin::decayProp, 1.0), setPadProp (DrumMachinePlugin::decayProp),
                                    [] (double v) { return v >= 0.999 ? String ("Full") : String (roundToInt (v * 100)) + "%"; }));
    padKnobs.add (new PropertyKnob ("Tone", 200.0, 20000.0, 20000.0, padProp (DrumMachinePlugin::cutoffProp, 20000.0), setPadProp (DrumMachinePlugin::cutoffProp),
                                    [] (double v) { return v >= 19500 ? String ("Open") : String (roundToInt (v)) + " Hz"; }));
    padKnobs.add (new PropertyKnob ("Velocity", 0.0, 1.0, 0.75, padProp (DrumMachinePlugin::velSensProp, 0.75), setPadProp (DrumMachinePlugin::velSensProp),
                                    [] (double v) { return String (roundToInt (v * 100)) + "%"; }));
    padKnobs.add (new PropertyKnob ("Start", 0.0, 0.99, 0.0, padProp (DrumMachinePlugin::startProp, 0.0), setPadProp (DrumMachinePlugin::startProp),
                                    [] (double v) { return String (roundToInt (v * 100)) + "%"; }));
    padKnobs.add (new PropertyKnob ("End", 0.01, 1.0, 1.0, padProp (DrumMachinePlugin::endProp, 1.0), setPadProp (DrumMachinePlugin::endProp),
                                    [] (double v) { return v >= 0.999 ? String ("Full") : String (roundToInt (v * 100)) + "%"; }));
    padKnobs[4]->slider.setSkewFactorFromMidPoint (2000.0);

    for (auto* k : padKnobs)
        addAndMakeVisible (k);

    for (auto* t : { &reverseToggle, &oneShotToggle, &muteToggle })
        addAndMakeVisible (t);

    reverseToggle.onClick = [this] { drums.setPadProperty (selectedPad, DrumMachinePlugin::reverseProp, reverseToggle.getToggleState()); };
    oneShotToggle.onClick = [this] { drums.setPadProperty (selectedPad, DrumMachinePlugin::oneShotProp, oneShotToggle.getToggleState()); };
    muteToggle.onClick = [this] { drums.setPadProperty (selectedPad, DrumMachinePlugin::muteProp, muteToggle.getToggleState()); };
    oneShotToggle.setTooltip ("One-shot: the whole sample plays even if you let go of the key");

    addAndMakeVisible (chokeBox);
    chokeBox.addItem ("No choke group", 1);
    for (int i = 1; i <= 8; ++i)
        chokeBox.addItem ("Choke group " + String (i), i + 1);
    chokeBox.setTooltip ("Pads in the same choke group cut each other off (e.g. open/closed hi-hat)");
    chokeBox.onChange = [this] { drums.setPadProperty (selectedPad, DrumMachinePlugin::chokeProp, chokeBox.getSelectedId() - 1); };

    addAndMakeVisible (learnButton);
    learnButton.setTooltip ("Then hit a pad or key on your MIDI controller to assign it to this pad");
    learnButton.onClick = [this]
    {
        drums.startLearn (selectedPad);
        if (session != nullptr)
            session->status ("Hit a pad on your controller to assign it to pad " + String (selectedPad + 1));
    };

    addAndMakeVisible (loadButton);
    loadButton.onClick = [this] { loadSampleIntoPad (selectedPad); };

    addAndMakeVisible (sampleButton);
    sampleButton.setColour (TextButton::buttonColourId, Col::north.withAlpha (0.35f));
    sampleButton.setTooltip ("Hold to record a sample from your audio input straight into this pad (like a PO-33)");
    sampleButton.onStateChange = [this]
    {
        auto down = sampleButton.isDown();
        if (down && (recorder == nullptr || ! recorder->isRecording()))
            startSampling();
        else if (! down && recorder != nullptr && recorder->isRecording())
            stopSampling();
    };

    refreshPadDetails();
    startTimerHz (30);
}

DrumMachineEditor::~DrumMachineEditor()
{
    stopTimer();
}

void DrumMachineEditor::rebuildKitBox()
{
    kitBox.clear (dontSendNotification);
    auto kits = DrumKits::findAll();
    int id = 1;
    String lastSource;

    for (auto& k : kits)
    {
        if (k.source != lastSource)
        {
            kitBox.addSectionHeading (k.source == "Lodestone" ? "Built-in kits" : (k.source == "Hydrogen" ? "Hydrogen kits" : "Your kits"));
            lastSource = k.source;
        }

        kitBox.addItem (k.name, id);
        if (k.name == drums.getKitName())
            kitBox.setSelectedId (id, dontSendNotification);
        ++id;
    }
}

void DrumMachineEditor::selectPad (int p)
{
    selectedPad = jlimit (0, DrumMachinePlugin::numPads - 1, p);
    refreshPadDetails();

    for (auto* pad : pads)
        pad->repaint();
}

void DrumMachineEditor::refreshPadDetails()
{
    auto st = drums.getPadState (selectedPad);
    auto file = drums.getPadFile (selectedPad);
    padTitle.setText ("Pad " + String (selectedPad + 1) + ": " + drums.getPadName (selectedPad)
                        + (file != File() ? "   (" + file.getFileName() + ")" : String()),
                      dontSendNotification);

    for (auto* k : padKnobs)
        k->refresh();

    reverseToggle.setToggleState ((bool) st.getProperty (DrumMachinePlugin::reverseProp, false), dontSendNotification);
    oneShotToggle.setToggleState ((bool) st.getProperty (DrumMachinePlugin::oneShotProp, true), dontSendNotification);
    muteToggle.setToggleState ((bool) st.getProperty (DrumMachinePlugin::muteProp, false), dontSendNotification);
    chokeBox.setSelectedId ((int) st.getProperty (DrumMachinePlugin::chokeProp, 0) + 1, dontSendNotification);
}

void DrumMachineEditor::timerCallback()
{
    for (auto* p : pads)
    {
        auto hits = drums.getPadHitCount (p->index);
        if (hits != p->lastHits)
        {
            p->lastHits = hits;
            p->flash = 0.4f + 0.6f * drums.getPadLastVelocity (p->index);
            p->repaint();
        }
        else if (p->flash > 0.0f)
        {
            p->flash = jmax (0.0f, p->flash - 0.12f);
            p->repaint();
        }
    }

    // pick up name/note changes (MIDI learn, kit loads, undo)
    static int counter = 0;
    if (++counter % 10 == 0)
    {
        for (auto* p : pads) p->repaint();
        auto name = drums.getPadName (selectedPad);
        if (! padTitle.getText().contains (name))
            refreshPadDetails();
    }

    if (recorder != nullptr && recorder->isRecording())
    {
        sampleButton.setButtonText ("Recording... " + String (Decibels::gainToDecibels (recorder->getLevel()), 0) + " dB");
    }
}

void DrumMachineEditor::loadSampleIntoPad (int pad)
{
    chooser = std::make_unique<FileChooser> ("Load a sample into pad " + String (pad + 1),
                                             File::getSpecialLocation (File::userMusicDirectory),
                                             "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3");
    chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles,
                          [this, pad] (const FileChooser& fc)
                          {
                              auto f = fc.getResult();
                              if (f.existsAsFile())
                              {
                                  drums.getUndoManager()->beginNewTransaction ("Load sample");
                                  drums.setPadSample (pad, f);
                                  selectPad (pad);
                              }
                          });
}

void DrumMachineEditor::startSampling()
{
    if (recorder == nullptr)
        recorder = std::make_unique<SampleRecorder> (drums.engine);

    recorder->start();
    sampleButton.setButtonText ("Recording...");
}

void DrumMachineEditor::stopSampling()
{
    File folder;
    if (session != nullptr)
        folder = session->getProjectFile().getParentDirectory().getChildFile ("Samples");
    else
        folder = getUserDataDir().getChildFile ("samples");

    auto f = recorder->stopAndSave (folder, "Pad " + String (selectedPad + 1) + " sample");
    sampleButton.setButtonText ("Hold to Sample");

    if (f.existsAsFile())
    {
        drums.getUndoManager()->beginNewTransaction ("Sample pad");
        drums.setPadSample (selectedPad, f, "Sample " + String (selectedPad + 1));
        drums.triggerPad (selectedPad, 0.9f);
        refreshPadDetails();
    }
    else if (session != nullptr)
    {
        session->status ("Nothing was recorded - check your audio input in Settings");
    }
}

void DrumMachineEditor::saveKit()
{
    auto* aw = new AlertWindow ("Save drum kit", "Name for this kit:", MessageBoxIconType::NoIcon);
    aw->addTextEditor ("name", drums.getKitName().isNotEmpty() ? drums.getKitName() + " (custom)" : "My Kit");
    aw->addButton ("Save", 1, KeyPress (KeyPress::returnKey));
    aw->addButton ("Cancel", 0, KeyPress (KeyPress::escapeKey));

    SafePointer<DrumMachineEditor> safe (this);
    aw->enterModalState (true, ModalCallbackFunction::create ([aw, safe] (int r)
    {
        if (r != 1 || safe == nullptr)
            return;

        auto& d = safe->drums;
        auto name = aw->getTextEditorContents ("name").trim();
        auto dir = getUserDataDir().getChildFile ("kits").getChildFile (File::createLegalFileName (name));
        dir.createDirectory();

        auto kit = new DynamicObject();
        kit->setProperty ("name", name);
        Array<var> padsArr;

        for (int i = 0; i < DrumMachinePlugin::numPads; ++i)
        {
            auto st = d.getPadState (i);
            auto pad = new DynamicObject();
            pad->setProperty ("name", st.getProperty (DrumMachinePlugin::nameProp));

            for (auto id : { DrumMachinePlugin::noteProp, DrumMachinePlugin::gainProp, DrumMachinePlugin::panProp, DrumMachinePlugin::tuneProp,
                             DrumMachinePlugin::decayProp, DrumMachinePlugin::cutoffProp, DrumMachinePlugin::chokeProp,
                             DrumMachinePlugin::reverseProp, DrumMachinePlugin::oneShotProp, DrumMachinePlugin::velSensProp,
                             DrumMachinePlugin::startProp, DrumMachinePlugin::endProp })
                if (st.hasProperty (id))
                    pad->setProperty (id, st.getProperty (id));

            Array<var> layers;
            for (auto l : st)
            {
                File src (l.getProperty (DrumMachinePlugin::fileProp).toString());
                if (! src.existsAsFile())
                    continue;

                auto dest = dir.getChildFile (src.getFileName());
                if (! dest.existsAsFile())
                    src.copyFileTo (dest);

                auto layer = new DynamicObject();
                layer->setProperty ("file", dest.getFileName());
                layer->setProperty ("minVel", l.getProperty (DrumMachinePlugin::minVelProp, 0.0));
                layer->setProperty ("maxVel", l.getProperty (DrumMachinePlugin::maxVelProp, 1.0));
                layers.add (var (layer));
            }

            pad->setProperty ("layers", layers);
            padsArr.add (var (pad));
        }

        kit->setProperty ("pads", padsArr);
        dir.getChildFile ("kit.json").replaceWithText (JSON::toString (var (kit)));
        d.state.setProperty ("kitName", name, nullptr);
        safe->rebuildKitBox();

        if (safe->session != nullptr)
            safe->session->status ("Saved kit \"" + name + "\" to " + dir.getFullPathName());
    }), true);
}

void DrumMachineEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
}

void DrumMachineEditor::resized()
{
    auto r = getLocalBounds().reduced (10);
    auto top = r.removeFromTop (28);
    saveKitButton.setBounds (top.removeFromRight (100));
    top.removeFromRight (6);
    kitBox.setBounds (top.removeFromLeft (jmin (280, top.getWidth())));
    r.removeFromTop (8);

    // pads: 4x4, pad 1 bottom-left like an MPC / MPD218
    auto padArea = r.removeFromLeft (jmin (r.getHeight() * 4 / 3, r.getWidth() / 2));
    auto padSize = jmin (padArea.getWidth() / 4, padArea.getHeight() / 4);
    for (int i = 0; i < DrumMachinePlugin::numPads; ++i)
    {
        int col = i % 4, row = 3 - i / 4;
        pads[i]->setBounds (padArea.getX() + col * padSize, padArea.getY() + row * padSize, padSize, padSize);
    }

    r.removeFromLeft (14);
    padTitle.setBounds (r.removeFromTop (24));
    r.removeFromTop (4);

    auto knobRow = r.removeFromTop (jlimit (70, 100, r.getHeight() - 84));
    auto kw = jmin (84, knobRow.getWidth() / jmax (1, padKnobs.size()));
    for (auto* k : padKnobs)
        k->setBounds (knobRow.removeFromLeft (kw));

    r.removeFromTop (6);
    auto row1 = r.removeFromTop (26);
    reverseToggle.setBounds (row1.removeFromLeft (90));
    oneShotToggle.setBounds (row1.removeFromLeft (96));
    muteToggle.setBounds (row1.removeFromLeft (72));
    chokeBox.setBounds (row1.removeFromLeft (150));

    r.removeFromTop (8);
    auto row2 = r.removeFromTop (28);
    loadButton.setBounds (row2.removeFromLeft (90));
    row2.removeFromLeft (6);
    learnButton.setBounds (row2.removeFromLeft (100));
    row2.removeFromLeft (6);
    sampleButton.setBounds (row2.removeFromLeft (170));
}

std::unique_ptr<te::Plugin::EditorComponent> DrumMachinePlugin::createEditor()
{
    struct Wrapper : public te::Plugin::EditorComponent
    {
        Wrapper (DrumMachinePlugin& p) : editor (p, nullptr)
        {
            addAndMakeVisible (editor);
            setSize (900, 420);
        }

        bool allowWindowResizing() override                         { return true; }
        ComponentBoundsConstrainer* getBoundsConstrainer() override { return nullptr; }
        void resized() override                                     { editor.setBounds (getLocalBounds()); }

        DrumMachineEditor editor;
    };

    return std::make_unique<Wrapper> (*this);
}

//==============================================================================
// SoundFontEditor
//==============================================================================
SoundFontEditor::SoundFontEditor (SoundFontPlugin& s) : sf (s)
{
    addAndMakeVisible (title);
    title.setFont (LodeLookAndFeel::font (15.0f, true));

    addAndMakeVisible (fontBox);
    auto fonts = SoundFonts::findInstalled();
    int id = 1;
    for (auto& f : fonts)
    {
        fontBox.addItem (f.getFileNameWithoutExtension(), id);
        if (f == sf.getSoundFontFile())
            fontBox.setSelectedId (id, dontSendNotification);
        ++id;
    }
    fontBox.addSeparator();
    fontBox.addItem ("Load a .sf2 file...", 9999);

    fontBox.onChange = [this, fonts]
    {
        auto idv = fontBox.getSelectedId();
        if (idv == 9999)
        {
            auto chooser = std::make_shared<FileChooser> ("Choose a SoundFont", File::getSpecialLocation (File::userHomeDirectory), "*.sf2;*.sf3");
            chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles,
                                  [this, chooser] (const FileChooser& fc)
                                  {
                                      if (fc.getResult().existsAsFile())
                                      {
                                          sf.setSoundFont (fc.getResult());
                                          refreshList();
                                      }
                                  });
            return;
        }

        if (isPositiveAndBelow (idv - 1, fonts.size()))
        {
            sf.getUndoManager()->beginNewTransaction ("SoundFont");
            sf.setSoundFont (fonts[idv - 1]);
            refreshList();
        }
    };

    addAndMakeVisible (filter);
    filter.setTextToShowWhenEmpty ("Filter sounds...", Col::textFaint);
    filter.onTextChange = [this] { refreshList(); };

    addAndMakeVisible (list);
    list.setRowHeight (22);
    list.setColour (ListBox::backgroundColourId, Col::bg0);

    volumeKnob = std::make_unique<ParamKnob> (sf.gainParam, "Volume");
    reverbKnob = std::make_unique<ParamKnob> (sf.reverbParam, "Reverb", Col::purple);
    chorusKnob = std::make_unique<ParamKnob> (sf.chorusParam, "Chorus", Col::green);
    addAndMakeVisible (*volumeKnob);
    addAndMakeVisible (*reverbKnob);
    addAndMakeVisible (*chorusKnob);

    refreshList();
}

void SoundFontEditor::refreshList()
{
    visible.clear();
    auto& presets = SoundFonts::getPresets (sf.getSoundFontFile());
    auto text = filter.getText().trim();

    for (int i = 0; i < presets.size(); ++i)
        if (text.isEmpty() || presets[i].name.containsIgnoreCase (text))
            visible.add (i);

    list.updateContent();
    title.setText (sf.getPresetName() + "   -   " + sf.getSoundFontFile().getFileNameWithoutExtension(), dontSendNotification);

    for (int r = 0; r < visible.size(); ++r)
    {
        auto p = presets[visible[r]];
        if (p.bank == sf.getBank() && p.program == sf.getProgram())
        {
            list.selectRow (r, false, true);
            list.scrollToEnsureRowIsOnscreen (r);
        }
    }

    list.repaint();
}

int SoundFontEditor::getNumRows()     { return visible.size(); }

void SoundFontEditor::paintListBoxItem (int row, Graphics& g, int w, int h, bool selected)
{
    auto& presets = SoundFonts::getPresets (sf.getSoundFontFile());
    if (! isPositiveAndBelow (row, visible.size()))
        return;

    auto p = presets[visible[row]];
    if (selected)
        g.fillAll (Col::south.withAlpha (0.35f));

    g.setColour (Col::textFaint);
    g.setFont (LodeLookAndFeel::font (11.0f));
    g.drawText (p.bank == 128 ? "Drums" : String (p.bank) + ":" + String (p.program), 6, 0, 60, h, Justification::centredLeft);
    g.setColour (Col::text);
    g.setFont (LodeLookAndFeel::font (13.0f));
    g.drawText (p.name, 66, 0, w - 70, h, Justification::centredLeft, true);
}

void SoundFontEditor::listBoxItemClicked (int row, const MouseEvent&)
{
    auto& presets = SoundFonts::getPresets (sf.getSoundFontFile());
    if (! isPositiveAndBelow (row, visible.size()))
        return;

    auto p = presets[visible[row]];
    sf.getUndoManager()->beginNewTransaction ("Change sound");
    sf.setProgram (p.bank, p.program);

    if (auto t = dynamic_cast<te::AudioTrack*> (sf.getOwnerTrack()))
        setTrackKind (*t, p.bank == 128 ? TrackKind::drums : TrackKind::instrument);

    title.setText (p.name + "   -   " + sf.getSoundFontFile().getFileNameWithoutExtension(), dontSendNotification);
}

void SoundFontEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
}

void SoundFontEditor::resized()
{
    auto r = getLocalBounds().reduced (10);
    auto top = r.removeFromTop (26);
    fontBox.setBounds (top.removeFromRight (jmin (260, top.getWidth() / 2)));
    title.setBounds (top);
    r.removeFromTop (8);

    auto knobs = r.removeFromRight (100);
    volumeKnob->setBounds (knobs.removeFromTop (100));
    reverbKnob->setBounds (knobs.removeFromTop (100));
    chorusKnob->setBounds (knobs.removeFromTop (100));

    r.removeFromRight (10);
    filter.setBounds (r.removeFromTop (26));
    r.removeFromTop (4);
    list.setBounds (r);

    // the list had no height when the current sound was first scrolled into view
    if (auto row = list.getSelectedRow(); row >= 0)
        list.scrollToEnsureRowIsOnscreen (row);
}

std::unique_ptr<te::Plugin::EditorComponent> SoundFontPlugin::createEditor()
{
    struct Wrapper : public te::Plugin::EditorComponent
    {
        Wrapper (SoundFontPlugin& p) : editor (p)
        {
            addAndMakeVisible (editor);
            setSize (640, 420);
        }

        bool allowWindowResizing() override                         { return true; }
        ComponentBoundsConstrainer* getBoundsConstrainer() override { return nullptr; }
        void resized() override                                     { editor.setBounds (getLocalBounds()); }

        SoundFontEditor editor;
    };

    return std::make_unique<Wrapper> (*this);
}

//==============================================================================
// SynthEditor (FourOsc)
//==============================================================================
SynthEditor::SynthEditor (te::Plugin& p) : synth (&p)
{
    build();
}

void SynthEditor::build()
{
    auto& p = *synth;
    addAndMakeVisible (title);
    title.setFont (LodeLookAndFeel::font (15.0f, true));
    title.setText ("Lodestone Synth  -  4 oscillators, filter, envelopes, effects", dontSendNotification);

    addAndMakeVisible (presetBox);
    presetBox.setTextWhenNothingSelected ("Presets...");
    auto names = SynthPresets::getNames();
    for (int i = 0; i < names.size(); ++i)
        presetBox.addItem (names[i], i + 1);
    presetBox.setText (p.state.getProperty ("lodePreset", "").toString(), dontSendNotification);
    presetBox.onChange = [this, names]
    {
        auto idx = presetBox.getSelectedId() - 1;
        if (isPositiveAndBelow (idx, names.size()))
        {
            synth->edit.getUndoManager().beginNewTransaction ("Synth preset");
            SynthPresets::apply (*synth, names[idx]);
        }
    };

    auto waveBox = [&p] (ComboBox& box, const char* prop)
    {
        box.addItem ("Off", 1);
        box.addItem ("Sine", 2);
        box.addItem ("Square", 3);
        box.addItem ("Saw", 4);
        box.addItem ("Triangle", 5);
        box.addItem ("Noise", 6);
        box.setSelectedId ((int) p.state.getProperty (prop, 0) + 1, dontSendNotification);
        box.onChange = [&p, &box, prop] { p.state.setProperty (prop, box.getSelectedId() - 1, p.getUndoManager()); };
    };

    waveBox (osc1Wave, "waveShape1");
    waveBox (osc2Wave, "waveShape2");
    addAndMakeVisible (osc1Wave);
    addAndMakeVisible (osc2Wave);
    osc1Wave.setTooltip ("Oscillator 1 waveform");
    osc2Wave.setTooltip ("Oscillator 2 waveform");

    filterType.addItem ("Filter off", 1);
    filterType.addItem ("Low-pass", 2);
    filterType.addItem ("High-pass", 3);
    filterType.addItem ("Band-pass", 4);
    filterType.addItem ("Notch", 5);
    filterType.setSelectedId ((int) p.state.getProperty ("filterType", 0) + 1, dontSendNotification);
    filterType.onChange = [this] { synth->state.setProperty ("filterType", filterType.getSelectedId() - 1, synth->getUndoManager()); };
    addAndMakeVisible (filterType);

    struct K { const char* id; const char* label; Colour col; };
    const K list[] = {
        { "tune2", "Osc 2 Tune", Col::south }, { "fineTune2", "Osc 2 Fine", Col::south }, { "level2", "Osc 2 Level", Col::south },
        { "detune1", "Unison Detune", Col::south },
        { "filterFreq", "Cutoff", Col::orange }, { "filterResonance", "Resonance", Col::orange }, { "filterAmount", "Env Amount", Col::orange },
        { "ampAttack", "Attack", Col::green }, { "ampDecay", "Decay", Col::green }, { "ampSustain", "Sustain", Col::green }, { "ampRelease", "Release", Col::green },
        { "distortion", "Drive", Col::north }, { "chorusMix", "Chorus", Col::purple }, { "delayMix", "Delay", Col::purple }, { "reverbMix", "Reverb", Col::purple },
        { "masterLevel", "Volume", Col::text } };

    for (auto& k : list)
        if (auto param = p.getAutomatableParameterByID (k.id))
            addAndMakeVisible (knobs.add (new ParamKnob (param, k.label, k.col)));

    // the effects need switching on to be heard
    for (auto [mix, on] : { std::pair<const char*, const char*> { "chorusMix", "chorusOn" }, { "delayMix", "delayOn" },
                            { "reverbMix", "reverbOn" }, { "distortion", "distortionOn" } })
        p.state.setProperty (on, true, nullptr);

    addAndMakeVisible (allParams);
    allParams.onClick = [this] { synth->showWindowExplicitly(); };
}

void SynthEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    g.setColour (Col::textFaint);
    g.setFont (LodeLookAndFeel::font (11.0f));
    g.drawText ("Osc 1", 10, 46, 80, 14, Justification::centredLeft);
}

void SynthEditor::resized()
{
    auto r = getLocalBounds().reduced (10);
    auto top = r.removeFromTop (26);
    allParams.setBounds (top.removeFromRight (130));
    top.removeFromRight (6);
    presetBox.setBounds (top.removeFromRight (170));
    title.setBounds (top);
    r.removeFromTop (10);

    auto row = r.removeFromTop (26);
    osc1Wave.setBounds (row.removeFromLeft (110));
    row.removeFromLeft (8);
    osc2Wave.setBounds (row.removeFromLeft (110));
    row.removeFromLeft (8);
    filterType.setBounds (row.removeFromLeft (120));
    r.removeFromTop (8);

    auto kw = 80, kh = 96;
    auto cols = jmax (1, r.getWidth() / kw);
    for (int i = 0; i < knobs.size(); ++i)
        knobs[i]->setBounds (r.getX() + (i % cols) * kw, r.getY() + (i / cols) * kh, kw - 4, kh);
}

//==============================================================================
// Plugin windows
//==============================================================================
namespace
{
    struct GenericEditorWrapper : public te::Plugin::EditorComponent
    {
        GenericEditorWrapper (te::Plugin& p) : editor (p)
        {
            addAndMakeVisible (editor);
            setSize (560, jlimit (140, 640, editor.getIdealHeight (560)));
        }

        bool allowWindowResizing() override                         { return true; }
        ComponentBoundsConstrainer* getBoundsConstrainer() override { return nullptr; }
        void resized() override                                     { editor.setBounds (getLocalBounds()); }

        GenericPluginEditor editor;
    };

   #if JUCE_LINUX
    constexpr bool addPluginWindowToDesktop = false;
   #else
    constexpr bool addPluginWindowToDesktop = true;
   #endif

    class PluginWindow : public DocumentWindow
    {
    public:
        PluginWindow (te::Plugin& p)
            : DocumentWindow (p.getName(), Col::bg1, DocumentWindow::closeButton, addPluginWindowToDesktop),
              plugin (p), windowState (*p.windowState)
        {
            getConstrainer()->setMinimumOnscreenAmounts (0x10000, 50, 30, 50);
            setResizeLimits (120, 60, 4000, 4000);
            setUsingNativeTitleBar (true);
            recreateEditor();
            setBoundsConstrained (getLocalBounds() + plugin.windowState->choosePositionForPluginWindow());

           #if JUCE_LINUX
            setAlwaysOnTop (true);
            addToDesktop();
           #endif

            updateStoredBounds = true;
        }

        ~PluginWindow() override
        {
            updateStoredBounds = false;
            plugin.edit.flushPluginStateIfNeeded (plugin);
            setEditor (nullptr);
        }

        static std::unique_ptr<Component> create (te::Plugin& plugin)
        {
            if (auto ext = dynamic_cast<te::ExternalPlugin*> (&plugin))
                if (ext->getAudioPluginInstance() == nullptr)
                    return {};

            auto w = std::make_unique<PluginWindow> (plugin);
            if (w->editor == nullptr)
                return {};

            w->setVisible (true);
            w->toFront (false);
            return w;
        }

        void setEditor (std::unique_ptr<te::Plugin::EditorComponent> e)
        {
            setConstrainer (nullptr);
            editor.reset();

            if (e != nullptr)
            {
                editor = std::move (e);
                setContentNonOwned (editor.get(), true);
            }

            setResizable (editor == nullptr || editor->allowWindowResizing(), false);

            if (editor != nullptr && editor->allowWindowResizing())
                setConstrainer (editor->getBoundsConstrainer());
        }

        void recreateEditor()
        {
            setEditor (nullptr);
            auto e = plugin.createEditor();

            if (e == nullptr)
                e = std::make_unique<GenericEditorWrapper> (plugin);

            setEditor (std::move (e));
        }

        void recreateEditorAsync()
        {
            setEditor (nullptr);
            Timer::callAfterDelay (50, [sp = SafePointer<PluginWindow> (this)] { if (sp != nullptr) sp->recreateEditor(); });
        }

        void moved() override
        {
            if (updateStoredBounds)
            {
                plugin.windowState->lastWindowBounds = getBounds();
                plugin.edit.pluginChanged (plugin);
            }
        }

        void closeButtonPressed() override              { plugin.windowState->closeWindowExplicitly(); }
        float getDesktopScaleFactor() const override    { return 1.0f; }

        std::unique_ptr<te::Plugin::EditorComponent> editor;
        te::Plugin& plugin;
        te::PluginWindowState& windowState;
        bool updateStoredBounds = false;
    };
}

std::unique_ptr<Component> LodeUIBehaviour::createPluginWindow (te::PluginWindowState& pws)
{
    if (auto ws = dynamic_cast<te::Plugin::WindowState*> (&pws))
        return PluginWindow::create (ws->plugin);

    return {};
}

void LodeUIBehaviour::recreatePluginWindowContentAsync (te::Plugin& p)
{
    if (auto* w = dynamic_cast<PluginWindow*> (p.windowState->pluginWindow.get()))
        return w->recreateEditorAsync();

    UIBehaviour::recreatePluginWindowContentAsync (p);
}

void LodeUIBehaviour::runTaskWithProgressBar (te::ThreadPoolJobWithProgress& t)
{
    ProjectIO::runTaskWithProgress (t);
}

void LodeUIBehaviour::showWarningAlert (const String& title, const String& message)
{
    alert (MessageBoxIconType::WarningIcon, title, message);
}

void LodeUIBehaviour::showInfoMessage (const String& m)
{
    if (onStatusMessage) onStatusMessage (m);
}

void LodeUIBehaviour::showWarningMessage (const String& m)
{
    if (onStatusMessage) onStatusMessage (m);
}

//==============================================================================
// Menus
//==============================================================================
void showAddEffectMenu (Session& s, te::AudioTrack& track, Component* target)
{
    te::AudioTrack::Ptr t = &track;
    showEffectMenu (s, target, [&s, t] (const String& description)
    {
        s.edit_().getUndoManager().beginNewTransaction ("Add effect");
        BrowserItems::applyToTrack (s, description, t.get(), false);
    });
}

void showAddMasterEffectMenu (Session& s, Component* target)
{
    showEffectMenu (s, target, [&s] (const String& description)
    {
        auto& edit = s.edit_();
        edit.getUndoManager().beginNewTransaction ("Add master effect");

        if (auto p = BrowserItems::createEffect (s, description))
        {
            // keep the master meter last so it shows what leaves the chain
            auto& list = edit.getMasterPluginList();
            int index = list.size();
            for (int i = 0; i < list.size(); ++i)
                if (dynamic_cast<te::LevelMeterPlugin*> (list[i]) != nullptr)
                    index = jmin (index, i);
            list.insertPlugin (p, index, nullptr);
            s.status ("Added " + p->getName() + " to the master");
        }
    });
}

void showEffectMenu (Session& s, Component* target, std::function<void (const String&)> add)
{
    PopupMenu m;

    for (auto [name, type] : std::initializer_list<std::pair<const char*, const char*>> {
             { "Reverb", te::ReverbPlugin::xmlTypeName }, { "Delay", te::DelayPlugin::xmlTypeName },
             { "Chorus", te::ChorusPlugin::xmlTypeName }, { "Phaser", te::PhaserPlugin::xmlTypeName },
             { "Compressor", te::CompressorPlugin::xmlTypeName }, { "EQ (4-band)", te::EqualiserPlugin::xmlTypeName },
             { "Low/High-pass Filter", te::LowPassPlugin::xmlTypeName }, { "Pitch Shifter", te::PitchShiftPlugin::xmlTypeName } })
        m.addItem (name, [add, d = String ("fx|") + type] { add (d); });

    std::map<String, PopupMenu> awCats;
    for (auto& a : airWindowsList)
        awCats[a.category].addItem (a.name, [add, d = String ("fx|") + a.xmlType] { add (d); });

    PopupMenu aw;
    for (auto& [cat, menu] : awCats)
        aw.addSubMenu (cat.substring (0, 1).toUpperCase() + cat.substring (1), menu);
    m.addSubMenu ("Airwindows (186 effects)", aw);

    PopupMenu plugins;
    std::map<String, PopupMenu> byMaker;
    for (auto& pd : s.engine.getPluginManager().knownPluginList.getTypes())
        if (! pd.isInstrument)
        {
            auto d = String ("fxplugin|") + pd.createXml()->toString (XmlElement::TextFormat().singleLine().withoutHeader());
            byMaker[pd.manufacturerName.isNotEmpty() ? pd.manufacturerName : String ("Other")]
                .addItem (pd.name + " (" + pd.pluginFormatName + ")", [add, d] { add (d); });
        }

    for (auto& [maker, menu] : byMaker)
        plugins.addSubMenu (maker, menu);

    if (byMaker.empty())
        plugins.addItem ("No plugins scanned yet (Tools > Scan for Plugins)", false, false, [] {});

    m.addSubMenu ("Plugins", plugins);
    m.showMenuAsync (PopupMenu::Options().withTargetComponent (target));
}

void showInstrumentMenu (Session& s, Component* target, std::function<void (const String&)> chosen)
{
    PopupMenu m;

    PopupMenu kits;
    for (auto& k : DrumKits::findAll())
        kits.addItem (k.name + (k.source == "Hydrogen" ? "  (Hydrogen)" : ""), [chosen, d = "kit|" + k.location.getFullPathName()] { chosen (d); });
    kits.addSeparator();
    kits.addItem ("General MIDI Drum Kit (SoundFont)", [chosen] { chosen ("gm|128|0"); });
    m.addSubMenu ("Drum Kits", kits);

    PopupMenu gm;
    for (int fam = 0; fam < 16; ++fam)
    {
        PopupMenu sub;
        for (int p = fam * 8; p < fam * 8 + 8; ++p)
            sub.addItem (SoundFonts::gmProgramName (p), [chosen, p] { chosen ("gm|0|" + String (p)); });
        gm.addSubMenu (SoundFonts::gmFamilyName (fam), sub);
    }
    m.addSubMenu ("Instruments", gm);

    PopupMenu synths;
    for (auto& n : SynthPresets::getNames())
        synths.addItem (n, [chosen, n] { chosen ("synth|" + n); });
    m.addSubMenu ("Synths", synths);

    PopupMenu plugins;
    for (auto& pd : s.engine.getPluginManager().knownPluginList.getTypes())
        if (pd.isInstrument)
        {
            auto d = String ("plugin|") + pd.createXml()->toString (XmlElement::TextFormat().singleLine().withoutHeader());
            plugins.addItem (pd.name + " (" + pd.pluginFormatName + ")", [chosen, d] { chosen (d); });
        }

    if (plugins.getNumItems() == 0)
        plugins.addItem ("No plugin instruments scanned yet", false, false, [] {});

    m.addSubMenu ("Plugin Instruments", plugins);
    m.showMenuAsync (PopupMenu::Options().withTargetComponent (target));
}

//==============================================================================
// DeviceChainPanel
//==============================================================================
DeviceChainPanel::DeviceChainPanel (Session& s) : session (s)
{
    addAndMakeVisible (addFxButton);
    addFxButton.onClick = [this]
    {
        if (auto t = track.get())
            showAddEffectMenu (session, *t, &addFxButton);
    };

    addAndMakeVisible (changeInstrument);
    changeInstrument.setTooltip ("Swap this track's instrument");
    changeInstrument.onClick = [this]
    {
        te::AudioTrack::Ptr t = track.get();
        if (t == nullptr)
            return;

        showInstrumentMenu (session, &changeInstrument, [this, t] (const String& d)
        {
            session.edit_().getUndoManager().beginNewTransaction ("Change instrument");
            BrowserItems::applyToTrack (session, d, t.get(), false);
            selectedPlugin = nullptr;
            rebuild();
        });
    };

    addAndMakeVisible (editorViewport);
    editorViewport.setScrollBarsShown (true, true);

    addAndMakeVisible (emptyLabel);
    emptyLabel.setJustificationType (Justification::centred);
    emptyLabel.setColour (Label::textColourId, Col::textDim);
    emptyLabel.setFont (LodeLookAndFeel::font (15.0f));

    session.getSelectionManager().addChangeListener (this);
    showTrack (session.getSelectedTrack());
}

DeviceChainPanel::~DeviceChainPanel()
{
    session.getSelectionManager().removeChangeListener (this);
    if (auto t = track.get())
        t->state.removeListener (this);
}

void DeviceChainPanel::changeListenerCallback (ChangeBroadcaster*)
{
    auto t = session.getSelectedTrack();
    if (t != track.get())
        showTrack (t);
}

void DeviceChainPanel::showTrack (te::AudioTrack* t)
{
    if (auto old = track.get())
        old->state.removeListener (this);

    track = t;
    selectedPlugin = nullptr;

    if (t != nullptr)
    {
        t->state.addListener (this);
        selectedPlugin = Session::getInstrument (*t);

        if (selectedPlugin == nullptr)
            for (auto p : t->pluginList)
                if (dynamic_cast<te::VolumeAndPanPlugin*> (p) == nullptr && dynamic_cast<te::LevelMeterPlugin*> (p) == nullptr)
                {
                    selectedPlugin = p;
                    break;
                }
    }

    rebuild();
}

void DeviceChainPanel::selectDevice (te::Plugin* p)
{
    selectedPlugin = p;
    rebuild();
}

void DeviceChainPanel::valueTreeChildAdded (ValueTree&, ValueTree& c)          { if (c.hasType (te::IDs::PLUGIN)) triggerAsyncUpdate(); }
void DeviceChainPanel::valueTreeChildRemoved (ValueTree&, ValueTree& c, int)   { if (c.hasType (te::IDs::PLUGIN)) triggerAsyncUpdate(); }
void DeviceChainPanel::valueTreeChildOrderChanged (ValueTree&, int, int)       { triggerAsyncUpdate(); }

void DeviceChainPanel::handleAsyncUpdate()
{
    if (auto t = track.get())
    {
        bool stillThere = false;
        for (auto p : t->pluginList)
            if (p == selectedPlugin.get())
                stillThere = true;

        if (! stillThere)
            selectedPlugin = Session::getInstrument (*t);
    }

    rebuild();
}

void DeviceChainPanel::rebuild()
{
    deviceButtons.clear();
    editorViewport.setViewedComponent (nullptr, false);
    editor.reset();

    auto t = track.get();
    addFxButton.setVisible (t != nullptr);
    changeInstrument.setVisible (t != nullptr && getTrackKind (*t) != TrackKind::audio);

    if (t == nullptr)
    {
        emptyLabel.setText ("Select a track to see its instrument and effects.", dontSendNotification);
        emptyLabel.setVisible (true);
        resized();
        repaint();
        return;
    }

    for (auto p : t->pluginList)
    {
        if (dynamic_cast<te::VolumeAndPanPlugin*> (p) != nullptr || dynamic_cast<te::LevelMeterPlugin*> (p) != nullptr)
            continue;

        auto b = deviceButtons.add (new TextButton (p->getName()));
        b->setClickingTogglesState (false);
        b->setToggleState (p == selectedPlugin.get(), dontSendNotification);
        b->setColour (TextButton::buttonColourId, p->isSynth() ? t->getColour().withAlpha (0.45f) : Col::bg3);
        b->setColour (TextButton::buttonOnColourId, Col::south);
        b->setTooltip (p->isEnabled() ? "Click to edit, right-click for options" : "Bypassed - right-click to enable");
        if (! p->isEnabled())
            b->setColour (TextButton::textColourOffId, Col::textFaint);

        te::Plugin::Ptr plugin = p;
        b->onClick = [this, plugin]
        {
            if (ModifierKeys::currentModifiers.isPopupMenu())
                showDeviceMenu (plugin.get());
            else
                selectDevice (plugin.get());
        };
        b->addMouseListener (this, false);
        addAndMakeVisible (b);
    }

    emptyLabel.setVisible (false);

    if (selectedPlugin != nullptr)
        createEditorFor (selectedPlugin.get());
    else if (getTrackKind (*t) == TrackKind::audio)
    {
        emptyLabel.setText ("Audio track: choose an input in the track header, arm it and press Record.\nAdd effects with  + Effect.", dontSendNotification);
        emptyLabel.setVisible (true);
    }
    else
    {
        emptyLabel.setText ("No instrument on this track - click Change... to pick one.", dontSendNotification);
        emptyLabel.setVisible (true);
    }

    resized();
    repaint();
}

void DeviceChainPanel::createEditorFor (te::Plugin* p)
{
    if (auto dm = dynamic_cast<DrumMachinePlugin*> (p))
        editor = std::make_unique<DrumMachineEditor> (*dm, &session);
    else if (auto sf = dynamic_cast<SoundFontPlugin*> (p))
        editor = std::make_unique<SoundFontEditor> (*sf);
    else if (dynamic_cast<te::FourOscPlugin*> (p) != nullptr)
        editor = std::make_unique<SynthEditor> (*p);
    else if (auto ext = dynamic_cast<te::ExternalPlugin*> (p))
    {
        struct ExternalPanel : public Component
        {
            ExternalPanel (te::ExternalPlugin& e) : plugin (e), params (e)
            {
                addAndMakeVisible (open);
                open.setButtonText ("Open " + e.getName() + " window");
                open.onClick = [this] { plugin.showWindowExplicitly(); };
                addAndMakeVisible (params);
                addAndMakeVisible (info);
                info.setColour (Label::textColourId, Col::textDim);
                info.setText (e.isMissing() ? "This plugin isn't installed on this computer." : e.desc.manufacturerName + "  -  " + e.desc.pluginFormatName,
                              dontSendNotification);
            }

            void resized() override
            {
                auto r = getLocalBounds().reduced (10);
                auto top = r.removeFromTop (28);
                open.setBounds (top.removeFromLeft (260));
                info.setBounds (top.withTrimmedLeft (10));
                r.removeFromTop (8);
                params.setBounds (r);
            }

            te::ExternalPlugin& plugin;
            TextButton open;
            Label info;
            GenericPluginEditor params;
        };

        editor = std::make_unique<ExternalPanel> (*ext);
    }
    else
        editor = std::make_unique<GenericPluginEditor> (*p);

    editorViewport.setViewedComponent (editor.get(), false);
}

void DeviceChainPanel::showDeviceMenu (te::Plugin* p)
{
    PopupMenu m;
    te::Plugin::Ptr plugin = p;
    m.addItem ("Open in window", [plugin] { plugin->showWindowExplicitly(); });
    m.addItem (p->isEnabled() ? "Bypass" : "Enable", [this, plugin]
    {
        session.edit_().getUndoManager().beginNewTransaction ("Bypass");
        plugin->setEnabled (! plugin->isEnabled());
        rebuild();
    });

    if (! p->isSynth())
    {
        m.addItem ("Move left", [this, plugin]
        {
            if (auto t = track.get())
            {
                auto& list = t->pluginList;
                auto idx = list.indexOf (plugin.get());
                if (idx > 0 && ! list[idx - 1]->isSynth())
                {
                    session.edit_().getUndoManager().beginNewTransaction ("Move effect");
                    plugin->removeFromParent();
                    list.insertPlugin (plugin, idx - 1, nullptr);
                }
            }
        });
        m.addItem ("Move right", [this, plugin]
        {
            if (auto t = track.get())
            {
                auto& list = t->pluginList;
                auto idx = list.indexOf (plugin.get());
                if (idx >= 0 && idx < Session::getVolumePluginIndex (*t) - 1)
                {
                    session.edit_().getUndoManager().beginNewTransaction ("Move effect");
                    plugin->removeFromParent();
                    list.insertPlugin (plugin, idx + 1, nullptr);
                }
            }
        });
    }

    m.addSeparator();
    m.addItem ("Remove", [this, plugin]
    {
        session.edit_().getUndoManager().beginNewTransaction ("Remove device");
        plugin->deleteFromParent();
    });
    m.showMenuAsync ({});
}

void DeviceChainPanel::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    g.setColour (Col::bg2);
    g.fillRect (getLocalBounds().removeFromTop (40));

    if (auto t = track.get())
    {
        g.setColour (t->getColour());
        g.fillRect (0, 0, 4, 40);
        g.setColour (Col::text);
        g.setFont (LodeLookAndFeel::font (14.0f, true));
        g.drawText (t->getName(), 12, 0, 150, 40, Justification::centredLeft, true);
    }
}

void DeviceChainPanel::resized()
{
    auto r = getLocalBounds();
    auto chain = r.removeFromTop (40).reduced (6, 6);
    chain.removeFromLeft (160);

    changeInstrument.setBounds (chain.removeFromRight (90));
    chain.removeFromRight (6);
    addFxButton.setBounds (chain.removeFromRight (90));
    chain.removeFromRight (10);

    for (auto* b : deviceButtons)
    {
        auto w = jmin (170, (int) GlyphArrangement::getStringWidth (LodeLookAndFeel::font (13.0f), b->getButtonText()) + 30);
        b->setBounds (chain.removeFromLeft (w));
        chain.removeFromLeft (14);
    }

    editorViewport.setBounds (r);
    emptyLabel.setBounds (r);

    if (editor != nullptr)
    {
        auto minW = dynamic_cast<DrumMachineEditor*> (editor.get()) != nullptr ? 760 : 520;
        editor->setSize (jmax (minW, r.getWidth() - editorViewport.getScrollBarThickness()),
                         jmax (300, r.getHeight() - (r.getWidth() < minW ? editorViewport.getScrollBarThickness() : 0)));
    }
}

} // namespace lode
