/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "TransportBar.h"

namespace lode
{
using namespace juce;

//==============================================================================
DragNumber::DragNumber (double mn, double mx, double st, int d)
    : minV (mn), maxV (mx), step (st), decimals (d)
{
    setMouseCursor (MouseCursor::UpDownResizeCursor);
}

void DragNumber::setValue (double v, bool notify)
{
    v = jlimit (minV, maxV, std::round (v / step) * step);
    if (std::abs (v - value) < 1.0e-9)
        return;

    value = v;
    repaint();

    if (notify && onChange)
        onChange (value);
}

void DragNumber::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (Col::bg0);
    g.fillRoundedRectangle (r, 4.0f);

    auto text = r.reduced (6.0f, 1.0f);
    if (caption.isNotEmpty())
    {
        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (9.5f));
        g.drawText (caption, text.removeFromTop (11.0f), Justification::centred);
    }

    g.setColour (Col::text);
    g.setFont (LodeLookAndFeel::font (jmin (17.0f, text.getHeight() * 0.9f), true));
    g.drawText (String (value, decimals) + suffix, text, Justification::centred);
}

void DragNumber::mouseDown (const MouseEvent&)
{
    dragStartValue = value;
}

void DragNumber::mouseDrag (const MouseEvent& e)
{
    auto fine = e.mods.isShiftDown() ? 0.1 : 1.0;
    setValue (dragStartValue - e.getDistanceFromDragStartY() * 0.25 * fine, true);
}

void DragNumber::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    auto inc = e.mods.isShiftDown() ? step : 1.0;
    setValue (value + (w.deltaY > 0 ? inc : -inc), true);
}

void DragNumber::mouseDoubleClick (const MouseEvent&)
{
    editor = std::make_unique<TextEditor>();
    addAndMakeVisible (*editor);
    editor->setBounds (getLocalBounds());
    editor->setJustification (Justification::centred);
    editor->setFont (LodeLookAndFeel::font (15.0f, true));
    editor->setText (String (value, decimals), false);
    editor->selectAll();
    editor->grabKeyboardFocus();

    auto finish = [this] (bool apply)
    {
        if (editor == nullptr) return;
        if (apply) setValue (editor->getText().getDoubleValue(), true);
        MessageManager::callAsync ([sp = SafePointer<DragNumber> (this)] { if (sp != nullptr) sp->editor.reset(); });
    };

    editor->onReturnKey = [finish] { finish (true); };
    editor->onEscapeKey = [finish] { finish (false); };
    editor->onFocusLost = [finish] { finish (true); };
}

//==============================================================================
TransportBar::TransportBar (Session& s, ApplicationCommandManager& cm)
    : session (s), commands (cm)
{
    auto& edit = session.edit_();

    for (auto* b : { &toStart, &play, &stopButton, &record, &loop, &metronome, &magnet, &keyboardButton, &browserButton })
        addAndMakeVisible (b);

    play.setOnColour (Col::green);
    record.setOnColour (Col::north);
    loop.setOnColour (Col::south);
    metronome.setOnColour (Col::yellow);
    magnet.setOnColour (Col::north);
    keyboardButton.setOnColour (Col::purple);
    browserButton.setOnColour (Col::south);

    toStart.onClick = [this] { session.goToStart(); };
    play.onClick = [this] { session.togglePlay(); refresh(); };
    stopButton.onClick = [this] { session.stop(); refresh(); };
    record.onClick = [this] { session.toggleRecord(); refresh(); };
    loop.onClick = [this, &edit] { auto& tc = edit.getTransport(); tc.looping = ! tc.looping.get(); refresh(); };
    metronome.onClick = [this, &edit] { edit.clickTrackEnabled = ! edit.clickTrackEnabled.get(); refresh(); };
    magnet.onClick = [this] { session.getView().snapOn = ! session.getView().snapOn.get(); refresh(); };
    keyboardButton.onClick = [this] { if (onToggleKeyboard) onToggleKeyboard(); };
    browserButton.onClick = [this] { if (onToggleBrowser) onToggleBrowser(); };
    browserButton.setToggleState (true, dontSendNotification);

    addAndMakeVisible (countIn);
    countIn.addItem ("No count-in", 1);
    countIn.addItem ("Count-in 1 bar", 2);
    countIn.addItem ("Count-in 2 bars", 3);
    countIn.setTooltip ("Count-in before recording");
    countIn.onChange = [this, &edit]
    {
        auto id = countIn.getSelectedId();
        edit.setCountInMode (id == 2 ? te::Edit::CountIn::oneBar : (id == 3 ? te::Edit::CountIn::twoBar : te::Edit::CountIn::none));
    };

    addAndMakeVisible (snapBox);
    int i = 1;
    for (auto [name, v] : std::initializer_list<std::pair<const char*, double>> {
             { "Bar", 4.0 }, { "1/2", 2.0 }, { "Beat", 1.0 }, { "1/8", 0.5 }, { "1/16", 0.25 }, { "1/32", 0.125 },
             { "1/8T", 1.0 / 3.0 }, { "1/16T", 1.0 / 6.0 } })
    {
        snapBox.addItem (name, i);
        snapBox.getProperties().set (String (i), v);
        ++i;
    }
    snapBox.setTooltip ("Grid size for snapping clips and notes");
    snapBox.onChange = [this]
    {
        session.getView().snapDivision = (double) snapBox.getProperties()[String (snapBox.getSelectedId())];
        session.sendChangeMessage();
    };

    addAndMakeVisible (tempo);
    tempo.caption = "BPM";
    tempo.onChange = [this] (double bpm)
    {
        session.edit_().getUndoManager().beginNewTransaction ("Tempo");
        session.setTempo (bpm);
    };

    addAndMakeVisible (tap);
    tap.setTooltip ("Tap tempo (T)");
    tap.onClick = [this] { session.tapTempo(); refresh(); };

    addAndMakeVisible (timeSig);
    for (auto [n, d, id] : std::initializer_list<std::tuple<int, int, int>> {
             { 2, 4, 1 }, { 3, 4, 2 }, { 4, 4, 3 }, { 5, 4, 4 }, { 6, 4, 5 }, { 7, 4, 6 }, { 3, 8, 7 }, { 5, 8, 8 }, { 6, 8, 9 }, { 7, 8, 10 }, { 9, 8, 11 }, { 12, 8, 12 } })
        timeSig.addItem (String (n) + "/" + String (d), id);
    timeSig.setTooltip ("Time signature");
    timeSig.onChange = [this]
    {
        auto parts = StringArray::fromTokens (timeSig.getText(), "/", {});
        if (parts.size() == 2)
        {
            session.edit_().getUndoManager().beginNewTransaction ("Time signature");
            session.setTimeSignature (parts[0].getIntValue(), parts[1].getIntValue());
        }
    };

    for (auto* l : { &positionLabel, &timeLabel, &cpuLabel })
    {
        addAndMakeVisible (l);
        l->setJustificationType (Justification::centred);
    }

    positionLabel.setFont (LodeLookAndFeel::font (20.0f, true));
    positionLabel.setColour (Label::textColourId, Col::text);
    timeLabel.setFont (LodeLookAndFeel::font (12.0f));
    timeLabel.setColour (Label::textColourId, Col::textDim);
    cpuLabel.setFont (LodeLookAndFeel::font (11.0f));
    cpuLabel.setColour (Label::textColourId, Col::textFaint);
    cpuLabel.setTooltip ("Audio engine CPU load");

    masterMeter = std::make_unique<LevelMeter> (findMasterMeter (edit), false);
    addAndMakeVisible (*masterMeter);
    masterMeter->setTooltip ("Master output level");

    edit.getTransport().addChangeListener (this);
    session.addChangeListener (this);
    refresh();
    startTimerHz (20);
}

TransportBar::~TransportBar()
{
    session.edit_().getTransport().removeChangeListener (this);
    session.removeChangeListener (this);
}

void TransportBar::changeListenerCallback (ChangeBroadcaster*)
{
    refresh();
}

void TransportBar::refresh()
{
    auto& edit = session.edit_();
    auto& tc = edit.getTransport();
    play.setToggleState (tc.isPlaying(), dontSendNotification);
    play.setIcon (tc.isPlaying() && ! tc.isRecording() ? "stop" : "play");
    record.setToggleState (tc.isRecording(), dontSendNotification);
    loop.setToggleState (tc.looping.get(), dontSendNotification);
    metronome.setToggleState (edit.clickTrackEnabled.get(), dontSendNotification);
    magnet.setToggleState (session.getView().snapOn.get(), dontSendNotification);

    tempo.setValue (session.getTempo(), false);

    auto mode = edit.getCountInMode();
    countIn.setSelectedId (mode == te::Edit::CountIn::oneBar ? 2 : (mode == te::Edit::CountIn::twoBar ? 3 : 1), dontSendNotification);

    auto div = session.getView().snapDivision.get();
    for (int i = 1; i <= snapBox.getNumItems(); ++i)
        if (std::abs ((double) snapBox.getProperties()[String (i)] - div) < 1.0e-6)
            snapBox.setSelectedId (i, dontSendNotification);

    if (auto ts = edit.tempoSequence.getTimeSig (0))
        timeSig.setText (String (ts->numerator.get()) + "/" + String (ts->denominator.get()), dontSendNotification);
}

void TransportBar::timerCallback()
{
    auto& edit = session.edit_();
    auto& tc = edit.getTransport();
    auto pos = tc.getPosition();
    auto beat = timeToBeat (edit, pos);

    positionLabel.setText (formatBarsBeats (beat, roundToInt (quarterNotesPerBar (edit))), dontSendNotification);
    timeLabel.setText (formatTime (pos.inSeconds()), dontSendNotification);

    auto cpu = session.engine.getDeviceManager().getCpuUsage();
    cpuLabel.setText ("CPU " + String (roundToInt (cpu * 100.0f)) + "%", dontSendNotification);
    cpuLabel.setColour (Label::textColourId, cpu > 0.8f ? Col::north : Col::textFaint);

    if (play.getToggleState() != tc.isPlaying() || record.getToggleState() != tc.isRecording())
        refresh();

    if (std::abs (tempo.getValue() - session.getTempo()) > 0.01)
        tempo.setValue (session.getTempo(), false);
}

void TransportBar::paint (Graphics& g)
{
    g.fillAll (Col::bg2);
    g.setColour (Col::bg0);
    g.fillRect (getLocalBounds().removeFromBottom (1));

    // the display well
    auto display = positionLabel.getBounds().getUnion (timeLabel.getBounds()).expanded (6, 2).toFloat();
    g.setColour (Col::bg0);
    g.fillRoundedRectangle (display, 6.0f);

    // brand
    g.setColour (Col::north);
    auto logo = Rectangle<float> (12.0f, 12.0f, 22.0f, 26.0f);
    g.fillPath (Draw::magnetIcon (logo));
    g.setColour (Col::south);
    g.fillRect (logo.getX(), logo.getY(), logo.getWidth() * 0.26f, 6.0f);
    g.setColour (Col::text);
    g.setFont (LodeLookAndFeel::font (16.0f, true));
    g.drawText ("Lodestone", 40, 0, 100, getHeight(), Justification::centredLeft);
}

void TransportBar::resized()
{
    auto r = getLocalBounds().reduced (8, 7);
    r.removeFromLeft (130);

    browserButton.setBounds (r.removeFromLeft (36));
    r.removeFromLeft (16);

    for (auto* b : { &toStart, &stopButton, &play, &record })
    {
        b->setBounds (r.removeFromLeft (38));
        r.removeFromLeft (4);
    }

    r.removeFromLeft (6);
    loop.setBounds (r.removeFromLeft (34));
    r.removeFromLeft (4);
    metronome.setBounds (r.removeFromLeft (34));
    r.removeFromLeft (4);
    countIn.setBounds (r.removeFromLeft (128).reduced (0, 4));
    r.removeFromLeft (14);

    auto display = r.removeFromLeft (150);
    positionLabel.setBounds (display.removeFromTop (display.getHeight() * 6 / 10));
    timeLabel.setBounds (display);
    r.removeFromLeft (14);

    tempo.setBounds (r.removeFromLeft (76));
    r.removeFromLeft (4);
    tap.setBounds (r.removeFromLeft (44).reduced (0, 4));
    r.removeFromLeft (8);
    timeSig.setBounds (r.removeFromLeft (64).reduced (0, 4));
    r.removeFromLeft (14);

    magnet.setBounds (r.removeFromLeft (34));
    r.removeFromLeft (2);
    snapBox.setBounds (r.removeFromLeft (76).reduced (0, 4));
    r.removeFromLeft (14);
    keyboardButton.setBounds (r.removeFromLeft (36));

    auto right = r.removeFromRight (190);
    cpuLabel.setBounds (right.removeFromLeft (64));
    masterMeter->setBounds (right.reduced (2, 10));
}

} // namespace lode
