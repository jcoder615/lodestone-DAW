# Lodestone

A friendly, open-source digital audio workstation for Linux that opens the projects you
made somewhere else. Built on [Tracktion Engine](https://github.com/Tracktion/tracktion_engine)
and [JUCE](https://juce.com). Licensed AGPL-3.0-or-later.

## Install (Linux Mint 22+, Ubuntu 24.04+, Debian 13+)

```
sudo apt install ./lodestone_0.9.0_amd64.deb
```

Use `apt`, not `dpkg -i`: apt pulls in the dependencies (FluidSynth, a General MIDI
SoundFont, Python 3, ffmpeg). The package is built on Ubuntu 24.04, so it needs glibc 2.39 or
newer - on Mint 21.x build from source instead (see below).

## What it does

- **Every MIDI controller at once.** Each controller either follows the selected track or is
  pinned to one track - e.g. an Akai MPD218 always plays the drums while your keyboard plays
  whatever track you click. Pad controllers are pinned to the Drums track automatically.
  No controller? `Ctrl+K` turns your computer keyboard into a piano (A W S E D F T G Y H U J K,
  Z/X octave, C/V velocity), and those notes record like any other MIDI input.
- **Drum machine.** 16 pads laid out like an MPD218 (pad 1 = note 36, bottom-left), velocity
  layers, choke groups (closed hat cuts the open hat), tune/decay/tone/pan per pad, sample
  start/end slicing, reverse, MIDI-learn any pad, and *Hold to Sample* to record your mic
  straight onto a pad. Four synthesized kits included (808, Punch, Lo-Fi Dust, Hand
  Percussion); Hydrogen drumkits are found automatically; save your own kits.
- **Step sequencer** with swing, Euclidean rhythms, fills and randomize, and a **piano roll**
  with scale lock, chord stamping, quantize, humanize, legato and arpeggiate.
- **Sounds:** the 128 General MIDI instruments + GM drum kits (FluidSynth), 15 synth presets
  (Tracktion's 4OSC), a sampler, and your plugins.
- **Effects:** reverb, delay, chorus, phaser, compressor, EQ, filter, pitch shift and all
  **186 Airwindows** effects, plus plugins.
- **Plugins:** VST3, LV2 and LADSPA, scanned out-of-process so a crashing plugin can't take
  Lodestone down. Windows **VST3** plugins work through
  [yabridge](https://github.com/robbert-vdh/yabridge). VST2 isn't supported (hosting it
  needs Steinberg's VST2 SDK, which can't be redistributed), so VST2-only plugins - Linux or
  Windows - won't load. Audio Units are macOS-only and can't exist on Linux.
- **Mixer** with inserts, pan, meters and master effects; **export** to WAV/FLAC/OGG (optional
  -14 LUFS loudness normalising), per-track stems, MIDI or DAWproject.
- Autosave every minute with crash recovery, undo for everything, a command palette (`F1`).

## Importing other DAWs' projects

`File > Open` (or `lodestone song.flp` from a terminal). The import becomes a new Lodestone
project in `~/Music/Lodestone/<name>/`, with the audio it uses copied next to it. A summary
lists anything that couldn't come across.

| Format | What carries over | What can't |
|---|---|---|
| **LMMS** `.mmp` `.mmpz` | tempo, time signature, all tracks and patterns, Beat/Bassline patterns and their placements (looped like LMMS does), sample tracks, volumes/pans/mutes, mixer-channel and master levels, AudioFileProcessor samples incl. start/end slices, DrumSynth `.ds` sounds (rendered by a port of LMMS's DrumSynth), SF2 Player soundfonts | LMMS's own synths (TripleOscillator, ZynAddSubFX, LB302...) become the nearest built-in sound; effects and automation are skipped |
| **FL Studio** `.flp` (FL 12 and newer, tested on FL 20 files; also zipped loop packages) | tempo, time signature, patterns and notes, playlist placements, audio clips, channel volume/pan, sampler channels, layers; VST plugins are matched by name if installed | FL's own instruments/effects only exist inside FL (replaced with similar sounds); FL factory samples aren't on Linux (drum sounds are substituted from the built-in kits); automation clips are skipped |
| **GarageBand** `.band`, **Logic Pro** `.logicx` (folder or `.zip`) - *experimental* | tempo and tempo changes, time signature, MIDI regions and notes, audio regions (position, trim, fades) with their audio (CAF/ALAC converted via ffmpeg), track names | Apple instruments/effects (MIDI tracks get a GM piano or drum kit); Drummer tracks and Live Loops; GarageBand 6 (2011) and older |
| **DAWproject** | tracks, MIDI and audio clips, volume/pan (import and export) | plugin states |
| **MIDI** `.mid` | every track, GM program changes and drum channel | - |

Imported mixes arrive without their compressors and limiters, so Lodestone renders the song
once after importing; if it would clip, every track is turned down by the same amount, and an
Airwindows *Clip Only* on the master catches any stray peaks (remove it in the Mixer if you like).

GarageBand/Logic import uses a reverse-engineered reader of Apple's undocumented ProjectData
format ([logicx](https://github.com/jonkubis/LogicProFormatWriter), MIT). It has been tested on
Logic sessions, not on a wide range of real GarageBand songs - if a project won't import,
GarageBand's *Share > Export Song to Disk* and *Export MIDI* always work.

## Keys worth knowing

| | |
|---|---|
| `Space` play/stop · `R` record · `L` loop · `C` metronome · `T` tap tempo | `Home` back to start |
| `S` split at playhead · `Q` quantize · `G` snap on/off · `Ctrl+D` duplicate | `Ctrl+Z` / `Ctrl+Shift+Z` undo/redo |
| `E` editor · `I` instrument · `X` mixer · `B` browser | `F1` / `Ctrl+Shift+P` command palette |
| `Ctrl+K` musical typing · `Ctrl+,` settings | Help > Keyboard Shortcuts for the full list |

## Command line

```
lodestone [project]              open a project or import one
lodestone --render IN OUT.wav    open/import IN and render it (.wav/.flac/.ogg), then exit
```

## Building from source

```
sudo apt install build-essential cmake ninja-build pkg-config git libfluidsynth-dev \
    libasound2-dev libjack-jackd2-dev libfreetype-dev libfontconfig1-dev libx11-dev \
    libxrandr-dev libxinerama-dev libxcursor-dev libxcomposite-dev librsvg2-bin dpkg-dev python3
scripts/fetch_deps.sh        # Tracktion Engine + JUCE at the pinned commits, + patches/
scripts/build_deb.sh         # -> dist/lodestone_<version>_<arch>.deb
```

The first build compiles Tracktion Engine and JUCE (15-30 minutes on a laptop); after that
only Lodestone's own sources rebuild. `scripts/make_kits.py` (needs numpy + scipy) regenerates
the drum kits; `tests/` has the UI smoke-test and render-check helpers used during development.

`patches/0001-juce-linux-nested-dispatch.patch` fixes a JUCE use-after-free on Linux when a
modal progress window runs inside a message callback (it crashed imports).

## Licence

Lodestone is free software under the GNU Affero General Public License v3 or later
(`LICENSE.md`). It statically links Tracktion Engine (GPLv3+), JUCE (AGPLv3), Airwindows (MIT),
SoundTouch (LGPL-2.1+) and Signalsmith Stretch (MIT), and uses FluidSynth (LGPL-2.1+).
The importers include a Python port of LMMS's DrumSynth (GPL-2.0+) and a subset of logicx (MIT).
The drum kits are synthesized from scratch and released as CC0. See `packaging/copyright`.
