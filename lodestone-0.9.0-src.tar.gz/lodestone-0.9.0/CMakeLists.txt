cmake_minimum_required(VERSION 3.22)

project(Lodestone VERSION 0.9.0 LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

set(TE_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/tracktion_engine" CACHE PATH "Tracktion Engine checkout")

add_subdirectory("${TE_DIR}/modules/juce" "${CMAKE_BINARY_DIR}/juce" EXCLUDE_FROM_ALL)
add_subdirectory("${TE_DIR}/modules" "${CMAKE_BINARY_DIR}/tracktion" EXCLUDE_FROM_ALL)

find_package(PkgConfig REQUIRED)
pkg_check_modules(FLUIDSYNTH REQUIRED IMPORTED_TARGET fluidsynth)

#==============================================================================
# The engine: JUCE + Tracktion Engine compiled once into a static library so
# that app edits never trigger an engine rebuild.
add_library(lodestone_engine STATIC)

target_link_libraries(lodestone_engine
    PRIVATE
        tracktion::tracktion_core
        tracktion::tracktion_engine
        tracktion::tracktion_graph
        juce::juce_audio_devices
        juce::juce_audio_processors
        juce::juce_audio_utils
        juce::juce_gui_extra
        juce::juce_dsp
        juce::juce_osc
    PUBLIC
        juce::juce_recommended_config_flags)

target_compile_definitions(lodestone_engine
    PUBLIC
        JUCE_GLOBAL_MODULE_SETTINGS_INCLUDED=1
        JUCE_STANDALONE_APPLICATION=1
        JUCE_PLUGINHOST_VST3=1
        JUCE_PLUGINHOST_LV2=1
        JUCE_PLUGINHOST_LADSPA=1
        JUCE_PLUGINHOST_AU=0
        JUCE_PLUGINHOST_VST=0
        JUCE_MODAL_LOOPS_PERMITTED=1
        JUCE_STRICT_REFCOUNTEDPOINTER=1
        JUCE_USE_CURL=0
        JUCE_WEB_BROWSER=0
        JUCE_USE_MP3AUDIOFORMAT=1
        JUCE_USE_FLAC=1
        JUCE_USE_OGGVORBIS=1
        JUCE_JACK=1
        JUCE_ALSA=1
        JUCE_DISPLAY_SPLASH_SCREEN=0
        TRACKTION_AIR_WINDOWS=1
        TRACKTION_ENABLE_TIMESTRETCH_SOUNDTOUCH=1
        TRACKTION_ENABLE_TIMESTRETCH_SIGNALSMITH=1
        TRACKTION_LOG_DEVICES=0
    INTERFACE
        $<TARGET_PROPERTY:lodestone_engine,COMPILE_DEFINITIONS>)

target_include_directories(lodestone_engine
    INTERFACE $<TARGET_PROPERTY:lodestone_engine,INCLUDE_DIRECTORIES>)

set_target_properties(lodestone_engine PROPERTIES POSITION_INDEPENDENT_CODE TRUE)
target_compile_options(lodestone_engine PRIVATE -w)

#==============================================================================
# The app
juce_add_gui_app(Lodestone
    PRODUCT_NAME "lodestone"
    COMPANY_NAME "Lodestone"
    BUNDLE_ID "io.github.lodestone"
    NEEDS_CURL FALSE
    NEEDS_WEB_BROWSER FALSE)

file(GLOB LODESTONE_SOURCES CONFIGURE_DEPENDS "${CMAKE_CURRENT_SOURCE_DIR}/src/*.cpp")
target_sources(Lodestone PRIVATE ${LODESTONE_SOURCES})
target_include_directories(Lodestone PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
target_precompile_headers(Lodestone PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src/Common.h")

target_compile_definitions(Lodestone PRIVATE
    LODESTONE_VERSION="${PROJECT_VERSION}"
    JUCE_APPLICATION_NAME_STRING="Lodestone"
    JUCE_APPLICATION_VERSION_STRING="${PROJECT_VERSION}")

target_link_libraries(Lodestone PRIVATE
    lodestone_engine
    PkgConfig::FLUIDSYNTH
    "-latomic")

target_compile_options(Lodestone PRIVATE -Wall -Wno-unused-parameter -Wno-sign-compare -Wno-unknown-pragmas)

install(TARGETS Lodestone RUNTIME DESTINATION bin)
