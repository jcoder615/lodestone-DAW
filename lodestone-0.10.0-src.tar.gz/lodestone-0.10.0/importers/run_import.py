#!/usr/bin/env python3
"""
Lodestone importer entry point.

    python3 -I run_import.py <project> --workdir <dir> [--pretty]

Prints the project as LIF JSON between ===LIF-BEGIN=== / ===LIF-END===, or a
user-facing message after ===ERROR===. Media the project needs is copied (and if
necessary converted) into --workdir, which is the new project's media folder.
"""
import argparse
import os
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lodestone_import import ImportFailure, import_project  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("source")
    ap.add_argument("--workdir", required=True)
    ap.add_argument("--pretty", action="store_true", help="indent the JSON (for debugging)")
    args = ap.parse_args()

    os.makedirs(args.workdir, exist_ok=True)

    try:
        lif = import_project(args.source, args.workdir)
    except ImportFailure as e:
        print("===ERROR===")
        print(str(e))
        return 1
    except Exception as e:  # noqa: BLE001 - report anything to the user rather than dying silently
        print("===ERROR===")
        print(f"The importer hit an unexpected problem: {type(e).__name__}: {e}")
        print()
        print("".join(traceback.format_exc().splitlines(True)[-6:]))
        return 1

    import json
    print("===LIF-BEGIN===")
    print(json.dumps(lif.to_dict(), indent=2 if args.pretty else None, separators=None if args.pretty else (",", ":")))
    print("===LIF-END===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
