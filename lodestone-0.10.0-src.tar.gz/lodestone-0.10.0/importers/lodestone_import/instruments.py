"""Picking Lodestone instruments for sounds we can't carry over exactly."""
import re

# must match SynthPresets.cpp
SYNTH_PRESETS = ["Saw Lead", "Square Lead", "Supersaw", "Sub Bass", "Acid Bass", "Reese Bass", "Warm Pad",
                 "String Pad", "Pluck", "Bell", "Organ", "Brass", "Soft Keys", "Chiptune", "Init (Sine)"]

_SYNTH_RULES = [
    (("acid", "303", "tb303", "lb302", "squelch"), "Acid Bass"),
    (("reese", "wobble", "growl", "neuro"), "Reese Bass"),
    (("sub", "808 bass", "bass"), "Sub Bass"),
    (("supersaw", "trance", "hoover", "stab"), "Supersaw"),
    (("chip", "8bit", "8 bit", "nes", "gameboy", "sid", "c64", "papu", "freeboy", "sfxr", "square"), "Chiptune"),
    (("pluck", "pizz", "harp", "arp"), "Pluck"),
    (("bell", "chime", "glock", "fm"), "Bell"),
    (("organ", "hammond", "organic"), "Organ"),
    (("brass", "horn", "trumpet"), "Brass"),
    (("string", "violin", "cello", "orch"), "String Pad"),
    (("pad", "atmos", "ambient", "drone", "texture", "choir", "warm"), "Warm Pad"),
    (("key", "piano", "rhodes", "epiano", "ep "), "Soft Keys"),
    (("lead", "saw", "synth", "osc"), "Saw Lead"),
    (("sine", "sin "), "Init (Sine)"),
]


def _norm(name):
    return " " + re.sub(r"[^a-z0-9]+", " ", str(name).lower()) + " "


def _has(n, key):
    key = key.strip()
    return (" " + key + " ") in n if len(key) <= 3 else key in n


def synth_preset_for(name, default="Saw Lead"):
    n = _norm(name)
    for keys, preset in _SYNTH_RULES:
        if any(_has(n, k) for k in keys):
            return preset
    return default


def synth(name, default="Saw Lead"):
    return {"type": "synth", "preset": synth_preset_for(name, default)}


def gm(program, bank=0):
    return {"type": "gm", "program": int(program), "bank": int(bank)}


GM_DRUMS = {"type": "gm", "program": 0, "bank": 128}
