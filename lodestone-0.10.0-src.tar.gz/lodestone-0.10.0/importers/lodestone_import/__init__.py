"""Lodestone project importers: LMMS, FL Studio, GarageBand / Logic Pro -> LIF JSON."""
import shutil
import tempfile
import zipfile
from pathlib import Path

from .lif import ImportFailure, LIF

__all__ = ["import_project", "ImportFailure", "LIF"]

PROJECT_EXTS = (".flp", ".mmp", ".mmpz", ".band", ".logicx")


def _safe_extract(zip_path, dest):
    dest = Path(dest).resolve()
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            target = (dest / info.filename).resolve()
            if dest != target and dest not in target.parents:
                continue                     # never write outside the extraction folder
            if info.filename.startswith("__MACOSX/"):
                continue
            z.extract(info, dest)


def _import_zip(p, workdir):
    """FL Studio 'zipped loop packages', zipped LMMS projects and zipped .band/.logicx bundles."""
    try:
        with zipfile.ZipFile(p) as z:
            names = [n for n in z.namelist() if not n.startswith("__MACOSX/")]
    except zipfile.BadZipFile as e:
        raise ImportFailure(f"This zip file is damaged: {e}")

    lowered = [n.lower().rstrip("/") for n in names]
    if any(".band/" in n or ".logicx/" in n or n.endswith((".band", ".logicx")) for n in lowered):
        from .apple import import_apple
        return import_apple(p, workdir)

    if not any(n.endswith((".flp", ".mmp", ".mmpz")) for n in lowered):
        raise ImportFailure("There's no FL Studio, LMMS, GarageBand or Logic project inside this zip.")

    tmp = Path(tempfile.mkdtemp(prefix="lodestone-zip-"))
    try:
        _safe_extract(p, tmp)
        projects = sorted([f for f in tmp.rglob("*") if f.suffix.lower() in (".flp", ".mmp", ".mmpz")],
                          key=lambda f: (len(f.parts), f.name))
        if not projects:
            raise ImportFailure("There's no FL Studio or LMMS project inside this zip.")
        lif = import_project(projects[0], workdir)
        if len(projects) > 1:
            lif.warn(f"The zip held {len(projects)} projects - imported {projects[0].name}")
        return lif
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def import_project(source, workdir):
    p = Path(source)
    if not p.exists():
        raise ImportFailure(f"{source} doesn't exist.")

    name = p.name.lower()
    ext = p.suffix.lower()

    if ext in (".mmp", ".mmpz"):
        from .lmms import import_lmms
        return import_lmms(p, workdir)

    if ext == ".flp":
        from .flp import import_flp
        return import_flp(p, workdir)

    if ext == ".zip":
        return _import_zip(p, workdir)

    if ext in (".band", ".logicx") or name.endswith((".band.zip", ".logicx.zip")) or p.is_dir():
        from .apple import import_apple
        return import_apple(p, workdir)

    raise ImportFailure(f"Lodestone doesn't know how to import \"{p.name}\" files.")
