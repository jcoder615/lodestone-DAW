"""
GarageBand (.band) and Logic Pro (.logicx) projects.

Both apps store the song in an undocumented little-endian binary, ProjectData
(Alternatives/NNN/ProjectData; very old GarageBand used a root-level projectData).
It's decoded with the vendored, read-only part of logicx (MIT, Jon Kubis), which was
reverse-engineered against Logic Pro sessions. GarageBand 10 writes the same format,
but this path is far less tested than LMMS/FL import - expect gaps.

What carries over: tempo (and tempo changes), time signature, MIDI regions and their
notes, audio regions (position, trim, length, fades) with their audio files
(CAF/ALAC/AAC converted to WAV via ffmpeg). Apple's instruments (Alchemy, Sampler,
Drum Kit Designer, Drummer...) and effects can't run on Linux; MIDI tracks get a
General MIDI piano or drum kit, chosen from the notes they play.
"""
import os
import plistlib
import shutil
import tempfile
import zipfile
from pathlib import Path

from .common import AUDIO_EXTS, FileIndex, MediaCollector
from .instruments import GM_DRUMS, gm
from .lif import LIF, ImportFailure, audio_clip, bars_ceil, midi_clip

PPQ = 960.0
DRUM_NOTES = {35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 59}


def _bundle_root(p: Path):
    """The .band/.logicx directory for a path inside or at it."""
    for cand in [p, *p.parents]:
        if cand.suffix.lower() in (".band", ".logicx") and cand.is_dir():
            return cand
    return p if p.is_dir() else p.parent


def _find_project_data(root: Path):
    alts = sorted((root / "Alternatives").glob("*/ProjectData")) if (root / "Alternatives").is_dir() else []
    if alts:
        # "000" is the main alternative; otherwise the most recently saved one
        main = [a for a in alts if a.parent.name == "000"]
        return main[0] if main else max(alts, key=lambda a: a.stat().st_mtime)
    for name in ("projectData", "ProjectData"):
        if (root / name).is_file():
            return root / name
    hits = list(root.rglob("ProjectData"))
    return hits[0] if hits else None


def _read_plist(path):
    try:
        with open(path, "rb") as f:
            return plistlib.load(f)
    except Exception:  # noqa: BLE001 - metadata is optional
        return {}


class Importer:
    def __init__(self, path, workdir):
        self.src = Path(path)
        self.workdir = Path(workdir)
        self.lif = LIF(workdir)
        self.media = MediaCollector(workdir, self.lif)
        self.extracted = None

    def open_bundle(self):
        p = self.src
        if p.is_file() and p.suffix.lower() == ".zip":
            self.extracted = Path(tempfile.mkdtemp(prefix="lodestone-apple-"))
            from . import _safe_extract
            try:
                _safe_extract(p, self.extracted)
            except zipfile.BadZipFile as e:
                raise ImportFailure(f"This zip file is damaged: {e}")
            bundles = [d for d in self.extracted.rglob("*") if d.is_dir() and d.suffix.lower() in (".band", ".logicx")]
            p = bundles[0] if bundles else self.extracted
        return _bundle_root(p)

    def run(self):
        try:
            return self._run()
        finally:
            if self.extracted is not None:
                shutil.rmtree(self.extracted, ignore_errors=True)

    def _run(self):
        root = self.open_bundle()
        pd_path = _find_project_data(root)
        if pd_path is None:
            if (root / "Output").is_dir() or (root / "Media").is_dir():
                raise ImportFailure("This GarageBand project has no ProjectData inside. Projects from GarageBand 6 "
                                    "(2011) or older use a format Lodestone can't read - open and re-save it in a "
                                    "newer GarageBand first.")
            raise ImportFailure("Couldn't find the song data (ProjectData) inside this project. If it came from a "
                                "Mac, copy the whole .band/.logicx folder (it's a package), or zip it on the Mac first.")

        try:
            from .vendor.logicx import ProjectData, session_model
            from .vendor.logicx import inspect as lx
            pd = ProjectData.parse(pd_path.read_bytes())
            model = session_model(pd)
        except ImportFailure:
            raise
        except Exception as e:  # noqa: BLE001 - the decoder is reverse-engineered; fail with a clear message
            raise ImportFailure(f"Lodestone couldn't decode this project's ProjectData ({type(e).__name__}: {e}). "
                                "GarageBand/Logic import is experimental; exporting MIDI and audio stems from "
                                "GarageBand (Share > Export) and importing those always works.")

        meta = _read_plist(pd_path.parent / "MetaData.plist")
        lif = self.lif

        bpm = model.get("initial_bpm") or meta.get("BeatsPerMinute") or 120.0
        lif.tempo = float(bpm)
        tempo_map = model.get("tempo_map") or []
        if len(tempo_map) > 1:
            lif.tempo = float(tempo_map[0][1])
            lif.tempo_map = [[t / PPQ, float(b)] for t, b in tempo_map[1:] if t > 0]
        meters = model.get("meter_map") or []
        num, den = 4, 4
        if meters:
            _, num, den = meters[0]
            num, den = int(num) or 4, int(den) or 4
        elif meta.get("SongSignatureNumerator"):
            num, den = int(meta.get("SongSignatureNumerator", 4)), int(meta.get("SongSignatureDenominator", 4))
        lif.time_sig = [num, den]
        bar_beats = 4.0 * num / den
        lif.markers = [[t / PPQ, n] for t, n in model.get("markers", []) if n]

        sample_rate = float(model.get("sample_rate") or meta.get("SampleRate") or 44100)

        # track names: arrange row (karT, ordinal = track - 1) -> channel slot -> environment object name
        names = {}
        try:
            env_names = {e.get("slot"): e.get("name") for e in lx.environment(pd)
                         if e.get("kind") in (4, 5) and e.get("name")}
            for row in lx.tracks(pd):
                if row.get("cluster") == 0x40000 and row.get("populated") and row.get("row_type") == 1:
                    nm = env_names.get(row.get("channel_slot"))
                    if nm:
                        names.setdefault(row["ordinal"] + 1, nm)
        except Exception:  # noqa: BLE001 - names are a nicety
            names = {}

        index = FileIndex([root, root.parent], max_files=20000)
        track_numbers = sorted(model.get("tracks", []))
        tracks = {}

        def track(num, kind):
            key = (num, kind)
            if key in tracks:
                return tracks[key]
            name = names.get(num) or (f"Audio {num}" if kind == "audio" else f"Track {num}")
            t = lif.add_track(name, kind if kind == "audio" else "instrument")
            tracks[key] = t
            return t

        # ---- MIDI regions
        drums_votes = {}
        for r in model.get("midi_regions", []):
            notes = r.get("notes") or []
            if not notes:
                continue
            t = track(r["track"], "midi")
            start = r["position_tick"] / PPQ
            end = max((tk + max(ln, 1)) / PPQ for tk, _p, _v, ln in notes)
            length = bars_ceil(end, bar_beats)
            t["clips"].append(midi_clip(start, length, [(tk / PPQ, max(ln, 1) / PPQ, p, v) for tk, p, v, ln in notes]))
            votes = drums_votes.setdefault(id(t), [0, 0])
            for _tk, p, _v, _ln in notes:
                votes[0 if p in DRUM_NOTES else 1] += 1

        for (num_, kind), t in tracks.items():
            if kind != "midi":
                continue
            v = drums_votes.get(id(t), [0, 1])
            drums = v[0] > 0.75 * (v[0] + v[1]) and v[0] >= 4
            t["instrument"] = GM_DRUMS if drums else gm(0)
            t["kind"] = "drums" if drums else "instrument"

        # ---- audio regions
        # Logic/GarageBand play only the top region where regions overlap (they never sum), so
        # takes stacked at the same spot are reduced to the first one the session lists
        seen_spots, stacked = set(), 0
        regions = []
        for r in model.get("audio_regions", []):
            spot = (r["track"], r["position_tick"], r.get("length_samples"))
            if spot in seen_spots:
                stacked += 1
                continue
            seen_spots.add(spot)
            regions.append(r)
        if stacked:
            lif.warn(f"{stacked} stacked take(s) at the same position were dropped (GarageBand/Logic only plays the top one)")

        missing = set()
        for r in regions:
            fname = r.get("file")
            if not fname:
                continue
            found = index.find(fname) or index.find_stem(os.path.splitext(fname)[0])
            if found is None:
                missing.add(fname)
                continue
            local = self.media.add(Path(found))
            if local is None:
                continue
            t = track(r["track"], "audio")
            length_s = (r.get("length_samples") or 0) / sample_rate
            trim_s = (r.get("trim_in_samples") or 0) / sample_rate
            t["clips"].append(audio_clip(r["position_tick"] / PPQ, local, length_seconds=length_s or None,
                                         name=(r.get("name") or "").strip() or None, offset_seconds=trim_s,
                                         fade_in=(r.get("fade_in") or 0) / sample_rate,
                                         fade_out=(r.get("fade_out") or 0) / sample_rate))
        if missing:
            shown = ", ".join(sorted(missing)[:6]) + (" ..." if len(missing) > 6 else "")
            lif.warn(f"{len(missing)} audio file(s) weren't inside the project: {shown}")

        if model.get("take_folders"):
            lif.warn("Take folders were flattened to the take/comp GarageBand or Logic was playing")

        lif.warn("GarageBand/Logic import is experimental: Apple's instruments and effects can't run on Linux, "
                 "so MIDI tracks use General MIDI sounds (change them in the Instrument panel)")

        lif.tracks = [t for t in lif.tracks if t["clips"]]
        # keep the project's track order
        lif.tracks.sort(key=lambda t: next((n for (n, k), tt in tracks.items() if tt is t), 0))
        if not lif.tracks:
            lif.warn("No MIDI or audio regions were found. GarageBand Drummer tracks and Live Loops "
                     "aren't stored as notes, so they can't be imported.")
        return lif


def import_apple(path, workdir):
    return Importer(path, workdir).run()
