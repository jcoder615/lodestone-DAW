"""
Lodestone Interchange Format (LIF) - the JSON every importer produces.

The C++ side (ProjectIO.cpp, addLIFToCurrentEdit) turns it into a Tracktion Edit:

{
  "tempo": 120.0, "timeSig": [4, 4],
  "tempoMap": [[beat, bpm], ...],            optional, beat 0 is "tempo"
  "loop": [startBeat, endBeat],              optional
  "markers": [[beat, "name"], ...],          optional
  "masterVolumeDb": -6.0,                    optional
  "masterSafetyClip": true,                  optional: Airwindows Clip Only on the master
  "baseDir": "/work/dir",                    relative kit-pad paths resolve here
  "warnings": ["..."],
  "tracks": [{
      "name": "Drums", "kind": "instrument" | "drums" | "audio",
      "color": "#rrggbb", "volumeDb": 0.0, "pan": 0.0, "mute": false, "solo": false,
      "instrument": {"type": "gm", "program": 0, "bank": 0}
                  | {"type": "sf2", "file": "...", "program": 0, "bank": 0}
                  | {"type": "drumkit", "kitDir": "..."} | {"type": "drumkit", "name": "..", "pads": [...kit.json pads...]}
                  | {"type": "synth", "preset": "Saw Lead"}
                  | {"type": "sampler", "file": "...", "root": 60}
                  | {"type": "plugin", "name": "Serum", "fallback": {...}},
      "clips": [
          {"type": "midi", "start": beats, "length": beats, "name": "..", "notes": [[beat, len, pitch, vel], ...]},
          {"type": "audio", "start": beats, "file": "/abs.wav", "length": beats, "offsetSeconds": 0.0, "gainDb": 0.0}
      ]
  }]
}
All times are in quarter-note beats; note positions are relative to their clip.
"""
import json
import math


class ImportFailure(Exception):
    """An error message meant for the user (shown in an alert as-is)."""


class LIF:
    def __init__(self, base_dir=""):
        self.tempo = 120.0
        self.time_sig = [4, 4]
        self.tempo_map = []
        self.markers = []
        self.loop = None
        self.base_dir = str(base_dir)
        self.tracks = []
        self.warnings = []
        self.master_volume_db = None
        self.safety_clip = True       # imported mixes lose their mastering effects; never let them clip

    def warn(self, message):
        if message not in self.warnings:
            self.warnings.append(message)

    def add_track(self, name, kind="instrument", instrument=None, **props):
        t = {"name": name or "Track", "kind": kind, "clips": []}
        if instrument:
            t["instrument"] = instrument
        for k, v in props.items():
            if v is not None:
                t[k] = v
        self.tracks.append(t)
        return t

    def to_dict(self):
        # drop empty instrument tracks that carry nothing (e.g. unused rack channels)
        d = {
            "tempo": round(float(self.tempo), 4),
            "timeSig": self.time_sig,
            "baseDir": self.base_dir,
            "warnings": self.warnings,
            "tracks": self.tracks,
        }
        if self.tempo_map:
            d["tempoMap"] = self.tempo_map
        if self.markers:
            d["markers"] = self.markers
        if self.loop:
            d["loop"] = self.loop
        if self.master_volume_db is not None and self.master_volume_db < -0.05:
            # the safety clipper sits before Tracktion's master fader, so fold the master
            # level into the tracks instead and leave the master at unity
            for t in self.tracks:
                t["volumeDb"] = round(max(-60.0, float(t.get("volumeDb", 0.0)) + self.master_volume_db), 2)
        elif self.master_volume_db is not None:
            d["masterVolumeDb"] = self.master_volume_db
        if self.safety_clip:
            d["masterSafetyClip"] = True
        return d

    def to_json(self):
        return json.dumps(self.to_dict(), separators=(",", ":"))


def midi_clip(start, length, notes, name=None, color=None, mute=False):
    c = {"type": "midi", "start": round(start, 6), "length": round(max(length, 0.25), 6),
         "notes": [[round(b, 6), round(max(l, 1.0 / 64), 6), int(p), int(max(1, min(127, v)))] for b, l, p, v in notes]}
    if name:
        c["name"] = name
    if color:
        c["color"] = color
    if mute:
        c["mute"] = True
    return c


def audio_clip(start, file, length=None, name=None, offset_seconds=0.0, gain_db=0.0, mute=False,
               fade_in=0.0, fade_out=0.0, length_seconds=None):
    c = {"type": "audio", "start": round(start, 6), "file": str(file)}
    if length is not None and length > 0:
        c["length"] = round(length, 6)
    elif length_seconds is not None and length_seconds > 0:
        c["lengthSeconds"] = round(length_seconds, 6)
    if name:
        c["name"] = name
    if offset_seconds > 0:
        c["offsetSeconds"] = round(offset_seconds, 6)
    if gain_db:
        c["gainDb"] = round(gain_db, 3)
    if mute:
        c["mute"] = True
    if fade_in > 0:
        c["fadeInSeconds"] = round(fade_in, 4)
    if fade_out > 0:
        c["fadeOutSeconds"] = round(fade_out, 4)
    return c


def gain_to_db(g, floor=-60.0):
    return floor if g <= 0 else max(floor, 20.0 * math.log10(g))


def bars_ceil(beats, beats_per_bar=4.0):
    return max(beats_per_bar, math.ceil(beats / beats_per_bar - 1e-6) * beats_per_bar)


def colour_hex(rgb):
    r, g, b = (max(0, min(255, int(x))) for x in rgb)
    return "#%02x%02x%02x" % (r, g, b)
