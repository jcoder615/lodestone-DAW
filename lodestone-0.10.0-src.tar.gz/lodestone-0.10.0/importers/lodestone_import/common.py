"""Shared helpers: finding samples that moved, bundled substitutes, audio conversion."""
import os
import re
import shutil
import subprocess
from pathlib import Path, PureWindowsPath

# formats Lodestone (JUCE) reads natively; anything else goes through ffmpeg
NATIVE_AUDIO = {".wav", ".wave", ".aif", ".aiff", ".aifc", ".flac", ".ogg", ".mp3"}
CONVERTIBLE_AUDIO = {".caf", ".m4a", ".aac", ".mp4", ".alac", ".wma", ".opus", ".wv", ".ape"}
AUDIO_EXTS = NATIVE_AUDIO | CONVERTIBLE_AUDIO


def importer_root():
    return Path(__file__).resolve().parent.parent


def find_kits_dir():
    """The bundled kits: /usr/share/lodestone/kits when installed, resources/kits in a checkout."""
    root = importer_root()
    for cand in (root.parent.parent / "share" / "lodestone" / "kits",      # /usr/lib/lodestone/importers -> /usr/share
                 root.parent / "resources" / "kits",                       # source checkout
                 Path("/usr/share/lodestone/kits"),
                 Path("/usr/local/share/lodestone/kits")):
        if (cand / "808" / "kit.json").exists():
            return cand
    return None


# keyword -> (kit, file) of the bundled synthesized kits, most specific first
_SUBSTITUTES = [
    (("open hat", "openhat", "open_hat", "ohat", " oh ", "hat open", "hh open", "hihat open"), "808", "11_open_hat.wav"),
    (("pedal",), "808", "09_pedal_hat.wav"),
    (("closed hat", "closedhat", "hat", "hh", "hihat", "hi-hat", "chh"), "808", "07_closed_hat_v3.wav"),
    (("808", "sub kick", "subkick", "boom"), "808", "01_kick_v3.wav"),
    (("kick", "bd", "bassdrum", "bass drum", "kik"), "punch", "01_kick_v3.wav"),
    (("snare", "sd", "snr"), "punch", "03_snare_v3.wav"),
    (("clap", "clp"), "808", "04_clap.wav"),
    (("rim", "stick"), "808", "02_rim.wav"),
    (("snap",), "percussion", "16_finger_snap.wav"),
    (("crash", "cymbal", "cym"), "808", "14_crash.wav"),
    (("ride",), "808", "16_ride.wav"),
    (("cowbell", "bell"), "808", "15_cowbell.wav"),
    (("conga",), "percussion", "02_mid_conga.wav"),
    (("bongo",), "percussion", "05_high_bongo.wav"),
    (("shaker", "shake", "maraca", "cabasa"), "percussion", "07_shaker_v2.wav"),
    (("tamb",), "percussion", "08_tambourine.wav"),
    (("clave",), "percussion", "09_clave.wav"),
    (("wood", "block"), "percussion", "10_woodblock.wav"),
    (("triangle",), "percussion", "11_triangle.wav"),
    (("tom", "floor"), "808", "10_mid_tom.wav"),
    (("perc",), "percussion", "15_timbale.wav"),
]


def _words(name):
    return " " + re.sub(r"[^a-z0-9]+", " ", str(name).lower()) + " "


def _has(words, key):
    """Short keys ('bd', 'oh') must be whole words; longer ones may be substrings ('kick' in 'kick01')."""
    key = key.strip()
    return (" " + key + " ") in words if len(key) <= 3 else key in words


def substitute_drum_sample(name):
    """A bundled sound that matches a drum sample's name, or None."""
    kits = find_kits_dir()
    if kits is None:
        return None
    n = _words(name)
    for keys, kit, fname in _SUBSTITUTES:
        if any(_has(n, k) for k in keys):
            f = kits / kit / fname
            if f.exists():
                return f
    return None


def looks_like_drum(name):
    n = _words(name)
    words = ("kick", "snare", "clap", "hat", "hihat", "cymbal", "crash", "ride", "tom", "perc", "rim", "snap",
             "shaker", "conga", "bongo", "tamb", "cowbell", "clave", "808", "909", "drum", "bd", "sd", "hh", "oh", "ch",
             "kik", "snr", "clp", "impact")
    return any(_has(n, w) for w in words)


class FileIndex:
    """Lazy basename -> path index of a few directory trees, for samples whose stored
    path is from another machine (Windows paths in FL projects, /Users/... in GarageBand)."""

    def __init__(self, roots, max_files=60000):
        self.roots = [Path(r) for r in roots if r and Path(r).is_dir()]
        self.max_files = max_files
        self._index = None

    def _build(self):
        self._index = {}
        count = 0
        for root in self.roots:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if not d.startswith(".")]
                for f in filenames:
                    self._index.setdefault(f.lower(), os.path.join(dirpath, f))
                    count += 1
                    if count > self.max_files:
                        return

    def find(self, basename):
        if self._index is None:
            self._build()
        return self._index.get(basename.lower())

    def find_stem(self, stem):
        """Match ignoring the extension (a .wav that was converted to .flac, say), or a file
        that was renamed with a suffix (LMMS renamed 'jungle01.ogg' to 'jungle01 - 168 BPM.ogg')."""
        if self._index is None:
            self._build()
        stem = stem.lower()
        renamed = None
        for k, v in self._index.items():
            ks, ke = os.path.splitext(k)
            if ke not in AUDIO_EXTS and ke != ".ds":
                continue
            if ks == stem:
                return v
            if renamed is None and ks.startswith(stem + " - "):
                renamed = v
        return renamed


def path_basename(p):
    p = str(p).strip().strip('"')
    if "\\" in p or re.match(r"^[A-Za-z]:", p) or p.startswith("%"):
        return PureWindowsPath(p).name
    return os.path.basename(p)


def resolve_path(stored, project_dir, index=None, extra_dirs=()):
    """Find a file referenced by a project. Returns a Path or None."""
    if not stored:
        return None
    s = str(stored).strip().strip('"')
    for prefix in ("factorysample:", "usersample:", "factorypreset:", "userpreset:", "file://"):
        if s.lower().startswith(prefix):
            s = s[len(prefix):]
    s = os.path.expanduser(s)

    if os.path.isabs(s) and os.path.isfile(s):
        return Path(s)

    rel = s.replace("\\", "/")
    for base in [project_dir, *extra_dirs]:
        if base:
            cand = Path(base) / rel
            if cand.is_file():
                return cand

    base = path_basename(s)
    if index is not None and base:
        hit = index.find(base) or index.find_stem(os.path.splitext(base)[0])
        if hit:
            return Path(hit)
    return None


def have_ffmpeg():
    return shutil.which("ffmpeg") is not None


def unique_name(directory, name):
    directory = Path(directory)
    stem, ext = os.path.splitext(name)
    cand = directory / name
    i = 2
    while cand.exists():
        cand = directory / f"{stem} ({i}){ext}"
        i += 1
    return cand


class MediaCollector:
    """Copies (and if needed converts) referenced media into the work dir so the new
    project owns its audio. Remembers what it already copied."""

    def __init__(self, workdir, lif, subdir=""):
        self.dir = Path(workdir) / subdir if subdir else Path(workdir)
        self.lif = lif
        self.done = {}
        self.missing_ffmpeg_warned = False

    def add(self, src):
        src = Path(src)
        key = str(src.resolve())
        if key in self.done:
            return self.done[key]

        self.dir.mkdir(parents=True, exist_ok=True)
        ext = src.suffix.lower()
        out = None

        if ext in NATIVE_AUDIO:
            out = unique_name(self.dir, src.name)
            shutil.copy2(src, out)
        elif ext == ".ds":
            from .drumsynth import render_to_wav
            out = unique_name(self.dir, src.stem + ".wav")
            try:
                ok = render_to_wav(src, out)
            except Exception as e:  # noqa: BLE001
                ok = False
                self.lif.warn(f"Couldn't render DrumSynth sound {src.name}: {e}")
            if not ok:
                out = None
        else:
            out = self.convert(src)

        self.done[key] = out
        return out

    def convert(self, src):
        if not have_ffmpeg():
            if not self.missing_ffmpeg_warned:
                self.lif.warn("Some audio is in a format that needs ffmpeg to convert (e.g. Apple CAF/ALAC). "
                              "Install it with: sudo apt install ffmpeg - then import again.")
                self.missing_ffmpeg_warned = True
            return None
        out = unique_name(self.dir, src.stem + ".wav")
        try:
            subprocess.run(["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-i", str(src),
                            "-c:a", "pcm_s24le", str(out)], check=True, timeout=300,
                           stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as e:
            msg = (e.stderr or b"").decode("utf-8", "replace").strip().splitlines()
            self.lif.warn(f"Couldn't convert {src.name}" + (f": {msg[-1]}" if msg else ""))
            return None
        except Exception as e:  # noqa: BLE001 - any failure is reported, never fatal
            self.lif.warn(f"Couldn't convert {src.name}: {e}")
            return None
        return out if out.exists() else None


def audio_length_seconds(path):
    """Best-effort duration for WAV files (used to size clips when a project omits it)."""
    import wave
    try:
        with wave.open(str(path), "rb") as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:  # noqa: BLE001
        pass
    if have_ffmpeg() and shutil.which("ffprobe"):
        try:
            r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of",
                                "default=nw=1:nk=1", str(path)], capture_output=True, text=True, timeout=30)
            return float(r.stdout.strip())
        except Exception:  # noqa: BLE001
            return None
    return None
