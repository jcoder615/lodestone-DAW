"""
FL Studio projects (.flp).

The format is a flat stream of tagged events (see the PyFLP project's reverse
engineering, MIT): byte events (id < 64), word (64-127), dword (128-191) and
variable-length text/data events (192+, varint size). This reader walks the
stream once and keeps only what Lodestone can use:

  channels   - 64 new channel, 21 type (0 sampler, 2 generator, 3 layer, 4 audio clip,
               5 automation), 201 plugin internal name, 203 display name, 196 sample path,
               219 levels (pan, volume), 135 root note, 94 layer children, 213 plugin data
  patterns   - 65 new pattern, 193 name, 224 notes (24-byte records)
  playlist   - 99 new arrangement, 241 its name, 233 items (32 bytes, 60 from FL 21),
               238 new playlist track, 239 track name; 100 current arrangement
  song       - 156 tempo x1000 (or 66 + 93 in old files), 17/18 time signature, 199 version

What can't come across: FL's own synths/effects (they only exist inside FL) are swapped for
the closest Lodestone sound; VST plugins are matched by name if you have them installed;
automation clips and mixer effects are skipped (reported as warnings).
"""
import math
import os
import struct
from pathlib import Path

from .common import FileIndex, MediaCollector, looks_like_drum, resolve_path, substitute_drum_sample, path_basename
from .instruments import GM_DRUMS, gm, synth, synth_preset_for
from .lif import LIF, ImportFailure, audio_clip, gain_to_db, midi_clip, colour_hex

PATTERN_BASE = 20480

# FL native generators -> Lodestone instruments
NATIVE = {
    "3x osc": None,                       # guess from the channel name
    "boobass": gm(33),
    "fl keys": gm(0),
    "fruity dx10": {"type": "synth", "preset": "Bell"},
    "sytrus": None, "harmor": None, "harmless": None, "toxic biohazard": None, "poizone": None,
    "morphine": None, "gms": None, "sawer": None, "simsynth": None, "flex": None, "vital": None,
    "transistor bass": {"type": "synth", "preset": "Acid Bass"},
    "sakura": gm(48), "fruity granulizer": {"type": "synth", "preset": "Warm Pad"},
    "plucked!": {"type": "synth", "preset": "Pluck"},
    "autogun": None, "ogun": {"type": "synth", "preset": "Bell"},
    "drumaxx": GM_DRUMS, "fpc": GM_DRUMS, "fruity drumsynth live": GM_DRUMS, "drumpad": GM_DRUMS,
    "fruity soundfont player": None, "directwave": None, "fruity slicer": None, "slicex": None,
    "beepmap": None, "wasp": None, "wasp xt": None, "fruity bass": {"type": "synth", "preset": "Sub Bass"},
    "groove machine synth": None, "pyro": None, "kepler": None, "kepler exo": None, "nova": None,
}
KICK_GENERATORS = {"fruit kick", "fruity kick", "kick", "fruity kick 2"}
SILENT_GENERATORS = {"midi out", "fruity envelope controller", "fruity keyboard controller", "fruity dance",
                     "fruity voltage controller", "patcher", "fruity formula controller", "control surface",
                     "fruity x-y controller", "fruity peak controller", "fruity big clock"}


class Channel:
    def __init__(self, iid):
        self.iid = iid
        self.type = 0
        self.internal = ""
        self.name = ""
        self.sample = ""
        self.volume = 10000
        self.pan = 6400
        self.root = 60
        self.children = []
        self.color = None
        self.plugin_data = b""
        self.enabled = True

    @property
    def display(self):
        return self.name or self.internal or (os.path.splitext(path_basename(self.sample))[0] if self.sample else "") or f"Channel {self.iid + 1}"


class Pattern:
    def __init__(self, iid):
        self.iid = iid
        self.name = ""
        self.notes = []          # (pos, length, key, velocity, channel)
        self.color = None


class Item:
    __slots__ = ("pos", "length", "pattern", "channel", "track", "start_offset", "muted")


def read_events(data):
    if len(data) < 22 or data[:4] != b"FLhd":
        raise ImportFailure("This isn't an FL Studio project (the file doesn't start with an FLhd header).")
    hlen = struct.unpack_from("<I", data, 4)[0]
    if hlen != 6:
        raise ImportFailure("This FL Studio project's header is damaged.")
    fmt, _nchan, ppq = struct.unpack_from("<hHH", data, 8)
    if fmt != 0:
        kinds = {0x10: "a score (.fsc)", 0x18: "an automation clip", 0x20: "a channel preset (.fst)",
                 0x30: "a plugin preset", 0x50: "a generator preset", 0x58: "an effect preset"}
        if fmt in kinds:
            raise ImportFailure(f"This FL Studio file is {kinds[fmt]}, not a project - open the .flp it came from instead.")
        raise ImportFailure(f"This file isn't an FL Studio project (unknown file type {fmt}).")
    if ppq <= 0:
        raise ImportFailure("This FL Studio project's timing resolution is invalid.")
    pos = 8 + hlen
    if data[pos:pos + 4] != b"FLdt":
        raise ImportFailure("This FL Studio project's data section is damaged.")
    dlen = struct.unpack_from("<I", data, pos + 4)[0]
    pos += 8
    end = min(len(data), pos + dlen)
    events = []
    while pos < end:
        eid = data[pos]
        pos += 1
        if eid < 64:
            if pos + 1 > end:
                break
            val = data[pos]
            pos += 1
        elif eid < 128:
            if pos + 2 > end:
                break
            val = struct.unpack_from("<H", data, pos)[0]
            pos += 2
        elif eid < 192:
            if pos + 4 > end:
                break
            val = struct.unpack_from("<I", data, pos)[0]
            pos += 4
        else:
            size, shift = 0, 0
            while pos < end:
                b = data[pos]
                pos += 1
                size |= (b & 0x7F) << shift
                shift += 7
                if not b & 0x80:
                    break
            if pos + size > end:
                raise ImportFailure("This FL Studio project is truncated or damaged (an event runs past the end of the file).")
            val = data[pos:pos + size]
            pos += size
        events.append((eid, val))
    return ppq, events


def parse_version(s):
    parts = []
    for p in s.split("."):
        try:
            parts.append(int("".join(ch for ch in p if ch.isdigit()) or 0))
        except ValueError:
            parts.append(0)
    return tuple(parts + [0, 0, 0])[:4]


def wrapper_plugin_name(data):
    """Name of the VST inside a Fruity Wrapper (plugin data records: u32 id, u64 size, bytes)."""
    try:
        if len(data) < 4:
            return None
        pos = 4
        name = None
        while pos + 12 <= len(data):
            rid = struct.unpack_from("<I", data, pos)[0]
            size = struct.unpack_from("<Q", data, pos + 4)[0]
            pos += 12
            if size > len(data) - pos:
                break
            if rid == 54:          # name
                name = data[pos:pos + size].decode("utf-8", "replace").strip("\x00 ")
            pos += size
        return name or None
    except struct.error:
        return None


class Importer:
    def __init__(self, path, workdir):
        self.path = Path(path)
        self.lif = LIF(workdir)
        self.media = MediaCollector(workdir, self.lif)
        extra = [Path(p) for p in os.environ.get("LODESTONE_SAMPLE_DIRS", "").split(os.pathsep) if p]
        self.index = FileIndex([self.path.parent] + extra)
        self.extra_dirs = extra

        self.ppq, self.events = read_events(self.path.read_bytes())
        self.version = (0, 0, 0, 0)
        self.channels = {}
        self.patterns = {}
        self.arrangements = []        # [{name, items, tracks: {idx: {name, enabled}}}]
        self.current_arrangement = 0
        self.tempo = 120.0
        self.num, self.den = 4, 4
        self.automation = 0

    # ------------------------------------------------------------------ parsing
    def text(self, b):
        if self.version >= (11, 5, 0, 0) and len(b) % 2 == 0:
            s = b.decode("utf-16-le", "replace")
        else:
            s = b.decode("cp1252", "replace")
        return s.split("\x00", 1)[0].strip()

    def parse(self):
        chan = pat = None
        arr = None
        track_idx = -1
        coarse_tempo = fine_tempo = None

        def ensure_arrangement():
            nonlocal arr
            if arr is None:
                arr = {"name": "", "items": [], "tracks": {}}
                self.arrangements.append(arr)
            return arr

        for eid, val in self.events:
            if eid == 199:
                self.version = parse_version(val.split(b"\x00", 1)[0].decode("ascii", "replace"))
            elif eid == 156:
                self.tempo = val / 1000.0
            elif eid == 66:
                coarse_tempo = val
            elif eid == 93:
                fine_tempo = val
            elif eid == 17:
                self.num = val or 4
            elif eid == 18:
                self.den = val or 4
            elif eid == 100:
                self.current_arrangement = val

            # channels
            elif eid == 64:
                chan = self.channels.setdefault(val, Channel(val))
                pat = None
            elif chan is not None and eid == 21:
                chan.type = val
            elif chan is not None and eid == 0:
                chan.enabled = bool(val)
            elif chan is not None and eid == 201:
                chan.internal = self.text(val)
            elif chan is not None and eid == 203:
                chan.name = self.text(val)
            elif chan is not None and eid == 196:
                chan.sample = self.text(val)
            elif chan is not None and eid == 213:
                chan.plugin_data = val
            elif chan is not None and eid == 219 and len(val) >= 8:
                chan.pan, chan.volume = struct.unpack_from("<iI", val, 0)
            elif chan is not None and eid == 72:          # old word volume / pan
                chan.volume = val
            elif chan is not None and eid == 73:
                chan.pan = val
            elif chan is not None and eid == 135:
                chan.root = val if val < 128 else 60
            elif chan is not None and eid == 94:
                chan.children.append(val)
            elif chan is not None and eid == 128:
                chan.color = val

            # patterns
            elif eid == 65:
                pat = self.patterns.setdefault(val, Pattern(val))
                chan = None
            elif pat is not None and eid == 193:
                pat.name = self.text(val)
            elif pat is not None and eid == 150:
                pat.color = val
            elif eid == 224:
                target = pat
                if target is None:
                    continue
                for k in range(0, len(val) - 23, 24):
                    p, _flags, rack, ln, key = struct.unpack_from("<IHHIH", val, k)
                    vel = val[k + 21]
                    target.notes.append((p, ln, key, vel, rack))

            # arrangements / playlist
            elif eid == 99:
                arr = {"name": "", "items": [], "tracks": {}}
                self.arrangements.append(arr)
                track_idx = -1
            elif eid == 241 and arr is not None:
                arr["name"] = self.text(val)
            elif eid == 238:
                a = ensure_arrangement()
                track_idx += 1
                enabled = True
                if len(val) >= 13:
                    enabled = bool(val[12])
                a["tracks"].setdefault(track_idx, {})["enabled"] = enabled
            elif eid == 239:
                a = ensure_arrangement()
                a["tracks"].setdefault(max(0, track_idx), {})["name"] = self.text(val)
            elif eid == 233:
                self.parse_playlist(ensure_arrangement(), val)

        if coarse_tempo and not any(e == 156 for e, _ in self.events):
            self.tempo = coarse_tempo + (fine_tempo or 0) / 1000.0

    def parse_playlist(self, arr, data):
        sizes = [60, 32] if self.version >= (21, 0, 0, 0) else [32, 60]
        size = None
        for s in sizes:
            if len(data) % s == 0 and all(struct.unpack_from("<H", data, k + 4)[0] == PATTERN_BASE
                                          for k in range(0, len(data), s)):
                size = s
                break
        if size is None:
            self.lif.warn("Part of the FL playlist uses a layout this importer doesn't know; some clips may be missing")
            size = sizes[0]
        for k in range(0, len(data) - size + 1, size):
            pos, base, idx, length, rv = struct.unpack_from("<IHHIH", data, k)
            so = struct.unpack_from("<f", data, k + 24)[0]
            it = Item()
            it.pos, it.length = pos, length
            it.track = 499 - rv if rv <= 499 else rv
            it.start_offset = so if (so == so and so not in (float("inf"), float("-inf")) and so > 0) else 0.0
            it.muted = False          # the mute bit isn't reliably known; never guess a mute
            if idx > base:
                it.pattern, it.channel = idx - base, None
            else:
                it.pattern, it.channel = None, idx
            arr["items"].append(it)

    # ------------------------------------------------------------------ mapping
    def beats(self, ticks):
        return ticks / float(self.ppq)

    def channel_kind(self, ch, keys):
        internal = ch.internal.lower()
        if ch.type == 5:
            return "automation"
        if ch.type == 4:
            return "audio"
        if ch.type == 3:
            return "layer"
        if internal in SILENT_GENERATORS:
            return "silent"
        if internal in KICK_GENERATORS:
            return "pad"
        if ch.type == 0 or internal in ("", "sampler", "audio clip"):
            if not ch.sample:
                return "silent"                    # an empty FL sampler makes no sound
            return "pad" if len(keys) <= 2 else "sampler"
        return "instrument"

    def instrument_for(self, ch):
        internal = ch.internal.lower()
        if internal == "fruity wrapper":
            name = wrapper_plugin_name(ch.plugin_data) or ch.name
            return {"type": "plugin", "name": name, "fallback": synth(ch.display)}
        if internal in NATIVE and NATIVE[internal] is not None:
            return NATIVE[internal]
        if internal and internal not in NATIVE:
            # an unknown generator: maybe it's a native plugin we don't know, maybe a renamed VST
            return {"type": "plugin", "name": ch.internal, "fallback": synth(ch.display)}
        return synth(ch.display if internal not in ("3x osc",) else ch.display + " " + internal)

    def sample_file(self, ch):
        f = resolve_path(ch.sample, self.path.parent, self.index, self.extra_dirs)
        return self.media.add(f) if f is not None else None

    def run(self):
        self.parse()
        lif = self.lif
        lif.tempo = self.tempo if 10 <= self.tempo <= 999 else 120.0
        lif.time_sig = [self.num, self.den]
        bar = self.ppq * 4.0 * self.num / self.den

        if not self.arrangements or not any(a["items"] for a in self.arrangements):
            arrangement = {"name": "", "items": self.layout_patterns(bar), "tracks": {}}
        else:
            idx = self.current_arrangement if self.current_arrangement < len(self.arrangements) else 0
            arrangement = self.arrangements[idx]
            if not arrangement["items"]:
                arrangement = next(a for a in self.arrangements if a["items"])
            if len([a for a in self.arrangements if a["items"]]) > 1:
                lif.warn(f"This project has several arrangements - imported \"{arrangement['name'] or 'the first one'}\"")

        tracks_info = arrangement["tracks"]

        def track_enabled(i):
            return tracks_info.get(i, {}).get("enabled", True)

        # expand layer channels into their children
        def targets(ch_iid, depth=0):
            ch = self.channels.get(ch_iid)
            if ch is None:
                return []
            if ch.type == 3 and depth < 4:
                out = []
                for c in ch.children:
                    out += targets(c, depth + 1)
                return out
            return [ch_iid]

        # which keys each channel plays (to tell drum hits from melodic samples)
        keys = {}
        for p in self.patterns.values():
            for n in p.notes:
                for t in targets(n[4]):
                    keys.setdefault(t, set()).add(n[2])

        kinds = {iid: self.channel_kind(ch, keys.get(iid, set())) for iid, ch in self.channels.items()}

        # ---- drum kit from one-shot channels
        pad_note = {}
        kit_tracks = []
        pad_channels = [iid for iid in sorted(self.channels) if kinds[iid] == "pad" and iid in keys]
        for k in range(0, len(pad_channels), 16):
            group = pad_channels[k:k + 16]
            pads = []
            for i, iid in enumerate(group):
                ch = self.channels[iid]
                note = 36 + i
                pad_note[iid] = (len(kit_tracks), note)
                pad = {"name": ch.display[:24], "note": note,
                       "gain": round(max(-60.0, 40.0 * math.log10(max(1, ch.volume) / 10000.0)), 2) if ch.volume else -60.0,
                       "pan": round((ch.pan - 6400) / 6400.0, 3)}
                f = self.sample_file(ch) if ch.sample else None
                if f is None:
                    sub = substitute_drum_sample(ch.display + " " + path_basename(ch.sample) + " " + ch.internal)
                    if sub is not None:
                        f = sub
                        if ch.sample:
                            lif.warn(f"{ch.display}: \"{path_basename(ch.sample)}\" isn't on this computer - used a similar built-in sound")
                    elif ch.sample:
                        lif.warn(f"{ch.display}: sample \"{path_basename(ch.sample)}\" not found")
                if f is not None:
                    pad["file"] = str(f)
                ks = keys.get(iid)
                if ks and ch.sample:
                    common = max(ks, key=lambda x: sum(1 for p in self.patterns.values() for n in p.notes if n[4] == iid and n[2] == x))
                    if common != ch.root:
                        pad["tune"] = float(max(-24, min(24, common - ch.root)))
                pads.append(pad)
            name = "Drums" if k == 0 else f"Drums {k // 16 + 1}"
            t = lif.add_track(name, "drums", {"type": "drumkit", "name": name, "pads": pads})
            kit_tracks.append(t)

        # ---- one track per melodic channel
        chan_tracks = {}

        def track_for(iid):
            if iid in chan_tracks:
                return chan_tracks[iid]
            ch = self.channels[iid]
            kind = kinds[iid]
            if kind == "sampler":
                f = self.sample_file(ch)
                if f is not None:
                    inst = {"type": "sampler", "file": str(f), "root": ch.root}
                else:
                    lif.warn(f"{ch.display}: sample \"{path_basename(ch.sample)}\" not found - using a synth instead")
                    inst = synth(ch.display)
            else:
                inst = self.instrument_for(ch)
            vol_db = max(-60.0, 40.0 * math.log10(max(1, ch.volume) / 10000.0)) if ch.volume else -60.0
            t = lif.add_track(ch.display, "drums" if inst is GM_DRUMS else "instrument", inst,
                              volumeDb=round(vol_db, 2), pan=round((ch.pan - 6400) / 6400.0, 3),
                              color=colour_hex(((ch.color or 0) & 0xFF, (ch.color or 0) >> 8 & 0xFF, (ch.color or 0) >> 16 & 0xFF)) if ch.color else None,
                              mute=(not ch.enabled) or None)
            chan_tracks[iid] = t
            return t

        # ---- playlist
        audio_tracks = {}
        skipped_auto = 0
        for it in sorted(arrangement["items"], key=lambda x: (x.pos, x.track)):
            muted = it.muted or not track_enabled(it.track)
            if it.pattern is not None:
                pat = self.patterns.get(it.pattern)
                if pat is None or not pat.notes:
                    continue
                start, length = self.beats(it.pos), self.beats(it.length)
                off = it.start_offset
                per_track = {}
                for (p, ln, key, vel, rack) in pat.notes:
                    if not (off - 1e-6 <= p < off + it.length):
                        continue
                    for iid in targets(rack):
                        kind = kinds.get(iid)
                        if kind in (None, "automation", "silent", "audio", "layer"):
                            continue
                        if kind == "pad" and iid in pad_note:
                            kt, note = pad_note[iid]
                            tgt = kit_tracks[kt]
                            pitch = note
                        else:
                            tgt = track_for(iid)
                            pitch = key
                        length_ticks = ln if ln > 0 else self.ppq / 4.0
                        length_ticks = min(length_ticks, off + it.length - p)
                        velocity = max(1, min(127, round(vel * 127 / 128)))
                        per_track.setdefault(id(tgt), (tgt, []))[1].append(
                            (self.beats(p - off), self.beats(length_ticks), pitch, velocity))
                for tgt, notes in per_track.values():
                    tgt["clips"].append(midi_clip(start, length, notes, name=pat.name or f"Pattern {pat.iid}", mute=muted))
            else:
                ch = self.channels.get(it.channel)
                if ch is None:
                    continue
                if ch.type == 5:
                    skipped_auto += 1
                    continue
                if not ch.sample:
                    continue
                f = self.sample_file(ch)
                if f is None and looks_like_drum(ch.display + " " + path_basename(ch.sample)):
                    f = substitute_drum_sample(ch.display + " " + path_basename(ch.sample))
                    if f is not None:
                        lif.warn(f"Audio clip \"{ch.display}\": \"{path_basename(ch.sample)}\" isn't on this computer - used a similar built-in sound")
                if f is None:
                    lif.warn(f"Audio clip \"{ch.display}\": file \"{path_basename(ch.sample)}\" not found")
                    continue
                t = audio_tracks.get(it.track)
                if t is None:
                    tname = tracks_info.get(it.track, {}).get("name") or f"Audio {len(audio_tracks) + 1}"
                    t = lif.add_track(tname, "audio")
                    audio_tracks[it.track] = t
                offset_s = self.beats(it.start_offset) * 60.0 / lif.tempo if it.start_offset > 0 else 0.0
                t["clips"].append(audio_clip(self.beats(it.pos), f, length=self.beats(it.length),
                                             name=ch.display, offset_seconds=offset_s, mute=muted))

        if skipped_auto:
            lif.warn(f"{skipped_auto} automation clip(s) weren't imported (automation import isn't supported yet)")
        natives = sorted({self.channels[i].internal for i, t in chan_tracks.items()
                          if self.channels[i].internal.lower() in NATIVE})
        if natives:
            lif.warn("FL Studio's own instruments only exist inside FL - " + ", ".join(natives) +
                     " were replaced with the closest built-in Lodestone sounds")

        lif.tracks = [t for t in lif.tracks if t["clips"]]
        if not lif.tracks:
            lif.warn("This project didn't contain any notes or audio clips Lodestone could use.")
        return lif

    def layout_patterns(self, bar):
        """No playlist: lay the patterns out one after another, the way you'd hear them in pattern mode."""
        items = []
        at = 0
        for iid in sorted(self.patterns):
            p = self.patterns[iid]
            if not p.notes:
                continue
            end = max(n[0] + max(n[1], self.ppq / 4) for n in p.notes)
            length = max(bar, math.ceil(end / bar - 1e-9) * bar)
            it = Item()
            it.pos, it.length, it.pattern, it.channel, it.track, it.start_offset, it.muted = at, int(length), iid, None, 0, 0.0, False
            items.append(it)
            at += int(length)
        if items:
            self.lif.warn("The playlist was empty, so the patterns were laid out one after another")
        return items


def import_flp(path, workdir):
    return Importer(path, workdir).run()
