"""
DrumSynth (.ds) renderer - a Python port of LMMS's src/core/DrumSynth.cpp.

LMMS ships ~760 DrumSynth presets (samples/drumsynth/...) and its AudioFileProcessor
renders them on load, so LMMS projects reference .ds files like ordinary samples.
This renders them to WAV so Lodestone's drum machine can play them.

Copyright (c) 1998-2000 Paul Kellett (mda-vst.com)
Copyright (c) 2007 Paul Giblock
Python port (c) 2026 the Lodestone authors

This file is free software; you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation;
either version 2 of the License, or (at your option) any later version.
"""
import math
import random
import re
import struct
import wave
import zlib

MAX, ENV, PNT, DENV, NEXTT = 0, 1, 2, 3, 4


class _Ini:
    def __init__(self, text):
        self.sections = {}
        cur = None
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("["):
                cur = line[1:line.find("]")].strip().lower() if "]" in line else None
                if cur is not None:
                    self.sections.setdefault(cur, {})
                continue
            if cur is None or "=" not in line:
                continue
            k, v = line.split("=", 1)
            self.sections[cur].setdefault(k.strip().lower(), v.strip())

    def str(self, sec, key, default=""):
        v = self.sections.get(sec.lower(), {}).get(key.lower(), "")
        return v if v else default

    def int(self, sec, key, default):
        v = self.str(sec, key, "")
        if not v:
            return default
        m = re.match(r"\s*[-+]?\d+", v)
        return int(m.group(0)) if m else 0

    def float(self, sec, key, default):
        v = self.str(sec, key, "")[:15]
        if not v:
            return float(default)
        m = re.match(r"\s*[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?", v)
        return float(m.group(0)) if m else 0.0


def _short(v):
    v = int(v)
    return ((v + 32768) & 0xFFFF) - 32768


def render(path, fs=44100, seed=0):
    """Returns a list of int16 samples, or None if the file isn't a DrumSynth file."""
    with open(path, "rb") as f:
        ini = _Ini(f.read().decode("latin-1"))

    ver = ini.str("General", "Version", "")
    if ver[:9].lower() != "drumsynth" or len(ver) < 12 or ver[11] not in "12":
        return None

    rnd = random.Random(seed or zlib.crc32(str(path).encode()))
    two_pi = 2.0 * math.pi

    envpts = [[[0.0] * 34, [0.0] * 34] for _ in range(8)]
    env = [[0.0] * 6 for _ in range(8)]
    chk = [0] * 8
    sli = [0] * 8

    def get_env(e, sec, key):
        txt = ini.str(sec, key, "0,0 100,0")[:255]
        ep = 0
        for tok in txt.split():
            if ep >= 32:
                break
            if "," in tok:
                tm, lv = tok.split(",", 1)
            else:
                tm, lv = tok, "0"
            try:
                envpts[e][0][ep] = float(tm)
            except ValueError:
                envpts[e][0][ep] = 0.0
            try:
                envpts[e][1][ep] = float(lv)
            except ValueError:
                envpts[e][1][ep] = 0.0
            ep += 1
        ep = max(ep, 1) - 1
        envpts[e][0][ep + 1] = -1.0
        env[e][MAX] = envpts[e][0][ep]

    stretch = 0.01 * ini.float("General", "Stretch", 100.0)
    stretch = min(10.0, max(0.2, stretch)) * fs / 44100.0

    def update_env(e, t):
        p = int(env[e][PNT])
        nxt = envpts[e][0][p + 1] * stretch if p + 1 < 34 else -1.0
        if nxt < 0:
            nxt = 442000 * stretch
        env[e][NEXTT] = nxt
        env[e][ENV] = envpts[e][1][p] * 0.01
        end = (envpts[e][1][p + 1] if p + 1 < 34 else 0.0) * 0.01
        dt = max(1.0, nxt - t)
        env[e][DENV] = (end - env[e][ENV]) / dt
        env[e][PNT] = p + 1.0

    dgain = 10 ** (0.05 * ini.float("General", "Level", 0))
    master_tune = 1.0594631 ** ini.float("General", "Tuning", 0.0)
    main_filter = 2 * ini.int("General", "Filter", 0)
    mf_res = math.sqrt(max(0.0, 0.0101 * ini.float("General", "Resonance", 0.0)))
    high_pass = ini.int("General", "HighPass", 0)
    get_env(7, "General", "FilterEnv")

    # noise
    chk[1] = ini.int("Noise", "On", 0)
    sli[1] = ini.int("Noise", "Level", 0)
    nt = ini.int("Noise", "Slope", 0)
    get_env(2, "Noise", "Envelope")
    non = chk[1]
    nl = float(sli[1] * sli[1])
    a = b = c = d = 0.0
    if nt < 0:
        a = 1.0 + nt / 105.0
        d = -nt / 105.0
        g = (1.0 + 0.0005 * nt * nt) * nl
    else:
        a = 1.0
        b = -nt / 50.0
        c = abs(float(nt)) / 100.0
        g = nl

    # tone
    chk[0] = ini.int("Tone", "On", 0)
    ton = chk[0]
    sli[0] = ini.int("Tone", "Level", 128)
    tl = float(sli[0] * sli[0])
    get_env(1, "Tone", "Envelope")
    f1 = master_tune * two_pi * ini.float("Tone", "F1", 200.0) / fs
    if abs(f1) < 0.001:
        f1 = 0.001
    f2 = master_tune * two_pi * ini.float("Tone", "F2", 120.0) / fs
    droop_rate = ini.float("Tone", "Droop", 0.0)
    tdroop = 0
    if droop_rate > 0.0:
        droop_rate = 10 ** ((droop_rate - 20.0) / 30.0)
        droop_rate = droop_rate * -4.0 / (env[1][MAX] or 1.0)
        tdroop = 1
        denom = 1.0 - math.exp(droop_rate * env[1][MAX])
        f2 = f1 + ((f2 - f1) / (denom if denom != 0 else 1e-9))
        ddf = f1 - f2
    else:
        ddf = f2 - f1
    tphi = ini.float("Tone", "Phase", 90.0) / 57.29578

    # overtones
    chk[2] = ini.int("Overtones", "On", 0)
    oon = chk[2]
    sli[2] = ini.int("Overtones", "Level", 128)
    ol = float(sli[2] * sli[2])
    get_env(3, "Overtones", "Envelope1")
    get_env(4, "Overtones", "Envelope2")
    omode = ini.int("Overtones", "Method", 2)
    of1 = master_tune * two_pi * ini.float("Overtones", "F1", 200.0) / fs
    of2 = master_tune * two_pi * ini.float("Overtones", "F2", 120.0) / fs
    ow1 = ini.int("Overtones", "Wave1", 0)
    ow2 = ini.int("Overtones", "Wave2", 0)
    obal2 = float(ini.int("Overtones", "Param", 50))
    odrive = (obal2 ** 3) / 125000.0
    obal2 *= 0.01
    obal1 = 1.0 - obal2
    ophi1 = ophi2 = tphi
    if main_filter == 0:
        main_filter = ini.int("Overtones", "Filter", 0)
    of1sync = of2sync = 0
    if ini.int("Overtones", "Track1", 0) == 1 and ton == 1:
        of1sync, of1 = 1, of1 / f1
    if ini.int("Overtones", "Track2", 0) == 1 and ton == 1:
        of2sync, of2 = 1, of2 / f1

    oca = 0.28 + obal1 * obal1
    ocq = oca * oca
    ocf = (1.8 - 0.7 * ocq) * 0.92
    oca *= 1.0 + 4.0 * obal1
    ocf1 = two_pi / of1 if of1 else 1.0
    ocf2 = two_pi / of2 if of2 else 1.0
    oc = [[ocf1 + (ocf2 - ocf1) * 0.2 * i] * 2 for i in range(6)]
    oc0 = oc1 = oc2 = 0.0

    # noise bands
    def band(sec, e, idx):
        chk[idx] = ini.int(sec, "On", 0)
        sli[idx] = ini.int(sec, "Level", 128)
        bl = float(sli[idx] * sli[idx])
        bf = master_tune * two_pi * ini.float(sec, "F", 1000.0) / fs
        get_env(e, sec, "Envelope")
        step = ini.int(sec, "dF", 50)
        bq = float(step)
        den = 10000.0 - 6600.0 * (math.sqrt(max(0.0, bf)) - 0.19)
        bq = bq * bq / (den if den != 0 else 1e-9)
        step = 1 + int((40.0 - (step / 2.5)) / (bq + 1.0 + bf))
        return chk[idx], bl, bf, bq, max(1, step)

    bon, bl, bf, bq, bstep = band("NoiseBand", 5, 3)
    bon2, bl2, bf2, bq2, bstep2 = band("NoiseBand2", 6, 4)
    bphi = bphi2 = math.pi / 4.0
    bdf = bdf2 = 0.0

    # distortion
    chk[5] = ini.int("Distortion", "On", 0)
    dion = chk[5]
    dstep = 1 + ini.int("Distortion", "Rate", 0)
    dstep = {7: 20, 6: 10, 5: 8}.get(dstep, dstep)
    dstep = max(1, dstep)
    clippoint = 32700
    datten = 1.0
    if dion == 1:
        loudest = 0.0
        for i in range(5):
            if chk[i] == 1 and sli[i] > loudest:
                loudest = float(sli[i])
        datten = dgain * _short(loudest * loudest)
        clippoint = 32700 if datten > 32700 else _short(datten)
        datten = 2.0 ** (2.0 * ini.int("Distortion", "Bits", 0))
        dgain = datten * dgain * 10 ** (0.05 * ini.int("Distortion", "Clipping", 0))

    # envelopes / length
    for i in range(1, 8):
        env[i][NEXTT] = 0.0
        env[i][PNT] = 0.0
    longest = 0.0
    for e in range(1, 7):
        eon = e - 1
        if eon > 2:
            eon -= 1
        p = 0
        while p + 1 < 34 and envpts[e][0][p + 1] >= 0.0:
            p += 1
        env[e][MAX] = envpts[e][0][p] * stretch
        if chk[eon] == 1 and env[e][MAX] > longest:
            longest = env[e][MAX]
    length = 2400 + 1200 * int(longest / 1200)
    length = min(length, fs * 20)

    out = []
    tphi_start = 0.0
    x0 = x1 = x2 = tt = 0.0
    mf_in = mf_out = 0.0
    sin, cos, exp = math.sin, math.cos, math.exp
    uniform = rnd.uniform
    tpos = 0

    def wavef(ph, form):
        if form == 0:
            return sin(ph)
        if form == 1:
            return abs(2.0 * sin(0.5 * ph)) - 1.0
        saw = (ph / two_pi) % 1.0
        if form == 2:
            return 1.0 - 4.0 * abs(saw - 0.5)
        if form == 3:
            return 2.0 * saw - 1.0
        return 1.0 if saw < 0.5 else -1.0

    while tpos < length:
        tplus = tpos + 1199
        df = [0.0] * 1200
        phi = [f2] * 1200

        if non == 1:
            e = env[2]
            for t in range(tpos, tplus + 1):
                if t < e[NEXTT]:
                    e[ENV] += e[DENV]
                else:
                    update_env(2, t)
                x2, x1 = x1, x0
                x0 = uniform(-1.0, 1.0)
                tt = a * x0 + b * x1 + c * x2 + d * tt
                df[t - tpos] = tt * g * e[ENV]
            if tplus + 1 >= env[2][MAX]:
                non = 0

        if ton == 1:
            tphi_start = tphi
            if tdroop == 1:
                for t in range(tpos, tplus + 1):
                    phi[t - tpos] = f2 + ddf * exp(t * droop_rate)
            else:
                m = env[1][MAX] or 1.0
                for t in range(tpos, tplus + 1):
                    phi[t - tpos] = f1 + (t / m) * ddf
            e = env[1]
            for t in range(tpos, tplus + 1):
                k = t - tpos
                if t < e[NEXTT]:
                    e[ENV] += e[DENV]
                else:
                    update_env(1, t)
                tphi += phi[k]
                df[k] += tl * e[ENV] * sin(tphi)
            if tplus + 1 >= env[1][MAX]:
                ton = 0

        if bon == 1:
            e = env[5]
            for t in range(tpos, tplus + 1):
                if t < e[NEXTT]:
                    e[ENV] += e[DENV]
                else:
                    update_env(5, t)
                if t % bstep == 0:
                    bdf = uniform(-0.5, 0.5)
                bphi += bf + bq * bdf
                df[t - tpos] += cos(bphi) * e[ENV] * bl
            if tplus + 1 >= env[5][MAX]:
                bon = 0

        if bon2 == 1:
            e = env[6]
            for t in range(tpos, tplus + 1):
                if t < e[NEXTT]:
                    e[ENV] += e[DENV]
                else:
                    update_env(6, t)
                if t % bstep2 == 0:
                    bdf2 = uniform(-0.5, 0.5)
                bphi2 += bf2 + bq2 * bdf2
                df[t - tpos] += cos(bphi2) * e[ENV] * bl2
            if tplus + 1 >= env[6][MAX]:
                bon2 = 0

        e3, e4, e7 = env[3], env[4], env[7]
        for t in range(tpos, tplus + 1):
            k = t - tpos
            ot = 0.0
            if oon == 1:
                if t < e3[NEXTT]:
                    e3[ENV] += e3[DENV]
                elif t >= e3[MAX]:
                    e3[ENV] = e3[DENV] = 0.0
                    e3[NEXTT] = 999999
                else:
                    update_env(3, t)
                if t < e4[NEXTT]:
                    e4[ENV] += e4[DENV]
                elif t >= e4[MAX]:
                    e4[ENV] = e4[DENV] = 0.0
                    e4[NEXTT] = 999999
                else:
                    update_env(4, t)

                tphi_start += phi[k]
                ophi1 = tphi_start * of1 if of1sync else ophi1 + of1
                ophi2 = tphi_start * of2 if of2sync else ophi2 + of2

                if omode == 0:
                    ot = obal1 * e3[ENV] * wavef(ophi1, ow1)
                    ot = ol * (ot + obal2 * e4[ENV] * wavef(ophi2, ow2))
                elif omode == 1:
                    ot = odrive * e4[ENV] * wavef(ophi2, ow2)
                    ot = ol * e3[ENV] * wavef(ophi1 + ot, ow1)
                elif omode == 2:
                    ot = (1 - odrive / 8) + (((odrive / 8) * e4[ENV]) * wavef(ophi2, ow2))
                    ot = ol * e3[ENV] * wavef(ophi1, ow1) * ot
                elif omode == 3:
                    for j in range(6):
                        oc[j][0] += 1.0
                        if oc[j][0] > oc[j][1]:
                            oc[j][0] -= oc[j][1]
                            ot = ol * e3[ENV]
                    f = e4[ENV] * ocf
                    oc0 += f * oc1
                    oc1 += f * (ot + oc2 - ocq * oc1 - oc0)
                    oc2 = ot
                    ot = oc1

            if main_filter in (1, 2):
                if t < e7[NEXTT]:
                    e7[ENV] += e7[DENV]
                else:
                    update_env(7, t)
                mt = e7[ENV]
                fb = 1.001 - 10 ** (mt - 1) if mt > 0.2 else 0.999 - 0.7824 * mt
                if fb == 0:
                    fb = 1e-9
                if main_filter == 1:
                    tmp = ot + mf_res * (1.0 + 1.0 / fb) * (mf_in - mf_out)
                    mf_in = fb * (mf_in - tmp) + tmp
                    mf_out = fb * (mf_out - mf_in) + mf_in
                    df[k] += mf_out - high_pass * ot
                else:
                    tmp = df[k] + ot + mf_res * (1.0 + 1.0 / fb) * (mf_in - mf_out)
                    mf_in = fb * (mf_in - tmp) + tmp
                    mf_out = fb * (mf_out - mf_in) + mf_in
                    df[k] = mf_out - high_pass * (df[k] + ot)
            else:
                df[k] += ot

        if dion == 1:
            for j in range(1200):
                df[j] = dgain * int(df[j] / datten)
            for j in range(0, 1200, dstep):
                seg = df[j:j + dstep]
                ave = sum(seg) / dstep
                for jj in range(j, min(1200, j + dstep)):
                    df[jj] = ave
        else:
            for j in range(1200):
                df[j] *= dgain

        for v in df:
            if v != v:          # NaN guard
                v = 0.0
            if v > clippoint:
                out.append(clippoint)
            elif v < -clippoint:
                out.append(-clippoint)
            else:
                out.append(int(v))

        tpos += 1200

    return out


def render_to_wav(ds_path, wav_path, fs=44100):
    samples = render(ds_path, fs)
    if not samples:
        return False
    # trim trailing silence so pads don't hold voices for seconds of nothing
    end = len(samples)
    while end > 64 and abs(samples[end - 1]) < 8:
        end -= 1
    samples = samples[:end + 32]
    with wave.open(str(wav_path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(fs)
        w.writeframes(struct.pack("<%dh" % len(samples), *samples))
    return True
