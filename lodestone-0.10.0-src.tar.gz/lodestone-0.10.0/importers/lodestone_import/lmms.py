"""
LMMS projects (.mmp = XML, .mmpz = Qt qCompress'd XML).

What carries over: tempo, time signature, every instrument/sample/Beat-Bassline track,
patterns and their notes, BB placements (looped the way LMMS loops them), sample clips,
volume/pan/mute/solo, AudioFileProcessor samples (as samplers or drum-kit pads),
SF2 Player soundfonts, Kicker (as a kick pad). LMMS-only synths (TripleOscillator,
ZynAddSubFX, LB302...) become the closest built-in Lodestone sound. Effects and
automation are not imported (reported as warnings).

Timing: LMMS uses 48 ticks per quarter note (192 per 4/4 bar).
Keys: project format < 20 (LMMS <= 1.2) stored keys an octave low; the same
correction LMMS's own upgrade_extendedNoteRange() applies is applied here.
"""
import math
import os
import zlib
import xml.etree.ElementTree as ET
from pathlib import Path

from .common import FileIndex, MediaCollector, resolve_path, substitute_drum_sample
from .instruments import gm, synth, synth_preset_for
from .lif import LIF, ImportFailure, audio_clip, gain_to_db, midi_clip

TPB = 48.0                      # ticks per beat (quarter note)
AFFECTED_BY_1048 = {"zynaddsubfx", "vestige", "lv2instrument", "carlapatchbay", "carlarack"}
PATTERN_TAGS = ("pattern", "midiclip")
BB_CLIP_TAGS = ("bbtco", "patternclip")
BB_TRACK_TAGS = ("bbtrack", "patterntrack")
SAMPLE_CLIP_TAGS = ("sampletco", "sampleclip")
AUTOMATION_TAGS = ("automationpattern", "automationclip")
CHIP = {"sid", "papu", "freeboy", "nes", "sfxr", "gameboy"}
DISPLAY_NAMES = {"tripleoscillator": "TripleOscillator", "audiofileprocessor": "AudioFileProcessor", "bitinvader": "BitInvader",
                 "lb302": "LB302", "zynaddsubfx": "ZynAddSubFX", "sf2player": "SF2 Player", "kicker": "Kicker",
                 "monstro": "Monstro", "watsyn": "Watsyn", "organic": "Organic", "vibedstrings": "Vibed",
                 "malletsstk": "Mallets", "sid": "SID", "papu": "FreeBoy", "freeboy": "FreeBoy", "nes": "Nescaline",
                 "sfxr": "sfxr", "opulenz": "OpulenZ", "xpressive": "Xpressive", "slicert": "SlicerT", "vestige": "VeSTige"}


def load_xml(path):
    data = Path(path).read_bytes()
    if not data.lstrip()[:1] == b"<":
        if len(data) < 5:
            raise ImportFailure("This LMMS file is empty.")
        try:
            data = zlib.decompress(data[4:])       # qCompress: 4-byte big-endian size + zlib stream
        except zlib.error as e:
            raise ImportFailure(f"This doesn't look like an LMMS project ({e}).")
    try:
        root = ET.fromstring(data)
    except ET.ParseError as e:
        raise ImportFailure(f"The LMMS project's XML is damaged: {e}")
    if root.tag != "lmms-project":
        raise ImportFailure(f"Not an LMMS project (root element is <{root.tag}>).")
    return root


def first_child(el, tags):
    for t in tags:
        c = el.find(t)
        if c is not None:
            return c
    return None


def children(el, tags):
    return [c for c in el if c.tag in tags]


def fnum(el, attr, default=0.0):
    try:
        return float(el.get(attr, default))
    except (TypeError, ValueError):
        return float(default)


def lmms_sample_dirs(project_dir):
    home = Path.home()
    dirs = [project_dir, home / "lmms" / "samples", home / "Documents" / "lmms" / "samples",
            home / ".lmms" / "samples", Path("/usr/share/lmms/samples"), Path("/usr/local/share/lmms/samples"),
            Path("/usr/lib/lmms/samples")]
    extra = os.environ.get("LODESTONE_SAMPLE_DIRS", "")
    dirs += [Path(p) for p in extra.split(os.pathsep) if p]
    return [d for d in dirs if d.is_dir()]


class Importer:
    def __init__(self, path, workdir):
        self.path = Path(path)
        self.root = load_xml(self.path)
        self.lif = LIF(workdir)
        self.media = MediaCollector(workdir, self.lif)
        self.sample_dirs = lmms_sample_dirs(self.path.parent)
        self.index = FileIndex([self.path.parent] + self.sample_dirs)

        v = self.root.get("version", "1.0")
        try:
            self.shift = int(v) < 20
        except ValueError:
            self.shift = True                     # legacy "1.0"

        head = self.root.find("head")
        self.num = int(fnum(head, "timesig_numerator", 4)) if head is not None else 4
        self.den = int(fnum(head, "timesig_denominator", 4)) if head is not None else 4
        self.tpbar = 192.0 * self.num / self.den
        self.step = self.tpbar / 16.0
        self.bpm = fnum(head, "bpm", 120) if head is not None else 120.0
        if head is not None and head.find("bpm") is not None:   # very old files: <bpm value=..>
            self.bpm = fnum(head.find("bpm"), "value", self.bpm)
        self.lif.tempo = self.bpm
        self.lif.time_sig = [self.num, self.den]

        # LMMS mixer: channel volumes (linear) and the master volume knob (percent)
        self.mix_vol = {}
        mixer = self.root.find(".//mixer")
        if mixer is None:
            mixer = self.root.find(".//fxmixer")
        if mixer is not None:
            for ch in mixer:
                if ch.tag in ("mixerchannel", "fxchannel"):
                    vol = fnum(ch, "volume", 1.0)
                    if ch.get("muted") == "1":
                        vol = 0.0
                    self.mix_vol[int(fnum(ch, "num", 0))] = vol
        master = self.mix_vol.get(0, 1.0) * (fnum(head, "mastervol", 100) / 100.0 if head is not None else 1.0)
        self.lif.master_volume_db = round(gain_to_db(master), 2) if master > 0 else -60.0

    # ------------------------------------------------------------------ helpers
    def beats(self, ticks):
        return ticks / TPB

    def sample(self, src):
        f = resolve_path(src, self.path.parent, self.index, self.sample_dirs)
        if f is None:
            return None
        return self.media.add(f)

    def note_list(self, pattern, info):
        """[(tick, len_ticks, key, velocity)] with LMMS's key fixes applied."""
        out = []
        for n in pattern.iter("note"):
            key = int(fnum(n, "key", 57))
            if self.shift and info["inst"] not in AFFECTED_BY_1048:
                key += 12
            ln = fnum(n, "len", 48)                # <= 0: a step note, "play the whole sample"
            vel = int(round(min(200.0, fnum(n, "vol", 100)) * 127.0 / 100.0))
            out.append((fnum(n, "pos", 0), ln, key, max(1, min(127, vel))))
        return out

    def sized(self, notes, whole_sample_len):
        """Give step notes (length <= 0) a real length."""
        return [(t, l if l > 0 else whole_sample_len, k, v) for t, l, k, v in notes]

    def gated(self, info):
        """LMMS AudioFileProcessor plays a sample for as long as the note is held, except
        for step notes; a pad whose notes are mostly held notes is gated, not one-shot."""
        lens = [fnum(n, "len", 48) for p in children(info["el"], PATTERN_TAGS) for n in p.iter("note")]
        return sum(1 for l in lens if l > 0) > len(lens) / 2

    def pattern_len(self, pattern, notes):
        if pattern.get("len"):
            return max(self.step, fnum(pattern, "len", self.tpbar))
        end = max((t + max(l, self.step) for t, l, _, _ in notes), default=0.0)
        if pattern.get("type", "1") == "0":        # beat (step) pattern
            end = max(end, fnum(pattern, "steps", 16) * self.step)
        return max(self.tpbar, math.ceil(end / self.tpbar - 1e-9) * self.tpbar)

    def track_info(self, track):
        it = track.find("instrumenttrack")
        inst_el = it.find("instrument") if it is not None else None
        iname = inst_el.get("name", "") if inst_el is not None else ""
        params = inst_el.find(iname) if (inst_el is not None and iname) else None
        basenote = int(fnum(it, "basenote", 57 if self.shift else 69)) if it is not None else 69
        if self.shift:
            basenote += 12
        name = track.get("name", "Track")
        if name.strip().lower() in ("default preset", "") and iname:
            name = DISPLAY_NAMES.get(iname, iname.capitalize())
        mixch = int(fnum(it, "mixch", fnum(it, "fxch", 0))) if it is not None else 0
        channel_gain = self.mix_vol.get(mixch, 1.0) if mixch != 0 else 1.0
        return {
            "el": track, "name": name, "inst": iname,
            "params": params.attrib if params is not None else {},
            "vol": (fnum(it, "vol", 100) if it is not None else 100.0) * channel_gain,
            "pan": fnum(it, "pan", 0) if it is not None else 0.0,
            "basenote": basenote,
            "muted": track.get("muted") == "1", "solo": track.get("solo") == "1",
        }

    def pitch_for(self, info, key):
        """Instruments that transpose by base note (everything but sample players)."""
        return key + (69 - info["basenote"])

    def is_drum_pad(self, info):
        if info["inst"] == "kicker":
            return True
        if info["inst"] != "audiofileprocessor":
            return False
        # a sample triggered at only one or two pitches is a drum hit, not a melodic sampler
        keys = {n.get("key") for p in children(info["el"], PATTERN_TAGS) for n in p.iter("note")}
        return len(keys) <= 2

    def instrument_for(self, info):
        name, iname, p = info["name"], info["inst"], info["params"]
        if iname == "audiofileprocessor":
            f = self.sample(p.get("src", ""))
            if f is None:
                self.lif.warn(f"{name}: sample \"{p.get('src', '')}\" not found")
                return synth(name)
            return {"type": "sampler", "file": str(f), "root": info["basenote"]}
        if iname == "sf2player":
            src = p.get("src", "")
            f = resolve_path(src, self.path.parent, self.index, self.sample_dirs) if src else None
            bank, patch = int(fnum_d(p, "bank", 0)), int(fnum_d(p, "patch", 0))
            if f is not None:
                return {"type": "sf2", "file": str(f), "bank": bank, "program": patch}
            if src:
                self.lif.warn(f"{name}: SoundFont \"{os.path.basename(src)}\" not found - using General MIDI")
            return gm(patch, 128 if bank == 128 else 0)
        if iname == "lb302":
            return {"type": "synth", "preset": "Acid Bass"}
        if iname in CHIP:
            return {"type": "synth", "preset": synth_preset_for(name, "Chiptune")}
        if iname == "organic":
            return {"type": "synth", "preset": "Organ"}
        if iname == "vibedstrings":
            return gm(45)
        if iname == "malletsstk":
            return gm(12)
        if iname == "patman":
            return gm(0)
        if iname == "vestige":
            plug = os.path.splitext(os.path.basename(p.get("plugin", "").replace("\\", "/")))[0]
            if plug:
                return {"type": "plugin", "name": plug, "fallback": synth(name)}
        if iname == "zynaddsubfx":
            self.lif.warn("ZynAddSubFX patches can't be carried over - those tracks use the closest built-in sound")
        return synth(name)

    def mix_props(self, info):
        return {"volumeDb": round(gain_to_db(info["vol"] / 100.0), 2), "pan": round(info["pan"] / 100.0, 3),
                "mute": info["muted"] or None, "solo": info["solo"] or None}

    # ------------------------------------------------------------------ song tracks
    def import_instrument_track(self, track):
        info = self.track_info(track)
        patterns = children(track, PATTERN_TAGS)
        if self.is_drum_pad(info):
            kit = self.make_kit(info["name"], [info])
            t = self.lif.add_track(info["name"], "drums", kit["instrument"], **self.mix_props(info))
            full = self.tpbar if self.gated(info) else self.step
            for p in patterns:
                notes = [(tk, ln, kit["pad_note"][0], v) for tk, ln, _, v in self.sized(self.note_list(p, info), full)]
                self.add_pattern_clip(t, p, notes)
            return

        inst = self.instrument_for(info)
        t = self.lif.add_track(info["name"], "instrument", inst, **self.mix_props(info))
        sampler = inst.get("type") == "sampler"
        for p in patterns:
            notes = [(tk, ln, k if sampler else self.pitch_for(info, k), v)
                     for tk, ln, k, v in self.sized(self.note_list(p, info), self.step)]
            self.add_pattern_clip(t, p, notes)

    def add_pattern_clip(self, track, p, notes):
        if not notes:
            return
        length = self.pattern_len(p, notes)
        track["clips"].append(midi_clip(self.beats(fnum(p, "pos", 0)), self.beats(length),
                                        [(self.beats(t), self.beats(l), k, v) for t, l, k, v in notes if t < length],
                                        name=p.get("name") or None, mute=p.get("muted") == "1"))

    def import_sample_track(self, track):
        st = track.find("sampletrack")
        vol = fnum(st, "vol", 100) if st is not None else 100.0
        if st is not None:
            mixch = int(fnum(st, "mixch", fnum(st, "fxch", 0)))
            if mixch:
                vol *= self.mix_vol.get(mixch, 1.0)
        pan = fnum(st, "pan", 0) if st is not None else 0.0
        t = self.lif.add_track(track.get("name", "Samples"), "audio", None,
                               volumeDb=round(gain_to_db(vol / 100.0), 2), pan=round(pan / 100.0, 3),
                               mute=track.get("muted") == "1" or None, solo=track.get("solo") == "1" or None)
        for c in children(track, SAMPLE_CLIP_TAGS):
            src = c.get("src", "")
            f = self.sample(src)
            if f is None:
                self.lif.warn(f"{t['name']}: audio file \"{src}\" not found")
                continue
            off_ticks = fnum(c, "off", 0)
            off_seconds = max(0.0, -off_ticks) / TPB * 60.0 / self.bpm if off_ticks < 0 else 0.0
            t["clips"].append(audio_clip(self.beats(fnum(c, "pos", 0)), f, length=self.beats(fnum(c, "len", 0)),
                                         offset_seconds=off_seconds, mute=c.get("muted") == "1"))

    # ------------------------------------------------------------------ Beat/Bassline
    def make_kit(self, kit_name, members):
        pads, note_of = [], {}
        for i, info in enumerate(members[:16]):
            note = 36 + i
            pad = {"name": info["name"][:24], "note": note,
                   "gain": round(gain_to_db(info["vol"] / 100.0), 2), "pan": round(info["pan"] / 100.0, 3)}
            if info["inst"] == "audiofileprocessor" and self.gated(info):
                pad["oneShot"] = False
            p = info["params"]
            f = None
            if info["inst"] == "audiofileprocessor":
                f = self.sample(p.get("src", ""))
                if f is None:
                    sub = substitute_drum_sample(info["name"] + " " + os.path.basename(p.get("src", "")))
                    if sub:
                        f = sub
                        self.lif.warn(f"{info['name']}: sample \"{p.get('src', '')}\" not found - used a similar built-in sound")
                    else:
                        self.lif.warn(f"{info['name']}: sample \"{p.get('src', '')}\" not found")
                amp = fnum_d(p, "amp", 100)
                pad["gain"] = round(pad["gain"] + gain_to_db(amp / 100.0), 2)
                if p.get("reversed") == "1":
                    pad["reverse"] = True
                # LMMS users slice breakbeats by setting each AudioFileProcessor's start/end points
                sframe, eframe = fnum_d(p, "sframe", 0.0), fnum_d(p, "eframe", 1.0)
                if sframe > 0.001 or eframe < 0.999:
                    pad["start"] = round(max(0.0, min(0.999, sframe)), 5)
                    pad["end"] = round(max(pad["start"] + 0.001, min(1.0, eframe)), 5)
                # pitch the pad the way the sample sounded at the notes LMMS triggered
                keys = [int(fnum(n, "key", 57)) + (12 if self.shift else 0)
                        for pt in children(info["el"], PATTERN_TAGS) for n in pt.iter("note")]
                if keys:
                    tune = max(set(keys), key=keys.count) - info["basenote"]
                    if tune:
                        pad["tune"] = float(max(-24, min(24, tune)))
            elif info["inst"] == "kicker":
                f = substitute_drum_sample("808 kick") or substitute_drum_sample("kick")
            if f is not None:
                pad["file"] = str(f)
            pads.append(pad)
            note_of[id(info)] = note
        return {"instrument": {"type": "drumkit", "name": kit_name, "pads": pads},
                "pad_note": [note_of.get(id(m), 36) for m in members]}

    def import_beat_basslines(self, bb_tracks):
        container = None
        for bt in bb_tracks:
            holder = first_child(bt, BB_TRACK_TAGS)
            if holder is not None and holder.find("trackcontainer") is not None:
                container = holder.find("trackcontainer")
                break
        if container is None:
            return

        members = [self.track_info(t) for t in container.findall("track") if t.get("type", "0") == "0"]
        drums = [m for m in members if self.is_drum_pad(m)]
        melodic = [m for m in members if m not in drums]

        # pattern i of a container track = the one starting at bar i
        def pattern_for(info, bb):
            for p in children(info["el"], PATTERN_TAGS):
                if int(round(fnum(p, "pos", 0) / self.tpbar)) == bb:
                    return p
            return None

        bb_count = len(bb_tracks)
        bb_len = []
        for bb in range(bb_count):
            ln = self.tpbar
            for m in members:
                p = pattern_for(m, bb)
                if p is not None:
                    ln = max(ln, self.pattern_len(p, self.note_list(p, m)))
            bb_len.append(ln)

        kit_tracks = []
        for k in range(0, len(drums), 16):
            group = drums[k:k + 16]
            name = "Beat/Bassline Drums" + ("" if k == 0 else f" {k // 16 + 1}")
            kit = self.make_kit(name, group)
            t = self.lif.add_track(name, "drums", kit["instrument"])
            kit_tracks.append((t, group, kit["pad_note"]))

        melodic_tracks = []
        for m in melodic:
            inst = self.instrument_for(m)
            t = self.lif.add_track(m["name"], "instrument", inst, **self.mix_props(m))
            melodic_tracks.append((t, m, inst.get("type") == "sampler"))

        for bb, bt in enumerate(bb_tracks):
            name = bt.get("name", f"Beat/Bassline {bb}")
            muted_track = bt.get("muted") == "1"
            period = bb_len[bb]

            for clip in children(bt, BB_CLIP_TAGS):
                start, length = fnum(clip, "pos", 0), fnum(clip, "len", period)
                if length <= 0:
                    continue
                muted = muted_track or clip.get("muted") == "1"

                def tiled(notes):
                    out = []
                    reps = int(math.ceil(length / period))
                    for r in range(reps):
                        for t0, ln, key, vel in notes:
                            at = r * period + t0
                            if t0 < period and at < length:
                                out.append((self.beats(at), self.beats(min(ln, length - at)), key, vel))
                    return out

                for t, group, pad_notes in kit_tracks:
                    notes = []
                    for info, pad in zip(group, pad_notes):
                        if info["muted"]:
                            continue
                        p = pattern_for(info, bb)
                        if p is not None and p.get("muted") != "1":
                            full = self.tpbar if self.gated(info) else self.step
                            notes += [(tk, ln, pad, v) for tk, ln, _, v in self.sized(self.note_list(p, info), full)]
                    if notes:
                        t["clips"].append(midi_clip(self.beats(start), self.beats(length), tiled(notes), name=name, mute=muted))

                for t, info, sampler in melodic_tracks:
                    p = pattern_for(info, bb)
                    if p is None or p.get("muted") == "1":
                        continue
                    notes = [(tk, ln, k if sampler else self.pitch_for(info, k), v)
                             for tk, ln, k, v in self.sized(self.note_list(p, info), self.step)]
                    if notes:
                        t["clips"].append(midi_clip(self.beats(start), self.beats(length), tiled(notes), name=name, mute=muted))

    # ------------------------------------------------------------------ main
    def run(self):
        song = self.root.find("song")
        if song is None:
            raise ImportFailure("This LMMS file has no song in it (is it a preset or a template?).")
        tc = song.find("trackcontainer")
        if tc is None:
            raise ImportFailure("This LMMS project has no tracks.")

        tracks = tc.findall("track")
        bb_tracks = [t for t in tracks if t.get("type") == "1"]
        automation = 0

        for t in tracks:
            ty = t.get("type", "0")
            if ty == "0":
                self.import_instrument_track(t)
            elif ty == "2":
                self.import_sample_track(t)
            elif ty in ("5", "6"):
                automation += len(children(t, AUTOMATION_TAGS))

        if bb_tracks:
            self.import_beat_basslines(bb_tracks)

        if automation:
            self.lif.warn(f"{automation} automation clip(s) weren't imported (automation import isn't supported yet)")
        fx = sum(1 for e in self.root.iter("effect"))
        if fx:
            self.lif.warn(f"{fx} LMMS effect(s) weren't imported - add effects from Lodestone's Effects browser")

        loop = song.find("timeline")
        if loop is not None and loop.get("lpstate") == "1":
            a, b = fnum(loop, "lp0pos", 0), fnum(loop, "lp1pos", 0)
            if b > a:
                self.lif.loop = [self.beats(a), self.beats(b)]

        # drop instrument tracks that ended up with nothing on them (LMMS templates are full of these)
        self.lif.tracks = [t for t in self.lif.tracks if t["clips"] or t["kind"] == "audio"]
        if not self.lif.tracks:
            self.lif.warn("The project didn't contain any notes or audio clips.")
        return self.lif


def fnum_d(d, key, default=0.0):
    try:
        return float(d.get(key, default))
    except (TypeError, ValueError):
        return float(default)


def import_lmms(path, workdir):
    return Importer(path, workdir).run()
