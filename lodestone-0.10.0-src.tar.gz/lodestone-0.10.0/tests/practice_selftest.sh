#!/bin/bash
# Runs Lodestone's built-in Practice mode self-test against a JACK dummy device:
#   - jackd's dummy driver stands in for an audio interface (2 in, 2 out)
#   - jack_metro feeds a 440 Hz tone into input 1 (the "mic")
#   - notes are played on the "Computer Keyboard" MIDI device from inside the app
#
# usage: tests/practice_selftest.sh [screenshot-dir]
# env:   LODE_BIN (binary), LODE_SELFTEST_PAUSE (seconds to hold the final screen)

set -u
BIN=${LODE_BIN:-$(dirname "$0")/../build/Lodestone_artefacts/Release/lodestone}
SHOTS=${1:-}
WORK=$(mktemp -d /tmp/lodepractice.XXXX)
export HOME=$WORK/home
mkdir -p "$HOME/Music"
export DISPLAY=${DISPLAY:-:98}
export JACK_NO_AUDIO_RESERVATION=1
export JACK_NO_START_SERVER=1      # never let jack_lsp start a second server

LODE_PID= METRO_PID= JACK_PID= XVFB_PID=
cleanup() {
    for p in $LODE_PID $METRO_PID $JACK_PID $XVFB_PID; do kill "$p" 2>/dev/null; done
    sleep 0.5
    for p in $LODE_PID $METRO_PID $JACK_PID $XVFB_PID; do kill -9 "$p" 2>/dev/null; done
    true
}
trap cleanup EXIT

if ! xdpyinfo >/dev/null 2>&1; then
    Xvfb "$DISPLAY" -screen 0 1600x1000x24 >/dev/null 2>&1 &
    XVFB_PID=$!
    sleep 1
fi

jackd --no-realtime -d dummy -r 48000 -p 256 -C 2 -P 2 > "$WORK/jackd.log" 2>&1 &
JACK_PID=$!
for i in $(seq 50); do jack_lsp >/dev/null 2>&1 && break; sleep 0.1; done

# 1.8 s of A440 every 2 s: a sustained note for the tuner, with onsets for slicing
jack_metro -b 30 -f 440 -A 0.4 -D 1800 > "$WORK/metro.log" 2>&1 &
METRO_PID=$!

LODE_AUDIO_TYPE=JACK LODE_SELFTEST=practice ${LODE_WRAP:-} "$BIN" > "$WORK/lodestone.log" 2>&1 &
LODE_PID=$!

# wire the tone into the app's first input as soon as its ports exist
for i in $(seq 200); do
    IN=$(jack_lsp 2>/dev/null | grep -E '^Lodestone:in_1$|:in_1$' | grep -v metro | head -1)
    [ -n "$IN" ] && break
    sleep 0.1
done
METRO_PORT=$(jack_lsp 2>/dev/null | grep '^metro:' | head -1)
echo "JACK: tone $METRO_PORT -> $IN"
jack_connect "$METRO_PORT" "$IN"

if [ -n "$SHOTS" ]; then
    mkdir -p "$SHOTS"
    ( for n in $(seq 1 60); do
          sleep 1
          grep -q "practice setup persisted\|sounds are still there" "$WORK/lodestone.log" 2>/dev/null && {
              sleep 1.5; import -window root "$SHOTS/practice.png"; break; }
      done ) &
fi

wait $LODE_PID
RESULT=$?
cat "$WORK/lodestone.log"
echo "exit code $RESULT"
echo "work dir: $WORK"
exit $RESULT
