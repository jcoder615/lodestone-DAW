#!/bin/bash
# usage: ui_session.sh start|stop|shot NAME|key KEYS|click X Y|dclick X Y|type TEXT
export DISPLAY=:99
OUT=/tmp/lodetest
mkdir -p $OUT
case "$1" in
  start)
    pgrep -x Xvfb >/dev/null || (Xvfb :99 -screen 0 1600x1000x24 >/dev/null 2>&1 &)
    sleep 1
    export HOME=${LODE_HOME:-/tmp/lodehome}; mkdir -p $HOME/Music
    nohup ${LODE_BIN:-/home/claude/lodestone/build/Lodestone_artefacts/Release/lodestone} "${@:2}" > $OUT/run.log 2>&1 &
    echo $! > $OUT/pid
    sleep ${LODE_WAIT:-8};;
  stop) kill $(cat $OUT/pid) 2>/dev/null; sleep 1; kill -9 $(cat $OUT/pid) 2>/dev/null; true;;
  shot) sleep ${2:+0}; import -window root $OUT/$2.png;;
  key) xdotool key --delay 80 "${@:2}"; sleep 0.8;;
  click) xdotool mousemove $2 $3 click 1; sleep 0.8;;
  rclick) xdotool mousemove $2 $3 click 3; sleep 0.8;;
  dclick) xdotool mousemove $2 $3 click --repeat 2 --delay 60 1; sleep 1;;
  drag) xdotool mousemove $2 $3 mousedown 1 mousemove $4 $5 sleep 0.2 mouseup 1; sleep 0.8;;
  type) xdotool type --delay 50 "$2"; sleep 0.8;;
  alive) kill -0 $(cat $OUT/pid) 2>/dev/null && echo ALIVE || (echo DEAD; tail -20 $OUT/run.log);;
esac
