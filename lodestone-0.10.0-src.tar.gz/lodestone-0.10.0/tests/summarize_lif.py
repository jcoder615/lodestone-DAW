#!/usr/bin/env python3
"""Summarize importer output: python3 -I summarize_lif.py <run_import output file> [--brief]"""
import json
import sys

text = open(sys.argv[1], encoding="utf-8", errors="replace").read()
brief = "--brief" in sys.argv
if "===LIF-BEGIN===" not in text:
    print("ERROR:", text.split("===ERROR===")[-1].strip()[:600])
    sys.exit(1)
j = json.loads(text.split("===LIF-BEGIN===")[1].split("===LIF-END===")[0])
notes = sum(len(c.get("notes", [])) for t in j["tracks"] for c in t["clips"])
audio = sum(1 for t in j["tracks"] for c in t["clips"] if c["type"] == "audio")
end = max((c["start"] + c.get("length", 0) for t in j["tracks"] for c in t["clips"]), default=0)
print(f"tempo {j['tempo']} sig {j['timeSig']} tracks {len(j['tracks'])} notes {notes} audio clips {audio} length {end / 4:.0f} bars, warnings {len(j['warnings'])}")
if brief:
    sys.exit(0)
for t in j["tracks"]:
    inst = t.get("instrument", {})
    detail = inst.get("preset") or (f"prog {inst.get('program')} bank {inst.get('bank')}" if inst.get("type") in ("gm", "sf2") else "")
    if inst.get("type") == "drumkit":
        pads = inst.get("pads", [])
        detail = f"{len(pads)} pads, {sum(1 for p in pads if p.get('file'))} with samples"
    if inst.get("type") == "sampler":
        detail = inst["file"].split("/")[-1] + f" root {inst.get('root')}"
    if inst.get("type") == "plugin":
        detail = inst.get("name")
    n = sum(len(c.get("notes", [])) for c in t["clips"])
    print(f"  {t['name'][:30]:30s} {t['kind']:10s} {str(inst.get('type', '-')):8s} clips {len(t['clips']):3d} notes {n:5d}  {detail}")
for w in j["warnings"]:
    print("  ! " + w)
