#!/bin/bash
# render_check.sh <input> <out.wav>: headless import+render, then print level stats
export DISPLAY=${DISPLAY:-:99}
H=/tmp/rhome_$$; rm -rf $H; mkdir -p $H/Music
HOME=$H timeout 600 /home/claude/lodestone/build/Lodestone_artefacts/Release/lodestone --render "$1" "$2" 2>&1 | grep -E "Rendered|failed|Imported|import" | cut -c1-300
python3 -I - "$2" <<'PY'
import sys, numpy as np, wave
try:
    w=wave.open(sys.argv[1])
except Exception as e:
    print("no output:", e); sys.exit()
n=w.getnframes(); ch=w.getnchannels(); sr=w.getframerate(); raw=w.readframes(n)
b=np.frombuffer(raw,dtype=np.uint8).reshape(-1,3)
x=(b[:,0].astype(np.int32)|(b[:,1].astype(np.int32)<<8)|(b[:,2].astype(np.int32)<<16)); x=np.where(x>=1<<23,x-(1<<24),x)/8388607.0
x=x.reshape(-1,ch)
seg=sr*8
rms=[20*np.log10(np.sqrt((x[i:i+seg]**2).mean())+1e-9) for i in range(0,len(x),seg)]
print(f"  {n/sr:.1f}s peak {20*np.log10(np.abs(x).max()+1e-12):.1f} dBFS, clipped {(np.abs(x)>0.999).sum()} samples, rms/8s:", ' '.join(f"{r:.0f}" for r in rms))
PY
rm -rf $H
