/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    The "Instrument" panel (think GarageBand's Smart Controls): a device
    chain for the selected track with an editor for whichever device is
    selected. Also: plugin windows, the UIBehaviour, and sample recording.
*/
#pragma once

#include "Session.h"
#include "Theme.h"

namespace lode
{

class DrumMachinePlugin;
class SoundFontPlugin;

//==============================================================================
/** A rotary knob bound to an AutomatableParameter. */
class ParamKnob : public juce::Component,
                  private juce::Timer
{
public:
    ParamKnob (te::AutomatableParameter::Ptr, const juce::String& label = {}, juce::Colour = Col::south);
    ~ParamKnob() override;

    void resized() override;
    void paint (juce::Graphics&) override;

    juce::Slider slider;
    te::AutomatableParameter::Ptr param;

private:
    juce::String label;
    void timerCallback() override;
};

/** A knob for a raw ValueTree property (for settings that aren't automatable). */
class PropertyKnob : public juce::Component
{
public:
    PropertyKnob (const juce::String& label, double min, double max, double defaultValue,
                  std::function<double()> getter, std::function<void (double)> setter,
                  std::function<juce::String (double)> formatter = {});

    void resized() override;
    void paint (juce::Graphics&) override;
    void refresh();

    juce::Slider slider;

private:
    juce::String label;
    std::function<double()> getter;
    std::function<void (double)> setter;
    std::function<juce::String (double)> formatter;
};

//==============================================================================
class GenericPluginEditor : public juce::Component
{
public:
    GenericPluginEditor (te::Plugin&);

    void resized() override;
    void paint (juce::Graphics&) override;
    int getIdealHeight (int width) const;

private:
    te::Plugin::Ptr plugin;
    juce::OwnedArray<ParamKnob> knobs;
    juce::Viewport viewport;
    juce::Component content;
};

//==============================================================================
/** Records a short sample from the audio input (PO-33 style: hold to sample). */
class SampleRecorder : public juce::AudioIODeviceCallback
{
public:
    SampleRecorder (te::Engine&);
    ~SampleRecorder() override;

    void start();
    juce::File stopAndSave (const juce::File& folder, const juce::String& baseName);
    bool isRecording() const        { return recording.load(); }
    float getLevel() const          { return level.load(); }

    void audioDeviceIOCallbackWithContext (const float* const* in, int numIn, float* const* out, int numOut,
                                           int numSamples, const juce::AudioIODeviceCallbackContext&) override;
    void audioDeviceAboutToStart (juce::AudioIODevice*) override;
    void audioDeviceStopped() override {}

private:
    te::Engine& engine;
    std::atomic<bool> recording { false };
    std::atomic<float> level { 0.0f };
    juce::AudioBuffer<float> buffer;
    std::atomic<int> writePos { 0 };
    double sampleRate = 44100.0;
};

//==============================================================================
class DrumMachineEditor : public juce::Component,
                          private juce::Timer
{
public:
    DrumMachineEditor (DrumMachinePlugin&, Session*);
    ~DrumMachineEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    void selectPad (int);

private:
    class Pad;
    DrumMachinePlugin& drums;
    Session* session;
    juce::OwnedArray<Pad> pads;
    int selectedPad = 0;

    juce::ComboBox kitBox;
    juce::TextButton saveKitButton { "Save Kit..." };
    juce::Label padTitle;
    juce::OwnedArray<PropertyKnob> padKnobs;
    juce::ToggleButton reverseToggle { "Reverse" }, oneShotToggle { "One-shot" }, muteToggle { "Mute" };
    juce::ComboBox chokeBox;
    juce::TextButton learnButton { "Learn note" }, loadButton { "Load..." }, sampleButton { "Hold to Sample" };
    std::unique_ptr<SampleRecorder> recorder;
    std::unique_ptr<juce::FileChooser> chooser;

    void timerCallback() override;
    void refreshPadDetails();
    void rebuildKitBox();
    void loadSampleIntoPad (int pad);
    void saveKit();
    void startSampling();
    void stopSampling();

    friend class Pad;
};

//==============================================================================
class SoundFontEditor : public juce::Component,
                        private juce::ListBoxModel
{
public:
    SoundFontEditor (SoundFontPlugin&);

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    SoundFontPlugin& sf;
    juce::ComboBox fontBox;
    juce::TextEditor filter;
    juce::ListBox list { "Programs", this };
    juce::Array<int> visible;    // indices into the preset list
    std::unique_ptr<ParamKnob> volumeKnob, reverbKnob, chorusKnob;
    juce::Label title;

    void refreshList();
    int getNumRows() override;
    void paintListBoxItem (int row, juce::Graphics&, int w, int h, bool selected) override;
    void listBoxItemClicked (int row, const juce::MouseEvent&) override;
};

//==============================================================================
class SynthEditor : public juce::Component
{
public:
    SynthEditor (te::Plugin& fourOsc);

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    te::Plugin::Ptr synth;
    juce::ComboBox presetBox, osc1Wave, osc2Wave, filterType;
    juce::OwnedArray<juce::Component> knobs;
    juce::TextButton allParams { "All parameters..." };
    juce::Label title;

    void build();
};

//==============================================================================
/** The Instrument tab: device chain of the selected track + device editor. */
class DeviceChainPanel : public juce::Component,
                         private juce::ChangeListener,
                         private juce::ValueTree::Listener,
                         private juce::AsyncUpdater
{
public:
    DeviceChainPanel (Session&);
    ~DeviceChainPanel() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void showTrack (te::AudioTrack*);
    void selectDevice (te::Plugin*);

private:
    Session& session;
    te::SafeSelectable<te::AudioTrack> track;
    te::Plugin::Ptr selectedPlugin;
    juce::OwnedArray<juce::TextButton> deviceButtons;
    juce::TextButton addFxButton { "+ Effect" }, changeInstrument { "Change..." };
    std::unique_ptr<juce::Component> editor;
    juce::Viewport editorViewport;
    juce::Label emptyLabel;

    void rebuild();
    void createEditorFor (te::Plugin*);
    void showDeviceMenu (te::Plugin*);
    void changeListenerCallback (juce::ChangeBroadcaster*) override;
    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override;
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override;
    void valueTreeChildOrderChanged (juce::ValueTree&, int, int) override;
    void handleAsyncUpdate() override;
};

//==============================================================================
class LodeUIBehaviour : public te::UIBehaviour
{
public:
    LodeUIBehaviour() = default;

    std::unique_ptr<juce::Component> createPluginWindow (te::PluginWindowState&) override;
    void recreatePluginWindowContentAsync (te::Plugin&) override;
    void runTaskWithProgressBar (te::ThreadPoolJobWithProgress&) override;
    void showWarningAlert (const juce::String& title, const juce::String& message) override;
    void showInfoMessage (const juce::String&) override;
    void showWarningMessage (const juce::String&) override;

    std::function<void (const juce::String&)> onStatusMessage;
};

/** Builds a menu of everything that can be inserted as an effect. */
void showAddEffectMenu (Session&, te::AudioTrack&, juce::Component* target);
void showAddMasterEffectMenu (Session&, juce::Component* target);
void showEffectMenu (Session&, juce::Component* target, std::function<void (const juce::String& description)> chosen);

/** Builds a menu of instruments; calls back with a description string. */
void showInstrumentMenu (Session&, juce::Component* target, std::function<void (const juce::String&)> chosen);

} // namespace lode
