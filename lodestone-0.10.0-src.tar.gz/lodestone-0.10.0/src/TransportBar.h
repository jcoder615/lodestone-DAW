/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#pragma once

#include "Session.h"
#include "Theme.h"
#include "Mixer.h"

namespace lode
{

/** A number you can drag up/down, scroll, or double-click to type (tempo etc.). */
class DragNumber : public juce::Component
{
public:
    DragNumber (double min, double max, double step, int decimals);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

    void setValue (double, bool notify);
    double getValue() const     { return value; }

    std::function<void (double)> onChange;
    juce::String suffix, caption;

private:
    double value = 0, minV, maxV, step, dragStartValue = 0;
    int decimals;
    std::unique_ptr<juce::TextEditor> editor;
};

//==============================================================================
class TransportBar : public juce::Component,
                     private juce::Timer,
                     private juce::ChangeListener
{
public:
    TransportBar (Session&, juce::ApplicationCommandManager&);
    ~TransportBar() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void refresh();

    std::function<void()> onToggleBrowser, onToggleKeyboard;
    void setKeyboardActive (bool b)     { keyboardButton.setToggleState (b, juce::dontSendNotification); }

private:
    Session& session;
    juce::ApplicationCommandManager& commands;

    IconButton toStart { "tostart", "Go to start (Home)" }, play { "play", "Play / Stop (Space)" },
               stopButton { "stop", "Stop / return to start" }, record { "record", "Record (R)" },
               loop { "loop", "Loop (L)" }, metronome { "metronome", "Metronome (C)" },
               magnet { "magnet", "Snap to grid (G)" }, keyboardButton { "keyboard", "Musical typing: play notes with your computer keyboard (Ctrl+K)" },
               browserButton { "folder", "Show/hide the browser (B)" };
    juce::ComboBox countIn, snapBox, timeSig;
    DragNumber tempo { 20.0, 400.0, 0.1, 1 };
    juce::TextButton tap { "TAP" }, practiceButton { "Practice" };
    juce::Label positionLabel, timeLabel, cpuLabel;
    std::unique_ptr<LevelMeter> masterMeter;

    void timerCallback() override;
    void changeListenerCallback (juce::ChangeBroadcaster*) override;
};

} // namespace lode
