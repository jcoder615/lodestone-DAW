/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Theme.h"

namespace lode
{
using namespace juce;

LodeLookAndFeel::LodeLookAndFeel()
{
    setColourScheme ({ Col::bg1, Col::bg2, Col::bg2, Col::line, Col::text, Col::south,
                       Col::text, Col::bg3, Col::text });

    setColour (ResizableWindow::backgroundColourId, Col::bg1);
    setColour (DocumentWindow::backgroundColourId, Col::bg1);
    setColour (TextButton::buttonColourId, Col::bg3);
    setColour (TextButton::buttonOnColourId, Col::south);
    setColour (TextButton::textColourOffId, Col::text);
    setColour (TextButton::textColourOnId, Colours::white);
    setColour (ComboBox::backgroundColourId, Col::bg3);
    setColour (ComboBox::outlineColourId, Col::line);
    setColour (ComboBox::textColourId, Col::text);
    setColour (ComboBox::arrowColourId, Col::textDim);
    setColour (PopupMenu::backgroundColourId, Col::bg2);
    setColour (PopupMenu::textColourId, Col::text);
    setColour (PopupMenu::highlightedBackgroundColourId, Col::south.withAlpha (0.85f));
    setColour (PopupMenu::highlightedTextColourId, Colours::white);
    setColour (PopupMenu::headerTextColourId, Col::textDim);
    setColour (Label::textColourId, Col::text);
    setColour (Slider::thumbColourId, Col::text);
    setColour (Slider::trackColourId, Col::south);
    setColour (Slider::backgroundColourId, Col::bg0);
    setColour (Slider::rotarySliderFillColourId, Col::south);
    setColour (Slider::rotarySliderOutlineColourId, Col::bg0);
    setColour (Slider::textBoxTextColourId, Col::text);
    setColour (Slider::textBoxBackgroundColourId, Col::bg0);
    setColour (Slider::textBoxOutlineColourId, Colours::transparentBlack);
    setColour (TextEditor::backgroundColourId, Col::bg0);
    setColour (TextEditor::textColourId, Col::text);
    setColour (TextEditor::highlightColourId, Col::south.withAlpha (0.4f));
    setColour (TextEditor::outlineColourId, Col::line);
    setColour (TextEditor::focusedOutlineColourId, Col::south);
    setColour (CaretComponent::caretColourId, Col::text);
    setColour (ScrollBar::thumbColourId, Col::bg4);
    setColour (ListBox::backgroundColourId, Col::bg1);
    setColour (ListBox::textColourId, Col::text);
    setColour (TreeView::backgroundColourId, Col::bg1);
    setColour (TreeView::linesColourId, Col::line);
    setColour (TreeView::selectedItemBackgroundColourId, Col::south.withAlpha (0.35f));
    setColour (ToggleButton::textColourId, Col::text);
    setColour (ToggleButton::tickColourId, Col::south);
    setColour (ToggleButton::tickDisabledColourId, Col::textFaint);
    setColour (TooltipWindow::backgroundColourId, Col::bg0);
    setColour (TooltipWindow::textColourId, Col::text);
    setColour (TooltipWindow::outlineColourId, Col::line);
    setColour (AlertWindow::backgroundColourId, Col::bg2);
    setColour (AlertWindow::textColourId, Col::text);
    setColour (AlertWindow::outlineColourId, Col::line);
    setColour (TabbedButtonBar::tabOutlineColourId, Colours::transparentBlack);
    setColour (TabbedComponent::backgroundColourId, Col::bg1);
    setColour (TabbedComponent::outlineColourId, Colours::transparentBlack);
    setColour (DirectoryContentsDisplayComponent::highlightColourId, Col::south.withAlpha (0.35f));
    setColour (DirectoryContentsDisplayComponent::textColourId, Col::text);
    setColour (FileTreeComponent::backgroundColourId, Col::bg1);
    setColour (ProgressBar::backgroundColourId, Col::bg0);
    setColour (ProgressBar::foregroundColourId, Col::south);
    setColour (ResizableWindow::backgroundColourId, Col::bg1);
}

Font LodeLookAndFeel::font (float height, bool bold)
{
    auto opts = FontOptions (height);
    if (bold)
        opts = opts.withStyle ("Bold");
    return Font (opts);
}

void LodeLookAndFeel::drawButtonBackground (Graphics& g, Button& b, const Colour& backgroundColour,
                                            bool isHighlighted, bool isDown)
{
    auto r = b.getLocalBounds().toFloat().reduced (0.5f);
    auto base = backgroundColour;

    if (b.getToggleState())
        base = b.findColour (TextButton::buttonOnColourId);

    if (! b.isEnabled())
        base = base.withMultipliedAlpha (0.4f);
    else if (isDown)
        base = base.brighter (0.25f);
    else if (isHighlighted)
        base = base.brighter (0.12f);

    g.setColour (base);
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (Colours::white.withAlpha (0.05f));
    g.drawRoundedRectangle (r, 4.0f, 1.0f);
}

Font LodeLookAndFeel::getTextButtonFont (TextButton&, int buttonHeight)
{
    return font (jmin (14.0f, (float) buttonHeight * 0.55f));
}

void LodeLookAndFeel::drawButtonText (Graphics& g, TextButton& b, bool, bool)
{
    g.setFont (getTextButtonFont (b, b.getHeight()));
    auto col = b.findColour (b.getToggleState() ? TextButton::textColourOnId : TextButton::textColourOffId);
    g.setColour (col.withMultipliedAlpha (b.isEnabled() ? 1.0f : 0.45f));
    g.drawFittedText (b.getButtonText(), b.getLocalBounds().reduced (4, 1), Justification::centred, 1, 0.8f);
}

void LodeLookAndFeel::drawRotarySlider (Graphics& g, int x, int y, int width, int height, float pos,
                                        float startAngle, float endAngle, Slider& s)
{
    auto bounds = Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (3.0f);
    auto radius = jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
    auto centre = bounds.getCentre();
    auto toAngle = startAngle + pos * (endAngle - startAngle);
    auto lineW = jmax (2.0f, radius * 0.18f);
    auto arcR = radius - lineW * 0.5f;

    Path bg;
    bg.addCentredArc (centre.x, centre.y, arcR, arcR, 0.0f, startAngle, endAngle, true);
    g.setColour (Col::bg0);
    g.strokePath (bg, PathStrokeType (lineW, PathStrokeType::curved, PathStrokeType::rounded));

    auto fillCol = s.findColour (Slider::rotarySliderFillColourId);
    if (! s.isEnabled())
        fillCol = fillCol.withMultipliedAlpha (0.4f);

    // bipolar sliders fill from the centre
    auto zeroAngle = startAngle;
    if (s.getMinimum() < 0.0 && s.getMaximum() > 0.0)
        zeroAngle = startAngle + (float) s.valueToProportionOfLength (0.0) * (endAngle - startAngle);

    Path val;
    val.addCentredArc (centre.x, centre.y, arcR, arcR, 0.0f, jmin (zeroAngle, toAngle), jmax (zeroAngle, toAngle), true);
    g.setColour (fillCol);
    g.strokePath (val, PathStrokeType (lineW, PathStrokeType::curved, PathStrokeType::rounded));

    auto knobR = radius * 0.62f;
    g.setColour (Col::bg4);
    g.fillEllipse (centre.x - knobR, centre.y - knobR, knobR * 2, knobR * 2);

    Path tick;
    tick.addRoundedRectangle (-1.5f, -knobR, 3.0f, knobR * 0.55f, 1.5f);
    g.setColour (Col::text);
    g.fillPath (tick, AffineTransform::rotation (toAngle).translated (centre));
}

void LodeLookAndFeel::drawLinearSlider (Graphics& g, int x, int y, int width, int height, float sliderPos,
                                        float minSliderPos, float maxSliderPos, Slider::SliderStyle style, Slider& s)
{
    if (style == Slider::LinearBarVertical || style == Slider::LinearBar)
    {
        LookAndFeel_V4::drawLinearSlider (g, x, y, width, height, sliderPos, minSliderPos, maxSliderPos, style, s);
        return;
    }

    auto isVertical = s.isVertical();
    auto r = Rectangle<float> ((float) x, (float) y, (float) width, (float) height);
    auto trackW = isVertical ? jmin (6.0f, r.getWidth() * 0.3f) : jmin (6.0f, r.getHeight() * 0.3f);

    Rectangle<float> track = isVertical ? r.withSizeKeepingCentre (trackW, r.getHeight())
                                        : r.withSizeKeepingCentre (r.getWidth(), trackW);
    g.setColour (Col::bg0);
    g.fillRoundedRectangle (track, trackW * 0.5f);

    auto fill = s.findColour (Slider::trackColourId);
    if (! s.isEnabled()) fill = fill.withMultipliedAlpha (0.4f);
    g.setColour (fill);

    if (isVertical)
        g.fillRoundedRectangle (track.withTop (sliderPos), trackW * 0.5f);
    else
        g.fillRoundedRectangle (track.withRight (sliderPos), trackW * 0.5f);

    // thumb
    if (isVertical)
    {
        auto thumb = Rectangle<float> (jmin (r.getWidth(), 26.0f), 12.0f).withCentre ({ r.getCentreX(), sliderPos });
        g.setColour (Col::bg4.brighter (0.3f));
        g.fillRoundedRectangle (thumb, 3.0f);
        g.setColour (Col::text);
        g.fillRect (thumb.withSizeKeepingCentre (thumb.getWidth() - 6.0f, 1.5f));
    }
    else
    {
        auto thumbR = jmin (7.0f, r.getHeight() * 0.45f);
        g.setColour (Col::text);
        g.fillEllipse (Rectangle<float> (thumbR * 2, thumbR * 2).withCentre ({ sliderPos, r.getCentreY() }));
    }
}

void LodeLookAndFeel::drawComboBox (Graphics& g, int width, int height, bool, int, int, int, int, ComboBox& box)
{
    auto r = Rectangle<float> (0, 0, (float) width, (float) height).reduced (0.5f);
    g.setColour (box.findColour (ComboBox::backgroundColourId).withMultipliedAlpha (box.isEnabled() ? 1.0f : 0.5f));
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (box.findColour (ComboBox::outlineColourId));
    g.drawRoundedRectangle (r, 4.0f, 1.0f);

    auto arrowZone = Rectangle<float> ((float) width - 16.0f, 0.0f, 12.0f, (float) height);
    Path p;
    auto c = arrowZone.getCentre();
    p.addTriangle (c.x - 3.5f, c.y - 1.5f, c.x + 3.5f, c.y - 1.5f, c.x, c.y + 2.5f);
    g.setColour (box.findColour (ComboBox::arrowColourId));
    g.fillPath (p);
}

Font LodeLookAndFeel::getComboBoxFont (ComboBox& b)
{
    return font (jmin (14.0f, (float) b.getHeight() * 0.6f));
}

void LodeLookAndFeel::positionComboBoxText (ComboBox& box, Label& label)
{
    label.setBounds (4, 1, box.getWidth() - 20, box.getHeight() - 2);
    label.setFont (getComboBoxFont (box));
}

Font LodeLookAndFeel::getPopupMenuFont()        { return font (14.0f); }

void LodeLookAndFeel::drawPopupMenuBackground (Graphics& g, int width, int height)
{
    g.fillAll (Col::bg2);
    g.setColour (Col::line);
    g.drawRect (0, 0, width, height);
}

void LodeLookAndFeel::drawToggleButton (Graphics& g, ToggleButton& b, bool isHighlighted, bool)
{
    auto r = b.getLocalBounds().toFloat();
    auto box = r.removeFromLeft (r.getHeight()).reduced (4.0f);
    g.setColour (b.getToggleState() ? Col::south : Col::bg0);
    g.fillRoundedRectangle (box, 3.0f);
    g.setColour (isHighlighted ? Col::textDim : Col::line);
    g.drawRoundedRectangle (box, 3.0f, 1.0f);

    if (b.getToggleState())
    {
        Path tick;
        tick.startNewSubPath (box.getX() + box.getWidth() * 0.22f, box.getCentreY());
        tick.lineTo (box.getX() + box.getWidth() * 0.42f, box.getBottom() - box.getHeight() * 0.25f);
        tick.lineTo (box.getRight() - box.getWidth() * 0.2f, box.getY() + box.getHeight() * 0.25f);
        g.setColour (Colours::white);
        g.strokePath (tick, PathStrokeType (2.0f));
    }

    g.setColour (b.findColour (ToggleButton::textColourId).withMultipliedAlpha (b.isEnabled() ? 1.0f : 0.5f));
    g.setFont (font (jmin (14.0f, r.getHeight() * 0.6f)));
    g.drawFittedText (b.getButtonText(), r.toNearestInt().withTrimmedLeft (4), Justification::centredLeft, 1);
}

void LodeLookAndFeel::drawScrollbar (Graphics& g, ScrollBar&, int x, int y, int width, int height,
                                     bool isVertical, int thumbStart, int thumbSize, bool isMouseOver, bool isMouseDown)
{
    Rectangle<int> thumb;
    if (isVertical)
        thumb = { x + 2, thumbStart, width - 4, thumbSize };
    else
        thumb = { thumbStart, y + 2, thumbSize, height - 4 };

    g.setColour (Col::bg4.brighter (isMouseDown ? 0.3f : (isMouseOver ? 0.15f : 0.0f)));
    g.fillRoundedRectangle (thumb.toFloat(), 3.0f);
}

Font LodeLookAndFeel::getLabelFont (Label& l)
{
    return l.getFont();
}

void LodeLookAndFeel::drawTabButton (TabBarButton& button, Graphics& g, bool isMouseOver, bool)
{
    auto r = button.getLocalBounds().toFloat().reduced (2.0f, 3.0f);
    auto front = button.isFrontTab();

    if (front)
    {
        g.setColour (Col::bg3);
        g.fillRoundedRectangle (r, 5.0f);
    }
    else if (isMouseOver)
    {
        g.setColour (Col::bg2.brighter (0.1f));
        g.fillRoundedRectangle (r, 5.0f);
    }

    g.setColour (front ? Col::text : Col::textDim);
    g.setFont (font (13.5f, front));
    g.drawFittedText (button.getButtonText(), r.toNearestInt(), Justification::centred, 1);
}

int LodeLookAndFeel::getTabButtonBestWidth (TabBarButton& b, int)
{
    return (int) GlyphArrangement::getStringWidth (font (13.5f, true), b.getButtonText()) + 28;
}

void LodeLookAndFeel::drawTabAreaBehindFrontButton (TabbedButtonBar&, Graphics&, int, int) {}

void LodeLookAndFeel::drawStretchableLayoutResizerBar (Graphics& g, int w, int h, bool, bool isMouseOver, bool isMouseDragging)
{
    g.setColour (isMouseDragging ? Col::south : (isMouseOver ? Col::line.brighter (0.2f) : Col::bg0));
    g.fillRect (0, 0, w, h);
}

void LodeLookAndFeel::fillTextEditorBackground (Graphics& g, int width, int height, TextEditor& e)
{
    g.setColour (e.findColour (TextEditor::backgroundColourId));
    g.fillRoundedRectangle (Rectangle<float> (0, 0, (float) width, (float) height), 4.0f);
}

void LodeLookAndFeel::drawTextEditorOutline (Graphics& g, int width, int height, TextEditor& e)
{
    if (e.isEnabled())
    {
        g.setColour (e.hasKeyboardFocus (true) ? e.findColour (TextEditor::focusedOutlineColourId)
                                               : e.findColour (TextEditor::outlineColourId));
        g.drawRoundedRectangle (Rectangle<float> (0, 0, (float) width, (float) height).reduced (0.5f), 4.0f, 1.0f);
    }
}

//==============================================================================
namespace Draw
{
    void panel (Graphics& g, Rectangle<float> r, Colour fill, float corner)
    {
        g.setColour (fill);
        g.fillRoundedRectangle (r, corner);
    }

    static float dbToProportion (float db)
    {
        // -60 dB .. +6 dB mapped with a gentle curve
        auto p = jlimit (0.0f, 1.0f, (db + 60.0f) / 66.0f);
        return std::pow (p, 1.6f);
    }

    void meter (Graphics& g, Rectangle<float> r, float dbL, float dbR, bool vertical)
    {
        g.setColour (Col::bg0);
        g.fillRoundedRectangle (r, 2.0f);

        auto drawBar = [&] (Rectangle<float> bar, float db)
        {
            auto p = dbToProportion (db);
            if (p <= 0.0f) return;

            ColourGradient grad (Col::green, vertical ? bar.getBottomLeft() : bar.getTopLeft(),
                                 Col::north, vertical ? bar.getTopLeft() : bar.getTopRight(), false);
            grad.addColour (dbToProportion (-12.0f), Col::green);
            grad.addColour (dbToProportion (-3.0f), Col::yellow);
            g.setGradientFill (grad);

            if (vertical)
                g.fillRect (bar.withTop (bar.getBottom() - bar.getHeight() * p));
            else
                g.fillRect (bar.withWidth (bar.getWidth() * p));
        };

        auto inner = r.reduced (1.0f);
        if (vertical)
        {
            auto left = inner.removeFromLeft (inner.getWidth() * 0.5f).withTrimmedRight (0.5f);
            drawBar (left, dbL);
            drawBar (inner.withTrimmedLeft (0.5f), dbR);
        }
        else
        {
            auto top = inner.removeFromTop (inner.getHeight() * 0.5f).withTrimmedBottom (0.5f);
            drawBar (top, dbL);
            drawBar (inner.withTrimmedTop (0.5f), dbR);
        }
    }

    Path magnetIcon (Rectangle<float> r)
    {
        // a horseshoe magnet - Lodestone's snap-to-grid symbol
        Path p;
        auto w = r.getWidth(), h = r.getHeight();
        auto x = r.getX(), y = r.getY();
        auto thick = w * 0.26f;
        auto outerR = w * 0.5f;

        p.startNewSubPath (x, y);
        p.lineTo (x + thick, y);
        p.lineTo (x + thick, y + h - outerR);
        p.addCentredArc (x + outerR, y + h - outerR, outerR - thick, outerR - thick, 0.0f,
                         -MathConstants<float>::halfPi, MathConstants<float>::halfPi, false);
        p.lineTo (x + w - thick, y);
        p.lineTo (x + w, y);
        p.lineTo (x + w, y + h - outerR);
        p.addCentredArc (x + outerR, y + h - outerR, outerR, outerR, 0.0f,
                         MathConstants<float>::halfPi, -MathConstants<float>::halfPi, false);
        p.closeSubPath();
        return p;
    }

    Path icon (const String& name, Rectangle<float> r)
    {
        Path p;
        auto c = r.getCentre();
        auto s = jmin (r.getWidth(), r.getHeight());
        auto sq = Rectangle<float> (s, s).withCentre (c);

        if (name == "play")
        {
            p.addTriangle (sq.getX() + s * 0.2f, sq.getY() + s * 0.1f,
                           sq.getX() + s * 0.2f, sq.getBottom() - s * 0.1f,
                           sq.getRight() - s * 0.1f, c.y);
        }
        else if (name == "stop")
        {
            p.addRoundedRectangle (sq.reduced (s * 0.18f), s * 0.06f);
        }
        else if (name == "record")
        {
            p.addEllipse (sq.reduced (s * 0.16f));
        }
        else if (name == "tostart")
        {
            p.addRectangle (sq.getX() + s * 0.12f, sq.getY() + s * 0.15f, s * 0.12f, s * 0.7f);
            p.addTriangle (sq.getRight() - s * 0.12f, sq.getY() + s * 0.15f,
                           sq.getRight() - s * 0.12f, sq.getBottom() - s * 0.15f,
                           sq.getX() + s * 0.3f, c.y);
        }
        else if (name == "loop")
        {
            auto rr = sq.reduced (s * 0.15f);
            Path arc;
            arc.addCentredArc (c.x, c.y, rr.getWidth() * 0.5f, rr.getHeight() * 0.38f, 0.0f, 0.4f, MathConstants<float>::pi - 0.2f, true);
            Path arc2;
            arc2.addCentredArc (c.x, c.y, rr.getWidth() * 0.5f, rr.getHeight() * 0.38f, 0.0f, MathConstants<float>::pi + 0.4f, MathConstants<float>::twoPi - 0.2f, true);
            PathStrokeType st (s * 0.09f);
            st.createStrokedPath (p, arc);
            Path p2;
            st.createStrokedPath (p2, arc2);
            p.addPath (p2);
            auto a1 = arc.getCurrentPosition();
            p.addTriangle (a1.x - s * 0.12f, a1.y - s * 0.02f, a1.x + s * 0.1f, a1.y - s * 0.12f, a1.x + s * 0.06f, a1.y + s * 0.12f);
            auto a2 = arc2.getCurrentPosition();
            p.addTriangle (a2.x + s * 0.12f, a2.y + s * 0.02f, a2.x - s * 0.1f, a2.y + s * 0.12f, a2.x - s * 0.06f, a2.y - s * 0.12f);
        }
        else if (name == "metronome")
        {
            p.startNewSubPath (sq.getX() + s * 0.3f, sq.getBottom() - s * 0.1f);
            p.lineTo (sq.getX() + s * 0.42f, sq.getY() + s * 0.1f);
            p.lineTo (sq.getRight() - s * 0.42f, sq.getY() + s * 0.1f);
            p.lineTo (sq.getRight() - s * 0.3f, sq.getBottom() - s * 0.1f);
            p.closeSubPath();
            Path needle;
            needle.startNewSubPath (c.x, sq.getBottom() - s * 0.25f);
            needle.lineTo (sq.getRight() - s * 0.12f, sq.getY() + s * 0.2f);
            Path stroked;
            PathStrokeType (s * 0.08f).createStrokedPath (stroked, needle);
            p.setUsingNonZeroWinding (false);
            p.addPath (stroked);
        }
        else if (name == "magnet")
        {
            p = magnetIcon (sq.reduced (s * 0.15f));
        }
        else if (name == "plus")
        {
            p.addRoundedRectangle (c.x - s * 0.06f, sq.getY() + s * 0.2f, s * 0.12f, s * 0.6f, s * 0.03f);
            p.addRoundedRectangle (sq.getX() + s * 0.2f, c.y - s * 0.06f, s * 0.6f, s * 0.12f, s * 0.03f);
        }
        else if (name == "mixer")
        {
            for (int i = 0; i < 3; ++i)
            {
                auto x = sq.getX() + s * (0.22f + 0.28f * (float) i);
                p.addRectangle (x - s * 0.03f, sq.getY() + s * 0.12f, s * 0.06f, s * 0.76f);
                auto ky = sq.getY() + s * (0.3f + 0.2f * (float) ((i * 2) % 3));
                p.addRoundedRectangle (x - s * 0.1f, ky, s * 0.2f, s * 0.12f, s * 0.03f);
            }
        }
        else if (name == "piano")
        {
            auto rr = sq.reduced (s * 0.12f);
            p.addRectangle (rr);
            Path holes;
            for (int i = 1; i < 4; ++i)
                holes.addRectangle (rr.getX() + rr.getWidth() * (float) i / 4.0f - 0.6f, rr.getY() + rr.getHeight() * 0.55f, 1.2f, rr.getHeight() * 0.45f);
            for (int i : { 1, 2 })
                holes.addRectangle (rr.getX() + rr.getWidth() * ((float) i / 4.0f) - rr.getWidth() * 0.07f, rr.getY(), rr.getWidth() * 0.14f, rr.getHeight() * 0.55f);
            p.setUsingNonZeroWinding (false);
            p.addPath (holes);
        }
        else if (name == "drum")
        {
            auto rr = sq.reduced (s * 0.12f);
            p.addEllipse (rr.getX(), rr.getY() + rr.getHeight() * 0.15f, rr.getWidth(), rr.getHeight() * 0.35f);
            p.addRectangle (rr.getX(), rr.getY() + rr.getHeight() * 0.33f, rr.getWidth(), rr.getHeight() * 0.42f);
            p.addEllipse (rr.getX(), rr.getY() + rr.getHeight() * 0.58f, rr.getWidth(), rr.getHeight() * 0.35f);
        }
        else if (name == "wave")
        {
            Path w;
            auto rr = sq.reduced (s * 0.1f);
            w.startNewSubPath (rr.getX(), rr.getCentreY());
            for (int i = 1; i <= 24; ++i)
            {
                auto t = (float) i / 24.0f;
                auto amp = std::sin (t * MathConstants<float>::pi) * 0.45f;
                w.lineTo (rr.getX() + rr.getWidth() * t, rr.getCentreY() + rr.getHeight() * amp * ((i % 2) ? -1.0f : 1.0f));
            }
            PathStrokeType (s * 0.07f).createStrokedPath (p, w);
        }
        else if (name == "gear")
        {
            auto rr = sq.reduced (s * 0.1f);
            auto cr = rr.getWidth() * 0.5f;
            for (int i = 0; i < 8; ++i)
            {
                auto a = (float) i * MathConstants<float>::twoPi / 8.0f;
                Path tooth;
                tooth.addRectangle (-s * 0.07f, -cr, s * 0.14f, s * 0.2f);
                p.addPath (tooth, AffineTransform::rotation (a).translated (c));
            }
            p.addEllipse (c.x - cr * 0.72f, c.y - cr * 0.72f, cr * 1.44f, cr * 1.44f);
            Path hole;
            hole.addEllipse (c.x - cr * 0.3f, c.y - cr * 0.3f, cr * 0.6f, cr * 0.6f);
            p.setUsingNonZeroWinding (false);
            p.addPath (hole);
        }
        else if (name == "mic")
        {
            auto rr = sq.reduced (s * 0.12f);
            p.addRoundedRectangle (c.x - rr.getWidth() * 0.18f, rr.getY(), rr.getWidth() * 0.36f, rr.getHeight() * 0.6f, rr.getWidth() * 0.18f);
            p.addRectangle (c.x - s * 0.03f, rr.getY() + rr.getHeight() * 0.7f, s * 0.06f, rr.getHeight() * 0.22f);
            p.addRectangle (c.x - rr.getWidth() * 0.22f, rr.getBottom() - s * 0.06f, rr.getWidth() * 0.44f, s * 0.06f);
        }
        else if (name == "keyboard")
        {
            auto rr = sq.reduced (s * 0.08f).withSizeKeepingCentre (sq.getWidth() * 0.84f, sq.getHeight() * 0.55f);
            p.addRoundedRectangle (rr, s * 0.05f);
            Path keys;
            for (int row = 0; row < 2; ++row)
                for (int i = 0; i < 5; ++i)
                    keys.addRectangle (rr.getX() + rr.getWidth() * (0.08f + 0.18f * (float) i), rr.getY() + rr.getHeight() * (0.15f + 0.38f * (float) row),
                                       rr.getWidth() * 0.12f, rr.getHeight() * 0.25f);
            p.setUsingNonZeroWinding (false);
            p.addPath (keys);
        }
        else if (name == "folder")
        {
            auto rr = sq.reduced (s * 0.12f);
            p.startNewSubPath (rr.getX(), rr.getY() + rr.getHeight() * 0.15f);
            p.lineTo (rr.getX() + rr.getWidth() * 0.4f, rr.getY() + rr.getHeight() * 0.15f);
            p.lineTo (rr.getX() + rr.getWidth() * 0.5f, rr.getY() + rr.getHeight() * 0.28f);
            p.lineTo (rr.getRight(), rr.getY() + rr.getHeight() * 0.28f);
            p.lineTo (rr.getRight(), rr.getBottom() - rr.getHeight() * 0.1f);
            p.lineTo (rr.getX(), rr.getBottom() - rr.getHeight() * 0.1f);
            p.closeSubPath();
        }
        else if (name == "search")
        {
            Path circle;
            circle.addEllipse (sq.getX() + s * 0.15f, sq.getY() + s * 0.15f, s * 0.48f, s * 0.48f);
            PathStrokeType st (s * 0.09f);
            st.createStrokedPath (p, circle);
            Path handle;
            handle.startNewSubPath (sq.getX() + s * 0.56f, sq.getY() + s * 0.56f);
            handle.lineTo (sq.getRight() - s * 0.15f, sq.getBottom() - s * 0.15f);
            Path h2;
            PathStrokeType (s * 0.12f, PathStrokeType::mitered, PathStrokeType::rounded).createStrokedPath (h2, handle);
            p.addPath (h2);
        }
        else if (name == "power")
        {
            Path arc;
            arc.addCentredArc (c.x, c.y, s * 0.32f, s * 0.32f, 0.0f, 0.6f, MathConstants<float>::twoPi - 0.6f, true);
            PathStrokeType st (s * 0.1f, PathStrokeType::curved, PathStrokeType::rounded);
            st.createStrokedPath (p, arc);
            p.addRoundedRectangle (c.x - s * 0.05f, sq.getY() + s * 0.1f, s * 0.1f, s * 0.4f, s * 0.05f);
        }
        else if (name == "close")
        {
            Path x;
            x.startNewSubPath (sq.getX() + s * 0.25f, sq.getY() + s * 0.25f);
            x.lineTo (sq.getRight() - s * 0.25f, sq.getBottom() - s * 0.25f);
            x.startNewSubPath (sq.getRight() - s * 0.25f, sq.getY() + s * 0.25f);
            x.lineTo (sq.getX() + s * 0.25f, sq.getBottom() - s * 0.25f);
            PathStrokeType (s * 0.1f, PathStrokeType::mitered, PathStrokeType::rounded).createStrokedPath (p, x);
        }
        else if (name == "pencil")
        {
            Path pen;
            pen.addRectangle (-s * 0.08f, -s * 0.35f, s * 0.16f, s * 0.55f);
            pen.addTriangle (-s * 0.08f, s * 0.2f, s * 0.08f, s * 0.2f, 0.0f, s * 0.36f);
            p.addPath (pen, AffineTransform::rotation (MathConstants<float>::pi * 0.25f).translated (c));
        }
        else if (name == "pointer")
        {
            p.startNewSubPath (sq.getX() + s * 0.28f, sq.getY() + s * 0.1f);
            p.lineTo (sq.getX() + s * 0.28f, sq.getBottom() - s * 0.18f);
            p.lineTo (sq.getX() + s * 0.45f, sq.getBottom() - s * 0.33f);
            p.lineTo (sq.getX() + s * 0.58f, sq.getBottom() - s * 0.08f);
            p.lineTo (sq.getX() + s * 0.68f, sq.getBottom() - s * 0.13f);
            p.lineTo (sq.getX() + s * 0.55f, sq.getBottom() - s * 0.38f);
            p.lineTo (sq.getRight() - s * 0.2f, sq.getBottom() - s * 0.4f);
            p.closeSubPath();
        }
        else if (name == "scissors")
        {
            p.addEllipse (sq.getX() + s * 0.1f, sq.getBottom() - s * 0.38f, s * 0.26f, s * 0.26f);
            p.addEllipse (sq.getRight() - s * 0.36f, sq.getBottom() - s * 0.38f, s * 0.26f, s * 0.26f);
            Path blades;
            blades.startNewSubPath (sq.getX() + s * 0.3f, sq.getBottom() - s * 0.35f);
            blades.lineTo (sq.getRight() - s * 0.25f, sq.getY() + s * 0.1f);
            blades.startNewSubPath (sq.getRight() - s * 0.3f, sq.getBottom() - s * 0.35f);
            blades.lineTo (sq.getX() + s * 0.25f, sq.getY() + s * 0.1f);
            Path b2;
            PathStrokeType (s * 0.08f).createStrokedPath (b2, blades);
            p.setUsingNonZeroWinding (false);
            p.addPath (b2);
        }
        else
        {
            p.addEllipse (sq.reduced (s * 0.3f));
        }

        return p;
    }
}

//==============================================================================
IconButton::IconButton (const String& name, const String& tooltip)
    : Button (name), iconName (name)
{
    setTooltip (tooltip);
}

void IconButton::paintButton (Graphics& g, bool isHighlighted, bool isDown)
{
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    auto on = getToggleState();

    g.setColour (on ? onColour.withAlpha (0.22f) : (isHighlighted ? Col::bg4 : Col::bg3));
    if (isDown) g.setColour (Col::bg4.brighter (0.2f));
    g.fillRoundedRectangle (r, 5.0f);

    auto iconArea = r.reduced (r.getHeight() * 0.2f);
    auto col = on ? onColour : (isEnabled() ? Col::text : Col::textFaint);
    g.setColour (col);
    g.fillPath (Draw::icon (iconName, iconArea));
}

//==============================================================================
void LodeLookAndFeel::drawAlertBox (Graphics& g, AlertWindow& alert, const Rectangle<int>& textArea, TextLayout& textLayout)
{
    auto bounds = alert.getLocalBounds().toFloat();
    g.setColour (alert.findColour (AlertWindow::backgroundColourId));
    g.fillRoundedRectangle (bounds, 8.0f);
    g.setColour (alert.findColour (AlertWindow::outlineColourId));
    g.drawRoundedRectangle (bounds.reduced (0.5f), 8.0f, 1.0f);

    // a coloured accent strip instead of V4's giant corner icon, which overlaps long messages
    if (alert.getAlertType() != MessageBoxIconType::NoIcon)
    {
        auto type = alert.getAlertType();
        auto colour = type == MessageBoxIconType::WarningIcon ? Col::yellow
                    : type == MessageBoxIconType::QuestionIcon ? Col::south : Col::green;
        g.setColour (colour);
        g.fillRoundedRectangle (bounds.withWidth (5.0f).reduced (0.0f, 10.0f).translated (6.0f, 0.0f), 2.5f);
    }

    g.setColour (alert.findColour (AlertWindow::textColourId));
    textLayout.draw (g, textArea.toFloat());
}

} // namespace lode
