/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Three small built-in plugins that make Practice mode work:

    KeyZonePlugin    sits in front of an instrument and decides which notes reach
                     it: key range, MIDI channel and transpose. Splits and layers
                     are just several zones listening to the same controller. It
                     also reports every note it sees (keyboard map, range learning
                     and "Save what I played").

    InputTapPlugin   the first plugin on an audio-input sound (the mic): picks the
                     interface channel the mic is plugged into, gates monitoring,
                     meters, feeds the tuner, records hold-to-sample takes and
                     keeps a rolling capture of the last few minutes.

    MasterTapPlugin  near the end of the master chain: writes practice recordings
                     and logs the transport position against the audio clock, so
                     notes played to the metronome land on the beat when saved.
*/
#pragma once

#include "Utils.h"

namespace lode
{

//==============================================================================
/** Lock-free single-producer (audio thread) / single-consumer (message thread) queue. */
template <typename T, int Capacity>
class EventFifo
{
public:
    bool push (const T& item) noexcept
    {
        const auto scope = fifo.write (1);

        if (scope.blockSize1 > 0)       items[(size_t) scope.startIndex1] = item;
        else if (scope.blockSize2 > 0)  items[(size_t) scope.startIndex2] = item;
        else                            return false;

        return true;
    }

    template <typename Fn>
    void drain (Fn&& fn)
    {
        const auto scope = fifo.read (fifo.getNumReady());
        for (int i = 0; i < scope.blockSize1; ++i) fn (items[(size_t) (scope.startIndex1 + i)]);
        for (int i = 0; i < scope.blockSize2; ++i) fn (items[(size_t) (scope.startIndex2 + i)]);
    }

private:
    juce::AbstractFifo fifo { Capacity };
    std::array<T, (size_t) Capacity> items {};
};

/** A MIDI event seen by a KeyZone, stamped with the audio device's clock. */
struct ZoneEvent
{
    double time = 0.0;              // DeviceManager stream time, seconds
    juce::uint8 bytes[3] {};        // the message as it left the zone (already transposed)
    juce::int8 inNote = -1;         // notes only: the key that was actually pressed
    bool passed = true;             // false: the zone filtered it out (still useful for learning)
};

/** True for the plugins Practice mode manages itself - they're hidden from device chains. */
bool isPracticeUtilityPlugin (const te::Plugin*);

//==============================================================================
class KeyZonePlugin : public te::Plugin
{
public:
    KeyZonePlugin (te::PluginCreationInfo);
    ~KeyZonePlugin() override;

    static const char* getPluginName()                  { return NEEDS_TRANS ("Key Zone"); }
    static const char* xmlTypeName;

    juce::String getName() const override               { return "Key Zone"; }
    juce::String getPluginType() override               { return xmlTypeName; }
    juce::String getShortName (int) override            { return "Zone"; }
    juce::String getSelectableDescription() override    { return "Key Zone"; }
    juce::String getVendor() override                   { return "Lodestone"; }

    BusLayout getBusses() const override                { return {}; }
    bool takesMidiInput() override                      { return true; }
    bool takesAudioInput() override                     { return false; }
    bool producesAudioWhenNoAudioInput() override       { return false; }
    int getNumOutputChannelsGivenInputs (int) override  { return 0; }
    void getChannelNames (juce::StringArray*, juce::StringArray*) override {}
    bool canBeAddedToClip() override                    { return false; }
    bool canBeAddedToRack() override                    { return false; }
    bool canBeAddedToMaster() override                  { return false; }

    void initialise (const te::PluginInitialisationInfo&) override;
    void deinitialise() override {}
    void midiPanic() override;
    void applyToBuffer (const te::PluginRenderContext&) override;
    void restorePluginStateFromValueTree (const juce::ValueTree&) override;

    // message thread
    int getLow() const;
    int getHigh() const;
    int getTranspose() const;
    int getChannel() const;     // 0 = any
    void setRange (int low, int high);
    void setTranspose (int semitones);
    void setChannel (int channel);

    EventFifo<ZoneEvent, 4096> events;

    static const juce::Identifier lowID, highID, transposeID, channelID;

private:
    std::atomic<int> lo { 0 }, hi { 127 }, shift { 0 }, chan { 0 };
    std::array<juce::int16, 16 * 128> sounding {};     // (channel, key) -> output note + 1, 0 = not sounding
    te::MidiMessageArray scratch;

    void valueTreeChanged() override;
    void updateAtomics();
    void push (const juce::MidiMessage&, double time, int inNote, bool passed) noexcept;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (KeyZonePlugin)
};

//==============================================================================
class InputTapPlugin : public te::Plugin
{
public:
    InputTapPlugin (te::PluginCreationInfo);
    ~InputTapPlugin() override;

    static const char* getPluginName()                  { return NEEDS_TRANS ("Input"); }
    static const char* xmlTypeName;

    juce::String getName() const override               { return "Input"; }
    juce::String getPluginType() override               { return xmlTypeName; }
    juce::String getShortName (int) override            { return "Input"; }
    juce::String getSelectableDescription() override    { return "Input"; }
    juce::String getVendor() override                   { return "Lodestone"; }

    BusLayout getBusses() const override                { return BusLayout::singlePassThrough(); }
    bool takesAudioInput() override                     { return true; }
    bool takesMidiInput() override                      { return false; }
    int getNumOutputChannelsGivenInputs (int) override  { return 2; }
    bool canBeAddedToClip() override                    { return false; }
    bool canBeAddedToRack() override                    { return false; }
    bool canBeAddedToMaster() override                  { return false; }

    void initialise (const te::PluginInitialisationInfo&) override;
    void deinitialise() override {}
    void applyToBuffer (const te::PluginRenderContext&) override;
    void restorePluginStateFromValueTree (const juce::ValueTree&) override;

    /** Which channel of the input device the source is on: 0, 1, or -1 for both (stereo). */
    int getInputChannel() const;
    void setInputChannel (int);
    bool isMonitoring() const;
    void setMonitoring (bool);

    // --- UI feeds (message thread)
    float getPeakAndReset() noexcept                    { return peak.exchange (0.0f); }
    int copyRecent (float* dest, int num) const;        // most recent (mono) samples for the tuner
    double getSampleRate() const noexcept               { return sampleRate.load(); }
    bool isReceivingAudio() const;                      // has the input been processed lately?

    // --- hold to sample
    void startSampling();
    juce::AudioBuffer<float> stopSampling();
    bool isSampling() const noexcept                    { return sampling.load(); }
    double getSampledSeconds() const noexcept;

    // --- rolling capture of the last few minutes, for "Save what I played"
    static constexpr double captureSeconds = 300.0;
    void enableCapture();                               // allocates the ring (once)
    /** Copies the captured audio between two stream times. Returns false if none overlaps.
        actualStart receives the stream time of the first copied sample. */
    bool copyCapture (double fromTime, double toTime, juce::AudioBuffer<float>& dest, double& actualStart) const;

    static const juce::Identifier inputChannelID, monitorID;

private:
    std::atomic<int> mode { 0 };
    std::atomic<bool> gate { false };
    std::atomic<float> peak { 0.0f };
    std::atomic<double> sampleRate { 48000.0 };
    std::atomic<juce::uint32> lastProcessMs { 0 };

    // tuner ring (mono)
    static constexpr int analysisSize = 8192;
    std::vector<float> analysis = std::vector<float> ((size_t) analysisSize, 0.0f);
    std::atomic<juce::uint32> analysisWrite { 0 };

    // sampling (allocated once, never reallocated: the audio thread may still be writing)
    juce::AudioBuffer<float> sampleBuffer;
    std::atomic<bool> sampling { false };
    std::atomic<int> samplePos { 0 };

    // rolling capture: interleaved stereo int16, written continuously once enabled
    std::vector<juce::int16> ring;
    std::atomic<juce::int64> ringFrames { 0 };          // capacity in frames (0 = not allocated)
    std::atomic<juce::int64> ringWritten { 0 };         // frames written in the current run
    std::atomic<double> ringStartTime { 0.0 };          // stream time of frame 0 of the current run
    double expectedTime = -1.0;

    void valueTreeChanged() override;
    void updateAtomics();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (InputTapPlugin)
};

//==============================================================================
class MasterTapPlugin : public te::Plugin
{
public:
    MasterTapPlugin (te::PluginCreationInfo);
    ~MasterTapPlugin() override;

    static const char* getPluginName()                  { return NEEDS_TRANS ("Practice Tap"); }
    static const char* xmlTypeName;

    juce::String getName() const override               { return "Practice Tap"; }
    juce::String getPluginType() override               { return xmlTypeName; }
    juce::String getShortName (int) override            { return "Tap"; }
    juce::String getSelectableDescription() override    { return "Practice Tap"; }
    juce::String getVendor() override                   { return "Lodestone"; }

    BusLayout getBusses() const override                { return BusLayout::singlePassThrough(); }
    bool takesAudioInput() override                     { return true; }
    int getNumOutputChannelsGivenInputs (int n) override { return juce::jmax (2, n); }
    bool canBeAddedToClip() override                    { return false; }
    bool canBeAddedToRack() override                    { return false; }

    void initialise (const te::PluginInitialisationInfo&) override;
    void deinitialise() override {}
    void applyToBuffer (const te::PluginRenderContext&) override;

    /** A point where the transport position jumped (start, stop, locate). Between two
        marks, edit time advances in step with stream time. */
    struct TransportMark
    {
        double streamTime = 0.0, editTime = 0.0;
        bool playing = false;
    };

    EventFifo<TransportMark, 512> marks;

    /** Stream time at the end of the last processed block. */
    double getLatestStreamTime() const noexcept         { return latestStreamTime.load(); }
    double getSampleRate() const noexcept               { return sampleRate.load(); }

    /** The writer is owned by the caller; pass nullptr before deleting it. */
    void setWriter (juce::AudioFormatWriter::ThreadedWriter*);
    juce::int64 getSamplesWritten() const noexcept      { return samplesWritten.load(); }
    float getPeakAndReset() noexcept                    { return peak.exchange (0.0f); }

private:
    std::atomic<double> latestStreamTime { 0.0 }, sampleRate { 48000.0 };
    double expectedStream = -1.0, expectedEdit = -1.0;
    bool lastPlaying = false;

    juce::SpinLock writerLock;
    juce::AudioFormatWriter::ThreadedWriter* writer = nullptr;
    std::atomic<juce::int64> samplesWritten { 0 };
    std::atomic<float> peak { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MasterTapPlugin)
};

} // namespace lode
