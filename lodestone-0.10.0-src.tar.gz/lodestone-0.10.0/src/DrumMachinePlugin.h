/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    A 16-pad drum sampler designed for playing from MIDI pad controllers
    (Akai MPD218 & friends), e-drum kits, the step sequencer and imported
    FL Studio / LMMS beat patterns.
*/
#pragma once

#include "Utils.h"

namespace lode
{

//==============================================================================
/** Describes a drum kit on disk (Lodestone kit.json or Hydrogen drumkit.xml). */
struct DrumKitInfo
{
    juce::String name;
    juce::File location;        // the kit folder
    juce::String source;        // "Lodestone", "Hydrogen", "User"
};

namespace DrumKits
{
    juce::Array<DrumKitInfo> findAll();
    juce::File getDefaultKitDir();
    juce::String gmDrumName (int note);     // General MIDI percussion names (35..81)

    /** Default pad notes: pad 1 = C1 (36) upwards chromatically, the factory
        layout of most pad controllers and of GM's kick..ride range. */
    inline int defaultNoteForPad (int pad)   { return 36 + pad; }
}

//==============================================================================
class DrumMachinePlugin : public te::Plugin,
                          private juce::AsyncUpdater,
                          private juce::Timer
{
public:
    static constexpr int numPads = 16;

    DrumMachinePlugin (te::PluginCreationInfo);
    ~DrumMachinePlugin() override;

    static const char* getPluginName()                  { return NEEDS_TRANS ("Lodestone Drums"); }
    static const char* xmlTypeName;

    juce::String getName() const override               { return "Lodestone Drums"; }
    juce::String getPluginType() override               { return xmlTypeName; }
    juce::String getShortName (int) override            { return "Drums"; }
    juce::String getSelectableDescription() override    { return "Lodestone Drums"; }
    juce::String getVendor() override                   { return "Lodestone"; }

    bool isSynth() override                             { return true; }
    bool takesMidiInput() override                      { return true; }
    bool takesAudioInput() override                     { return true; }
    bool producesAudioWhenNoAudioInput() override       { return true; }
    bool noTail() override                              { return false; }
    double getTailLength() const override               { return 4.0; }
    int getNumOutputChannelsGivenInputs (int) override  { return 2; }
    BusLayout getBusses() const override                { return BusLayout::singleStereoInOut(); }

    void initialise (const te::PluginInitialisationInfo&) override;
    void deinitialise() override;
    void reset() override;
    void midiPanic() override;
    void applyToBuffer (const te::PluginRenderContext&) override;

    bool hasNameForMidiNoteNumber (int note, int midiChannel, juce::String& name) override;
    void restorePluginStateFromValueTree (const juce::ValueTree&) override;
    std::unique_ptr<EditorComponent> createEditor() override;   // defined in InstrumentPanel.cpp

    //==============================================================================
    // Pad model (message thread)
    juce::ValueTree getPadState (int pad);
    juce::String getPadName (int pad);
    int getPadNote (int pad);
    juce::File getPadFile (int pad);
    bool padHasSample (int pad);
    int findPadForNote (int note);

    void setPadSample (int pad, const juce::File&, const juce::String& name = {});
    void setPadProperty (int pad, const juce::Identifier&, const juce::var&);
    void clearPad (int pad);
    void swapPads (int a, int b);

    /** Loads a kit folder (kit.json or Hydrogen drumkit.xml). Returns an error or empty. */
    juce::String loadKit (const juce::File& kitDir);
    juce::String getKitName() const     { return state.getProperty ("kitName").toString(); }

    /** Applies a JSON kit description: { name, pads:[{name,file,note,gain,pan,tune,decay,choke,...}] } */
    void loadKitDescription (const juce::var& kit, const juce::File& baseDir);

    /** Triggers a pad for auditioning from the UI. */
    void triggerPad (int pad, float velocity);

    /** UI feedback: increments every time a pad is hit. */
    juce::uint32 getPadHitCount (int pad) const     { return padHits[(size_t) pad].load(); }
    float getPadLastVelocity (int pad) const        { return padVelocity[(size_t) pad].load(); }

    /** MIDI learn: the next incoming note will be assigned to this pad. */
    void startLearn (int pad)                       { learnPad = pad; }
    int getLearnPad() const                         { return learnPad; }

    static const juce::Identifier padType, layerType;
    static const juce::Identifier nameProp, noteProp, gainProp, panProp, tuneProp, decayProp, cutoffProp,
                                  reverseProp, chokeProp, velSensProp, oneShotProp, muteProp, fileProp,
                                  minVelProp, maxVelProp, startProp, endProp;

    te::AutomatableParameter::Ptr masterGainParam;
    juce::CachedValue<float> masterGainValue;

private:
    //==============================================================================
    struct SampleData
    {
        juce::AudioBuffer<float> buffer;
        double sampleRate = 44100.0;
    };

    struct Layer
    {
        std::shared_ptr<const SampleData> sample;
        float minVel = 0.0f, maxVel = 1.0f, gain = 1.0f;
    };

    struct PadRuntime
    {
        std::vector<Layer> layers;
        int note = 36;
        float gain = 1.0f, pan = 0.0f, pitch = 1.0f, decay = 1.0f, cutoff = 20000.0f, velSens = 0.75f;
        float start = 0.0f, end = 1.0f;        // the part of the sample that plays (0..1)
        bool reverse = false, oneShot = true, mute = false;
        int choke = 0;
    };

    struct Kit
    {
        std::array<PadRuntime, numPads> pads;
    };

    struct Voice
    {
        bool active = false;
        int pad = -1, note = -1, choke = 0;
        const SampleData* sample = nullptr;
        std::shared_ptr<const SampleData> keepAlive;
        double pos = 0.0, inc = 1.0;
        double lo = 0.0, hi = 0.0, edgeFade = 0.0;   // playable range (source samples), fade at a cut end
        float gainL = 1.0f, gainR = 1.0f;
        float env = 1.0f, envMul = 1.0f;
        float fade = 1.0f, fadeStep = 0.0f;
        bool reverse = false, oneShot = true, released = false;
        float lpCoef = 1.0f, lpL = 0.0f, lpR = 0.0f;
        int startDelay = 0;
    };

    std::atomic<std::shared_ptr<const Kit>> currentKit;
    std::vector<std::shared_ptr<const Kit>> retiredKits;
    std::map<juce::String, std::shared_ptr<const SampleData>> sampleCache;

    std::array<Voice, 64> voices;
    double sampleRate = 44100.0;

    juce::AbstractFifo uiFifo { 128 };
    std::array<std::pair<int, float>, 128> uiEvents;

    std::array<std::atomic<juce::uint32>, numPads> padHits {};
    std::array<std::atomic<float>, numPads> padVelocity {};
    std::atomic<int> learnPad { -1 };
    std::atomic<int> learnedNote { -1 };

    void ensurePadStates();
    void rebuildKit();
    std::shared_ptr<const SampleData> loadSample (const juce::File&);

    void startVoice (const Kit&, int pad, int note, float velocity, int sampleOffset);
    void noteOff (const Kit&, int note, int sampleOffset);
    void renderVoices (juce::AudioBuffer<float>&, int start, int num);

    void valueTreeChanged() override                    { Plugin::valueTreeChanged(); triggerAsyncUpdate(); }
    void handleAsyncUpdate() override;
    void timerCallback() override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DrumMachinePlugin)
};

} // namespace lode
