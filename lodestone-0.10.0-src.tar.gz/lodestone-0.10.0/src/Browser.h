/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    The browser: sounds (kits, GM instruments, synth presets, plugin
    instruments), effects (built-ins, 186 Airwindows, plugins) and files.
    Everything in it can be dragged onto the arrangement or double-clicked.
*/
#pragma once

#include "Session.h"
#include "Theme.h"

namespace lode
{

namespace BrowserItems
{
    /** Item descriptions look like "kind|payload". */
    bool isInstrument (const juce::String& description);
    bool isEffect (const juce::String& description);
    InstrumentSpec toInstrumentSpec (const juce::String& description);
    te::Plugin::Ptr createEffect (Session&, const juce::String& description);
    juce::String displayName (const juce::String& description);

    /** Applies an item to a track: instruments replace the track's instrument (or make
        a new track if track is null), effects are inserted before the fader. */
    bool applyToTrack (Session&, const juce::String& description, te::AudioTrack* track, bool createTrackIfNeeded);

    /** All items as flat (name, description, category) entries - used by search and the command palette. */
    struct Entry { juce::String name, description, category; };
    juce::Array<Entry> getAllEntries (te::Engine&);
}

//==============================================================================
class PreviewPlayer : public juce::ChangeBroadcaster
{
public:
    PreviewPlayer (te::Engine&);
    ~PreviewPlayer() override;

    void play (const juce::File&);
    void stop();
    bool isPlaying() const;

private:
    te::Engine& engine;
    juce::AudioSourcePlayer sourcePlayer;
    juce::AudioTransportSource transport;
    std::unique_ptr<juce::AudioFormatReaderSource> readerSource;
};

//==============================================================================
class BrowserPanel : public juce::Component,
                     private juce::FileBrowserListener
{
public:
    BrowserPanel (Session&);
    ~BrowserPanel() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void refresh();
    void showTab (int);

    std::function<void (const juce::File&)> onOpenFile;    // projects/MIDI imported via the main window
    juce::Array<juce::File> getSelectedFiles() const;

    Session& session;

private:
    struct Item;
    juce::OwnedArray<juce::TextButton> tabButtons;
    juce::TextEditor search;
    juce::TreeView tree;
    std::unique_ptr<juce::TreeViewItem> root;
    int currentTab = 0;

    juce::TimeSliceThread fileThread { "Lodestone file browser" };
    juce::WildcardFileFilter fileFilter { "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3;*.mid;*.midi;*.mmp;*.mmpz;*.flp;*.band;*.logicx;*.dawproject;*.lodestone;*.sf2;*.zip",
                                          "*", "Media & projects" };
    juce::DirectoryContentsList fileList { &fileFilter, fileThread };
    juce::FileTreeComponent fileTree { fileList };
    juce::ComboBox places;
    juce::ToggleButton previewToggle { "Preview" };
    PreviewPlayer preview;
    juce::Label hint;

    void rebuildTree();
    void selectionChanged() override;
    void fileClicked (const juce::File&, const juce::MouseEvent&) override;
    void fileDoubleClicked (const juce::File&) override;
    void browserRootChanged (const juce::File&) override {}
};

} // namespace lode
