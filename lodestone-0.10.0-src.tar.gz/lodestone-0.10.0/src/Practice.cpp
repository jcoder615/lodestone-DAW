/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Practice.h"
#include "Browser.h"
#include "Mixer.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"

namespace lode
{
using namespace juce;

//==============================================================================
// Pitch detection (YIN, de Cheveigne & Kawahara 2002)
//==============================================================================
float PitchDetector::detect (const float* x, int n, double sr, float& clarity)
{
    clarity = 0.0f;

    const int minTau = jmax (2, (int) (sr / 1500.0));     // highest pitch we look for
    const int maxTau = jmin (n / 2, (int) (sr / 40.0));    // lowest: a bass's low E is 41 Hz

    if (maxTau <= minTau + 2)
        return 0.0f;

    double energy = 0.0;
    for (int i = 0; i < n; ++i)
        energy += (double) x[i] * x[i];

    if (energy / n < 1.0e-7)       // about -70 dBFS: nothing there
        return 0.0f;

    const int window = n - (maxTau + 1);
    std::vector<float> d ((size_t) maxTau + 2, 0.0f);

    for (int tau = 1; tau <= maxTau + 1; ++tau)
    {
        double s = 0.0;
        for (int i = 0; i < window; ++i)
        {
            const float diff = x[i] - x[i + tau];
            s += diff * diff;
        }
        d[(size_t) tau] = (float) s;
    }

    // cumulative mean normalised difference
    std::vector<float> cmnd (d.size(), 1.0f);
    double running = 0.0;
    for (size_t tau = 1; tau < d.size(); ++tau)
    {
        running += d[tau];
        cmnd[tau] = running > 0.0 ? (float) (d[tau] * (double) tau / running) : 1.0f;
    }

    int best = -1;
    for (int tau = minTau; tau <= maxTau; ++tau)
    {
        if (cmnd[(size_t) tau] < 0.15f)
        {
            while (tau + 1 <= maxTau && cmnd[(size_t) tau + 1] < cmnd[(size_t) tau])
                ++tau;

            best = tau;
            break;
        }
    }

    if (best < 0)
    {
        best = minTau;
        for (int tau = minTau; tau <= maxTau; ++tau)
            if (cmnd[(size_t) tau] < cmnd[(size_t) best])
                best = tau;

        if (cmnd[(size_t) best] > 0.35f)
            return 0.0f;
    }

    double refined = best;
    if (best > 1 && best + 1 < (int) cmnd.size())
    {
        const double s0 = cmnd[(size_t) best - 1], s1 = cmnd[(size_t) best], s2 = cmnd[(size_t) best + 1];
        const double denom = s0 + s2 - 2.0 * s1;
        if (std::abs (denom) > 1.0e-12)
            refined = best + 0.5 * (s0 - s2) / denom;
    }

    clarity = jlimit (0.0f, 1.0f, 1.0f - cmnd[(size_t) best]);
    return refined > 0.0 ? (float) (sr / refined) : 0.0f;
}

float PitchDetector::detectInBuffer (const AudioBuffer<float>& b, double sr, float& clarity)
{
    clarity = 0.0f;
    const int win = 4096;

    if (b.getNumSamples() < win)
        return 0.0f;

    // the loudest window is usually the steadiest part of a sung or played note
    int bestStart = 0;
    float bestRms = 0.0f;
    for (int s = 0; s + win <= b.getNumSamples(); s += win / 4)
        if (auto rms = b.getRMSLevel (0, s, win); rms > bestRms)
        {
            bestRms = rms;
            bestStart = s;
        }

    std::vector<float> mono ((size_t) win);
    for (int i = 0; i < win; ++i)
        mono[(size_t) i] = 0.5f * (b.getSample (0, bestStart + i) + b.getSample (jmin (1, b.getNumChannels() - 1), bestStart + i));

    return detect (mono.data(), win, sr, clarity);
}

//==============================================================================
// Samples
//==============================================================================
Range<int> findActivity (const AudioBuffer<float>& b, double sampleRate, double frameSeconds, double minActiveSeconds)
{
    const int frame = jmax (32, (int) (frameSeconds * sampleRate));
    const int numFrames = b.getNumSamples() / frame;
    const int chans = jmin (2, b.getNumChannels());

    if (numFrames < 2 || chans == 0)
        return {};

    std::vector<float> db ((size_t) numFrames);
    for (int f = 0; f < numFrames; ++f)
    {
        float rms = 0.0f;
        for (int ch = 0; ch < chans; ++ch)
            rms = jmax (rms, b.getRMSLevel (ch, f * frame, frame));
        db[(size_t) f] = Decibels::gainToDecibels (rms, -120.0f);
    }

    // "Played" means clearly above this input's own noise floor - a condenser mic in a
    // quiet room still hisses at -60..-50 dBFS - but never needing more than -24 dBFS.
    auto sorted = db;
    std::sort (sorted.begin(), sorted.end());
    const float floorDb = sorted[sorted.size() / 20];
    const float threshold = jlimit (-50.0f, -24.0f, floorDb + 12.0f);

    int firstActive = -1, lastActive = -1, active = 0;
    for (int f = 0; f < numFrames; ++f)
        if (db[(size_t) f] > threshold)
        {
            if (firstActive < 0)
                firstActive = f;
            lastActive = f;
            ++active;
        }

    if (firstActive < 0 || active * frame < (int) (minActiveSeconds * sampleRate))
        return {};

    return { firstActive * frame, jmin (b.getNumSamples(), (lastActive + 1) * frame) };
}

File saveSampleTake (const AudioBuffer<float>& buffer, double sampleRate, const File& folder, const String& baseName)
{
    const int len = buffer.getNumSamples();
    if (len < 256)
        return {};

    const int chans = jmin (2, buffer.getNumChannels());
    auto active = findActivity (buffer, sampleRate, 0.01, 0.02);

    if (active.isEmpty())
        return {};

    int start = jmax (0, active.getStart() - (int) (0.006 * sampleRate));
    int end = jmin (len, active.getEnd() + (int) (0.06 * sampleRate));

    if (end - start < (int) (0.02 * sampleRate))
        return {};

    AudioBuffer<float> out (2, end - start);
    for (int ch = 0; ch < 2; ++ch)
        out.copyFrom (ch, 0, buffer, jmin (ch, chans - 1), start, end - start);

    if (auto mag = out.getMagnitude (0, out.getNumSamples()); mag > 0.0001f)
        out.applyGain (Decibels::decibelsToGain (-1.0f) / mag);

    const int fade = jmin (out.getNumSamples() / 4, (int) (0.003 * sampleRate));
    out.applyGainRamp (0, fade, 0.0f, 1.0f);
    out.applyGainRamp (out.getNumSamples() - fade, fade, 1.0f, 0.0f);

    folder.createDirectory();
    auto file = folder.getNonexistentChildFile (File::createLegalFileName (baseName), ".wav", false);

    std::unique_ptr<OutputStream> stream = std::make_unique<FileOutputStream> (file);
    WavAudioFormat wav;
    auto writer = wav.createWriterFor (stream, AudioFormatWriterOptions().withSampleRate (sampleRate)
                                                                         .withNumChannels (2)
                                                                         .withBitsPerSample (24));
    if (writer == nullptr)
        return {};

    writer->writeFromAudioSampleBuffer (out, 0, out.getNumSamples());
    return file;
}

Array<float> findSlicePoints (const AudioBuffer<float>& b, double sr, int maxSlices)
{
    Array<float> starts;
    starts.add (0.0f);

    const int len = b.getNumSamples();
    const int hop = jmax (32, (int) (sr * 0.005));
    const int chans = jmin (2, b.getNumChannels());

    if (len < hop * 8 || chans == 0)
        return starts;

    // energy in 5 ms frames
    std::vector<float> energy;
    for (int s = 0; s + hop <= len; s += hop)
    {
        double e = 0.0;
        for (int ch = 0; ch < chans; ++ch)
        {
            auto* p = b.getReadPointer (ch, s);
            for (int i = 0; i < hop; ++i)
                e += (double) p[i] * p[i];
        }
        energy.push_back ((float) (e / (hop * chans)));
    }

    // a hit = energy jumping 6 dB over the quietest of the last 15 ms, above -45 dBFS
    const float floorE = std::pow (10.0f, -45.0f / 10.0f);
    const int minGap = jmax (1, (int) (0.08 * sr / hop));
    struct Onset { int frame; float strength; };
    std::vector<Onset> onsets;

    for (int k = 1; k < (int) energy.size(); ++k)
    {
        float background = energy[(size_t) k - 1];
        for (int j = 2; j <= 3 && k - j >= 0; ++j)
            background = jmin (background, energy[(size_t) (k - j)]);

        const float e = energy[(size_t) k];
        const float rise = 10.0f * std::log10 ((e + 1.0e-10f) / (background + 1.0e-10f));

        if (e < floorE || rise < 6.0f || e <= energy[(size_t) k - 1])
            continue;

        if (! onsets.empty() && k - onsets.back().frame < minGap)
        {
            onsets.back().strength = jmax (onsets.back().strength, rise);   // same hit: keep its start
            continue;
        }

        onsets.push_back ({ k, rise });
    }

    // keep the strongest, in time order
    std::sort (onsets.begin(), onsets.end(), [] (auto& a, auto& c) { return a.strength > c.strength; });

    SortedSet<int> positions;
    for (auto& o : onsets)
    {
        if (positions.size() >= maxSlices - 1)
            break;

        const int pos = jmax (0, o.frame * hop - hop / 2);
        if (pos > (int) (0.03 * sr))        // the first hit is already slice 1
            positions.add (pos);
    }

    if (! positions.isEmpty())
    {
        for (auto p : positions)
            starts.add ((float) p / (float) len);
        return starts;
    }

    // a held sound with no hits to find: equal slices, PO-33 style
    starts.clear();
    const int n = jlimit (1, maxSlices, (int) (len / (0.06 * sr)));
    for (int i = 0; i < n; ++i)
        starts.add ((float) i / (float) n);

    return starts;
}

//==============================================================================
// PracticeController
//==============================================================================
PracticeController::PracticeController (Session& s)
    : session (s), edit (*s.getEdit())
{
    jassert (session.isPracticeMode());

    ensureSetup();
    session.engine.getDeviceManager().addChangeListener (this);
    startTimerHz (30);
}

PracticeController::~PracticeController()
{
    stopTimer();
    session.engine.getDeviceManager().removeChangeListener (this);
    stopRecording();

    if (auto t = samplingSlot.get())
        if (auto tap = getTap (*t))
            tap->stopSampling();

    if (edit.getTransport().isPlaying())
        edit.getTransport().stop (false, false);

    writerThread.stopThread (2000);
}

//==============================================================================
bool PracticeController::isSlot (const te::AudioTrack& t)        { return t.state[PracticeIDs::slot]; }
bool PracticeController::isAudioSlot (const te::AudioTrack& t)   { return t.state[PracticeIDs::audio]; }

KeyZonePlugin* PracticeController::getZone (const te::AudioTrack& t)
{
    for (auto p : t.pluginList)
        if (auto z = dynamic_cast<KeyZonePlugin*> (p))
            return z;
    return nullptr;
}

InputTapPlugin* PracticeController::getTap (const te::AudioTrack& t)
{
    for (auto p : t.pluginList)
        if (auto tap = dynamic_cast<InputTapPlugin*> (p))
            return tap;
    return nullptr;
}

MasterTapPlugin* PracticeController::getMasterTap() const
{
    for (auto p : edit.getMasterPluginList())
        if (auto t = dynamic_cast<MasterTapPlugin*> (p))
            return t;
    return nullptr;
}

Array<te::AudioTrack*> PracticeController::getSlots() const
{
    Array<te::AudioTrack*> slots;
    for (auto t : te::getAudioTracks (edit))
        if (isSlot (*t))
            slots.add (t);
    return slots;
}

ValueTree PracticeController::getSettings()
{
    return edit.state.getOrCreateChildWithName (PracticeIDs::settings, nullptr);
}

void PracticeController::ensureMasterTap()
{
    auto& list = edit.getMasterPluginList();
    findMasterMeter (edit);     // makes sure the meter exists, at the end

    if (getMasterTap() != nullptr)
        return;

    if (auto p = edit.getPluginCache().createNewPlugin (MasterTapPlugin::xmlTypeName, {}))
    {
        int index = list.size();
        for (int i = 0; i < list.size(); ++i)
            if (dynamic_cast<te::LevelMeterPlugin*> (list[i]) != nullptr)
                index = jmin (index, i);

        list.insertPlugin (p, index, nullptr);
    }
}

void PracticeController::ensureSlotPlugins (te::AudioTrack& t)
{
    auto removeAll = [&t] (auto* dummy)
    {
        using Type = std::remove_pointer_t<decltype (dummy)>;
        for (int i = t.pluginList.size(); --i >= 0;)
            if (dynamic_cast<Type*> (t.pluginList[i]) != nullptr)
                t.pluginList[i]->deleteFromParent();
    };

    if (isAudioSlot (t))
    {
        removeAll ((KeyZonePlugin*) nullptr);

        if (getTap (t) == nullptr)
            if (auto p = edit.getPluginCache().createNewPlugin (InputTapPlugin::xmlTypeName, {}))
                t.pluginList.insertPlugin (p, 0, nullptr);

        if (auto tap = getTap (t))
            tap->enableCapture();
    }
    else
    {
        removeAll ((InputTapPlugin*) nullptr);

        if (getZone (t) == nullptr)
            if (auto p = edit.getPluginCache().createNewPlugin (KeyZonePlugin::xmlTypeName, {}))
                t.pluginList.insertPlugin (p, 0, nullptr);
    }
}

void PracticeController::ensureSetup()
{
    ensureMasterTap();

    edit.clickTrackEmphasiseBars = true;
    edit.clickTrackRecordingOnly = false;
    edit.clickTrackEnabled = true;      // silent until the metronome (transport) runs

    if (getSlots().isEmpty())
        createDefaultSlots();

    for (auto t : getSlots())
        ensureSlotPlugins (*t);

    if (auto first = findMainKeysSlot())
        lastInstrumentSlot = first;

    refreshDevices (true);
    session.savePracticeSetup();
}

void PracticeController::createDefaultSlots()
{
    StringArray keys, pads;
    for (auto& n : getConnectedControllerNames())
        (looksLikePads (n) ? pads : keys).add (n);

    addInstrumentSlot (InstrumentSpec::gm (0), "Grand Piano", keys);
    addInstrumentSlot (InstrumentSpec::drums(), "Drums", pads);
    addAudioSlot ("Mic");

    StringArray known;
    known.addArray (keys);
    known.addArray (pads);
    getSettings().setProperty (PracticeIDs::knownControllers, known.joinIntoString ("\n"), nullptr);
}

void PracticeController::resetToDefaults()
{
    learning = nullptr;
    session.selectTrack (nullptr);

    for (auto t : getSlots())
        session.deleteTrack (*t);

    history.clear();
    getSettings().removeProperty (PracticeIDs::knownControllers, nullptr);
    createDefaultSlots();
    lastInstrumentSlot = findMainKeysSlot();
    applyRouting();

    if (onSlotsChanged)
        onSlotsChanged();
}

//==============================================================================
te::AudioTrack* PracticeController::addInstrumentSlot (const InstrumentSpec& spec, const String& name, const StringArray& ctrls)
{
    auto t = session.addTrackWithInstrument (spec, name);
    if (t == nullptr)
        return nullptr;

    t->state.setProperty (PracticeIDs::slot, true, nullptr);
    t->state.setProperty (PracticeIDs::controllers, ctrls.joinIntoString ("\n"), nullptr);
    ensureSlotPlugins (*t);
    applyRouting();

    if (onSlotsChanged)
        onSlotsChanged();

    return t;
}

te::AudioTrack* PracticeController::addAudioSlot (const String& name)
{
    auto t = session.addTrack (TrackKind::audio, name.isNotEmpty() ? name : String ("Line In"));
    if (t == nullptr)
        return nullptr;

    t->state.setProperty (PracticeIDs::slot, true, nullptr);
    t->state.setProperty (PracticeIDs::audio, true, nullptr);
    ensureSlotPlugins (*t);

    // pick an input nobody else is using yet
    auto choices = getInputChoices();
    StringArray used;
    for (auto s : getSlots())
        if (s != t && isAudioSlot (*s))
            if (auto idx = getCurrentInputChoice (*s); idx >= 0)
                used.add (choices[idx].label);

    for (auto& c : choices)
        if (c.channel >= 0 && ! used.contains (c.label))
        {
            setSlotInput (*t, c);
            break;
        }

    if (getCurrentInputChoice (*t) < 0 && ! choices.isEmpty())
        setSlotInput (*t, choices.getFirst());

    applyRouting();

    if (onSlotsChanged)
        onSlotsChanged();

    return t;
}

te::AudioTrack* PracticeController::duplicateSlot (te::AudioTrack& t)
{
    auto copy = session.duplicateTrack (t);
    if (copy == nullptr)
        return nullptr;

    ensureSlotPlugins (*copy);
    applyRouting();

    if (onSlotsChanged)
        onSlotsChanged();

    return copy;
}

void PracticeController::deleteSlot (te::AudioTrack& t)
{
    if (learning.get() == &t)
        learning = nullptr;

    history.erase (t.itemID);
    session.selectTrack (nullptr);
    session.deleteTrack (t);
    applyRouting();

    if (onSlotsChanged)
        onSlotsChanged();
}

void PracticeController::setSlotSound (te::AudioTrack& t, const String& description)
{
    BrowserItems::applyToTrack (session, description, &t, false);
    t.state.removeProperty (PracticeIDs::sampled, nullptr);
    ensureSlotPlugins (t);

    if (onSlotsChanged)
        onSlotsChanged();
}

String PracticeController::getSoundName (te::AudioTrack& t) const
{
    if (isAudioSlot (t))
        return "Audio input";

    if (auto dm = Session::getDrumMachine (t))
    {
        if (t.state[PracticeIDs::sampled].toString() == "pads")
            return "Sample chopped to pads";

        auto kit = dm->getKitName();
        return kit.isNotEmpty() ? kit + " kit" : String ("Drum machine");
    }

    if (auto sp = dynamic_cast<te::SamplerPlugin*> (Session::getInstrument (t)))
        return sp->getNumSounds() > 0 ? "Sample: " + sp->getSoundName (0) : String ("Sampler (empty)");

    if (auto p = Session::getInstrument (t))
        return p->getName();

    return "No sound - pick one";
}

void PracticeController::noteSelected (te::AudioTrack* t)
{
    if (t != nullptr && ! isAudioSlot (*t))
        lastInstrumentSlot = t;
}

te::AudioTrack* PracticeController::findMainKeysSlot() const
{
    te::AudioTrack* fallback = nullptr;

    for (auto t : getSlots())
    {
        if (isAudioSlot (*t))
            continue;

        if (getTrackKind (*t) != TrackKind::drums && t->state[PracticeIDs::sampled].toString().isEmpty())
            return t;

        if (fallback == nullptr && getTrackKind (*t) != TrackKind::drums)
            fallback = t;
    }

    return fallback;
}

te::AudioTrack* PracticeController::findMainPadsSlot() const
{
    for (auto t : getSlots())
        if (! isAudioSlot (*t) && getTrackKind (*t) == TrackKind::drums)
            return t;

    return nullptr;
}

//==============================================================================
// Controllers
//==============================================================================
static bool isUserMidiInput (const te::MidiInputDevice& m)
{
    auto type = m.getDeviceType();
    return type == te::InputDevice::physicalMidiDevice
        || (type == te::InputDevice::virtualMidiDevice && m.getDeviceID() != "all_midi_in");
}

bool PracticeController::looksLikePads (const String& deviceName)
{
    auto n = deviceName.toLowerCase();

    for (auto word : { "mpd", "pad", "drum", "mpc", "beatstep", "maschine", "launchpad", "trigger finger", "mpx", "octapad" })
        if (n.contains (word))
            return true;

    return false;
}

StringArray PracticeController::getConnectedControllerNames() const
{
    StringArray names;

    for (auto& m : session.engine.getDeviceManager().getMidiInDevices())
        if (isUserMidiInput (*m) && m->isEnabled())
            names.addIfNotAlreadyThere (m->getName());

    return names;
}

Array<PracticeController::Controller> PracticeController::getControllers() const
{
    Array<Controller> list;

    for (auto& n : getConnectedControllerNames())
        list.add ({ n, true, looksLikePads (n) });

    // remembered ones that aren't plugged in right now
    for (auto t : getSlots())
        for (auto& n : getSlotControllers (*t))
        {
            bool found = false;
            for (auto& c : list)
                found = found || c.name == n;

            if (! found)
                list.add ({ n, false, looksLikePads (n) });
        }

    return list;
}

StringArray PracticeController::getSlotControllers (const te::AudioTrack& t) const
{
    StringArray names;
    names.addLines (t.state[PracticeIDs::controllers].toString());
    names.removeEmptyStrings();
    return names;
}

void PracticeController::setSlotControllers (te::AudioTrack& t, const StringArray& names)
{
    t.state.setProperty (PracticeIDs::controllers, names.joinIntoString ("\n"), nullptr);
    applyRouting();
}

void PracticeController::toggleSlotController (te::AudioTrack& t, const String& name)
{
    auto names = getSlotControllers (t);

    if (names.contains (name))
        names.removeString (name);
    else
        names.add (name);

    setSlotControllers (t, names);
}

String PracticeController::describeControllers (const te::AudioTrack& t) const
{
    auto names = getSlotControllers (t);
    auto connected = getConnectedControllerNames();

    if (names.isEmpty())
        return "Nothing - click to choose";

    StringArray shown;
    for (auto& n : names)
        shown.add (connected.contains (n) ? n : n + " (unplugged)");

    return shown.joinIntoString (", ");
}

void PracticeController::refreshDevices (bool autoAssign)
{
    auto& dm = session.engine.getDeviceManager();

    for (auto& m : dm.getMidiInDevices())
        if (isUserMidiInput (*m))
        {
            if (! m->isEnabled())
                m->setEnabled (true);

            if (m->getMonitorMode() != te::InputDevice::MonitorMode::on)
                m->setMonitorMode (te::InputDevice::MonitorMode::on);
        }

    auto names = getConnectedControllerNames();

    if (autoAssign)
    {
        auto settings = getSettings();
        StringArray known;
        known.addLines (settings[PracticeIDs::knownControllers].toString());
        known.removeEmptyStrings();

        for (auto& n : names)
        {
            if (known.contains (n))
                continue;

            known.add (n);

            // someone plugged something new in: put it where it obviously belongs
            if (auto target = looksLikePads (n) ? findMainPadsSlot() : findMainKeysSlot())
            {
                auto list = getSlotControllers (*target);
                list.addIfNotAlreadyThere (n);
                target->state.setProperty (PracticeIDs::controllers, list.joinIntoString ("\n"), nullptr);

                if (n != "Computer Keyboard")     // not something you plugged in
                    status ("\"" + n + "\" plays " + target->getName() + " - change it on the sound's card");
            }
        }

        settings.setProperty (PracticeIDs::knownControllers, known.joinIntoString ("\n"), nullptr);
    }

    // an audio input that's gone (different interface, changed settings): fall back to
    // the same channel on what's there now, rather than silently hearing nothing
    auto choices = getInputChoices();
    if (! choices.isEmpty())
        for (auto t : getSlots())
            if (isAudioSlot (*t) && getCurrentInputChoice (*t) < 0)
            {
                auto tap = getTap (*t);
                auto wanted = tap != nullptr ? tap->getInputChannel() : 0;
                auto pick = choices.getFirst();

                for (auto& c : choices)
                    if (c.channel == wanted)
                    {
                        pick = c;
                        break;
                    }

                t->state.setProperty (PracticeIDs::inputDevice, pick.deviceID, nullptr);
                if (tap != nullptr)
                    tap->setInputChannel (pick.channel);
            }

    applyRouting();

    if (names != lastDeviceNames)
    {
        lastDeviceNames = names;

        if (onDevicesChanged)
            onDevicesChanged();
    }
}

void PracticeController::applyRouting()
{
    auto& tc = edit.getTransport();
    tc.ensureContextAllocated();

    auto slots = getSlots();
    bool changed = false;

    auto isSlotID = [&slots] (te::EditItemID id)
    {
        for (auto t : slots)
            if (t->itemID == id)
                return true;
        return false;
    };

    for (auto* inst : edit.getAllInputDevices())
    {
        auto& dev = inst->getInputDevice();
        const auto type = dev.getDeviceType();
        const bool isWave = type == te::InputDevice::waveDevice;
        const bool isMidi = (type == te::InputDevice::physicalMidiDevice || type == te::InputDevice::virtualMidiDevice)
                              && dev.getDeviceID() != "all_midi_in";

        if (! isWave && ! isMidi)
            continue;

        const auto targets = inst->getTargets();
        bool deviceUsed = false;

        for (auto t : slots)
        {
            bool want = false;

            if (isMidi && ! isAudioSlot (*t))
                want = getSlotControllers (*t).contains (dev.getName());
            else if (isWave && isAudioSlot (*t))
                want = t->state[PracticeIDs::inputDevice].toString() == dev.getDeviceID();

            deviceUsed = deviceUsed || want;
            const bool has = targets.contains (t->itemID);

            if (want && ! has)
            {
                [[maybe_unused]] auto r = inst->setTarget (t->itemID, false, nullptr);
                changed = true;
            }
            else if (! want && has)
            {
                [[maybe_unused]] auto r = inst->removeTarget (t->itemID, nullptr);
                changed = true;
            }
        }

        for (auto id : targets)
            if (! isSlotID (id))
            {
                [[maybe_unused]] auto r = inst->removeTarget (id, nullptr);
                changed = true;
            }

        // audio inputs always flow (the InputTap gates what you hear), so the tuner,
        // meters and sampler work even with monitoring off
        if (isWave)
        {
            auto mode = deviceUsed ? te::InputDevice::MonitorMode::on : te::InputDevice::MonitorMode::automatic;
            if (dev.getMonitorMode() != mode)
            {
                dev.setMonitorMode (mode);
                changed = true;
            }
        }
    }

    if (changed)
        edit.restartPlayback();
}

//==============================================================================
// Audio inputs
//==============================================================================
Array<PracticeController::InputChoice> PracticeController::getInputChoices() const
{
    Array<InputChoice> list;

    for (auto* w : session.engine.getDeviceManager().getWaveInputDevices())
    {
        if (! w->isEnabled())
            continue;

        auto& chans = w->getChannels();
        auto label = [&chans] (size_t i) { return "Input " + String (chans[i].indexInDevice + 1); };

        if (chans.size() == 1)
        {
            list.add ({ label (0), w->getDeviceID(), 0 });
        }
        else if (chans.size() >= 2)
        {
            list.add ({ label (0), w->getDeviceID(), 0 });
            list.add ({ label (1), w->getDeviceID(), 1 });
            list.add ({ "Inputs " + String (chans[0].indexInDevice + 1) + "+" + String (chans[1].indexInDevice + 1) + " (stereo)",
                        w->getDeviceID(), -1 });
        }
    }

    return list;
}

int PracticeController::getCurrentInputChoice (const te::AudioTrack& t) const
{
    auto tap = getTap (t);
    if (tap == nullptr)
        return -1;

    auto id = t.state[PracticeIDs::inputDevice].toString();
    auto choices = getInputChoices();

    for (int i = 0; i < choices.size(); ++i)
        if (choices[i].deviceID == id && choices[i].channel == tap->getInputChannel())
            return i;

    return -1;
}

void PracticeController::setSlotInput (te::AudioTrack& t, const InputChoice& c)
{
    t.state.setProperty (PracticeIDs::inputDevice, c.deviceID, nullptr);

    if (auto tap = getTap (t))
        tap->setInputChannel (c.channel);

    applyRouting();
}

void PracticeController::setMonitoring (te::AudioTrack& t, bool on)
{
    if (auto tap = getTap (t))
        tap->setMonitoring (on);
}

bool PracticeController::isMonitoring (const te::AudioTrack& t) const
{
    auto tap = getTap (t);
    return tap != nullptr && tap->isMonitoring();
}

//==============================================================================
// Live note state
//==============================================================================
Array<int> PracticeController::getHeldKeys (const te::AudioTrack& t) const
{
    Array<int> keys;
    if (auto it = history.find (t.itemID); it != history.end())
        for (auto& [k, v] : it->second.held)
            keys.add (k);
    return keys;
}

bool PracticeController::isSounding (const te::AudioTrack& t) const
{
    if (auto it = history.find (t.itemID); it != history.end())
        return ! it->second.held.empty() || Time::getMillisecondCounter() - it->second.lastNoteMs < 150;

    return false;
}

void PracticeController::startLearningRange (te::AudioTrack& t)
{
    learning = &t;
    learnStage = 0;
    learnFirst = -1;
    status ("Press the lowest key you want \"" + t.getName() + "\" to play...");
}

void PracticeController::cancelLearning()
{
    learning = nullptr;
    learnStage = 0;
}

void PracticeController::drainEvents()
{
    const auto nowMs = Time::getMillisecondCounter();
    double latest = 0.0;

    if (auto tap = getMasterTap())
    {
        tap->marks.drain ([this] (const MasterTapPlugin::TransportMark& m) { marks.push_back (m); });
        latest = tap->getLatestStreamTime();
    }

    const double keepFrom = latest - (InputTapPlugin::captureSeconds + 30.0);

    for (auto t : getSlots())
    {
        auto zone = getZone (*t);
        if (zone == nullptr)
            continue;

        auto& h = history[t->itemID];

        zone->events.drain ([&] (const ZoneEvent& e)
        {
            const int status = e.bytes[0] & 0xf0;
            const bool noteOn = status == 0x90 && e.bytes[2] > 0;
            const bool noteOff = status == 0x80 || (status == 0x90 && e.bytes[2] == 0);

            if (noteOn && learning.get() == t)
            {
                if (learnStage == 0)
                {
                    learnFirst = e.inNote;
                    learnStage = 1;
                    session.status ("Lowest key: " + noteName (e.inNote) + ". Now press the highest key...");
                }
                else
                {
                    zone->setRange (learnFirst, e.inNote);
                    session.status ("\"" + t->getName() + "\" now plays " + noteName (zone->getLow()) + " to " + noteName (zone->getHigh()));
                    learning = nullptr;
                    learnStage = 0;
                }
            }

            if (! e.passed)
                return;

            if (noteOn)
            {
                h.held[e.inNote] = e.bytes[2];
                h.lastNoteMs = nowMs;
            }
            else if (noteOff)
            {
                h.held.erase (e.inNote);
            }

            h.events.push_back (e);
        });

        while (! h.events.empty() && h.events.front().time < keepFrom)
            h.events.pop_front();
    }

    // transport marks: keep the last one before the capture window
    while (marks.size() > 1 && marks[1].streamTime < keepFrom)
        marks.erase (marks.begin());
}

void PracticeController::timerCallback()
{
    drainEvents();

    if (++tick % 60 == 0)       // every couple of seconds: plugged / unplugged controllers
        refreshDevices (true);
}

void PracticeController::changeListenerCallback (ChangeBroadcaster*)
{
    refreshDevices (true);
}

//==============================================================================
// Metronome
//==============================================================================
bool PracticeController::isMetronomeOn() const
{
    return edit.getTransport().isPlaying();
}

void PracticeController::setMetronome (bool on)
{
    auto& tc = edit.getTransport();

    // The click stays enabled in Practice: it only sounds while the transport runs, and
    // switching it on rebuilds the audio graph - which, right after pressing play, can
    // leave the play head stopped (the transport then stops itself).
    if (! edit.clickTrackEnabled.get())
        edit.clickTrackEnabled = true;

    if (on)
    {
        tc.looping = false;
        tc.setPosition (te::TimePosition());
        tc.play (false);
    }
    else
    {
        tc.stop (false, false);
    }
}

double PracticeController::getBeat() const
{
    return timeToBeat (edit, edit.getTransport().getPosition());
}

//==============================================================================
// Recorder
//==============================================================================
File PracticeController::getRecordingsFolder()
{
    return getDefaultProjectsDir().getChildFile ("Practice Recordings");
}

bool PracticeController::startRecording()
{
    if (writer != nullptr)
        return true;

    auto tap = getMasterTap();
    if (tap == nullptr)
        return false;

    auto folder = getRecordingsFolder();
    folder.createDirectory();
    recordingFile = folder.getNonexistentChildFile ("Practice " + Time::getCurrentTime().formatted ("%Y-%m-%d %H-%M-%S"), ".wav", false);
    recordingRate = tap->getSampleRate();

    std::unique_ptr<OutputStream> stream = std::make_unique<FileOutputStream> (recordingFile);
    if (static_cast<FileOutputStream*> (stream.get())->failedToOpen())
        return false;

    WavAudioFormat wav;
    auto w = wav.createWriterFor (stream, AudioFormatWriterOptions().withSampleRate (recordingRate)
                                                                    .withNumChannels (2)
                                                                    .withBitsPerSample (24));
    if (w == nullptr)
        return false;

    if (! writerThread.isThreadRunning())
        writerThread.startThread();

    writer = std::make_unique<AudioFormatWriter::ThreadedWriter> (w.release(), writerThread, 1 << 17);
    tap->setWriter (writer.get());
    return true;
}

File PracticeController::stopRecording()
{
    if (writer == nullptr)
        return {};

    if (auto tap = getMasterTap())
        tap->setWriter (nullptr);

    writer.reset();     // flushes and closes the file
    return recordingFile;
}

double PracticeController::getRecordingSeconds() const
{
    if (auto tap = getMasterTap(); tap != nullptr && writer != nullptr)
        return tap->getSamplesWritten() / jmax (1.0, recordingRate);

    return 0.0;
}

//==============================================================================
// Hold-to-sample
//==============================================================================
bool PracticeController::startSampling (te::AudioTrack& slot)
{
    auto tap = getTap (slot);
    if (tap == nullptr)
        return false;

    if (! tap->isReceivingAudio())
        status ("No audio is reaching \"" + slot.getName() + "\" - check its input, and the audio device in Settings");

    tap->startSampling();
    samplingSlot = &slot;
    return true;
}

String PracticeController::stopSampling (te::AudioTrack& slot, bool chopToPads)
{
    auto tap = getTap (slot);
    if (tap == nullptr)
        return {};

    auto raw = tap->stopSampling();
    samplingSlot = nullptr;

    const double sr = tap->getSampleRate();
    auto folder = Session::getPracticeFile().getSiblingFile ("Samples");
    auto file = saveSampleTake (raw, sr, folder, slot.getName() + " sample");

    if (file == File())
        return "That was silent - is the input turned up? Watch the meter on \"" + slot.getName() + "\".";

    // the take as saved (trimmed + normalised), for pitch and slicing
    AudioBuffer<float> take;
    double takeRate = sr;
    {
        AudioFormatManager fm;
        fm.registerBasicFormats();
        if (auto reader = std::unique_ptr<AudioFormatReader> (fm.createReaderFor (file)))
        {
            take.setSize (2, (int) reader->lengthInSamples);
            reader->read (&take, 0, (int) reader->lengthInSamples, 0, true, true);
            takeRate = reader->sampleRate;
        }
    }

    auto last = lastInstrumentSlot.get();
    const String kind = chopToPads ? "pads" : "keys";

    // re-sampling onto a sample sound you've selected replaces it, like a PO-33
    te::AudioTrack* target = nullptr;
    if (last != nullptr && last->state[PracticeIDs::sampled].toString() == kind)
        target = last;

    te::AudioTrack* previous = nullptr;
    String result;

    if (! chopToPads)
    {
        int root = 60;
        float clarity = 0.0f;
        auto hz = PitchDetector::detectInBuffer (take, takeRate, clarity);

        if (hz > 50.0f && hz < 2000.0f && clarity > 0.8f)
            root = jlimit (0, 127, roundToInt (69.0 + 12.0 * std::log2 (hz / 440.0)));

        auto spec = InstrumentSpec::sampler (file, root);

        if (target != nullptr)
        {
            session.setInstrument (*target, spec);
            result = "New sample on \"" + target->getName() + "\"";
        }
        else
        {
            previous = (last != nullptr && getTrackKind (*last) != TrackKind::drums && ! isAudioSlot (*last)) ? last : findMainKeysSlot();
            auto ctrls = previous != nullptr ? getSlotControllers (*previous) : getConnectedControllerNames();

            target = addInstrumentSlot (spec, session.makeUniqueTrackName ("Mic Sample"), ctrls);
            if (target == nullptr)
                return "Couldn't make a sampler";

            target->state.setProperty (PracticeIDs::sampled, kind, nullptr);
            result = "Your sample is on the keys";
        }

        result << " - " << noteName (root) << " plays it at its real pitch";
    }
    else
    {
        auto starts = findSlicePoints (take, takeRate, DrumMachinePlugin::numPads);

        if (target == nullptr)
        {
            previous = (last != nullptr && getTrackKind (*last) == TrackKind::drums && last->state[PracticeIDs::sampled].toString().isEmpty())
                           ? last : findMainPadsSlot();

            StringArray ctrls;
            if (previous != nullptr)
                ctrls = getSlotControllers (*previous);
            else
                for (auto& n : getConnectedControllerNames())
                    if (looksLikePads (n))
                        ctrls.add (n);

            if (ctrls.isEmpty())
                if (auto keys = findMainKeysSlot())
                    ctrls = getSlotControllers (*keys);

            target = addInstrumentSlot (InstrumentSpec::drums(), session.makeUniqueTrackName ("Chops"), ctrls);
            if (target == nullptr)
                return "Couldn't make a drum machine";

            target->state.setProperty (PracticeIDs::sampled, kind, nullptr);
        }

        if (auto dm = Session::getDrumMachine (*target))
        {
            for (int pad = 0; pad < DrumMachinePlugin::numPads; ++pad)
            {
                if (pad < starts.size())
                {
                    const float s = starts[pad];
                    const float e = pad + 1 < starts.size() ? starts[pad + 1] : 1.0f;
                    dm->setPadSample (pad, file, "Chop " + String (pad + 1));
                    dm->setPadProperty (pad, DrumMachinePlugin::startProp, s);
                    dm->setPadProperty (pad, DrumMachinePlugin::endProp, e);
                    dm->setPadProperty (pad, DrumMachinePlugin::oneShotProp, true);
                }
                else
                {
                    dm->clearPad (pad);
                }
            }
        }

        result = "Chopped into " + String (starts.size()) + " pad" + (starts.size() == 1 ? "" : "s") + " on \"" + target->getName() + "\""
                 + " (pad 1 = " + noteName (DrumKits::defaultNoteForPad (0)) + ")";
    }

    if (previous != nullptr && previous != target && ! previous->isMuted (false))
    {
        previous->setMute (true);
        result << ". \"" << previous->getName() << "\" is muted so you hear it alone - unmute it to layer";
    }

    lastInstrumentSlot = target;
    session.selectTrack (target);

    if (onSlotsChanged)
        onSlotsChanged();

    return result;
}

//==============================================================================
// Save what I played
//==============================================================================
namespace
{
    /** Copies samples a plugin uses out of the practice folder into the project, so
        the saved project doesn't depend on files it doesn't own. */
    void relocateMedia (ValueTree v, const File& practiceDir, const File& destDir)
    {
        for (int i = 0; i < v.getNumProperties(); ++i)
        {
            auto id = v.getPropertyName (i);
            auto s = v[id].toString();

            if (! File::isAbsolutePath (s))
                continue;

            File f (s);
            if (f.existsAsFile() && f.isAChildOf (practiceDir))
            {
                destDir.createDirectory();
                auto dest = destDir.getChildFile (f.getFileName());

                if (! dest.existsAsFile())
                    f.copyFileTo (dest);

                v.setProperty (id, dest.getFullPathName(), nullptr);
            }
        }

        for (auto c : v)
            relocateMedia (c, practiceDir, destDir);
    }

    bool writeWav (const File& file, const AudioBuffer<float>& buffer, int start, int num, double sr)
    {
        file.getParentDirectory().createDirectory();
        std::unique_ptr<OutputStream> stream = std::make_unique<FileOutputStream> (file);
        WavAudioFormat wav;
        auto w = wav.createWriterFor (stream, AudioFormatWriterOptions().withSampleRate (sr).withNumChannels (2).withBitsPerSample (24));
        return w != nullptr && w->writeFromAudioSampleBuffer (buffer, start, num);
    }
}

PracticeController::TakeResult PracticeController::saveWhatIPlayed (double seconds, bool lastPhraseOnly)
{
    drainEvents();

    TakeResult result;
    auto tap = getMasterTap();
    const double now = tap != nullptr ? tap->getLatestStreamTime() : session.engine.getDeviceManager().getCurrentStreamTime();
    const double from = now - seconds;

    struct Note { int pitch; double start, end; int velocity; };
    struct Ctrl { double time; int type, value; };

    struct Take
    {
        te::AudioTrack* track = nullptr;
        std::vector<Note> notes;
        std::vector<Ctrl> ctrls;
        AudioBuffer<float> audio;
        double audioStart = 0.0, sampleRate = 48000.0;
        std::vector<Range<double>> audioActive;     // stream times where the input was being played
    };

    std::vector<Take> takes;
    std::vector<Range<double>> activity;            // everything played, from every sound

    for (auto t : getSlots())
    {
        Take take;
        take.track = t;

        if (isAudioSlot (*t))
        {
            if (auto in = getTap (*t))
            {
                if (in->copyCapture (from, now, take.audio, take.audioStart))
                {
                    take.sampleRate = in->getSampleRate();

                    // where it's clearly above its own noise floor, in 50 ms steps
                    auto overall = findActivity (take.audio, take.sampleRate);
                    if (! overall.isEmpty())
                    {
                        const int frame = (int) (0.05 * take.sampleRate);
                        const float floorGain = [&]
                        {
                            std::vector<float> rms;
                            for (int f = 0; (f + 1) * frame <= take.audio.getNumSamples(); ++f)
                                rms.push_back (jmax (take.audio.getRMSLevel (0, f * frame, frame), take.audio.getRMSLevel (1, f * frame, frame)));
                            std::sort (rms.begin(), rms.end());
                            auto floorDb = Decibels::gainToDecibels (rms[rms.size() / 20], -120.0f);
                            return Decibels::decibelsToGain (jlimit (-50.0f, -24.0f, floorDb + 12.0f));
                        }();

                        for (int f = 0; (f + 1) * frame <= take.audio.getNumSamples(); ++f)
                        {
                            auto rms = jmax (take.audio.getRMSLevel (0, f * frame, frame), take.audio.getRMSLevel (1, f * frame, frame));
                            if (rms <= floorGain)
                                continue;

                            Range<double> r (take.audioStart + f * frame / take.sampleRate, take.audioStart + (f + 1) * frame / take.sampleRate);

                            if (! take.audioActive.empty() && r.getStart() - take.audioActive.back().getEnd() < 0.5)
                                take.audioActive.back() = take.audioActive.back().withEnd (r.getEnd());
                            else
                                take.audioActive.push_back (r);
                        }

                        for (auto& r : take.audioActive)
                            activity.push_back (r);
                    }

                    if (take.audioActive.empty())
                        take.audio.setSize (0, 0);      // just the room: leave it out
                }
            }
        }
        else if (auto it = history.find (t->itemID); it != history.end())
        {
            std::map<int, std::pair<double, int>> open;    // sounding note -> (start, velocity); start < 0 = began before the window
            int sustainBefore = -1;

            for (auto& e : it->second.events)
            {
                if (e.time > now)
                    break;

                const int status = e.bytes[0] & 0xf0;
                const int d1 = e.bytes[1], d2 = e.bytes[2];
                const bool noteOn = status == 0x90 && d2 > 0;
                const bool noteOff = status == 0x80 || (status == 0x90 && d2 == 0);

                if (e.time < from)
                {
                    if (noteOn)                             open[d1] = { -1.0, d2 };
                    else if (noteOff)                       open.erase (d1);
                    else if (status == 0xb0 && d1 == 64)    sustainBefore = d2;
                    continue;
                }

                if (noteOn)
                {
                    if (auto o = open.find (d1); o != open.end() && o->second.first >= 0.0)
                        take.notes.push_back ({ d1, o->second.first, e.time, o->second.second });

                    open[d1] = { e.time, d2 };
                }
                else if (noteOff)
                {
                    if (auto o = open.find (d1); o != open.end())
                    {
                        if (o->second.first >= 0.0)
                            take.notes.push_back ({ d1, o->second.first, e.time, o->second.second });

                        open.erase (o);
                    }
                }
                else if (status == 0xb0)
                {
                    take.ctrls.push_back ({ e.time, d1, d2 << 7 });
                }
                else if (status == 0xe0)
                {
                    take.ctrls.push_back ({ e.time, te::MidiControllerEvent::pitchWheelType, d1 | (d2 << 7) });
                }
                else if (status == 0xd0)
                {
                    take.ctrls.push_back ({ e.time, te::MidiControllerEvent::channelPressureType, d1 << 7 });
                }
            }

            for (auto& [pitch, sv] : open)              // still held when you clicked
                if (sv.first >= 0.0)
                    take.notes.push_back ({ pitch, sv.first, now, sv.second });

            if (! take.notes.empty())
            {
                if (sustainBefore >= 64)
                    take.ctrls.insert (take.ctrls.begin(), { from, 64, sustainBefore << 7 });

                for (auto& n : take.notes)
                    activity.push_back ({ n.start, jmax (n.start + 0.05, n.end) });
            }
        }

        if (! take.notes.empty() || take.audio.getNumSamples() > 0)
            takes.push_back (std::move (take));
    }

    if (activity.empty())
    {
        result.message = "Nothing to save yet - play something first (the last " + String (roundToInt (InputTapPlugin::captureSeconds / 60.0))
                         + " minutes are always kept)";
        return result;
    }

    // Which part to keep: "the last thing I played" goes back to the last pause of a
    // few seconds; the timed choices keep everything in the window.
    std::sort (activity.begin(), activity.end(), [] (auto& a, auto& b) { return a.getStart() < b.getStart(); });

    double first = activity.front().getStart(), last = activity.front().getEnd();
    {
        constexpr double phraseGap = 6.0;
        double clusterStart = first, clusterEnd = last;

        for (auto& r : activity)
        {
            if (r.getStart() - clusterEnd > phraseGap)
                clusterStart = r.getStart();

            clusterEnd = jmax (clusterEnd, r.getEnd());
        }

        last = clusterEnd;
        if (lastPhraseOnly)
            first = clusterStart;
    }

    // drop what came before the part we're keeping
    for (auto& take : takes)
    {
        take.notes.erase (std::remove_if (take.notes.begin(), take.notes.end(), [first] (const Note& n) { return n.start < first - 0.05; }),
                          take.notes.end());

        // a pedal pressed just before still counts
        take.ctrls.erase (std::remove_if (take.ctrls.begin(), take.ctrls.end(), [first] (const Ctrl& c) { return c.time < first - 1.0; }),
                          take.ctrls.end());

        if (! take.audioActive.empty())
        {
            bool any = false;
            for (auto& r : take.audioActive)
                any = any || r.getEnd() > first;

            if (! any)
                take.audio.setSize (0, 0);
        }

        if (take.notes.empty())
            take.ctrls.clear();
    }

    takes.erase (std::remove_if (takes.begin(), takes.end(), [] (const Take& t) { return t.notes.empty() && t.audio.getNumSamples() == 0; }),
                 takes.end());

    const double startTime = jmax (from, first - 0.25);
    const double endTime = jmin (now, last + 1.0);

    // If the metronome ran through the whole take, put the notes where they were
    // against the click. Otherwise the take simply starts at bar 1.
    const MasterTapPlugin::TransportMark* segment = nullptr;
    bool aligned = false;
    {
        for (auto& m : marks)
            if (m.streamTime <= first)
                segment = &m;

        aligned = segment != nullptr && segment->playing;

        for (auto& m : marks)
            if (m.streamTime > first && m.streamTime <= last)
                aligned = false;
    }

    const double bpm = session.getTempo();
    const double qpb = quarterNotesPerBar (edit);
    double shift = 0.0;

    auto rawBeat = [&] (double t)
    {
        if (aligned)
            return timeToBeat (edit, T (segment->editTime + (t - segment->streamTime)));

        return (t - startTime) * bpm / 60.0;
    };

    if (aligned)
        shift = std::floor (rawBeat (first) / qpb + 1.0e-6) * qpb;    // the first note's bar becomes bar 1

    auto toBeat = [&] (double t) { return rawBeat (t) - shift; };

    // ---- the new project
    auto file = session.createUntitledProjectFile ("Practice Take");
    auto projectDir = file.getParentDirectory();
    auto newEdit = session.createBlankEdit (file);
    if (newEdit == nullptr)
    {
        result.message = "Couldn't create a project in " + projectDir.getFullPathName();
        return result;
    }

    newEdit->tempoSequence.getTempo (0)->setBpm (bpm);
    if (auto src = edit.tempoSequence.getTimeSig (0))
        if (auto dst = newEdit->tempoSequence.getTimeSig (0))
        {
            dst->numerator = src->numerator.get();
            dst->denominator = src->denominator.get();
        }

    newEdit->editFileRetriever = [file] { return file; };

    {
        // media paths are stored relative to the project file, which has to exist first
        te::EditFileOperations ops (*newEdit);
        ops.writeToFile (file, false);
    }

    const auto practiceDir = Session::getPracticeFile().getParentDirectory();
    int numSounds = 0;
    double lastBeat = 0.0;

    for (auto& take : takes)
    {
        auto src = take.track;
        auto t = newEdit->insertNewAudioTrack (te::TrackInsertPoint::getEndOfTracks (*newEdit), nullptr, true);
        if (t == nullptr)
            continue;

        t->setName (src->getName());
        t->setColour (src->getColour());
        t->state.setProperty (kindProp, src->state[kindProp], nullptr);

        // the same sound: instrument and effects, minus the practice plumbing
        int insertAt = 0;
        for (auto p : src->pluginList)
        {
            if (isPracticeUtilityPlugin (p) || dynamic_cast<te::VolumeAndPanPlugin*> (p) != nullptr
                 || dynamic_cast<te::LevelMeterPlugin*> (p) != nullptr)
                continue;

            auto v = p->state.createCopy();
            te::EditItemID::remapIDs (v, nullptr, *newEdit);
            relocateMedia (v, practiceDir, projectDir.getChildFile ("Samples"));

            if (auto np = newEdit->getPluginCache().createNewPlugin (v))
                t->pluginList.insertPlugin (np, insertAt++, nullptr);
        }

        if (auto sv = src->getVolumePlugin())
            if (auto dv = t->getVolumePlugin())
            {
                dv->setVolumeDb (sv->getVolumeDb());
                dv->setPan (sv->getPan());
            }

        if (src->isMuted (false))
            t->setMute (true);

        if (! take.notes.empty())
        {
            double endBeat = 0.0;
            for (auto& n : take.notes)
                endBeat = jmax (endBeat, toBeat (n.end));

            const double lengthBeats = jmax (qpb, std::ceil ((endBeat + 0.001) / qpb) * qpb);
            lastBeat = jmax (lastBeat, lengthBeats);

            if (auto clip = t->insertMIDIClip ({ T (0.0), beatToTime (*newEdit, lengthBeats) }, nullptr))
            {
                clip->setName (src->getName());
                clip->setColour (src->getColour());
                auto& seq = clip->getSequence();

                for (auto& n : take.notes)
                {
                    const double b0 = jmax (0.0, toBeat (n.start));
                    const double b1 = jmax (b0 + 1.0 / 64.0, toBeat (n.end));
                    seq.addNote (n.pitch, B (b0), BD (b1 - b0), n.velocity, 0, nullptr);
                }

                for (auto& c : take.ctrls)
                    seq.addControllerEvent (B (jmax (0.0, toBeat (c.time))), c.type, c.value, nullptr);
            }
        }

        if (take.audio.getNumSamples() > 0)
        {
            const double sr = take.sampleRate;
            int s0 = jlimit (0, take.audio.getNumSamples(), (int) ((startTime - take.audioStart) * sr));
            const int s1 = jlimit (0, take.audio.getNumSamples(), (int) std::ceil ((endTime - take.audioStart) * sr));

            double startBeat = toBeat (take.audioStart + s0 / sr);
            if (startBeat < 0.0)
            {
                s0 += (int) std::ceil (-startBeat * 60.0 / bpm * sr);
                startBeat = 0.0;
            }

            if (s1 - s0 > (int) (0.05 * sr))
            {
                auto wav = projectDir.getChildFile ("Recordings").getNonexistentChildFile (File::createLegalFileName (src->getName()), ".wav", false);

                if (writeWav (wav, take.audio, s0, s1 - s0, sr))
                {
                    auto start = beatToTime (*newEdit, startBeat);
                    t->insertWaveClip (src->getName(), wav, { { start, start + TD ((s1 - s0) / sr) }, {} }, false);
                    lastBeat = jmax (lastBeat, timeToBeat (*newEdit, start + TD ((s1 - s0) / sr)));
                }
            }
        }

        ++numSounds;
    }

    te::EditFileOperations ops (*newEdit);
    if (! ops.writeToFile (file, false))
    {
        result.message = "Couldn't write " + file.getFullPathName();
        return result;
    }

    session.addRecentFile (file);

    result.ok = true;
    result.file = file;
    result.message = "Saved \"" + file.getFileNameWithoutExtension() + "\": " + String (numSounds) + " sound" + (numSounds == 1 ? "" : "s")
                     + ", " + formatTime (endTime - startTime).upToLastOccurrenceOf (".", false, false)
                     + (aligned ? " - on the beat at " + String (bpm, 1) + " BPM" : String());
    return result;
}

} // namespace lode
