/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#pragma once

#include "Utils.h"

namespace lode
{

class LodeLookAndFeel : public juce::LookAndFeel_V4
{
public:
    LodeLookAndFeel();

    static juce::Font font (float height, bool bold = false);

    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour& backgroundColour,
                               bool isHighlighted, bool isDown) override;
    juce::Font getTextButtonFont (juce::TextButton&, int buttonHeight) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool isHighlighted, bool isDown) override;

    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height, float sliderPos,
                           float rotaryStartAngle, float rotaryEndAngle, juce::Slider&) override;

    void drawLinearSlider (juce::Graphics&, int x, int y, int width, int height, float sliderPos,
                           float minSliderPos, float maxSliderPos, juce::Slider::SliderStyle, juce::Slider&) override;

    int getSliderThumbRadius (juce::Slider&) override { return 7; }

    void drawComboBox (juce::Graphics&, int width, int height, bool isButtonDown,
                       int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox&) override;
    juce::Font getComboBoxFont (juce::ComboBox&) override;
    void positionComboBoxText (juce::ComboBox&, juce::Label&) override;

    juce::Font getPopupMenuFont() override;
    void drawPopupMenuBackground (juce::Graphics&, int width, int height) override;

    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool isHighlighted, bool isDown) override;

    void drawScrollbar (juce::Graphics&, juce::ScrollBar&, int x, int y, int width, int height,
                        bool isScrollbarVertical, int thumbStartPosition, int thumbSize,
                        bool isMouseOver, bool isMouseDown) override;

    juce::Font getLabelFont (juce::Label&) override;

    void drawAlertBox (juce::Graphics&, juce::AlertWindow&, const juce::Rectangle<int>& textArea, juce::TextLayout&) override;

    void drawTabButton (juce::TabBarButton&, juce::Graphics&, bool isMouseOver, bool isMouseDown) override;
    int getTabButtonBestWidth (juce::TabBarButton&, int tabDepth) override;
    void drawTabAreaBehindFrontButton (juce::TabbedButtonBar&, juce::Graphics&, int w, int h) override;

    void drawStretchableLayoutResizerBar (juce::Graphics&, int w, int h, bool isVerticalBar,
                                          bool isMouseOver, bool isMouseDragging) override;

    void fillTextEditorBackground (juce::Graphics&, int width, int height, juce::TextEditor&) override;
    void drawTextEditorOutline (juce::Graphics&, int width, int height, juce::TextEditor&) override;
};

//==============================================================================
/** Small helpers for drawing consistent UI bits. */
namespace Draw
{
    void panel (juce::Graphics&, juce::Rectangle<float>, juce::Colour fill, float corner = 6.0f);
    void meter (juce::Graphics&, juce::Rectangle<float>, float levelDbL, float levelDbR, bool vertical = true);
    juce::Path magnetIcon (juce::Rectangle<float>);
    juce::Path icon (const juce::String& name, juce::Rectangle<float>);
}

/** A button that draws one of the built-in vector icons. */
class IconButton : public juce::Button
{
public:
    IconButton (const juce::String& iconName, const juce::String& tooltip = {});

    void setIcon (const juce::String& name)     { iconName = name; repaint(); }
    void setOnColour (juce::Colour c)           { onColour = c; repaint(); }

    void paintButton (juce::Graphics&, bool isHighlighted, bool isDown) override;

private:
    juce::String iconName;
    juce::Colour onColour { Col::north };
};

} // namespace lode
