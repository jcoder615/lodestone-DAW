/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "PianoRoll.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"

namespace lode
{
using namespace juce;

static const std::vector<std::pair<const char*, double>>& gridOptions()
{
    static const std::vector<std::pair<const char*, double>> opts = {
        { "1 bar", 4.0 }, { "1/2", 2.0 }, { "1/4 (beat)", 1.0 }, { "1/8", 0.5 }, { "1/16", 0.25 },
        { "1/32", 0.125 }, { "1/8 triplet", 1.0 / 3.0 }, { "1/16 triplet", 1.0 / 6.0 } };
    return opts;
}

//==============================================================================
class PianoRollEditor::Keys : public Component
{
public:
    Keys (PianoRollEditor& o) : owner (o) {}

    void paint (Graphics& g) override
    {
        g.fillAll (Col::bg2);
        auto track = owner.clip->getAudioTrack();
        auto drums = track != nullptr && getTrackKind (*track) == TrackKind::drums;
        auto& sc = owner.scale();

        for (int n = 0; n < 128; ++n)
        {
            auto y = owner.noteToY (n);
            if (y > getHeight() || y + owner.noteHeight < 0)
                continue;

            auto r = Rectangle<float> (0, y, (float) getWidth(), owner.noteHeight);

            if (drums)
            {
                g.setColour (n % 2 ? Col::bg2 : Col::bg3);
                g.fillRect (r);
            }
            else
            {
                g.setColour (isBlackKey (n) ? Col::bg0 : Col::text.withAlpha (0.82f));
                g.fillRect (r.withTrimmedRight (isBlackKey (n) ? 18.0f : 0.0f));

                if (owner.view.scaleLock.get() && Theory::isInScale (n, owner.view.keyRoot.get(), sc))
                {
                    g.setColour (Col::south.withAlpha (0.7f));
                    g.fillRect (r.removeFromRight (4.0f));
                }
            }

            g.setColour (Col::bg0.withAlpha (0.6f));
            g.fillRect (0.0f, y + owner.noteHeight - 1.0f, (float) getWidth(), 1.0f);

            String label;
            if (drums && owner.noteHeight >= 10.0f)
            {
                String name;
                if (auto inst = Session::getInstrument (*track))
                    if (! inst->hasNameForMidiNoteNumber (n, 10, name))
                        name = DrumKits::gmDrumName (n);
                label = name;
            }
            else if (n % 12 == 0 && owner.noteHeight >= 8.0f)
                label = noteName (n);

            if (label.isNotEmpty())
            {
                g.setColour (drums ? Col::text : Colours::black.withAlpha (0.75f));
                g.setFont (LodeLookAndFeel::font (jmin (12.0f, owner.noteHeight - 1.0f)));
                g.drawText (label, r.reduced (4.0f, 0.0f), drums ? Justification::centredLeft : Justification::centredRight, true);
            }
        }
    }

    void mouseDown (const MouseEvent& e) override       { owner.previewNote (owner.yToNote ((float) e.y)); }
    void mouseDrag (const MouseEvent& e) override
    {
        auto n = owner.yToNote ((float) e.y);
        if (n != lastNote)
        {
            lastNote = n;
            owner.previewNote (n);
        }
    }

private:
    PianoRollEditor& owner;
    int lastNote = -1;
};

//==============================================================================
class PianoRollEditor::Grid : public Component
{
public:
    Grid (PianoRollEditor& o) : owner (o)
    {
        setWantsKeyboardFocus (false);
    }

    void paint (Graphics& g) override
    {
        g.fillAll (Col::bg1);
        auto& sc = owner.scale();
        auto lock = owner.view.scaleLock.get();

        // rows
        for (int n = 0; n < 128; ++n)
        {
            auto y = owner.noteToY (n);
            if (y > getHeight() || y + owner.noteHeight < 0)
                continue;

            Colour c = isBlackKey (n) ? Col::bg0.brighter (0.03f) : Col::bg1.brighter (0.02f);
            if (lock && ! Theory::isInScale (n, owner.view.keyRoot.get(), sc))
                c = c.darker (0.5f);
            if (lock && ((n - owner.view.keyRoot.get()) % 12 + 12) % 12 == 0)
                c = c.interpolatedWith (Col::south, 0.08f);

            g.setColour (c);
            g.fillRect (0.0f, y, (float) getWidth(), owner.noteHeight);
            g.setColour (Col::bg0.withAlpha (n % 12 == 0 ? 0.9f : 0.35f));
            g.fillRect (0.0f, y + owner.noteHeight - 1.0f, (float) getWidth(), 1.0f);
        }

        // vertical grid
        auto bpb = quarterNotesPerBar (owner.clip->edit);
        auto start = owner.xToBeat (0), end = owner.xToBeat ((float) getWidth());
        auto div = owner.snapDiv();

        if (div * owner.pixelsPerBeat >= 6.0)
            for (auto b = std::floor (start / div) * div; b <= end; b += div)
            {
                auto isBar = std::abs (std::fmod (b + 1.0e-6, bpb)) < 1.0e-4;
                auto isBeat = std::abs (std::fmod (b + 1.0e-6, 1.0)) < 1.0e-4;
                g.setColour (Colours::white.withAlpha (isBar ? 0.16f : (isBeat ? 0.08f : 0.03f)));
                g.fillRect (owner.beatToX (b), 0.0f, 1.0f, (float) getHeight());
            }

        // clip region
        auto cs = clipStartBeat (*owner.clip), ce = clipEndBeat (*owner.clip);
        g.setColour (Colours::black.withAlpha (0.35f));
        g.fillRect (0.0f, 0.0f, jmax (0.0f, owner.beatToX (cs)), (float) getHeight());
        g.fillRect (owner.beatToX (ce), 0.0f, (float) getWidth(), (float) getHeight());
        g.setColour (owner.clip->getColour().withAlpha (0.8f));
        g.fillRect (owner.beatToX (ce) - 1.0f, 0.0f, 2.0f, (float) getHeight());

        // notes
        auto col = owner.clip->getColour();
        auto cStart = owner.contentStart();

        for (auto n : owner.getNotes())
        {
            auto x1 = owner.beatToX (cStart + n->getStartBeat().inBeats());
            auto x2 = owner.beatToX (cStart + n->getEndBeat().inBeats());
            auto y = owner.noteToY (n->getNoteNumber());

            if (x2 < 0 || x1 > getWidth() || y > getHeight() || y + owner.noteHeight < 0)
                continue;

            auto r = Rectangle<float> (x1, y + 1.0f, jmax (3.0f, x2 - x1 - 1.0f), owner.noteHeight - 2.0f);
            auto vel = (float) n->getVelocity() / 127.0f;
            auto sel = owner.isSelected (n);
            g.setColour ((sel ? Col::text : col).withMultipliedBrightness (0.55f + 0.45f * vel));
            g.fillRoundedRectangle (r, 2.5f);
            g.setColour (sel ? Col::south : col.darker (0.6f));
            g.drawRoundedRectangle (r, 2.5f, sel ? 1.5f : 1.0f);

            if (r.getWidth() > 26 && owner.noteHeight >= 11)
            {
                g.setColour (Colours::black.withAlpha (0.7f));
                g.setFont (LodeLookAndFeel::font (jmin (10.5f, owner.noteHeight - 3.0f)));
                g.drawText (noteName (n->getNoteNumber()), r.reduced (3.0f, 0.0f), Justification::centredLeft, false);
            }
        }

        // playhead
        auto& tc = owner.clip->edit.getTransport();
        auto px = owner.beatToX (timeToBeat (owner.clip->edit, tc.getPosition()));
        g.setColour (Col::north);
        g.fillRect (px, 0.0f, 1.5f, (float) getHeight());

        if (! band.isEmpty())
        {
            g.setColour (Col::south.withAlpha (0.15f));
            g.fillRect (band);
            g.setColour (Col::south);
            g.drawRect (band);
        }
    }

    te::MidiNote* noteAt (Point<float> p, bool& onRightEdge)
    {
        auto cStart = owner.contentStart();
        auto notes = owner.getNotes();

        for (int i = notes.size(); --i >= 0;)
        {
            auto n = notes[i];
            auto x1 = owner.beatToX (cStart + n->getStartBeat().inBeats());
            auto x2 = owner.beatToX (cStart + n->getEndBeat().inBeats());
            auto y = owner.noteToY (n->getNoteNumber());

            if (p.y >= y && p.y < y + owner.noteHeight && p.x >= x1 && p.x <= x2 + 1.0f)
            {
                onRightEdge = p.x >= x2 - jmin (7.0f, (x2 - x1) * 0.35f);
                return n;
            }
        }

        return nullptr;
    }

    void mouseMove (const MouseEvent& e) override
    {
        bool edge = false;
        auto n = noteAt (e.position, edge);
        setMouseCursor (n != nullptr && edge ? MouseCursor::LeftRightResizeCursor
                                             : (n != nullptr ? MouseCursor::DraggingHandCursor : MouseCursor::NormalCursor));
    }

    void mouseDown (const MouseEvent& e) override
    {
        owner.grabKeyboardFocus();
        auto& um = owner.clip->edit.getUndoManager();
        um.beginNewTransaction ("Edit notes");
        bool edge = false;
        auto hit = noteAt (e.position, edge);
        band = {};
        dragging = false;
        mode = Mode::none;

        if (e.mods.isPopupMenu())
        {
            // right-click deletes, like LMMS / FL
            if (hit != nullptr)
            {
                owner.selection.removeFirstMatchingValue (hit);
                owner.clip->getSequence().removeNote (*hit, &um);
                erasing = true;
            }
            return;
        }

        if (hit != nullptr)
        {
            if (e.mods.isShiftDown())
            {
                if (owner.isSelected (hit)) owner.selection.removeFirstMatchingValue (hit);
                else owner.selection.add (hit);
            }
            else if (! owner.isSelected (hit))
            {
                owner.selectOnly (hit);
            }

            owner.previewNote (hit->getNoteNumber(), hit->getVelocity());
            mode = edge ? Mode::resize : Mode::move;
            beginDrag (hit);
            repaint();
            return;
        }

        if (! owner.drawTool || e.mods.isCtrlDown())
        {
            mode = Mode::band;
            if (! e.mods.isShiftDown())
                owner.selection.clear();
            repaint();
            return;
        }

        // draw a new note (or chord)
        auto absBeat = owner.xToBeat (e.position.x);
        auto start = jmax (clipStartBeat (*owner.clip), floorBeat (absBeat, owner.snapDiv()));
        auto pitch = owner.yToNote (e.position.y);

        if (owner.view.scaleLock.get())
            pitch = Theory::snapToScale (pitch, owner.view.keyRoot.get(), owner.scale());

        auto& chord = Theory::chords()[(size_t) jlimit (0, (int) Theory::chords().size() - 1, owner.chordIndex)];
        auto pitches = Theory::buildChord (pitch, chord, owner.view.keyRoot.get(), owner.scale());

        owner.selection.clear();
        auto rel = start - owner.contentStart();

        for (auto p : pitches)
            if (auto n = owner.clip->getSequence().addNote (p, B (rel), BD (owner.lastNoteLength), owner.newVelocity, 0, &um))
                owner.selection.add (n);

        owner.previewNote (pitch, owner.newVelocity);

        if (! owner.selection.isEmpty())
        {
            mode = Mode::resize;
            beginDrag (owner.selection.getFirst());
            drawingNew = true;
        }

        repaint();
    }

    void beginDrag (te::MidiNote* anchorNote)
    {
        anchor = anchorNote;
        originals.clear();
        for (auto n : owner.selection)
            originals.push_back ({ n, n->getStartBeat().inBeats(), n->getLengthBeats().inBeats(), n->getNoteNumber() });
        duplicated = false;
        drawingNew = false;
    }

    void mouseDrag (const MouseEvent& e) override
    {
        auto& um = owner.clip->edit.getUndoManager();

        if (erasing)
        {
            bool edge = false;
            if (auto hit = noteAt (e.position, edge))
            {
                owner.selection.removeFirstMatchingValue (hit);
                owner.clip->getSequence().removeNote (*hit, &um);
            }
            return;
        }

        if (mode == Mode::band)
        {
            band = Rectangle<float> (e.mouseDownPosition, e.position);
            auto cStart = owner.contentStart();
            if (! e.mods.isShiftDown())
                owner.selection.clear();

            for (auto n : owner.getNotes())
            {
                auto r = Rectangle<float> (owner.beatToX (cStart + n->getStartBeat().inBeats()), owner.noteToY (n->getNoteNumber()),
                                           jmax (2.0f, (float) (n->getLengthBeats().inBeats() * owner.pixelsPerBeat)), owner.noteHeight);
                if (r.intersects (band))
                    owner.selection.addIfNotAlreadyThere (n);
            }
            repaint();
            return;
        }

        if (originals.empty() || ! e.mouseWasDraggedSinceMouseDown())
            return;

        dragging = true;
        auto deltaBeats = (e.position.x - e.mouseDownPosition.x) / owner.pixelsPerBeat;
        auto noSnap = e.mods.isShiftDown();

        if (mode == Mode::move)
        {
            if (e.mods.isCtrlDown() && ! duplicated)
            {
                for (auto& o : originals)
                    owner.clip->getSequence().addNote (o.pitch, B (o.start), BD (o.length), o.note->getVelocity(), 0, &um);
                duplicated = true;
            }

            auto* anchorOrig = &originals.front();
            for (auto& o : originals)
                if (o.note == anchor) anchorOrig = &o;

            auto newStart = anchorOrig->start + deltaBeats;
            if (! noSnap)
                newStart = owner.snap (newStart + owner.contentStart()) - owner.contentStart();
            auto delta = newStart - anchorOrig->start;

            auto pitchDelta = owner.yToNote (e.position.y) - owner.yToNote (e.mouseDownPosition.y);

            for (auto& o : originals)
            {
                auto p = jlimit (0, 127, o.pitch + pitchDelta);
                if (owner.view.scaleLock.get() && pitchDelta != 0)
                    p = Theory::snapToScale (p, owner.view.keyRoot.get(), owner.scale());

                o.note->setStartAndLength (B (jmax (0.0, o.start + delta)), BD (o.length), &um);

                if (p != o.note->getNoteNumber())
                {
                    o.note->setNoteNumber (p, &um);
                    if (o.note == anchor)
                        owner.previewNote (p, o.note->getVelocity());
                }
            }
        }
        else if (mode == Mode::resize)
        {
            for (auto& o : originals)
            {
                auto end = o.start + o.length + deltaBeats;
                if (! noSnap)
                    end = owner.snap (end + owner.contentStart()) - owner.contentStart();
                auto len = jmax (noSnap ? 1.0 / 64.0 : owner.snapDiv(), end - o.start);
                o.note->setStartAndLength (B (o.start), BD (len), &um);

                if (o.note == anchor)
                    owner.lastNoteLength = len;
            }
        }

        repaint();
        owner.repaintVelocityLane();
    }

    void mouseUp (const MouseEvent&) override
    {
        if (mode == Mode::resize && ! dragging && ! drawingNew && anchor != nullptr)
            owner.lastNoteLength = anchor->getLengthBeats().inBeats();

        erasing = false;
        band = {};
        originals.clear();
        mode = Mode::none;
        repaint();
        owner.repaintVelocityLane();
    }

    void mouseDoubleClick (const MouseEvent& e) override
    {
        bool edge = false;
        if (auto hit = noteAt (e.position, edge))
        {
            owner.selection.removeFirstMatchingValue (hit);
            owner.clip->getSequence().removeNote (*hit, &owner.clip->edit.getUndoManager());
        }
    }

private:
    PianoRollEditor& owner;
    enum class Mode { none, move, resize, band };
    Mode mode = Mode::none;
    struct Orig { te::MidiNote* note; double start, length; int pitch; };
    std::vector<Orig> originals;
    te::MidiNote* anchor = nullptr;
    Rectangle<float> band;
    bool dragging = false, duplicated = false, erasing = false, drawingNew = false;
};

//==============================================================================
class PianoRollEditor::VelocityLane : public Component
{
public:
    VelocityLane (PianoRollEditor& o) : owner (o) {}

    void paint (Graphics& g) override
    {
        g.fillAll (Col::bg0);
        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (10.0f));
        g.drawText ("velocity", 4, 2, 60, 12, Justification::topLeft);

        auto cStart = owner.contentStart();
        auto col = owner.clip->getColour();

        for (auto n : owner.getNotes())
        {
            auto x = owner.beatToX (cStart + n->getStartBeat().inBeats());
            if (x < -4 || x > getWidth() + 4) continue;
            auto h = (float) (getHeight() - 6) * (float) n->getVelocity() / 127.0f;
            g.setColour (owner.isSelected (n) ? Col::text : col);
            g.fillRect (x, (float) getHeight() - h, 3.0f, h);
            g.fillEllipse (x - 2.0f, (float) getHeight() - h - 3.0f, 7.0f, 7.0f);
        }
    }

    void mouseDown (const MouseEvent& e) override
    {
        owner.clip->edit.getUndoManager().beginNewTransaction ("Velocity");
        mouseDrag (e);
    }

    void mouseDrag (const MouseEvent& e) override
    {
        auto vel = jlimit (1, 127, roundToInt ((1.0f - (float) e.y / (float) getHeight()) * 127.0f));
        auto cStart = owner.contentStart();
        auto& um = owner.clip->edit.getUndoManager();
        auto onlySelected = ! owner.selection.isEmpty() && e.mods.isShiftDown();

        for (auto n : owner.getNotes())
        {
            auto x = owner.beatToX (cStart + n->getStartBeat().inBeats());
            if (std::abs (x - (float) e.x) <= 4.0f && (! onlySelected || owner.isSelected (n)))
                n->setVelocity (vel, &um);
        }

        repaint();
        owner.grid->repaint();
    }

private:
    PianoRollEditor& owner;
};

//==============================================================================
class PianoRollEditor::Toolbar : public Component
{
public:
    Toolbar (PianoRollEditor& o) : owner (o)
    {
        addAndMakeVisible (drawBtn);
        addAndMakeVisible (selectBtn);
        drawBtn.setClickingTogglesState (true);
        selectBtn.setClickingTogglesState (true);
        drawBtn.setRadioGroupId (77);
        selectBtn.setRadioGroupId (77);
        drawBtn.setToggleState (owner.drawTool, dontSendNotification);
        selectBtn.setToggleState (! owner.drawTool, dontSendNotification);
        drawBtn.onClick = [this] { owner.drawTool = true; };
        selectBtn.onClick = [this] { owner.drawTool = false; };
        drawBtn.setTooltip ("Draw notes (right-click deletes)");
        selectBtn.setTooltip ("Select notes (Ctrl+drag also selects in draw mode)");

        addAndMakeVisible (gridBox);
        int i = 1;
        for (auto& [name, v] : gridOptions())
        {
            gridBox.addItem ("Grid " + String (name), i);
            if (std::abs (v - owner.view.snapDivision.get()) < 1.0e-6)
                gridBox.setSelectedId (i, dontSendNotification);
            ++i;
        }
        gridBox.onChange = [this]
        {
            auto idx = gridBox.getSelectedId() - 1;
            if (isPositiveAndBelow (idx, (int) gridOptions().size()))
                owner.view.snapDivision = gridOptions()[(size_t) idx].second;
            owner.repaint();
        };

        addAndMakeVisible (keyBox);
        auto keys = Theory::keyNames();
        for (int k = 0; k < 12; ++k)
            keyBox.addItem (keys[k], k + 1);
        keyBox.setSelectedId (owner.view.keyRoot.get() + 1, dontSendNotification);
        keyBox.onChange = [this] { owner.view.keyRoot = keyBox.getSelectedId() - 1; owner.repaint(); };

        addAndMakeVisible (scaleBox);
        int s = 1;
        for (auto& sc : Theory::scales())
        {
            scaleBox.addItem (sc.name, s);
            if (owner.view.scaleName.get() == sc.name)
                scaleBox.setSelectedId (s, dontSendNotification);
            ++s;
        }
        scaleBox.onChange = [this] { owner.view.scaleName = scaleBox.getText(); owner.repaint(); };

        addAndMakeVisible (lockBtn);
        lockBtn.setClickingTogglesState (true);
        lockBtn.setToggleState (owner.view.scaleLock.get(), dontSendNotification);
        lockBtn.setTooltip ("Scale lock: highlight the scale and keep new/moved notes in key");
        lockBtn.onClick = [this] { owner.view.scaleLock = lockBtn.getToggleState(); owner.repaint(); };

        addAndMakeVisible (chordBox);
        int c = 1;
        for (auto& ch : Theory::chords())
            chordBox.addItem (ch.name, c++);
        chordBox.setSelectedId (1, dontSendNotification);
        chordBox.setTooltip ("Chord stamp: each click draws this chord");
        chordBox.onChange = [this] { owner.chordIndex = chordBox.getSelectedId() - 1; };

        for (auto* b : { &quantizeBtn, &humanizeBtn, &legatoBtn, &arpBtn })
            addAndMakeVisible (b);

        quantizeBtn.onClick = [this] { owner.quantize (1.0f); };
        humanizeBtn.onClick = [this] { owner.humanize(); };
        legatoBtn.onClick = [this] { owner.legato(); };
        arpBtn.onClick = [this] { owner.arpeggiate(); };
        quantizeBtn.setTooltip ("Snap selected notes (or all) to the grid  [Q]");
        humanizeBtn.setTooltip ("Add small random timing and velocity changes");
        legatoBtn.setTooltip ("Stretch each note to the start of the next");
        arpBtn.setTooltip ("Turn selected chords into an upward arpeggio on the grid");

        addAndMakeVisible (velSlider);
        velSlider.setSliderStyle (Slider::LinearHorizontal);
        velSlider.setTextBoxStyle (Slider::TextBoxRight, false, 34, 20);
        velSlider.setRange (1, 127, 1);
        velSlider.setValue (owner.newVelocity, dontSendNotification);
        velSlider.setTooltip ("Velocity for new notes");
        velSlider.onValueChange = [this] { owner.newVelocity = (int) velSlider.getValue(); };
    }

    void paint (Graphics& g) override
    {
        g.fillAll (Col::bg2);
        g.setColour (Col::textDim);
        g.setFont (LodeLookAndFeel::font (11.0f));
        g.drawText ("vel", velSlider.getX() - 24, 0, 22, getHeight(), Justification::centredRight);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (6, 5);
        drawBtn.setBounds (r.removeFromLeft (28));
        r.removeFromLeft (2);
        selectBtn.setBounds (r.removeFromLeft (28));
        r.removeFromLeft (8);
        gridBox.setBounds (r.removeFromLeft (120));
        r.removeFromLeft (8);
        keyBox.setBounds (r.removeFromLeft (56));
        r.removeFromLeft (2);
        scaleBox.setBounds (r.removeFromLeft (130));
        r.removeFromLeft (2);
        lockBtn.setBounds (r.removeFromLeft (54));
        r.removeFromLeft (8);
        chordBox.setBounds (r.removeFromLeft (130));
        r.removeFromLeft (8);

        for (auto* b : { &quantizeBtn, &humanizeBtn, &legatoBtn, &arpBtn })
        {
            b->setBounds (r.removeFromLeft (78));
            r.removeFromLeft (3);
        }

        r.removeFromLeft (30);
        velSlider.setBounds (r.removeFromLeft (jmin (150, r.getWidth())));
    }

    PianoRollEditor& owner;
    IconButton drawBtn { "pencil", "Draw" }, selectBtn { "pointer", "Select" };
    ComboBox gridBox, keyBox, scaleBox, chordBox;
    TextButton lockBtn { "Lock" }, quantizeBtn { "Quantize" }, humanizeBtn { "Humanize" }, legatoBtn { "Legato" }, arpBtn { "Arpeggiate" };
    Slider velSlider;
};

//==============================================================================
PianoRollEditor::PianoRollEditor (Session& s, te::MidiClip& c)
    : session (s), clip (&c), view (s.getView())
{
    keys = std::make_unique<Keys> (*this);
    grid = std::make_unique<Grid> (*this);
    velocity = std::make_unique<VelocityLane> (*this);
    toolbar = std::make_unique<Toolbar> (*this);

    addAndMakeVisible (*toolbar);
    addAndMakeVisible (*keys);
    addAndMakeVisible (*grid);
    addAndMakeVisible (*velocity);
    addAndMakeVisible (hScroll);
    addAndMakeVisible (vScroll);
    hScroll.setAutoHide (false);
    vScroll.setAutoHide (false);

    hScroll.addListener (this);
    vScroll.addListener (this);

    // frame the clip and its notes
    scrollBeat = clipStartBeat (c);
    int lo = 127, hi = 0;
    for (auto n : c.getSequence().getNotes())
    {
        lo = jmin (lo, n->getNoteNumber());
        hi = jmax (hi, n->getNoteNumber());
    }
    topNote = hi >= lo ? jmin (127, hi + 6) : 78;

    if (auto t = c.getAudioTrack(); t != nullptr && getTrackKind (*t) == TrackKind::drums)
        topNote = jmax (topNote, 55);

    lastNoteLength = view.snapDivision.get();
    setWantsKeyboardFocus (true);
    clip->state.addListener (this);
    startTimerHz (25);
}

PianoRollEditor::~PianoRollEditor()
{
    hScroll.removeListener (this);
    vScroll.removeListener (this);
    clip->state.removeListener (this);
}

double PianoRollEditor::contentStart() const    { return clipContentStartBeat (*clip); }
double PianoRollEditor::snapDiv() const         { return view.snapDivision.get(); }
double PianoRollEditor::snap (double beat) const { return view.snapOn.get() ? snapBeat (beat, snapDiv()) : beat; }
const Theory::Scale& PianoRollEditor::scale() const { return Theory::findScale (view.scaleName.get()); }

Array<te::MidiNote*> PianoRollEditor::getNotes() const
{
    return clip->getSequence().getNotes();
}

void PianoRollEditor::selectOnly (te::MidiNote* n)
{
    selection.clear();
    if (n != nullptr)
        selection.add (n);
    repaint();
}

void PianoRollEditor::handleAsyncUpdate()
{
    auto notes = getNotes();
    for (int i = selection.size(); --i >= 0;)
        if (! notes.contains (selection[i]))
            selection.remove (i);

    repaint();
}

void PianoRollEditor::timerCallback()
{
    if (clip->edit.getTransport().isPlaying())
        grid->repaint();
}

void PianoRollEditor::previewNote (int note, int vel)
{
    if (auto t = clip->getAudioTrack())
        t->playGuideNote (note, te::MidiChannel (1), vel, true, true, true);
}

void PianoRollEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
}

void PianoRollEditor::resized()
{
    auto r = getLocalBounds();
    toolbar->setBounds (r.removeFromTop (36));
    auto bottom = r.removeFromBottom (12);
    hScroll.setBounds (bottom.withTrimmedLeft (64).withTrimmedRight (12));
    auto vel = r.removeFromBottom (72);
    velocity->setBounds (vel.withTrimmedLeft (64).withTrimmedRight (12));
    vScroll.setBounds (r.removeFromRight (12));
    keys->setBounds (r.removeFromLeft (64));
    grid->setBounds (r);
    updateScrollbars();
}

void PianoRollEditor::repaintVelocityLane()
{
    if (velocity != nullptr)
        velocity->repaint();
}

void PianoRollEditor::scrollBarMoved (ScrollBar* sb, double start)
{
    if (sb == &hScroll)
        scrollBeat = start;
    else
        topNote = jlimit (0, 127, 127 - roundToInt (start));

    repaint();
}

void PianoRollEditor::updateScrollbars()
{
    auto visibleBeats = grid->getWidth() / pixelsPerBeat;
    auto end = jmax (clipEndBeat (*clip) + 8.0, scrollBeat + visibleBeats);
    hScroll.setRangeLimits (jmax (0.0, clipStartBeat (*clip) - 8.0), end, dontSendNotification);
    hScroll.setCurrentRange (scrollBeat, visibleBeats, dontSendNotification);

    auto visibleNotes = grid->getHeight() / noteHeight;
    vScroll.setRangeLimits (0.0, 128.0, dontSendNotification);
    vScroll.setCurrentRange (127 - topNote, visibleNotes, dontSendNotification);
}

void PianoRollEditor::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    if (e.mods.isCtrlDown())
    {
        auto pos = grid->getLocalPoint (e.eventComponent, e.position);
        auto anchor = xToBeat (pos.x);
        pixelsPerBeat = jlimit (8.0, 800.0, pixelsPerBeat * (w.deltaY > 0 ? 1.15 : 1.0 / 1.15));
        scrollBeat = anchor - pos.x / pixelsPerBeat;
    }
    else if (e.mods.isAltDown())
    {
        noteHeight = jlimit (6.0f, 30.0f, noteHeight + (w.deltaY > 0 ? 1.0f : -1.0f));
    }
    else if (e.mods.isShiftDown() || std::abs (w.deltaX) > std::abs (w.deltaY))
    {
        auto d = std::abs (w.deltaX) > std::abs (w.deltaY) ? w.deltaX : w.deltaY;
        scrollBeat = jmax (0.0, scrollBeat - d * 200.0 / pixelsPerBeat);
    }
    else
    {
        topNote = jlimit (10, 127, topNote + (w.deltaY > 0 ? 3 : -3));
    }

    updateScrollbars();
    repaint();
}

bool PianoRollEditor::keyPressed (const KeyPress& k)
{
    auto code = k.getKeyCode();
    auto mods = k.getModifiers();

    if (code == KeyPress::deleteKey || code == KeyPress::backspaceKey)   { deleteSelected(); return true; }
    if (code == KeyPress::upKey)    { transposeSelected (mods.isShiftDown() ? 12 : 1, view.scaleLock.get()); return true; }
    if (code == KeyPress::downKey)  { transposeSelected (mods.isShiftDown() ? -12 : -1, view.scaleLock.get()); return true; }
    if (code == KeyPress::leftKey)  { nudgeSelected (-snapDiv()); return true; }
    if (code == KeyPress::rightKey) { nudgeSelected (snapDiv()); return true; }

    if (mods.isCommandDown() && (code == 'a' || code == 'A'))
    {
        selection = getNotes();
        repaint();
        return true;
    }

    if (mods.isCommandDown() && (code == 'd' || code == 'D'))  { duplicateSelected(); return true; }
    if (! mods.isAnyModifierKeyDown() && (code == 'q' || code == 'Q')) { quantize (1.0f); return true; }

    return false;
}

void PianoRollEditor::deleteSelected()
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Delete notes");
    auto sel = selection;
    selection.clear();
    for (auto n : sel)
        clip->getSequence().removeNote (*n, &um);
}

void PianoRollEditor::transposeSelected (int semis, bool inScale)
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Transpose");
    auto targets = selection.isEmpty() ? getNotes() : selection;

    for (auto n : targets)
    {
        auto p = n->getNoteNumber();
        if (inScale && std::abs (semis) < 12)
            p = Theory::scaleStep (p, view.keyRoot.get(), scale(), semis);
        else
            p += semis;
        n->setNoteNumber (jlimit (0, 127, p), &um);
    }

    if (targets.size() == 1)
        previewNote (targets.getFirst()->getNoteNumber());
}

void PianoRollEditor::nudgeSelected (double beats)
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Nudge notes");
    for (auto n : selection)
        n->setStartAndLength (B (jmax (0.0, n->getStartBeat().inBeats() + beats)), n->getLengthBeats(), &um);
}

void PianoRollEditor::duplicateSelected()
{
    if (selection.isEmpty())
        return;

    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Duplicate notes");
    double minS = 1.0e9, maxE = 0.0;
    for (auto n : selection)
    {
        minS = jmin (minS, n->getStartBeat().inBeats());
        maxE = jmax (maxE, n->getEndBeat().inBeats());
    }

    auto shift = snapBeat (maxE - minS, snapDiv());
    if (shift <= 0.0) shift = snapDiv();

    Array<te::MidiNote*> added;
    for (auto n : selection)
        if (auto c = clip->getSequence().addNote (n->getNoteNumber(), n->getStartBeat() + BD (shift), n->getLengthBeats(), n->getVelocity(), 0, &um))
            added.add (c);

    // grow the clip if the copy runs past its end
    auto needEnd = contentStart() + maxE + shift;
    if (needEnd > clipEndBeat (*clip))
        clip->setEnd (beatToTime (clip->edit, std::ceil (needEnd / quarterNotesPerBar (clip->edit)) * quarterNotesPerBar (clip->edit)), true);

    selection = added;
}

void PianoRollEditor::quantize (float strength)
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Quantize");
    auto targets = selection.isEmpty() ? getNotes() : selection;
    auto cs = contentStart();

    for (auto n : targets)
    {
        auto abs = cs + n->getStartBeat().inBeats();
        auto q = abs + (snapBeat (abs, snapDiv()) - abs) * strength;
        n->setStartAndLength (B (jmax (0.0, q - cs)), n->getLengthBeats(), &um);
    }

    session.status ("Quantized " + String (targets.size()) + " notes to the grid");
}

void PianoRollEditor::humanize()
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Humanize");
    auto targets = selection.isEmpty() ? getNotes() : selection;
    Random r;

    for (auto n : targets)
    {
        auto jitter = (r.nextDouble() - 0.5) * 0.04;      // +/- 1/100 of a beat-ish
        n->setStartAndLength (B (jmax (0.0, n->getStartBeat().inBeats() + jitter)), n->getLengthBeats(), &um);
        n->setVelocity (jlimit (1, 127, n->getVelocity() + r.nextInt ({ -12, 13 })), &um);
    }
}

void PianoRollEditor::legato()
{
    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Legato");
    auto targets = selection.isEmpty() ? getNotes() : selection;
    std::vector<te::MidiNote*> sorted (targets.begin(), targets.end());
    std::sort (sorted.begin(), sorted.end(), [] (auto a, auto b) { return a->getStartBeat() < b->getStartBeat(); });

    for (size_t i = 0; i < sorted.size(); ++i)
    {
        double nextStart = -1.0;
        for (size_t j = i + 1; j < sorted.size(); ++j)
            if (sorted[j]->getStartBeat().inBeats() > sorted[i]->getStartBeat().inBeats() + 1.0e-6)
            {
                nextStart = sorted[j]->getStartBeat().inBeats();
                break;
            }

        if (nextStart > 0.0)
            sorted[i]->setStartAndLength (sorted[i]->getStartBeat(), BD (nextStart - sorted[i]->getStartBeat().inBeats()), &um);
    }
}

void PianoRollEditor::arpeggiate()
{
    auto targets = selection.isEmpty() ? getNotes() : selection;
    if (targets.size() < 2)
        return;

    auto& um = clip->edit.getUndoManager();
    um.beginNewTransaction ("Arpeggiate");

    // group notes that start together into chords
    std::map<int, std::vector<te::MidiNote*>> chords;
    for (auto n : targets)
        chords[roundToInt (n->getStartBeat().inBeats() * 96.0)].push_back (n);

    auto step = snapDiv();
    std::vector<std::tuple<int, double, double, int>> toAdd;
    std::vector<te::MidiNote*> toRemove;

    for (auto& [key, notes] : chords)
    {
        if (notes.size() < 2)
            continue;

        std::sort (notes.begin(), notes.end(), [] (auto a, auto b) { return a->getNoteNumber() < b->getNoteNumber(); });
        auto start = notes.front()->getStartBeat().inBeats();
        double end = 0.0;
        for (auto n : notes)
            end = jmax (end, n->getEndBeat().inBeats());

        int i = 0;
        for (auto t = start; t < end - 1.0e-6; t += step, ++i)
        {
            auto n = notes[(size_t) i % notes.size()];
            toAdd.emplace_back (n->getNoteNumber(), t, jmin (step, end - t), n->getVelocity());
        }

        for (auto n : notes)
            toRemove.push_back (n);
    }

    selection.clear();
    for (auto n : toRemove)
        clip->getSequence().removeNote (*n, &um);

    for (auto& [p, t, len, v] : toAdd)
        if (auto n = clip->getSequence().addNote (p, B (t), BD (len), v, 0, &um))
            selection.add (n);
}

//==============================================================================
// DrumGridEditor
//==============================================================================
DrumGridEditor::DrumGridEditor (Session& s, te::MidiClip& c)
    : session (s), clip (&c)
{
    buildRows();

    addAndMakeVisible (stepBox);
    int i = 1;
    for (auto [name, v] : std::initializer_list<std::pair<const char*, double>> {
             { "Steps: 1/8", 0.5 }, { "Steps: 1/16", 0.25 }, { "Steps: 1/32", 0.125 }, { "Steps: 1/8 triplet", 1.0 / 3.0 }, { "Steps: 1/16 triplet", 1.0 / 6.0 } })
    {
        stepBox.addItem (name, i);
        if (std::abs (v - stepBeats) < 1.0e-6) stepBox.setSelectedId (i, dontSendNotification);
        stepBox.getProperties().set (String (i), v);
        ++i;
    }
    stepBox.onChange = [this] { stepBeats = (double) stepBox.getProperties()[String (stepBox.getSelectedId())]; repaint(); };

    addAndMakeVisible (lengthBox);
    for (int bars : { 1, 2, 4, 8, 16 })
        lengthBox.addItem ("Length: " + String (bars) + (bars == 1 ? " bar" : " bars"), bars);
    auto bpb = quarterNotesPerBar (c.edit);
    lengthBox.setSelectedId (jlimit (1, 16, roundToInt (c.getLengthInBeats().inBeats() / bpb)), dontSendNotification);
    lengthBox.onChange = [this]
    {
        auto bars = lengthBox.getSelectedId();
        auto bpb2 = quarterNotesPerBar (clip->edit);
        clip->edit.getUndoManager().beginNewTransaction ("Clip length");
        clip->setEnd (beatToTime (clip->edit, clipStartBeat (*clip) + bars * bpb2), true);
        repaint();
    };

    addAndMakeVisible (swing);
    swing.setSliderStyle (Slider::LinearHorizontal);
    swing.setRange (0.0, 0.75, 0.01);
    swing.setValue (0.0);
    swing.setTextBoxStyle (Slider::TextBoxRight, false, 40, 20);
    swing.setTooltip ("Swing amount: how far off-beat steps get pushed late");

    addAndMakeVisible (applySwing);
    applySwing.onClick = [this]
    {
        auto amount = swing.getValue();
        auto& um = clip->edit.getUndoManager();
        um.beginNewTransaction ("Swing");
        for (auto n : clip->getSequence().getNotes())
        {
            auto st = n->getStartBeat().inBeats();
            auto stepIndex = (int) std::floor (st / stepBeats + 1.0e-6);
            auto onStep = stepIndex * stepBeats;
            if (stepIndex % 2 == 1 && std::abs (st - onStep) < stepBeats * 0.1)
                n->setStartAndLength (B (onStep + amount * stepBeats * 0.66), n->getLengthBeats(), &um);
        }
        session.status ("Applied " + String (roundToInt (amount * 100)) + "% swing");
    };

    addAndMakeVisible (clearAll);
    clearAll.onClick = [this]
    {
        clip->edit.getUndoManager().beginNewTransaction ("Clear pattern");
        clip->getSequence().removeAllNotes (&clip->edit.getUndoManager());
    };

    addAndMakeVisible (hint);
    hint.setFont (LodeLookAndFeel::font (11.0f));
    hint.setColour (Label::textColourId, Col::textFaint);
    hint.setText ("Click to add/remove, drag to paint. Shift = accent, Alt = ghost note, wheel over a step = velocity. Right-click a sound for Euclidean rhythms.",
                  dontSendNotification);

    clip->state.addListener (this);
    startTimerHz (20);
}

DrumGridEditor::~DrumGridEditor()
{
    clip->state.removeListener (this);
}

void DrumGridEditor::buildRows()
{
    rows.clear();
    auto track = clip->getAudioTrack();

    if (track != nullptr)
    {
        if (auto dm = Session::getDrumMachine (*track))
        {
            for (int p = 0; p < DrumMachinePlugin::numPads; ++p)
                rows.push_back ({ dm->getPadNote (p), dm->getPadName (p) });
            return;
        }
    }

    for (int n : { 36, 38, 40, 37, 39, 42, 44, 46, 41, 43, 45, 47, 48, 50, 49, 51, 54, 56 })
        rows.push_back ({ n, DrumKits::gmDrumName (n) });

    // add any other notes already used in the clip
    for (auto n : clip->getSequence().getNotes())
    {
        auto used = std::any_of (rows.begin(), rows.end(), [n] (auto& r) { return r.note == n->getNoteNumber(); });
        if (! used)
            rows.push_back ({ n->getNoteNumber(), DrumKits::gmDrumName (n->getNoteNumber()) });
    }
}

int DrumGridEditor::numSteps() const
{
    return jmax (1, (int) std::round (clip->getLengthInBeats().inBeats() / stepBeats));
}

Rectangle<int> DrumGridEditor::cellBounds (int row, int step) const
{
    auto w = (float) (getWidth() - headerW - 8) / (float) numSteps();
    return Rectangle<float> ((float) headerW + step * w, (float) (topH + row * rowH), w, (float) rowH).toNearestInt();
}

te::MidiNote* DrumGridEditor::findNote (int note, int step) const
{
    auto offset = clip->getOffsetInBeats().inBeats();
    auto s = offset + step * stepBeats, e = s + stepBeats;

    for (auto n : clip->getSequence().getNotes())
        if (n->getNoteNumber() == note)
        {
            auto st = n->getStartBeat().inBeats();
            if (st >= s - 1.0e-6 && st < e - 1.0e-6)
                return n;
        }

    return nullptr;
}

void DrumGridEditor::setCell (int row, int step, bool on, int velocity)
{
    auto& um = clip->edit.getUndoManager();
    auto note = rows[(size_t) row].note;
    auto existing = findNote (note, step);

    if (on && existing == nullptr)
    {
        auto offset = clip->getOffsetInBeats().inBeats();
        clip->getSequence().addNote (note, B (offset + step * stepBeats), BD (stepBeats), velocity, 0, &um);
    }
    else if (! on && existing != nullptr)
    {
        clip->getSequence().removeNote (*existing, &um);
    }
}

void DrumGridEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    g.setColour (Col::bg2);
    g.fillRect (0, 0, getWidth(), topH);

    auto steps = numSteps();
    auto stepsPerBeat = jmax (1, roundToInt (1.0 / stepBeats));
    auto& tc = clip->edit.getTransport();
    auto playBeat = timeToBeat (clip->edit, tc.getPosition()) - clipStartBeat (*clip) + clip->getOffsetInBeats().inBeats();
    auto playingStep = (tc.isPlaying() && playBeat >= 0) ? (int) std::floor (playBeat / stepBeats) : -1;
    auto col = clip->getColour();

    for (int r = 0; r < (int) rows.size(); ++r)
    {
        auto y = topH + r * rowH;
        if (y > getHeight())
            break;

        g.setColour (r % 2 ? Col::bg2 : Col::bg2.brighter (0.03f));
        g.fillRect (0, y, headerW, rowH);
        g.setColour (Col::text);
        g.setFont (LodeLookAndFeel::font (12.0f));
        g.drawText (rows[(size_t) r].name, 8, y, headerW - 40, rowH, Justification::centredLeft, true);
        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (10.0f));
        g.drawText (String (rows[(size_t) r].note), headerW - 34, y, 28, rowH, Justification::centredRight);

        for (int s = 0; s < steps; ++s)
        {
            auto cell = cellBounds (r, s).reduced (1);
            auto beatGroup = (s / stepsPerBeat) % 2 == 0;
            g.setColour (beatGroup ? Col::bg3 : Col::bg2.brighter (0.06f));
            if (s == playingStep) g.setColour (Col::bg4.brighter (0.1f));
            g.fillRoundedRectangle (cell.toFloat(), 3.0f);

            if (auto n = findNote (rows[(size_t) r].note, s))
            {
                auto vel = (float) n->getVelocity() / 127.0f;
                g.setColour (col.withMultipliedBrightness (0.45f + 0.65f * vel));
                g.fillRoundedRectangle (cell.toFloat().reduced (1.0f), 3.0f);

                if (n->getVelocity() >= 120)
                {
                    g.setColour (Colours::white.withAlpha (0.8f));
                    g.fillRect (cell.getX() + 3, cell.getY() + 3, cell.getWidth() - 6, 2);
                }
            }
        }
    }
}

void DrumGridEditor::resized()
{
    auto r = getLocalBounds().removeFromTop (topH).reduced (6, 5);
    stepBox.setBounds (r.removeFromLeft (160));
    r.removeFromLeft (6);
    lengthBox.setBounds (r.removeFromLeft (140));
    r.removeFromLeft (14);
    swing.setBounds (r.removeFromLeft (150));
    r.removeFromLeft (4);
    applySwing.setBounds (r.removeFromLeft (100));
    r.removeFromLeft (6);
    clearAll.setBounds (r.removeFromLeft (64));
    r.removeFromLeft (10);
    hint.setBounds (r);
}

void DrumGridEditor::mouseDown (const MouseEvent& e)
{
    auto row = (e.y - topH) / rowH;
    if (e.y < topH || ! isPositiveAndBelow (row, (int) rows.size()))
        return;

    auto track = clip->getAudioTrack();

    if (e.x < headerW)
    {
        if (e.mods.isPopupMenu())
            showRowMenu (row);
        else if (track != nullptr)
            track->playGuideNote (rows[(size_t) row].note, te::MidiChannel (10), 110, true, true, true);
        return;
    }

    auto w = (float) (getWidth() - headerW - 8) / (float) numSteps();
    auto step = (int) ((e.x - headerW) / w);
    if (! isPositiveAndBelow (step, numSteps()))
        return;

    clip->edit.getUndoManager().beginNewTransaction ("Step edit");
    auto existing = findNote (rows[(size_t) row].note, step);

    if (e.mods.isPopupMenu())
    {
        setCell (row, step, false, 0);
        paintMode = -1;
    }
    else
    {
        paintMode = existing != nullptr ? -1 : 1;
        auto vel = e.mods.isShiftDown() ? 127 : (e.mods.isAltDown() ? 50 : 100);
        setCell (row, step, paintMode > 0, vel);

        if (paintMode > 0 && track != nullptr)
            track->playGuideNote (rows[(size_t) row].note, te::MidiChannel (10), vel, true, true, true);
    }

    lastPaintRow = row;
    lastPaintStep = step;
}

void DrumGridEditor::mouseDrag (const MouseEvent& e)
{
    if (paintMode == 0)
        return;

    auto row = (e.y - topH) / rowH;
    auto w = (float) (getWidth() - headerW - 8) / (float) numSteps();
    auto step = (int) ((e.x - headerW) / w);

    if (! isPositiveAndBelow (row, (int) rows.size()) || ! isPositiveAndBelow (step, numSteps()))
        return;

    if (row != lastPaintRow || step != lastPaintStep)
    {
        auto vel = e.mods.isShiftDown() ? 127 : (e.mods.isAltDown() ? 50 : 100);
        setCell (row, step, paintMode > 0, vel);
        lastPaintRow = row;
        lastPaintStep = step;
    }
}

void DrumGridEditor::mouseUp (const MouseEvent&)
{
    paintMode = 0;
}

void DrumGridEditor::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    auto row = (e.y - topH) / rowH;
    auto cw = (float) (getWidth() - headerW - 8) / (float) numSteps();
    auto step = (int) ((e.x - headerW) / cw);

    if (e.x > headerW && isPositiveAndBelow (row, (int) rows.size()) && isPositiveAndBelow (step, numSteps()))
        if (auto n = findNote (rows[(size_t) row].note, step))
        {
            clip->edit.getUndoManager().beginNewTransaction ("Velocity");
            n->setVelocity (jlimit (1, 127, n->getVelocity() + (w.deltaY > 0 ? 8 : -8)), &clip->edit.getUndoManager());
            return;
        }

    Component::mouseWheelMove (e, w);
}

void DrumGridEditor::showRowMenu (int row)
{
    PopupMenu m;
    m.addItem ("Euclidean rhythm...", [this, row] { euclidDialog (row); });

    PopupMenu every;
    for (int n : { 2, 3, 4, 8, 16 })
        every.addItem ("Every " + String (n) + " steps", [this, row, n]
        {
            clip->edit.getUndoManager().beginNewTransaction ("Fill");
            for (int s = 0; s < numSteps(); ++s)
                setCell (row, s, s % n == 0, 100);
        });
    m.addSubMenu ("Fill", every);

    m.addItem ("Randomize (30%)", [this, row]
    {
        clip->edit.getUndoManager().beginNewTransaction ("Randomize");
        Random r;
        for (int s = 0; s < numSteps(); ++s)
            setCell (row, s, r.nextFloat() < 0.3f, 70 + r.nextInt (50));
    });

    m.addItem ("Clear row", [this, row]
    {
        clip->edit.getUndoManager().beginNewTransaction ("Clear row");
        for (int s = 0; s < numSteps(); ++s)
            setCell (row, s, false, 0);
    });

    m.showMenuAsync ({});
}

void DrumGridEditor::euclidDialog (int row)
{
    auto* aw = new AlertWindow ("Euclidean rhythm",
                                "Spread N hits as evenly as possible over the steps.\n"
                                "Classics: 3 in 8 = tresillo, 5 in 8 = cinquillo, 5 in 16 = bossa nova.",
                                MessageBoxIconType::NoIcon);
    aw->addTextEditor ("pulses", "5", "Hits:");
    aw->addTextEditor ("steps", String (jmin (16, numSteps())), "Steps per cycle:");
    aw->addTextEditor ("rotate", "0", "Rotate:");
    aw->addButton ("Apply", 1, KeyPress (KeyPress::returnKey));
    aw->addButton ("Cancel", 0, KeyPress (KeyPress::escapeKey));

    SafePointer<DrumGridEditor> safe (this);
    aw->enterModalState (true, ModalCallbackFunction::create ([aw, safe, row] (int result)
    {
        if (result != 1 || safe == nullptr)
            return;

        auto pulses = aw->getTextEditorContents ("pulses").getIntValue();
        auto cycle = jmax (1, aw->getTextEditorContents ("steps").getIntValue());
        auto rot = aw->getTextEditorContents ("rotate").getIntValue();
        auto pattern = Theory::euclid (pulses, cycle, rot);

        safe->clip->edit.getUndoManager().beginNewTransaction ("Euclidean rhythm");
        for (int s = 0; s < safe->numSteps(); ++s)
            safe->setCell (row, s, pattern[(size_t) (s % cycle)], s % cycle == 0 ? 115 : 95);
    }), true);
}

//==============================================================================
// AudioClipEditor
//==============================================================================
AudioClipEditor::AudioClipEditor (Session& s, te::WaveAudioClip& c)
    : session (s), clip (&c), thumbnail (s.engine, c.getPlaybackFile(), *this, &c.edit)
{
    addAndMakeVisible (gain);
    gain.setSliderStyle (Slider::LinearHorizontal);
    gain.setRange (-24.0, 12.0, 0.1);
    gain.setValue (c.getGainDB(), dontSendNotification);
    gain.setTextValueSuffix (" dB");
    gain.setTextBoxStyle (Slider::TextBoxRight, false, 70, 20);
    gain.onDragStart = [this] { clip->edit.getUndoManager().beginNewTransaction ("Clip gain"); };
    gain.onValueChange = [this] { clip->setGainDB ((float) gain.getValue()); };

    addAndMakeVisible (pitch);
    pitch.setSliderStyle (Slider::LinearHorizontal);
    pitch.setRange (-24.0, 24.0, 1.0);
    pitch.setValue (c.getPitchChange(), dontSendNotification);
    pitch.setTextValueSuffix (" st");
    pitch.setTextBoxStyle (Slider::TextBoxRight, false, 70, 20);
    pitch.onValueChange = [this] { clip->setPitchChange ((float) pitch.getValue()); };

    addAndMakeVisible (reverse);
    reverse.setToggleState (c.getIsReversed(), dontSendNotification);
    reverse.onClick = [this] { clip->setIsReversed (reverse.getToggleState()); };

    addAndMakeVisible (autoTempo);
    autoTempo.setToggleState (c.getAutoTempo(), dontSendNotification);
    autoTempo.setTooltip ("Stretch the audio to follow the project tempo");
    autoTempo.onClick = [this] { clip->setAutoTempo (autoTempo.getToggleState()); };

    addAndMakeVisible (info);
    info.setColour (Label::textColourId, Col::textDim);
    te::AudioFile af (c.getPlaybackFile());
    info.setText (c.getOriginalFile().getFileName() + "   " + String (af.getSampleRate(), 0) + " Hz, "
                    + String (af.getNumChannels()) + " ch, " + formatTime (af.getLength()),
                  dontSendNotification);

    startTimerHz (5);
}

void AudioClipEditor::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    auto r = getLocalBounds().reduced (10).withTrimmedTop (72);
    g.setColour (Col::bg0);
    g.fillRoundedRectangle (r.toFloat(), 4.0f);
    g.setColour (clip->getColour().brighter (0.4f));
    thumbnail.drawChannels (g, r.reduced (2), { te::TimePosition(), TD (thumbnail.getTotalLength()) }, 1.0f);
}

void AudioClipEditor::resized()
{
    auto r = getLocalBounds().reduced (10);
    info.setBounds (r.removeFromTop (22));
    auto row = r.removeFromTop (28);
    gain.setBounds (row.removeFromLeft (260));
    row.removeFromLeft (10);
    pitch.setBounds (row.removeFromLeft (260));
    row.removeFromLeft (10);
    reverse.setBounds (row.removeFromLeft (90));
    autoTempo.setBounds (row.removeFromLeft (130));
}

//==============================================================================
// ClipEditorPanel
//==============================================================================
ClipEditorPanel::ClipEditorPanel (Session& s) : session (s)
{
    addAndMakeVisible (pianoRollButton);
    addAndMakeVisible (stepButton);
    pianoRollButton.setClickingTogglesState (true);
    stepButton.setClickingTogglesState (true);
    pianoRollButton.setRadioGroupId (33);
    stepButton.setRadioGroupId (33);
    pianoRollButton.onClick = [this] { showClip (currentClip.get(), 0); };
    stepButton.onClick = [this] { showClip (currentClip.get(), 1); };

    session.getSelectionManager().addChangeListener (this);
    showClip (session.getSelectedClip());
}

ClipEditorPanel::~ClipEditorPanel()
{
    session.getSelectionManager().removeChangeListener (this);
}

void ClipEditorPanel::changeListenerCallback (ChangeBroadcaster*)
{
    if (auto c = session.getSelectedClip())
        if (c != currentClip.get())
            showClip (c);
}

void ClipEditorPanel::showClip (te::Clip* c, int preferredMode)
{
    editor.reset();
    currentClip = c;

    auto mc = dynamic_cast<te::MidiClip*> (c);
    pianoRollButton.setVisible (mc != nullptr);
    stepButton.setVisible (mc != nullptr);

    if (mc != nullptr)
    {
        auto track = mc->getAudioTrack();
        auto isDrums = track != nullptr && getTrackKind (*track) == TrackKind::drums;
        mode = preferredMode >= 0 ? preferredMode : (isDrums ? 1 : 0);
        pianoRollButton.setToggleState (mode == 0, dontSendNotification);
        stepButton.setToggleState (mode == 1, dontSendNotification);

        if (mode == 1)
            editor = std::make_unique<DrumGridEditor> (session, *mc);
        else
            editor = std::make_unique<PianoRollEditor> (session, *mc);
    }
    else if (auto wac = dynamic_cast<te::WaveAudioClip*> (c))
    {
        editor = std::make_unique<AudioClipEditor> (session, *wac);
    }

    if (editor != nullptr)
        addAndMakeVisible (*editor);

    resized();
    repaint();
}

void ClipEditorPanel::paint (Graphics& g)
{
    g.fillAll (Col::bg1);

    if (editor == nullptr)
    {
        g.setColour (Col::textDim);
        g.setFont (LodeLookAndFeel::font (15.0f));
        g.drawFittedText ("Double-click a clip to edit it here.\nDouble-click an empty spot on an instrument track to make a new clip.",
                          getLocalBounds().reduced (20), Justification::centred, 3);
    }
}

void ClipEditorPanel::resized()
{
    auto r = getLocalBounds();

    if (pianoRollButton.isVisible())
    {
        auto top = r.removeFromTop (28).reduced (6, 2);
        pianoRollButton.setBounds (top.removeFromLeft (100));
        top.removeFromLeft (4);
        stepButton.setBounds (top.removeFromLeft (120));
    }

    if (editor != nullptr)
        editor->setBounds (r);
}

} // namespace lode
