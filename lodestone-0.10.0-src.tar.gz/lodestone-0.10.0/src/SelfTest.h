/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Developer self-tests that drive the real app (window, engine and audio device)
    from the inside. Run with LODE_SELFTEST=practice - see tests/practice_selftest.sh,
    which provides a JACK dummy device and a test tone on input 1.
*/
#pragma once

#include "Utils.h"

namespace lode
{
class MainComponent;

void startSelfTest (const juce::String& name, MainComponent&, std::function<void (int result)> done);
}
