/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "DrumMachinePlugin.h"

namespace lode
{
using namespace juce;

const char* DrumMachinePlugin::xmlTypeName = "lodestoneDrums";

const Identifier DrumMachinePlugin::padType ("PAD"), DrumMachinePlugin::layerType ("LAYER");
const Identifier DrumMachinePlugin::nameProp ("name"), DrumMachinePlugin::noteProp ("note"),
                 DrumMachinePlugin::gainProp ("gain"), DrumMachinePlugin::panProp ("pan"),
                 DrumMachinePlugin::tuneProp ("tune"), DrumMachinePlugin::decayProp ("decay"),
                 DrumMachinePlugin::cutoffProp ("cutoff"), DrumMachinePlugin::reverseProp ("reverse"),
                 DrumMachinePlugin::chokeProp ("choke"), DrumMachinePlugin::velSensProp ("velSens"),
                 DrumMachinePlugin::oneShotProp ("oneShot"), DrumMachinePlugin::muteProp ("mute"),
                 DrumMachinePlugin::fileProp ("file"), DrumMachinePlugin::minVelProp ("minVel"),
                 DrumMachinePlugin::maxVelProp ("maxVel"), DrumMachinePlugin::startProp ("start"),
                 DrumMachinePlugin::endProp ("end");

//==============================================================================
namespace DrumKits
{
    File getDefaultKitDir()
    {
        return getDataDir().getChildFile ("kits/808");
    }

    static void scanDir (const File& root, const String& source, Array<DrumKitInfo>& out)
    {
        if (! root.isDirectory())
            return;

        for (auto& d : root.findChildFiles (File::findDirectories, false))
        {
            DrumKitInfo info;
            info.location = d;
            info.source = source;

            if (d.getChildFile ("kit.json").existsAsFile())
            {
                auto json = JSON::parse (d.getChildFile ("kit.json"));
                info.name = json.getProperty ("name", d.getFileName()).toString();
                out.add (info);
            }
            else if (d.getChildFile ("drumkit.xml").existsAsFile())
            {
                if (auto xml = XmlDocument::parse (d.getChildFile ("drumkit.xml")))
                    info.name = xml->getChildElementAllSubText ("name", d.getFileName()).trim();

                if (info.name.isEmpty())
                    info.name = d.getFileName();

                out.add (info);
            }
        }
    }

    Array<DrumKitInfo> findAll()
    {
        Array<DrumKitInfo> kits;
        scanDir (getDataDir().getChildFile ("kits"), "Lodestone", kits);
        scanDir (getUserDataDir().getChildFile ("kits"), "User", kits);

        auto home = File::getSpecialLocation (File::userHomeDirectory);
        for (auto dir : { File ("/usr/share/hydrogen/data/drumkits"), File ("/usr/local/share/hydrogen/data/drumkits"),
                          home.getChildFile (".hydrogen/data/drumkits"), home.getChildFile (".local/share/hydrogen/data/drumkits"),
                          home.getChildFile (".local/share/hydrogen/drumkits") })
            scanDir (dir, "Hydrogen", kits);

        return kits;
    }

    String gmDrumName (int note)
    {
        static const char* names[] = {
            "Acoustic Bass Drum", "Kick", "Side Stick", "Snare", "Hand Clap", "Electric Snare", "Low Floor Tom",
            "Closed Hi-Hat", "High Floor Tom", "Pedal Hi-Hat", "Low Tom", "Open Hi-Hat", "Low-Mid Tom", "Hi-Mid Tom",
            "Crash Cymbal", "High Tom", "Ride Cymbal", "Chinese Cymbal", "Ride Bell", "Tambourine", "Splash Cymbal",
            "Cowbell", "Crash Cymbal 2", "Vibraslap", "Ride Cymbal 2", "Hi Bongo", "Low Bongo", "Mute Hi Conga",
            "Open Hi Conga", "Low Conga", "High Timbale", "Low Timbale", "High Agogo", "Low Agogo", "Cabasa",
            "Maracas", "Short Whistle", "Long Whistle", "Short Guiro", "Long Guiro", "Claves", "Hi Wood Block",
            "Low Wood Block", "Mute Cuica", "Open Cuica", "Mute Triangle", "Open Triangle" };

        if (note >= 35 && note <= 81)
            return names[note - 35];

        return noteName (note);
    }
}

//==============================================================================
DrumMachinePlugin::DrumMachinePlugin (te::PluginCreationInfo info)
    : Plugin (info)
{
    masterGainValue.referTo (state, "masterGain", getUndoManager(), 0.0f);
    masterGainParam = addParam ("masterGain", TRANS ("Kit Volume"), { -60.0f, 12.0f },
                                [] (float v) { return String (v, 1) + " dB"; },
                                [] (const String& s) { return s.getFloatValue(); });
    masterGainParam->attachToCurrentValue (masterGainValue);

    for (auto& v : padVelocity)
        v = 0.0f;

    const bool isNew = ! state.getChildWithName (padType).isValid();
    ensurePadStates();

    if (isNew)
    {
        auto defaultKit = DrumKits::getDefaultKitDir();
        if (defaultKit.isDirectory())
            loadKit (defaultKit);
    }

    rebuildKit();
    startTimerHz (25);
}

DrumMachinePlugin::~DrumMachinePlugin()
{
    stopTimer();
    notifyListenersOfDeletion();
    masterGainParam->detachFromCurrentValue();
}

void DrumMachinePlugin::ensurePadStates()
{
    int count = 0;
    for (auto c : state)
        if (c.hasType (padType))
            ++count;

    for (int i = count; i < numPads; ++i)
    {
        ValueTree p (padType);
        p.setProperty (nameProp, "Pad " + String (i + 1), nullptr);
        p.setProperty (noteProp, DrumKits::defaultNoteForPad (i), nullptr);
        state.appendChild (p, nullptr);
    }
}

ValueTree DrumMachinePlugin::getPadState (int pad)
{
    int i = 0;
    for (auto c : state)
        if (c.hasType (padType))
            if (i++ == pad)
                return c;

    return {};
}

String DrumMachinePlugin::getPadName (int pad)      { return getPadState (pad).getProperty (nameProp).toString(); }
int DrumMachinePlugin::getPadNote (int pad)         { return (int) getPadState (pad).getProperty (noteProp, DrumKits::defaultNoteForPad (pad)); }

File DrumMachinePlugin::getPadFile (int pad)
{
    auto l = getPadState (pad).getChildWithName (layerType);
    return l.isValid() ? File (l.getProperty (fileProp).toString()) : File();
}

bool DrumMachinePlugin::padHasSample (int pad)      { return getPadState (pad).getChildWithName (layerType).isValid(); }

int DrumMachinePlugin::findPadForNote (int note)
{
    for (int i = 0; i < numPads; ++i)
        if (getPadNote (i) == note)
            return i;

    return -1;
}

void DrumMachinePlugin::setPadSample (int pad, const File& f, const String& name)
{
    auto p = getPadState (pad);
    if (! p.isValid())
        return;

    auto um = getUndoManager();
    p.removeAllChildren (um);

    ValueTree l (layerType);
    l.setProperty (fileProp, f.getFullPathName(), nullptr);
    l.setProperty (minVelProp, 0.0f, nullptr);
    l.setProperty (maxVelProp, 1.0f, nullptr);
    p.appendChild (l, um);
    p.setProperty (nameProp, name.isNotEmpty() ? name : f.getFileNameWithoutExtension(), um);
}

void DrumMachinePlugin::setPadProperty (int pad, const Identifier& prop, const var& value)
{
    auto p = getPadState (pad);
    if (p.isValid())
        p.setProperty (prop, value, getUndoManager());
}

void DrumMachinePlugin::clearPad (int pad)
{
    auto p = getPadState (pad);
    if (! p.isValid())
        return;

    auto um = getUndoManager();
    p.removeAllChildren (um);
    p.setProperty (nameProp, "Pad " + String (pad + 1), um);
}

void DrumMachinePlugin::swapPads (int a, int b)
{
    auto pa = getPadState (a), pb = getPadState (b);
    if (! pa.isValid() || ! pb.isValid() || a == b)
        return;

    // keep each pad's MIDI note where it is (so the controller layout doesn't move) - swap the sounds
    auto noteA = pa.getProperty (noteProp), noteB = pb.getProperty (noteProp);
    auto ca = pa.createCopy(), cb = pb.createCopy();
    auto um = getUndoManager();
    pa.copyPropertiesAndChildrenFrom (cb, um);
    pb.copyPropertiesAndChildrenFrom (ca, um);
    pa.setProperty (noteProp, noteA, um);
    pb.setProperty (noteProp, noteB, um);
}

//==============================================================================
String DrumMachinePlugin::loadKit (const File& dir)
{
    if (dir.getChildFile ("kit.json").existsAsFile())
    {
        auto json = JSON::parse (dir.getChildFile ("kit.json"));
        if (! json.isObject())
            return "Couldn't read " + dir.getChildFile ("kit.json").getFullPathName();

        loadKitDescription (json, dir);
        return {};
    }

    auto xmlFile = dir.getChildFile ("drumkit.xml");
    if (! xmlFile.existsAsFile())
        return "No kit.json or drumkit.xml in " + dir.getFullPathName();

    auto xml = XmlDocument::parse (xmlFile);
    if (xml == nullptr)
        return "Couldn't parse " + xmlFile.getFullPathName();

    // Hydrogen drumkit -> Lodestone kit description
    auto kit = new DynamicObject();
    kit->setProperty ("name", xml->getChildElementAllSubText ("name", dir.getFileName()).trim());
    juce::Array<var> pads;
    std::set<int> usedNotes;

    if (auto list = xml->getChildByName ("instrumentList"))
    {
        int index = 0;
        for (auto* inst : list->getChildWithTagNameIterator ("instrument"))
        {
            if (pads.size() >= numPads)
                break;

            auto pad = new DynamicObject();
            pad->setProperty ("name", inst->getChildElementAllSubText ("name", "Pad").trim());

            int note = inst->getChildElementAllSubText ("midiOutNote", "-1").getIntValue();
            if (note < 0 || note > 127 || usedNotes.count (note) > 0)
                note = DrumKits::defaultNoteForPad (index);
            usedNotes.insert (note);
            pad->setProperty ("note", note);

            auto vol = inst->getChildElementAllSubText ("volume", "1").getFloatValue();
            pad->setProperty ("gain", Decibels::gainToDecibels (jmax (0.0001f, vol)));

            if (inst->getChildByName ("pan") != nullptr)
                pad->setProperty ("pan", jlimit (-1.0f, 1.0f, inst->getChildElementAllSubText ("pan", "0").getFloatValue()));
            else
            {
                auto pl = inst->getChildElementAllSubText ("pan_L", "1").getFloatValue();
                auto pr = inst->getChildElementAllSubText ("pan_R", "1").getFloatValue();
                pad->setProperty ("pan", jlimit (-1.0f, 1.0f, pr - pl));
            }

            auto mg = inst->getChildElementAllSubText ("muteGroup", "-1").getIntValue();
            pad->setProperty ("choke", mg >= 0 ? mg + 1 : 0);

            juce::Array<var> layers;
            auto addLayers = [&] (XmlElement& parent)
            {
                for (auto* layer : parent.getChildWithTagNameIterator ("layer"))
                {
                    auto l = new DynamicObject();
                    l->setProperty ("file", layer->getChildElementAllSubText ("filename", {}).trim());
                    l->setProperty ("minVel", layer->getChildElementAllSubText ("min", "0").getFloatValue());
                    l->setProperty ("maxVel", layer->getChildElementAllSubText ("max", "1").getFloatValue());
                    l->setProperty ("gain", layer->getChildElementAllSubText ("gain", "1").getFloatValue());
                    layers.add (var (l));
                }
            };

            addLayers (*inst);
            for (auto* comp : inst->getChildWithTagNameIterator ("instrumentComponent"))
                addLayers (*comp);

            if (layers.isEmpty() && inst->getChildByName ("filename") != nullptr)
            {
                auto l = new DynamicObject();
                l->setProperty ("file", inst->getChildElementAllSubText ("filename", {}).trim());
                layers.add (var (l));
            }

            pad->setProperty ("layers", layers);
            pads.add (var (pad));
            ++index;
        }
    }

    kit->setProperty ("pads", pads);
    loadKitDescription (var (kit), dir);
    return {};
}

void DrumMachinePlugin::loadKitDescription (const var& kit, const File& baseDir)
{
    auto um = getUndoManager();
    state.setProperty ("kitName", kit.getProperty ("name", baseDir.getFileName()), um);

    auto resolve = [&] (const String& path) -> File
    {
        if (path.isEmpty())
            return {};

        if (File::isAbsolutePath (path))
            return File (path);

        return baseDir.getChildFile (path);
    };

    auto* pads = kit.getProperty ("pads", var()).getArray();

    for (int i = 0; i < numPads; ++i)
    {
        auto p = getPadState (i);
        p.removeAllChildren (um);

        if (pads == nullptr || i >= pads->size())
        {
            p.setProperty (nameProp, "Pad " + String (i + 1), um);
            p.setProperty (noteProp, DrumKits::defaultNoteForPad (i), um);
            continue;
        }

        auto& d = pads->getReference (i);
        p.setProperty (nameProp, d.getProperty ("name", "Pad " + String (i + 1)), um);
        p.setProperty (noteProp, (int) d.getProperty ("note", DrumKits::defaultNoteForPad (i)), um);
        p.setProperty (gainProp, (float) d.getProperty ("gain", 0.0f), um);
        p.setProperty (panProp, (float) d.getProperty ("pan", 0.0f), um);
        p.setProperty (tuneProp, (float) d.getProperty ("tune", 0.0f), um);
        p.setProperty (decayProp, (float) d.getProperty ("decay", 1.0f), um);
        p.setProperty (cutoffProp, (float) d.getProperty ("cutoff", 20000.0f), um);
        p.setProperty (chokeProp, (int) d.getProperty ("choke", 0), um);
        p.setProperty (reverseProp, (bool) d.getProperty ("reverse", false), um);
        p.setProperty (oneShotProp, (bool) d.getProperty ("oneShot", true), um);
        p.setProperty (velSensProp, (float) d.getProperty ("velSens", 0.75f), um);
        p.setProperty (muteProp, false, um);

        if (d.hasProperty ("start") || d.hasProperty ("end"))
        {
            p.setProperty (startProp, (float) d.getProperty ("start", 0.0f), um);
            p.setProperty (endProp, (float) d.getProperty ("end", 1.0f), um);
        }
        else
        {
            p.removeProperty (startProp, um);
            p.removeProperty (endProp, um);
        }

        auto addLayer = [&] (const var& l)
        {
            auto f = resolve (l.getProperty ("file", {}).toString());
            if (f == File())
                return;

            ValueTree lt (layerType);
            lt.setProperty (fileProp, f.getFullPathName(), nullptr);
            lt.setProperty (minVelProp, (float) l.getProperty ("minVel", 0.0f), nullptr);
            lt.setProperty (maxVelProp, (float) l.getProperty ("maxVel", 1.0f), nullptr);
            lt.setProperty (gainProp, (float) l.getProperty ("gain", 1.0f), nullptr);
            p.appendChild (lt, um);
        };

        if (auto* layers = d.getProperty ("layers", var()).getArray())
            for (auto& l : *layers)
                addLayer (l);
        else if (d.hasProperty ("file"))
            addLayer (d);
    }

    triggerAsyncUpdate();
}

//==============================================================================
std::shared_ptr<const DrumMachinePlugin::SampleData> DrumMachinePlugin::loadSample (const File& f)
{
    auto key = f.getFullPathName();

    if (auto it = sampleCache.find (key); it != sampleCache.end())
        return it->second;

    std::unique_ptr<AudioFormatReader> reader (engine.getAudioFileFormatManager().readFormatManager.createReaderFor (f));

    if (reader == nullptr)
        return {};

    auto data = std::make_shared<SampleData>();
    auto len = (int) std::min ((int64) reader->lengthInSamples, (int64) (reader->sampleRate * 30.0));
    data->sampleRate = reader->sampleRate > 0 ? reader->sampleRate : 44100.0;
    data->buffer.setSize (2, jmax (1, len));
    data->buffer.clear();
    reader->read (&data->buffer, 0, len, 0, true, true);

    if (reader->numChannels == 1)
        data->buffer.copyFrom (1, 0, data->buffer, 0, 0, len);

    std::shared_ptr<const SampleData> result = data;
    sampleCache[key] = result;
    return result;
}

void DrumMachinePlugin::handleAsyncUpdate()
{
    rebuildKit();
}

void DrumMachinePlugin::rebuildKit()
{
    auto kit = std::make_shared<Kit>();

    for (int i = 0; i < numPads; ++i)
    {
        auto p = getPadState (i);
        auto& pr = kit->pads[(size_t) i];

        pr.note    = (int) p.getProperty (noteProp, DrumKits::defaultNoteForPad (i));
        pr.gain    = Decibels::decibelsToGain ((float) p.getProperty (gainProp, 0.0f));
        pr.pan     = jlimit (-1.0f, 1.0f, (float) p.getProperty (panProp, 0.0f));
        pr.pitch   = std::pow (2.0f, (float) p.getProperty (tuneProp, 0.0f) / 12.0f);
        pr.decay   = jlimit (0.0f, 1.0f, (float) p.getProperty (decayProp, 1.0f));
        pr.cutoff  = jlimit (40.0f, 20000.0f, (float) p.getProperty (cutoffProp, 20000.0f));
        pr.reverse = (bool) p.getProperty (reverseProp, false);
        pr.choke   = (int) p.getProperty (chokeProp, 0);
        pr.velSens = jlimit (0.0f, 1.0f, (float) p.getProperty (velSensProp, 0.75f));
        pr.oneShot = (bool) p.getProperty (oneShotProp, true);
        pr.mute    = (bool) p.getProperty (muteProp, false);
        pr.start   = jlimit (0.0f, 0.999f, (float) p.getProperty (startProp, 0.0f));
        pr.end     = jlimit (pr.start + 0.001f, 1.0f, (float) p.getProperty (endProp, 1.0f));

        for (auto l : p)
        {
            if (! l.hasType (layerType))
                continue;

            if (auto s = loadSample (File (l.getProperty (fileProp).toString())))
            {
                Layer layer;
                layer.sample = s;
                layer.minVel = (float) l.getProperty (minVelProp, 0.0f);
                layer.maxVel = (float) l.getProperty (maxVelProp, 1.0f);
                layer.gain = (float) l.getProperty (gainProp, 1.0f);
                pr.layers.push_back (layer);
            }
        }
    }

    std::shared_ptr<const Kit> newKit = kit;
    auto old = currentKit.exchange (newKit);

    if (old != nullptr)
        retiredKits.push_back (old);
}

void DrumMachinePlugin::timerCallback()
{
    // garbage-collect kits and samples the audio thread can no longer see
    retiredKits.erase (std::remove_if (retiredKits.begin(), retiredKits.end(),
                                       [] (auto& k) { return k.use_count() <= 1; }),
                       retiredKits.end());

    if (retiredKits.empty())
        for (auto it = sampleCache.begin(); it != sampleCache.end();)
        {
            if (it->second.use_count() <= 1)
                it = sampleCache.erase (it);
            else
                ++it;
        }

    // MIDI learn
    if (auto pad = learnPad.load(); pad >= 0)
    {
        if (auto note = learnedNote.exchange (-1); note >= 0)
        {
            // if another pad already used this note, give it this pad's old note
            auto other = findPadForNote (note);
            auto oldNote = getPadNote (pad);
            if (other >= 0 && other != pad)
                setPadProperty (other, noteProp, oldNote);

            setPadProperty (pad, noteProp, note);
            learnPad = -1;
        }
    }
}

//==============================================================================
void DrumMachinePlugin::initialise (const te::PluginInitialisationInfo& info)
{
    sampleRate = info.sampleRate;

    for (auto& v : voices)
    {
        v.active = false;
        v.keepAlive.reset();
    }
}

void DrumMachinePlugin::deinitialise() {}

void DrumMachinePlugin::reset()
{
    for (auto& v : voices)
        if (v.active)
        {
            v.fadeStep = 1.0f / (float) (0.005 * sampleRate);
            v.released = true;
        }
}

void DrumMachinePlugin::midiPanic()
{
    reset();
}

void DrumMachinePlugin::triggerPad (int pad, float velocity)
{
    const auto scope = uiFifo.write (1);

    if (scope.blockSize1 > 0)
        uiEvents[(size_t) scope.startIndex1] = { pad, velocity };
    else if (scope.blockSize2 > 0)
        uiEvents[(size_t) scope.startIndex2] = { pad, velocity };
}

void DrumMachinePlugin::startVoice (const Kit& kit, int pad, int note, float velocity, int sampleOffset)
{
    auto& pr = kit.pads[(size_t) pad];

    padHits[(size_t) pad]++;
    padVelocity[(size_t) pad] = velocity;

    if (pr.mute || pr.layers.empty())
        return;

    // choose a velocity layer
    const Layer* layer = nullptr;
    for (auto& l : pr.layers)
        if (velocity >= l.minVel - 1.0e-4f && velocity <= l.maxVel + 1.0e-4f)
        {
            layer = &l;
            break;
        }

    if (layer == nullptr)
    {
        float best = 1.0e9f;
        for (auto& l : pr.layers)
        {
            auto d = std::min (std::abs (velocity - l.minVel), std::abs (velocity - l.maxVel));
            if (d < best) { best = d; layer = &l; }
        }
    }

    if (layer == nullptr || layer->sample == nullptr || layer->sample->buffer.getNumSamples() < 2)
        return;

    // choke groups (e.g. open hat cut off by closed hat)
    if (pr.choke > 0)
        for (auto& v : voices)
            if (v.active && v.choke == pr.choke && ! v.released)
            {
                v.released = true;
                v.fadeStep = 1.0f / (float) (0.006 * sampleRate);
            }

    // find a voice, stealing the oldest/quietest if needed
    Voice* voice = nullptr;
    for (auto& v : voices)
        if (! v.active) { voice = &v; break; }

    if (voice == nullptr)
    {
        float quietest = 10.0f;
        for (auto& v : voices)
        {
            auto level = v.env * v.fade;
            if (level < quietest) { quietest = level; voice = &v; }
        }
    }

    auto& v = *voice;
    v.active = true;
    v.pad = pad;
    v.note = note;
    v.choke = pr.choke;
    v.sample = layer->sample.get();
    v.keepAlive = layer->sample;
    v.reverse = pr.reverse;
    v.oneShot = pr.oneShot;
    v.released = false;
    v.inc = (v.sample->sampleRate / sampleRate) * pr.pitch;

    auto n = (double) v.sample->buffer.getNumSamples();
    v.lo = std::floor (pr.start * (n - 1.0));
    v.hi = jmax (v.lo + 2.0, std::ceil (pr.end * (n - 1.0)));
    // a slice that ends mid-sound gets a 3 ms fade so it doesn't click
    v.edgeFade = (pr.end < 0.999f || (v.reverse && pr.start > 0.001f)) ? 0.003 * v.sample->sampleRate : 0.0;
    v.pos = v.reverse ? v.hi - 2.0 : v.lo;
    v.env = 1.0f;
    v.fade = 1.0f;
    v.fadeStep = 0.0f;
    v.startDelay = jmax (0, sampleOffset);
    v.lpL = v.lpR = 0.0f;

    if (pr.decay >= 0.999f)
        v.envMul = 1.0f;
    else
    {
        auto decaySeconds = 0.025 + std::pow ((double) pr.decay, 2.0) * 2.5;   // time to -60 dB
        v.envMul = (float) std::pow (0.001, 1.0 / (decaySeconds * sampleRate));
    }

    v.lpCoef = pr.cutoff >= 19500.0f ? 1.0f
                                      : (float) (1.0 - std::exp (-MathConstants<double>::twoPi * pr.cutoff / sampleRate));

    auto velGain = (1.0f - pr.velSens) + pr.velSens * velocity * velocity;
    auto gain = pr.gain * layer->gain * velGain * Decibels::decibelsToGain (masterGainParam->getCurrentValue());
    auto angle = (pr.pan + 1.0f) * MathConstants<float>::pi * 0.25f;
    v.gainL = gain * std::cos (angle) * MathConstants<float>::sqrt2;
    v.gainR = gain * std::sin (angle) * MathConstants<float>::sqrt2;
}

void DrumMachinePlugin::noteOff (const Kit&, int note, int)
{
    for (auto& v : voices)
        if (v.active && v.note == note && ! v.oneShot && ! v.released)
        {
            v.released = true;
            v.fadeStep = 1.0f / (float) (0.04 * sampleRate);
        }
}

void DrumMachinePlugin::renderVoices (AudioBuffer<float>& buffer, int start, int num)
{
    auto* outL = buffer.getWritePointer (0, start);
    auto* outR = buffer.getNumChannels() > 1 ? buffer.getWritePointer (1, start) : nullptr;

    for (auto& v : voices)
    {
        if (! v.active)
            continue;

        auto& data = v.sample->buffer;
        auto len = data.getNumSamples();
        auto* sL = data.getReadPointer (0);
        auto* sR = data.getReadPointer (1);

        int i = jmin (v.startDelay, num);
        v.startDelay = jmax (0, v.startDelay - num);
        bool finished = false;

        for (; i < num; ++i)
        {
            auto idx = (int) v.pos;
            if (idx < 0 || idx >= len - 1 || v.pos < v.lo || v.pos >= v.hi - 1.0)
            {
                finished = true;
                break;
            }

            auto frac = (float) (v.pos - idx);
            auto l = sL[idx] + frac * (sL[idx + 1] - sL[idx]);
            auto r = sR[idx] + frac * (sR[idx + 1] - sR[idx]);

            if (v.lpCoef < 1.0f)
            {
                v.lpL += v.lpCoef * (l - v.lpL);
                v.lpR += v.lpCoef * (r - v.lpR);
                l = v.lpL;
                r = v.lpR;
            }

            auto amp = v.env * v.fade;

            if (v.edgeFade > 0.0)
            {
                auto remain = v.reverse ? v.pos - v.lo : (v.hi - 1.0) - v.pos;
                if (remain < v.edgeFade)
                    amp *= (float) jmax (0.0, remain / v.edgeFade);
            }

            if (outR != nullptr)
            {
                outL[i] += l * amp * v.gainL;
                outR[i] += r * amp * v.gainR;
            }
            else
            {
                outL[i] += 0.5f * (l * v.gainL + r * v.gainR) * amp;
            }

            v.env *= v.envMul;

            if (v.fadeStep > 0.0f)
            {
                v.fade -= v.fadeStep;
                if (v.fade <= 0.0f) { finished = true; break; }
            }

            if (v.env < 0.0003f) { finished = true; break; }

            v.pos += v.reverse ? -v.inc : v.inc;
        }

        if (finished)
        {
            v.active = false;
            v.sample = nullptr;
            v.keepAlive.reset();   // never the last reference: the plugin's cache owns one
        }
    }
}

void DrumMachinePlugin::applyToBuffer (const te::PluginRenderContext& fc)
{
    if (fc.destBuffer == nullptr)
        return;

    SCOPED_REALTIME_CHECK

    auto& dest = *fc.destBuffer;
    const int start = fc.bufferStartSample;
    const int num = fc.bufferNumSamples;

    for (int ch = 2; ch < dest.getNumChannels(); ++ch)
        dest.clear (ch, start, num);

    auto kit = currentKit.load();

    if (kit == nullptr || num <= 0)
        return;

    // pads auditioned from the UI
    {
        const auto scope = uiFifo.read (uiFifo.getNumReady());
        auto handle = [&] (int index)
        {
            auto [pad, vel] = uiEvents[(size_t) index];
            if (pad >= 0 && pad < numPads)
                startVoice (*kit, pad, kit->pads[(size_t) pad].note, vel, 0);
        };

        for (int i = 0; i < scope.blockSize1; ++i) handle (scope.startIndex1 + i);
        for (int i = 0; i < scope.blockSize2; ++i) handle (scope.startIndex2 + i);
    }

    if (fc.bufferForMidiMessages != nullptr)
    {
        if (fc.bufferForMidiMessages->isAllNotesOff)
            for (auto& v : voices)
                if (v.active && ! v.oneShot)
                {
                    v.released = true;
                    v.fadeStep = 1.0f / (float) (0.01 * sampleRate);
                }

        for (auto& m : *fc.bufferForMidiMessages)
        {
            auto t = jlimit (start, start + num - 1, roundToInt (m.getTimeStamp() * sampleRate)) - start;

            if (m.isNoteOn())
            {
                auto note = m.getNoteNumber();

                if (learnPad.load() >= 0)
                    learnedNote = note;

                for (int p = 0; p < numPads; ++p)
                    if (kit->pads[(size_t) p].note == note)
                        startVoice (*kit, p, note, m.getFloatVelocity(), t);
            }
            else if (m.isNoteOff())
            {
                noteOff (*kit, m.getNoteNumber(), t);
            }
            else if (m.isAllNotesOff() || m.isAllSoundOff())
            {
                for (auto& v : voices)
                    if (v.active)
                    {
                        v.released = true;
                        v.fadeStep = 1.0f / (float) (0.01 * sampleRate);
                    }
            }
        }
    }

    renderVoices (dest, start, num);
}

bool DrumMachinePlugin::hasNameForMidiNoteNumber (int note, int, String& name)
{
    auto pad = findPadForNote (note);
    if (pad < 0)
        return false;

    name = getPadName (pad);
    return true;
}

void DrumMachinePlugin::restorePluginStateFromValueTree (const ValueTree& v)
{
    if (v.getChildWithName (padType).isValid())
    {
        for (int i = state.getNumChildren(); --i >= 0;)
            if (state.getChild (i).hasType (padType))
                state.removeChild (i, nullptr);

        for (auto c : v)
            if (c.hasType (padType))
                state.appendChild (c.createCopy(), nullptr);
    }

    if (v.hasProperty ("kitName"))
        state.setProperty ("kitName", v.getProperty ("kitName"), nullptr);

    te::copyPropertiesToCachedValues (v, masterGainValue);
    ensurePadStates();
    triggerAsyncUpdate();
}

} // namespace lode
