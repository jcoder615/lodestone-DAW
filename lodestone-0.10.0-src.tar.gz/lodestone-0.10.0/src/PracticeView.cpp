/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "PracticeView.h"
#include "InstrumentPanel.h"
#include "Mixer.h"
#include "TransportBar.h"
#include "Browser.h"
#include "DrumMachinePlugin.h"

namespace lode
{
using namespace juce;

namespace
{
    constexpr int cardWidth = 238, cardHeight = 306, addCardWidth = 170;

    // Menus and alerts can outlive the practice edit (leave Practice with one open):
    // they hold weak references, never a Ptr that would keep a track alive past its Edit.
    using WeakTrack = te::SafeSelectable<te::AudioTrack>;
    using WeakPlugin = te::SafeSelectable<te::Plugin>;

    Label* caption (Label& l, const String& text)
    {
        l.setText (text, dontSendNotification);
        l.setFont (LodeLookAndFeel::font (10.5f, true));
        l.setColour (Label::textColourId, Col::textFaint);
        l.setInterceptsMouseClicks (false, false);
        return &l;
    }

    String effectsSummary (te::AudioTrack& t)
    {
        StringArray names;
        for (auto p : t.pluginList)
            if (! p->isSynth() && ! isPracticeUtilityPlugin (p)
                 && dynamic_cast<te::VolumeAndPanPlugin*> (p) == nullptr && dynamic_cast<te::LevelMeterPlugin*> (p) == nullptr)
                names.add (p->getName() + (p->isEnabled() ? "" : " (off)"));

        return names.isEmpty() ? String ("No effects yet - add them below")
                               : "FX: " + names.joinIntoString (", ");
    }

    /** A note you drag up/down or scroll. */
    class NoteBox : public Component,
                    public SettableTooltipClient
    {
    public:
        std::function<void (int)> onChange;

        void setNote (int n)    { n = jlimit (0, 127, n); if (n != note) { note = n; repaint(); } }
        int getNote() const     { return note; }

        void paint (Graphics& g) override
        {
            auto r = getLocalBounds().toFloat();
            g.setColour (isMouseOverOrDragging() ? Col::bg4 : Col::bg0);
            g.fillRoundedRectangle (r, 4.0f);
            g.setColour (Col::text);
            g.setFont (LodeLookAndFeel::font (13.0f, true));
            g.drawText (noteName (note), getLocalBounds(), Justification::centred);
        }

        void mouseDown (const MouseEvent&) override         { dragStart = note; }
        void mouseDrag (const MouseEvent& e) override       { change (dragStart - e.getDistanceFromDragStartY() / 5); }
        void mouseWheelMove (const MouseEvent&, const MouseWheelDetails& w) override { change (note + (w.deltaY > 0 ? 1 : -1)); }
        void mouseEnter (const MouseEvent&) override        { repaint(); }
        void mouseExit (const MouseEvent&) override         { repaint(); }

    private:
        int note = 60, dragStart = 60;

        void change (int n)
        {
            n = jlimit (0, 127, n);
            if (n == note) return;
            note = n;
            repaint();
            if (onChange) onChange (note);
        }
    };

    /** A button that tells you when it's pressed and released (hold to sample). */
    class HoldButton : public TextButton
    {
    public:
        using TextButton::TextButton;
        std::function<void()> onPress, onRelease;

        void mouseDown (const MouseEvent& e) override
        {
            TextButton::mouseDown (e);
            if (e.mods.isLeftButtonDown() && onPress) { held = true; onPress(); }
        }

        void mouseUp (const MouseEvent& e) override
        {
            TextButton::mouseUp (e);
            if (held && onRelease) { held = false; onRelease(); }
        }

    private:
        bool held = false;
    };
}

//==============================================================================
// A card for one sound
//==============================================================================
class PracticeView::SlotCard : public Component
{
public:
    SlotCard (PracticeView& v, te::AudioTrack& t) : track (&t), view (v), pc (v.getController())
    {
        addAndMakeVisible (nameLabel);
        nameLabel.setFont (LodeLookAndFeel::font (15.0f, true));
        nameLabel.setColour (Label::textColourId, Col::text);
        nameLabel.setEditable (false, true, false);
        nameLabel.setTooltip ("Double-click to rename");
        nameLabel.onTextChange = [this]
        {
            if (auto n = nameLabel.getText().trim(); n.isNotEmpty())
                track->setName (n);
        };
        nameLabel.addMouseListener (this, false);

        addAndMakeVisible (menuButton);
        menuButton.setTooltip ("More: rename, duplicate, delete...");
        menuButton.onClick = [this] { showMenu(); };

        addAndMakeVisible (volume);
        volume.setSliderStyle (Slider::LinearHorizontal);
        volume.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
        volume.setRange (-60.0, 6.0, 0.1);
        volume.setDoubleClickReturnValue (true, 0.0);
        volume.setSkewFactorFromMidPoint (-12.0);
        volume.setTooltip ("Volume (double-click for 0 dB)");
        volume.onValueChange = [this]
        {
            if (auto vp = track->getVolumePlugin())
                vp->setVolumeDb ((float) volume.getValue());
        };

        for (auto* b : { &muteButton, &soloButton })
        {
            addAndMakeVisible (b);
            b->setClickingTogglesState (false);
        }

        muteButton.setColour (TextButton::buttonOnColourId, Col::yellow.withAlpha (0.8f));
        soloButton.setColour (TextButton::buttonOnColourId, Col::south);
        muteButton.setTooltip ("Mute this sound");
        soloButton.setTooltip ("Solo: hear only this sound");
        muteButton.onClick = [this] { track->setMute (! track->isMuted (false)); refresh(); };
        soloButton.onClick = [this] { track->setSolo (! track->isSolo (false)); view.refreshCards(); };

        addAndMakeVisible (fxLabel);
        fxLabel.setFont (LodeLookAndFeel::font (11.5f));
        fxLabel.setColour (Label::textColourId, Col::textDim);
        fxLabel.setMinimumHorizontalScale (0.8f);
        fxLabel.addMouseListener (this, false);
        fxLabel.setTooltip ("Click to edit the instrument and effects below");
    }

    te::AudioTrack::Ptr track;

    virtual void refresh()
    {
        nameLabel.setText (track->getName(), dontSendNotification);

        if (auto vp = track->getVolumePlugin())
            volume.setValue (vp->getVolumeDb(), dontSendNotification);

        muteButton.setToggleState (track->isMuted (false), dontSendNotification);
        soloButton.setToggleState (track->isSolo (false), dontSendNotification);
        fxLabel.setText (effectsSummary (*track), dontSendNotification);
        resized();
        repaint();
    }

    virtual void updateLive() {}

    void paint (Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (1.0f);
        const bool selected = view.getSelectedSlot() == track.get();
        const bool muted = track->isMuted (false);

        g.setColour (Col::bg2.interpolatedWith (track->getColour(), activity * 0.18f));
        g.fillRoundedRectangle (r, 8.0f);

        g.setColour (track->getColour().withAlpha (muted ? 0.35f : 1.0f));
        g.fillRoundedRectangle (r.removeFromTop (5.0f).withTrimmedLeft (6.0f).withTrimmedRight (6.0f), 2.0f);

        g.setColour (selected ? Col::south : Col::line.withAlpha (0.6f));
        g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (1.0f), 8.0f, selected ? 2.0f : 1.0f);

        if (muted)
        {
            auto badge = menuButton.getBounds().translated (-58, 0).withWidth (52).reduced (0, 3).toFloat();
            g.setColour (Col::yellow.withAlpha (0.18f));
            g.fillRoundedRectangle (badge, 4.0f);
            g.setColour (Col::yellow);
            g.setFont (LodeLookAndFeel::font (10.0f, true));
            g.drawText ("MUTED", badge, Justification::centred);
        }
    }

    void mouseDown (const MouseEvent& e) override
    {
        if (e.eventComponent == &nameLabel && e.getNumberOfClicks() > 1)
            return;

        view.takeFocusBack();
        view.selectSlot (track.get());
    }

protected:
    PracticeView& view;
    PracticeController& pc;
    Label nameLabel;
    TextButton menuButton { "..." };
    Slider volume;
    TextButton muteButton { "M" }, soloButton { "S" };
    Label fxLabel;
    float activity = 0.0f;

    Rectangle<int> layoutHeader (Rectangle<int>& r)
    {
        auto top = r.removeFromTop (34).withTrimmedTop (6);
        menuButton.setBounds (top.removeFromRight (30).reduced (0, 3));
        nameLabel.setBounds (top.withTrimmedRight (track->isMuted (false) ? 60 : 0));
        return top;
    }

    void layoutFooter (Rectangle<int>& r)
    {
        fxLabel.setBounds (r.removeFromBottom (20));
        r.removeFromBottom (4);
        auto row = r.removeFromBottom (24);
        soloButton.setBounds (row.removeFromRight (26));
        row.removeFromRight (4);
        muteButton.setBounds (row.removeFromRight (26));
        row.removeFromRight (6);
        volume.setBounds (row);
    }

    virtual void addMenuItems (PopupMenu&) {}

    void showMenu()
    {
        PopupMenu m;
        WeakTrack t (track.get());
        SafePointer<PracticeView> v (&view);
        SafePointer<SlotCard> self (this);

        m.addItem ("Rename", [self] { if (self != nullptr) self->nameLabel.showEditor(); });
        addMenuItems (m);
        m.addSeparator();
        m.addItem ("Duplicate", [v, t] { if (v != nullptr && t != nullptr) v->selectSlot (v->getController().duplicateSlot (*t.get())); });
        m.addItem ("Delete", [v, t]
        {
            if (v == nullptr || t == nullptr) return;
            AlertWindow::showAsync (MessageBoxOptions().withIconType (MessageBoxIconType::QuestionIcon)
                                        .withTitle ("Delete \"" + t->getName() + "\"?")
                                        .withMessage ("This removes the sound and its effects from Practice. Your projects aren't affected.")
                                        .withButton ("Delete", 1).withButton ("Cancel", 0),
                                    [v, t] (int r) { if (r == 1 && v != nullptr && t != nullptr) v->getController().deleteSlot (*t.get()); });
        });
        m.showMenuAsync (PopupMenu::Options().withTargetComponent (&menuButton));
    }
};

//==============================================================================
class PracticeView::InstrumentCard : public SlotCard
{
public:
    InstrumentCard (PracticeView& v, te::AudioTrack& t) : SlotCard (v, t)
    {
        addAndMakeVisible (soundButton);
        soundButton.setTooltip ("Change the sound: GM instruments, synths, drum kits, your plugins");
        soundButton.onClick = [this]
        {
            WeakTrack t (track.get());
            SafePointer<PracticeView> sv (&view);
            showInstrumentMenu (view.session, &soundButton, [sv, t] (const String& d)
            {
                if (sv != nullptr && t != nullptr)
                    sv->getController().setSlotSound (*t.get(), d);
            });
        };

        addAndMakeVisible (*caption (playsCaption, "PLAYS FROM"));
        addAndMakeVisible (playsButton);
        playsButton.setTooltip ("Which MIDI controllers play this sound. Put one controller on several sounds to layer them.");
        playsButton.onClick = [this] { showControllerMenu(); };

        addAndMakeVisible (*caption (keysCaption, "KEYS"));
        for (auto* nb : { &lowBox, &highBox })
        {
            addAndMakeVisible (nb);
            nb->setTooltip ("Drag or scroll to change. Splits: give two sounds different key ranges.");
        }

        lowBox.onChange = [this] (int n) { if (auto z = PracticeController::getZone (*track)) z->setRange (n, jmax (n, z->getHigh())); refresh(); };
        highBox.onChange = [this] (int n) { if (auto z = PracticeController::getZone (*track)) z->setRange (jmin (n, z->getLow()), n); refresh(); };

        addAndMakeVisible (learnButton);
        learnButton.setTooltip ("Set the range by pressing its lowest and highest keys on your controller");
        learnButton.onClick = [this]
        {
            if (pc.getLearningSlot() == track.get())
                pc.cancelLearning();
            else
                pc.startLearningRange (*track);
            updateLive();
        };

        addAndMakeVisible (*caption (playingCaption, "NOW PLAYING"));
        addAndMakeVisible (playingLabel);
        playingLabel.setFont (LodeLookAndFeel::font (13.0f, true));
        playingLabel.setColour (Label::textColourId, track->getColour().brighter (0.3f));
        playingLabel.setInterceptsMouseClicks (false, false);
        playingLabel.setMinimumHorizontalScale (0.6f);

        addAndMakeVisible (*caption (transposeCaption, "TRANSPOSE"));
        addAndMakeVisible (transpose);
        transpose.suffix = " st";
        transpose.onChange = [this] (double st)
        {
            if (auto z = PracticeController::getZone (*track))
                z->setTranspose (roundToInt (st));
        };

        for (auto [b, delta] : std::initializer_list<std::pair<TextButton*, int>> { { &octDown, -12 }, { &octUp, 12 } })
        {
            addAndMakeVisible (b);
            b->setTooltip (delta < 0 ? "Down an octave" : "Up an octave");
            b->onClick = [this, d = delta]
            {
                if (auto z = PracticeController::getZone (*track))
                    z->setTranspose (z->getTranspose() + d);
                refresh();
            };
        }

        refresh();
    }

    void refresh() override
    {
        SlotCard::refresh();
        soundButton.setButtonText (pc.getSoundName (*track));
        playsButton.setButtonText (pc.describeControllers (*track));

        if (auto z = PracticeController::getZone (*track))
        {
            lowBox.setNote (z->getLow());
            highBox.setNote (z->getHigh());
            transpose.setValue (z->getTranspose(), false);
        }

        updateLive();
    }

    void updateLive() override
    {
        const float target = pc.isSounding (*track) ? 1.0f : 0.0f;
        const float next = target > activity ? target : activity * 0.82f;

        if (std::abs (next - activity) > 0.01f)
        {
            activity = next;
            repaint();
        }

        const bool learning = pc.getLearningSlot() == track.get();
        learnButton.setButtonText (learning ? (pc.isLearningSecondKey() ? "Highest?" : "Lowest?") : "Learn");
        learnButton.setColour (TextButton::buttonColourId, learning ? Col::north.withAlpha (0.7f) : Col::bg3);

        auto keys = pc.getHeldKeys (*track);
        String text;
        if (keys.isEmpty())
        {
            text = pc.getSlotControllers (*track).isEmpty() ? "nothing plays this yet" : "-";
        }
        else
        {
            keys.sort();
            const int shift = PracticeController::getZone (*track) != nullptr ? PracticeController::getZone (*track)->getTranspose() : 0;
            StringArray names;
            for (auto k : keys)
                names.add (noteName (k + shift));
            text = names.joinIntoString ("  ");
        }

        if (playingLabel.getText() != text)
            playingLabel.setText (text, dontSendNotification);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (10, 4);
        layoutHeader (r);

        r.removeFromTop (2);
        soundButton.setBounds (r.removeFromTop (28));
        r.removeFromTop (8);

        playsCaption.setBounds (r.removeFromTop (14));
        playsButton.setBounds (r.removeFromTop (26));
        r.removeFromTop (8);

        keysCaption.setBounds (r.removeFromTop (14));
        auto keys = r.removeFromTop (26);
        learnButton.setBounds (keys.removeFromRight (70));
        keys.removeFromRight (6);
        auto w = (keys.getWidth() - 14) / 2;
        lowBox.setBounds (keys.removeFromLeft (w));
        keys.removeFromLeft (14);
        highBox.setBounds (keys);
        r.removeFromTop (8);

        transposeCaption.setBounds (r.removeFromTop (14));
        auto tr = r.removeFromTop (26);
        octUp.setBounds (tr.removeFromRight (40));
        tr.removeFromRight (4);
        octDown.setBounds (tr.removeFromRight (40));
        tr.removeFromRight (6);
        transpose.setBounds (tr);
        r.removeFromTop (8);

        playingCaption.setBounds (r.removeFromTop (14));
        playingLabel.setBounds (r.removeFromTop (20));

        layoutFooter (r);
    }

    void paint (Graphics& g) override
    {
        SlotCard::paint (g);

        // the dash between the two note boxes
        g.setColour (Col::textFaint);
        auto mid = lowBox.getBounds().getUnion (highBox.getBounds());
        g.drawText ("-", lowBox.getRight(), mid.getY(), highBox.getX() - lowBox.getRight(), mid.getHeight(), Justification::centred);
    }

private:
    TextButton soundButton, playsButton, learnButton { "Learn" }, octDown { "-12" }, octUp { "+12" };
    Label playsCaption, keysCaption, transposeCaption, playingCaption, playingLabel;
    NoteBox lowBox, highBox;
    DragNumber transpose { -48.0, 48.0, 1.0, 0 };

    void addMenuItems (PopupMenu& m) override
    {
        auto zone = PracticeController::getZone (*track);
        if (zone == nullptr)
            return;

        WeakPlugin zp (zone);
        SafePointer<SlotCard> self (this);
        PopupMenu ch;
        ch.addItem ("Any channel", true, zone->getChannel() == 0, [zp] { if (auto z = dynamic_cast<KeyZonePlugin*> (zp.get())) z->setChannel (0); });
        for (int c = 1; c <= 16; ++c)
            ch.addItem ("Channel " + String (c), true, zone->getChannel() == c, [zp, c] { if (auto z = dynamic_cast<KeyZonePlugin*> (zp.get())) z->setChannel (c); });

        m.addSubMenu ("Only MIDI channel...", ch);
        m.addItem ("Reset keys and transpose", [self, zp]
        {
            if (auto z = dynamic_cast<KeyZonePlugin*> (zp.get()))
            {
                z->setRange (0, 127);
                z->setTranspose (0);
                z->setChannel (0);
            }

            if (self != nullptr)
                self->refresh();
        });
    }

    void showControllerMenu()
    {
        PopupMenu m;
        WeakTrack t (track.get());
        SafePointer<PracticeView> v (&view);
        auto current = pc.getSlotControllers (*track);
        auto controllers = pc.getControllers();

        m.addSectionHeader ("Plays \"" + track->getName() + "\"");

        for (auto& c : controllers)
        {
            auto label = c.name + (c.connected ? "" : "  (unplugged)") + (c.looksLikePads ? "  - pads" : "");
            m.addItem (label, true, current.contains (c.name), [v, t, n = c.name]
            {
                if (v != nullptr && t != nullptr)
                {
                    v->getController().toggleSlotController (*t.get(), n);
                    v->refreshCards();
                }
            });
        }

        if (controllers.isEmpty())
            m.addItem ("No MIDI controllers found - plug one in", false, false, [] {});

        m.addSeparator();
        m.addItem ("Nothing", true, current.isEmpty(), [v, t]
        {
            if (v != nullptr && t != nullptr)
            {
                v->getController().setSlotControllers (*t.get(), {});
                v->refreshCards();
            }
        });

        m.showMenuAsync (PopupMenu::Options().withTargetComponent (&playsButton));
    }
};

//==============================================================================
class PracticeView::AudioCard : public SlotCard,
                                public SettableTooltipClient
{
public:
    AudioCard (PracticeView& v, te::AudioTrack& t) : SlotCard (v, t)
    {
        addAndMakeVisible (*caption (inputCaption, "INPUT"));
        addAndMakeVisible (inputBox);
        inputBox.setTooltip ("Which input of your audio interface this is plugged into");
        inputBox.onChange = [this]
        {
            auto choices = pc.getInputChoices();
            auto idx = inputBox.getSelectedId() - 1;
            if (isPositiveAndBelow (idx, choices.size()))
                pc.setSlotInput (*track, choices[idx]);
        };

        addAndMakeVisible (monitorButton);
        monitorButton.setTooltip ("Hear the input through its effects. Use headphones with a mic or it'll feed back. "
                                  "Leave it off if you listen through your interface's direct monitoring.");
        monitorButton.onClick = [this]
        {
            const bool on = monitorButton.getToggleState();
            pc.setMonitoring (*track, on);

            if (on)
                view.showNotice ("You'll hear \"" + track->getName() + "\" through its effects. With a mic, use headphones - "
                                 "through speakers it will feed back.");
        };

        addAndMakeVisible (sampleButton);
        sampleButton.setColour (TextButton::buttonColourId, Col::north.withAlpha (0.25f));
        sampleButton.setTooltip ("Hold, make a sound, let go. The sample becomes a sound you can play.");
        sampleButton.onPress = [this]
        {
            if (pc.startSampling (*track))
                updateLive();
        };
        sampleButton.onRelease = [this]
        {
            const bool pads = destBox.getSelectedId() == 2;
            auto msg = pc.stopSampling (*track, pads);
            view.showNotice (msg);
        };

        addAndMakeVisible (destBox);
        destBox.addItem ("to keys", 1);
        destBox.addItem ("to pads", 2);
        destBox.setTooltip ("Keys: one sample, pitched across the keyboard.\nPads: cut into slices on the drum pads (by hits, or evenly).");
        destBox.setSelectedId (track->state.getProperty ("practiceSampleDest", 1), dontSendNotification);
        destBox.onChange = [this] { track->state.setProperty ("practiceSampleDest", destBox.getSelectedId(), nullptr); };

        refresh();
    }

    void refresh() override
    {
        SlotCard::refresh();

        inputBox.clear (dontSendNotification);
        auto choices = pc.getInputChoices();
        for (int i = 0; i < choices.size(); ++i)
            inputBox.addItem (choices[i].label, i + 1);

        if (choices.isEmpty())
            inputBox.setTextWhenNothingSelected ("No audio inputs - check Settings");
        else
            inputBox.setTextWhenNothingSelected ("Choose an input");

        inputBox.setSelectedId (pc.getCurrentInputChoice (*track) + 1, dontSendNotification);
        monitorButton.setToggleState (pc.isMonitoring (*track), dontSendNotification);
    }

    void updateLive() override
    {
        auto tap = PracticeController::getTap (*track);
        if (tap == nullptr)
            return;

        const float pk = tap->getPeakAndReset();
        level = jmax (pk, level * 0.86f);
        if (pk > 0.98f)
            clipTime = Time::getMillisecondCounter();

        // the tuner, about 15 times a second
        if (++frame % 2 == 0)
        {
            std::vector<float> buf (4096);
            tap->copyRecent (buf.data(), (int) buf.size());

            float clarity = 0.0f;
            auto hz = level > 0.004f ? PitchDetector::detect (buf.data(), (int) buf.size(), tap->getSampleRate(), clarity) : 0.0f;

            if (hz > 0.0f && clarity > 0.85f)
            {
                recent.push_back (hz);
                if (recent.size() > 5)
                    recent.pop_front();

                auto sorted = std::vector<float> (recent.begin(), recent.end());
                std::sort (sorted.begin(), sorted.end());
                tunerHz = sorted[sorted.size() / 2];
                lastPitchMs = Time::getMillisecondCounter();
            }
            else if (Time::getMillisecondCounter() - lastPitchMs > 600)
            {
                recent.clear();
                tunerHz = 0.0f;
            }
        }

        if (tap->isSampling())
            sampleButton.setButtonText ("Recording " + String (tap->getSampledSeconds(), 1) + " s");
        else
            sampleButton.setButtonText ("Hold to sample");

        activity = jlimit (0.0f, 1.0f, level * 3.0f);
        repaint (meterArea.getUnion (tunerArea).expanded (2));
        repaint (getLocalBounds().removeFromTop (8));
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (10, 4);
        layoutHeader (r);
        r.removeFromTop (2);

        inputCaption.setBounds (r.removeFromTop (14));
        inputBox.setBounds (r.removeFromTop (26));
        r.removeFromTop (6);
        monitorButton.setBounds (r.removeFromTop (24));
        r.removeFromTop (6);
        meterArea = r.removeFromTop (10);
        r.removeFromTop (6);
        tunerArea = r.removeFromTop (54);
        r.removeFromTop (8);

        auto row = r.removeFromTop (30);
        destBox.setBounds (row.removeFromRight (82).reduced (0, 2));
        row.removeFromRight (6);
        sampleButton.setBounds (row);

        layoutFooter (r);
    }

    void paint (Graphics& g) override
    {
        SlotCard::paint (g);

        // input meter
        auto db = Decibels::gainToDecibels (level, -100.0f);
        Draw::meter (g, meterArea.toFloat(), db, db, false);
        if (Time::getMillisecondCounter() - clipTime < 1500)
        {
            g.setColour (Col::north);
            g.fillRect (meterArea.removeFromRight (6).toFloat());
        }

        // tuner
        auto t = tunerArea.toFloat();
        Draw::panel (g, t, Col::bg0, 6.0f);

        if (tunerHz <= 0.0f)
        {
            g.setColour (Col::textFaint);
            g.setFont (LodeLookAndFeel::font (12.0f));
            g.drawText (level > 0.004f ? "Tuner: listening..." : "Tuner: play or sing a note", tunerArea, Justification::centred);
            return;
        }

        const double midi = 69.0 + 12.0 * std::log2 (tunerHz / 440.0);
        const int note = roundToInt (midi);
        const float cents = (float) ((midi - note) * 100.0);
        const bool inTune = std::abs (cents) < 5.0f;

        auto text = t.reduced (8.0f, 4.0f);
        auto left = text.removeFromLeft (64.0f);
        g.setColour (inTune ? Col::green : Col::text);
        g.setFont (LodeLookAndFeel::font (24.0f, true));
        g.drawText (noteName (note), left, Justification::centredLeft);

        auto info = text.removeFromTop (16.0f);
        g.setColour (Col::textDim);
        g.setFont (LodeLookAndFeel::font (11.0f));
        g.drawText (String (tunerHz, 1) + " Hz", info, Justification::centredLeft);
        g.drawText ((cents >= 0 ? "+" : "") + String (roundToInt (cents)) + " cents", info, Justification::centredRight);

        // the needle: -50 .. +50 cents
        auto bar = text.reduced (0.0f, 6.0f);
        g.setColour (Col::bg3);
        g.fillRoundedRectangle (bar, 3.0f);
        g.setColour (Col::green.withAlpha (0.35f));
        g.fillRect (bar.withSizeKeepingCentre (bar.getWidth() * 0.1f, bar.getHeight()));
        auto x = bar.getCentreX() + bar.getWidth() * 0.5f * jlimit (-1.0f, 1.0f, cents / 50.0f);
        g.setColour (inTune ? Col::green : Col::yellow);
        g.fillRoundedRectangle (x - 2.5f, bar.getY() - 2.0f, 5.0f, bar.getHeight() + 4.0f, 2.0f);
    }

private:
    Label inputCaption;
    ComboBox inputBox, destBox;
    ToggleButton monitorButton { "Hear it (monitor)" };
    HoldButton sampleButton { "Hold to sample" };
    Rectangle<int> meterArea, tunerArea;
    float level = 0.0f, tunerHz = 0.0f;
    std::deque<float> recent;
    uint32 lastPitchMs = 0, clipTime = 0;
    int frame = 0;
};

//==============================================================================
class PracticeView::AddCard : public Component
{
public:
    AddCard (PracticeView& v) : view (v)
    {
        addAndMakeVisible (addSound);
        addSound.setTooltip ("Add another instrument. It plays from your main keyboard - set key ranges to split, or mute one.");
        addSound.onClick = [this]
        {
            SafePointer<PracticeView> sv (&view);
            showInstrumentMenu (view.session, &addSound, [sv] (const String& d)
            {
                if (sv == nullptr)
                    return;

                auto& pc = sv->getController();
                StringArray ctrls;
                te::AudioTrack* layeredWith = nullptr;

                for (auto t : pc.getSlots())
                    if (! PracticeController::isAudioSlot (*t) && getTrackKind (*t) != TrackKind::drums && ! pc.getSlotControllers (*t).isEmpty())
                    {
                        ctrls = pc.getSlotControllers (*t);
                        layeredWith = t;
                        break;
                    }

                auto spec = BrowserItems::toInstrumentSpec (d);
                if (spec.type == InstrumentSpec::Type::drums || spec.bank == 128)
                    for (auto& c : pc.getControllers())
                        if (c.looksLikePads && c.connected)
                            ctrls = StringArray (c.name);

                if (auto t = pc.addInstrumentSlot (spec, BrowserItems::displayName (d), ctrls))
                {
                    sv->selectSlot (t);
                    if (layeredWith != nullptr && pc.getSlotControllers (*t) == pc.getSlotControllers (*layeredWith))
                        sv->showNotice ("\"" + t->getName() + "\" is layered with \"" + layeredWith->getName()
                                         + "\" (same controllers). To split the keyboard instead, set KEYS on each card - or drag the bars on the keyboard below.");
                }
            });
        };

        addAndMakeVisible (addInput);
        addInput.setTooltip ("Another audio input: a second mic, a guitar, a synth's line out...");
        addInput.onClick = [this] { view.selectSlot (view.getController().addAudioSlot()); };

        addAndMakeVisible (reset);
        reset.setTooltip ("Start over with Grand Piano, Drums and Mic");
        reset.onClick = [this]
        {
            SafePointer<PracticeView> sv (&view);
            AlertWindow::showAsync (MessageBoxOptions().withIconType (MessageBoxIconType::QuestionIcon)
                                        .withTitle ("Reset Practice?")
                                        .withMessage ("This replaces all the practice sounds with the defaults (Grand Piano, Drums, Mic). "
                                                      "Your projects, recordings and saved takes aren't touched.")
                                        .withButton ("Reset", 1).withButton ("Cancel", 0),
                                    [sv] (int r) { if (r == 1 && sv != nullptr) sv->getController().resetToDefaults(); });
        };
    }

    void paint (Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (1.0f);
        g.setColour (Col::line);
        g.drawRoundedRectangle (r, 8.0f, 1.0f);
        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (11.5f));
        g.drawFittedText ("One controller on two sounds = a layer.\nDifferent KEYS on each = a split.",
                          getLocalBounds().reduced (12).withTrimmedTop (120).withHeight (60), Justification::centredTop, 4);
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (12);
        r.removeFromTop (14);
        addSound.setBounds (r.removeFromTop (40));
        r.removeFromTop (10);
        addInput.setBounds (r.removeFromTop (40));
        reset.setBounds (r.removeFromBottom (24));
    }

private:
    PracticeView& view;
    TextButton addSound { "+ Sound" }, addInput { "+ Audio input" }, reset { "Reset to defaults" };
};

//==============================================================================
/** The splits at a glance: a bar per sound over the keys it plays, the keys lit as
    you play them. Drag a bar's ends to change its range; click keys to hear them. */
class PracticeView::KeyboardMap : public Component,
                                  public SettableTooltipClient
{
public:
    KeyboardMap (PracticeView& v) : view (v)
    {
        setTooltip ("Each bar is a sound's key range - drag its ends to move a split. Click the keys to play.");
    }

    void updateLive()
    {
        std::vector<std::pair<int, juce::uint32>> now;
        for (auto t : view.getController().getSlots())
            if (! PracticeController::isAudioSlot (*t))
                for (auto k : view.getController().getHeldKeys (*t))
                    now.push_back ({ k, t->getColour().getARGB() });

        if (now != lit)
        {
            lit = now;
            repaint();
        }
    }

    void paint (Graphics& g) override
    {
        auto r = getLocalBounds();
        g.setColour (Col::bg1);
        g.fillRect (r);

        auto slots = zoneSlots();
        auto rows = r.removeFromTop (zoneArea);
        const float rowH = slots.isEmpty() ? 0.0f : jmin (13.0f, (float) (rows.getHeight() - 2) / (float) slots.size());

        for (int i = 0; i < slots.size(); ++i)
        {
            auto t = slots[i];
            auto z = PracticeController::getZone (*t);
            if (z == nullptr)
                continue;

            const bool muted = t->isMuted (false);
            auto x0 = keyX (jmax (lowKey, z->getLow())), x1 = keyRight (jmin (highKey, z->getHigh()));
            Rectangle<float> bar (x0, rows.getY() + 1.0f + i * rowH, jmax (2.0f, x1 - x0), rowH - 2.0f);

            g.setColour (t->getColour().withAlpha (muted ? 0.3f : 0.85f));
            g.fillRoundedRectangle (bar, 3.0f);

            if (bar.getWidth() > 60.0f && rowH >= 8.0f)
            {
                g.setColour (Colours::black.withAlpha (0.75f));
                g.setFont (LodeLookAndFeel::font (jmin (10.0f, rowH - 1.0f), true));
                auto label = t->getName();
                if (z->getTranspose() != 0)
                    label << "  " << (z->getTranspose() > 0 ? "+" : "") << z->getTranspose();
                g.drawText (label, bar.reduced (4.0f, 0.0f), Justification::centredLeft, true);
            }
        }

        // keys
        auto keys = r.toFloat();
        keyTop = keys.getY();

        for (int n = lowKey; n <= highKey; ++n)
            if (! isBlackKey (n))
            {
                auto k = Rectangle<float> (keyX (n), keys.getY(), whiteW - 1.0f, keys.getHeight());
                g.setColour (litColour (n).value_or (Colour (0xffe9ebef)));
                g.fillRect (k);
                if (n % 12 == 0)
                {
                    g.setColour (Col::textFaint);
                    g.setFont (LodeLookAndFeel::font (9.0f));
                    g.drawText (noteName (n), k.removeFromBottom (12.0f), Justification::centred);
                }
            }

        for (int n = lowKey; n <= highKey; ++n)
            if (isBlackKey (n))
            {
                auto k = Rectangle<float> (keyX (n), keys.getY(), whiteW * 0.62f, keys.getHeight() * 0.6f);
                g.setColour (litColour (n).value_or (Colour (0xff1b1e24)));
                g.fillRect (k);
            }
    }

    void resized() override
    {
        int whites = 0;
        for (int n = lowKey; n <= highKey; ++n)
            if (! isBlackKey (n))
                ++whites;

        whiteW = (float) getWidth() / (float) jmax (1, whites);
    }

    void mouseMove (const MouseEvent& e) override
    {
        auto hit = hitZone (e.position);
        setMouseCursor (hit.first != nullptr ? MouseCursor::LeftRightResizeCursor : MouseCursor::NormalCursor);
    }

    void mouseDown (const MouseEvent& e) override
    {
        view.takeFocusBack();
        auto hit = hitZone (e.position);
        dragSlot = hit.first;
        dragEdge = hit.second;

        if (dragSlot != nullptr)
        {
            view.selectSlot (dragSlot.get());
            return;
        }

        if (e.position.y >= keyTop)
        {
            playing = noteAt (e.position);
            if (playing >= 0)
                view.playKey (playing, true, jlimit (30, 127, roundToInt (60 + 67 * (e.position.y - keyTop) / jmax (1.0f, getHeight() - keyTop))));
        }
    }

    void mouseDrag (const MouseEvent& e) override
    {
        if (auto t = dragSlot.get())
        {
            if (auto z = PracticeController::getZone (*t))
            {
                auto n = jlimit (0, 127, noteAtX (e.position.x));
                if (dragEdge < 0) z->setRange (jmin (n, z->getHigh()), z->getHigh());
                else              z->setRange (z->getLow(), jmax (n, z->getLow()));
                repaint();
            }
            return;
        }

        auto n = noteAt (e.position);
        if (n != playing)
        {
            if (playing >= 0) view.playKey (playing, false);
            playing = n;
            if (playing >= 0) view.playKey (playing, true);
        }
    }

    void mouseUp (const MouseEvent&) override
    {
        if (dragSlot != nullptr)
            view.refreshCards();

        dragSlot = nullptr;

        if (playing >= 0)
            view.playKey (playing, false);

        playing = -1;
    }

    static constexpr int zoneArea = 52;

private:
    PracticeView& view;
    int lowKey = 21, highKey = 108;     // a full 88
    float whiteW = 10.0f, keyTop = 0.0f;
    std::vector<std::pair<int, juce::uint32>> lit;
    te::SafeSelectable<te::AudioTrack> dragSlot;
    int dragEdge = 0, playing = -1;

    Array<te::AudioTrack*> zoneSlots() const
    {
        Array<te::AudioTrack*> list;
        for (auto t : view.getController().getSlots())
            if (! PracticeController::isAudioSlot (*t))
                list.add (t);
        return list;
    }

    float keyX (int n) const
    {
        int whites = 0;
        for (int k = lowKey; k < n; ++k)
            if (! isBlackKey (k))
                ++whites;

        return isBlackKey (n) ? whites * whiteW - whiteW * 0.31f : whites * whiteW;
    }

    float keyRight (int n) const
    {
        return isBlackKey (n) ? keyX (n) + whiteW * 0.62f : keyX (n) + whiteW;
    }

    int noteAtX (float x) const
    {
        if (x < 0.0f) return lowKey;
        for (int n = lowKey; n <= highKey; ++n)
            if (! isBlackKey (n) && x < keyX (n) + whiteW)
                return n;
        return highKey;
    }

    int noteAt (Point<float> p) const
    {
        if (p.y < keyTop)
            return -1;

        if (p.y < keyTop + (getHeight() - keyTop) * 0.6f)
            for (int n = lowKey; n <= highKey; ++n)
                if (isBlackKey (n) && p.x >= keyX (n) && p.x < keyRight (n))
                    return n;

        return noteAtX (p.x);
    }

    std::pair<te::AudioTrack*, int> hitZone (Point<float> p) const
    {
        if (p.y >= zoneArea)
            return { nullptr, 0 };

        auto slots = zoneSlots();
        if (slots.isEmpty())
            return { nullptr, 0 };

        const float rowH = jmin (13.0f, (float) (zoneArea - 2) / (float) slots.size());
        auto i = (int) ((p.y - 1.0f) / rowH);

        if (! isPositiveAndBelow (i, slots.size()))
            return { nullptr, 0 };

        if (auto z = PracticeController::getZone (*slots[i]))
        {
            auto x0 = keyX (jmax (lowKey, z->getLow())), x1 = keyRight (jmin (highKey, z->getHigh()));
            if (std::abs (p.x - x0) < 7.0f) return { slots[i], -1 };
            if (std::abs (p.x - x1) < 7.0f) return { slots[i], 1 };
        }

        return { nullptr, 0 };
    }

    std::optional<Colour> litColour (int n) const
    {
        for (auto& [k, c] : lit)
            if (k == n)
                return Colour (c).interpolatedWith (Colours::white, isBlackKey (n) ? 0.1f : 0.35f);
        return std::nullopt;
    }
};

//==============================================================================
class PracticeView::MasterStrip : public Component
{
public:
    MasterStrip (PracticeView& v) : view (v)
    {
        addAndMakeVisible (addButton);
        addButton.setTooltip ("Add an effect on everything (reverb on the whole room, a limiter...)");
        addButton.onClick = [this] { showAddMasterEffectMenu (view.session, &addButton); };

        addAndMakeVisible (volume);
        volume.setSliderStyle (Slider::LinearHorizontal);
        volume.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
        volume.setRange (-60.0, 6.0, 0.1);
        volume.setSkewFactorFromMidPoint (-12.0);
        volume.setDoubleClickReturnValue (true, 0.0);
        volume.setTooltip ("Master volume (double-click for 0 dB)");
        volume.onValueChange = [this]
        {
            if (auto mv = view.session.edit_().getMasterVolumePlugin())
                mv->setVolumeDb ((float) volume.getValue());
        };

        rebuild();
    }

    void rebuild()
    {
        buttons.clear();
        auto& edit = view.session.edit_();

        for (auto p : edit.getMasterPluginList())
        {
            if (isPracticeUtilityPlugin (p) || dynamic_cast<te::LevelMeterPlugin*> (p) != nullptr)
                continue;

            auto b = buttons.add (new TextButton (p->getName()));
            b->setColour (TextButton::buttonColourId, p->isEnabled() ? Col::bg3 : Col::bg1);
            b->setTooltip ("Click to edit, right-click to bypass or remove");
            WeakPlugin plugin (p);
            b->onClick = [this, plugin, b]
            {
                if (plugin == nullptr)
                    return;

                if (ModifierKeys::currentModifiers.isPopupMenu())
                    showPluginMenu (plugin);
                else
                    showEditor (*plugin.get(), *b);
            };
            addAndMakeVisible (b);
        }

        if (auto mv = edit.getMasterVolumePlugin())
            volume.setValue (mv->getVolumeDb(), dontSendNotification);

        resized();
        repaint();
    }

    void paint (Graphics& g) override
    {
        g.fillAll (Col::bg2);
        g.setColour (Col::textFaint);
        g.setFont (LodeLookAndFeel::font (10.5f, true));
        g.drawText ("MASTER EFFECTS", 12, 0, 110, getHeight(), Justification::centredLeft);
        g.drawText ("VOLUME", volume.getX() - 56, 0, 52, getHeight(), Justification::centredRight);

        if (buttons.isEmpty())
        {
            g.setFont (LodeLookAndFeel::font (11.5f));
            g.drawText ("None - they'd affect every sound", addButton.getRight() + 10, 0, 260, getHeight(), Justification::centredLeft);
        }
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (8, 5);
        r.removeFromLeft (114);
        volume.setBounds (r.removeFromRight (160));
        r.removeFromRight (64);

        for (auto* b : buttons)
        {
            auto w = jmin (160, (int) GlyphArrangement::getStringWidth (LodeLookAndFeel::font (13.0f), b->getButtonText()) + 28);
            b->setBounds (r.removeFromLeft (w));
            r.removeFromLeft (6);
        }

        addButton.setBounds (r.removeFromLeft (90));
    }

private:
    PracticeView& view;
    OwnedArray<TextButton> buttons;
    TextButton addButton { "+ Effect" };
    Slider volume;

    SafePointer<CallOutBox> callout;

    void showEditor (te::Plugin& p, Component& from)
    {
        if (auto ext = dynamic_cast<te::ExternalPlugin*> (&p))
        {
            ext->showWindowExplicitly();
            return;
        }

        auto editor = std::make_unique<GenericPluginEditor> (p);
        editor->setSize (440, jmin (420, editor->getIdealHeight (440)));
        callout = &CallOutBox::launchAsynchronously (std::move (editor), from.getScreenBounds(), nullptr);
    }

    void showPluginMenu (WeakPlugin p)
    {
        PopupMenu m;
        SafePointer<PracticeView> v (&view);
        m.addItem (p->isEnabled() ? "Bypass" : "Turn back on", [p, v]
        {
            if (p != nullptr) p->setEnabled (! p->isEnabled());
            if (v != nullptr) v->refreshCards();
        });
        m.addItem ("Remove", [p] { if (p != nullptr) p->deleteFromParent(); });
        m.showMenuAsync ({});
    }

public:
    ~MasterStrip() override
    {
        // its editor holds the plugin: close it before the practice edit goes away
        if (callout != nullptr)
            delete callout.getComponent();
    }
};

//==============================================================================
class PracticeView::NoticeBar : public Component,
                                private Timer
{
public:
    NoticeBar()
    {
        addAndMakeVisible (text);
        text.setFont (LodeLookAndFeel::font (13.0f));
        text.setColour (Label::textColourId, Col::text);
        text.setMinimumHorizontalScale (0.7f);

        addAndMakeVisible (close);
        close.onClick = [this] { hide(); };
    }

    std::function<void()> onLayoutChange;

    void show (const String& message, StringArray labels, std::function<void (int)> callback, bool error)
    {
        isError = error;
        text.setText (message, dontSendNotification);
        buttons.clear();

        for (int i = 0; i < labels.size(); ++i)
        {
            auto b = buttons.add (new TextButton (labels[i]));
            b->onClick = [callback, i] { if (callback) callback (i); };
            addAndMakeVisible (b);
        }

        setVisible (true);
        startTimer (labels.isEmpty() ? 9000 : 20000);
        if (onLayoutChange) onLayoutChange();
        resized();
        repaint();
    }

    void hide()
    {
        stopTimer();
        setVisible (false);
        if (onLayoutChange) onLayoutChange();
    }

    void paint (Graphics& g) override
    {
        g.fillAll ((isError ? Col::north : Col::south).withAlpha (0.16f));
        g.setColour (isError ? Col::north : Col::south);
        g.fillRect (0, 0, 3, getHeight());
    }

    void resized() override
    {
        auto r = getLocalBounds().reduced (10, 4);
        close.setBounds (r.removeFromRight (24));
        r.removeFromRight (6);

        for (int i = buttons.size(); --i >= 0;)
        {
            auto* b = buttons[i];
            auto w = (int) GlyphArrangement::getStringWidth (LodeLookAndFeel::font (13.0f), b->getButtonText()) + 30;
            b->setBounds (r.removeFromRight (w));
            r.removeFromRight (6);
        }

        text.setBounds (r);
    }

private:
    Label text;
    TextButton close { "x" };
    OwnedArray<TextButton> buttons;
    bool isError = false;

    void timerCallback() override   { hide(); }
};

//==============================================================================
// PracticeView
//==============================================================================
PracticeView::PracticeView (Session& s) : session (s)
{
    controller = std::make_unique<PracticeController> (session);
    controller->onSlotsChanged = [this] { needsRebuild = true; triggerAsyncUpdate(); };
    controller->onDevicesChanged = [this] { triggerAsyncUpdate(); };

    auto& edit = session.edit_();

    addAndMakeVisible (backButton);
    backButton.setButtonText (String (CharPointer_UTF8 ("\xe2\x86\x90 ")) + "Back to \"" + session.getStashedProjectName() + "\"");
    backButton.setTooltip ("Leave Practice (Ctrl+P). Your practice setup is kept for next time.");
    backButton.onClick = [this] { if (onBack) onBack(); };

    addAndMakeVisible (metronomeButton);
    metronomeButton.setOnColour (Col::yellow);
    metronomeButton.onClick = [this] { toggleMetronome(); };

    tempo = std::make_unique<DragNumber> (20.0, 400.0, 0.1, 1);
    tempo->caption = "BPM";
    tempo->onChange = [this] (double bpm) { session.setTempo (bpm); };
    addAndMakeVisible (*tempo);

    addAndMakeVisible (tapButton);
    tapButton.setTooltip ("Tap the beat a few times (T)");
    tapButton.onClick = [this] { session.tapTempo(); refreshTopBar(); };

    addAndMakeVisible (timeSig);
    for (auto [n, d, id] : std::initializer_list<std::tuple<int, int, int>> {
             { 2, 4, 1 }, { 3, 4, 2 }, { 4, 4, 3 }, { 5, 4, 4 }, { 6, 8, 5 }, { 7, 8, 6 }, { 9, 8, 7 }, { 12, 8, 8 } })
        timeSig.addItem (String (n) + "/" + String (d), id);
    timeSig.setTooltip ("Time signature (the click accents the first beat)");
    timeSig.onChange = [this]
    {
        auto parts = StringArray::fromTokens (timeSig.getText(), "/", {});
        if (parts.size() == 2)
            session.setTimeSignature (parts[0].getIntValue(), parts[1].getIntValue());
        lastBeatShown = -1;
        repaint();
    };

    addAndMakeVisible (clickVolume);
    clickVolume.setSliderStyle (Slider::LinearHorizontal);
    clickVolume.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    clickVolume.setRange (0.2, 1.0, 0.01);
    clickVolume.setTooltip ("Click volume");
    clickVolume.onValueChange = [this] { session.edit_().clickTrackGain = (float) clickVolume.getValue(); };

    addAndMakeVisible (recordButton);
    recordButton.setOnColour (Col::north);
    recordButton.onClick = [this] { toggleRecording(); };

    addAndMakeVisible (recTime);
    recTime.setFont (LodeLookAndFeel::font (13.0f, true));
    recTime.setColour (Label::textColourId, Col::textDim);
    recTime.setTooltip ("Recordings go to " + PracticeController::getRecordingsFolder().getFullPathName());

    addAndMakeVisible (saveButton);
    saveButton.setColour (TextButton::buttonColourId, Col::green.withAlpha (0.35f));
    saveButton.setTooltip ("Turn the last few minutes of what you played - notes and audio inputs - into a new project. "
                           "Lodestone keeps the last 5 minutes in memory; nothing is written to disk until you click this.");
    saveButton.onClick = [this] { showSaveMenu (&saveButton); };

    addAndMakeVisible (keyboardButton);
    keyboardButton.setOnColour (Col::purple);
    keyboardButton.onClick = [this] { if (onToggleKeyboard) onToggleKeyboard(); };

    masterMeter = std::make_unique<LevelMeter> (findMasterMeter (edit), false);
    masterMeter->setTooltip ("What you're hearing");
    addAndMakeVisible (*masterMeter);

    notice = std::make_unique<NoticeBar>();
    notice->onLayoutChange = [this] { resized(); };
    addChildComponent (*notice);

    addAndMakeVisible (cardsViewport);
    cardsViewport.setViewedComponent (&cardsHolder, false);
    cardsViewport.setScrollBarsShown (false, true);

    addCard = std::make_unique<AddCard> (*this);
    cardsHolder.addAndMakeVisible (*addCard);

    keyboardMap = std::make_unique<KeyboardMap> (*this);
    addAndMakeVisible (*keyboardMap);

    masterStrip = std::make_unique<MasterStrip> (*this);
    addAndMakeVisible (*masterStrip);

    chain = std::make_unique<DeviceChainPanel> (session);
    addAndMakeVisible (*chain);

    edit.state.addListener (this);

    rebuildCards();

    if (session.getSelectedTrack() == nullptr || ! PracticeController::isSlot (*session.getSelectedTrack()))
        if (auto first = controller->getSlots().getFirst())
            selectSlot (first);

    refreshTopBar();
    startTimerHz (30);
}

PracticeView::~PracticeView()
{
    stopTimer();
    session.edit_().state.removeListener (this);
    chain.reset();
    cards.clear();
    controller.reset();
}

//==============================================================================
void PracticeView::selectSlot (te::AudioTrack* t)
{
    if (t == nullptr)
        return;

    session.selectTrack (t);
    controller->noteSelected (t);

    for (auto* c : cards)
        c->repaint();

    repaint (0, chain->getY() - 20, getWidth(), 20);
}

te::AudioTrack* PracticeView::getSelectedSlot() const
{
    return session.getSelectedTrack();
}

void PracticeView::playKey (int note, bool on, int velocity)
{
    for (auto& m : session.engine.getDeviceManager().getMidiInDevices())
        if (m->getName() == "Computer Keyboard")
            if (auto v = dynamic_cast<te::VirtualMidiInputDevice*> (m.get()))
            {
                auto msg = on ? MidiMessage::noteOn (1, note, (uint8) velocity) : MidiMessage::noteOff (1, note);
                msg.setTimeStamp (Time::getMillisecondCounterHiRes() * 0.001);
                v->handleIncomingMidiMessage (msg, v->getMPESourceID());
                return;
            }
}

void PracticeView::takeFocusBack()
{
    if (auto* p = getParentComponent())
        if (p->getWantsKeyboardFocus())
            p->grabKeyboardFocus();
}

void PracticeView::setKeyboardActive (bool b)
{
    keyboardButton.setToggleState (b, dontSendNotification);
}

void PracticeView::showNotice (const String& message, StringArray buttons, std::function<void (int)> onButton, bool isError)
{
    if (message.isEmpty())
        return;

    notice->show (message, buttons, onButton, isError);
    session.status (message);
}

//==============================================================================
void PracticeView::toggleMetronome()
{
    controller->setMetronome (! controller->isMetronomeOn());
    refreshTopBar();
}

void PracticeView::toggleRecording()
{
    if (controller->isRecording())
    {
        auto secs = controller->getRecordingSeconds();
        auto f = controller->stopRecording();
        showNotice ("Saved \"" + f.getFileName() + "\" (" + formatTime (secs).upToLastOccurrenceOf (".", false, false) + ")",
                    { "Show in folder" }, [f] (int) { f.revealToUser(); });
    }
    else if (controller->startRecording())
    {
        showNotice ("Recording everything you play (except the click). Press R or the record button again to stop.");
    }
    else
    {
        showNotice ("Couldn't start recording into " + PracticeController::getRecordingsFolder().getFullPathName(), {}, {}, true);
    }

    refreshTopBar();
}

void PracticeView::showSaveMenu (Component* target)
{
    PopupMenu m;
    m.addSectionHeader ("Turn what you just played into a project");

    SafePointer<PracticeView> sv (this);
    struct Choice { const char* label; double seconds; bool phrase; };

    for (auto c : std::initializer_list<Choice> { { "The last thing I played (since I paused)", 300.0, true },
                                                  { "The last 30 seconds", 30.0, false },
                                                  { "The last 2 minutes", 120.0, false },
                                                  { "The last 5 minutes", 300.0, false } })
    {
        m.addItem (c.label, [sv, c]
        {
            if (sv == nullptr)
                return;

            auto r = sv->controller->saveWhatIPlayed (c.seconds, c.phrase);

            if (! r.ok)
            {
                sv->showNotice (r.message, {}, {}, true);
                return;
            }

            sv->showNotice (r.message, { "Open it", "Show in folder" }, [sv, f = r.file] (int b)
            {
                if (b == 0)
                {
                    if (sv != nullptr && sv->onOpenProject)
                        sv->onOpenProject (f);
                }
                else
                {
                    f.getParentDirectory().revealToUser();
                }
            });
        });
    }

    m.addSeparator();
    m.addItem ("Open the practice recordings folder", [] { auto d = PracticeController::getRecordingsFolder(); d.createDirectory(); d.revealToUser(); });
    m.showMenuAsync (PopupMenu::Options().withTargetComponent (target));
}

//==============================================================================
void PracticeView::rebuildCards()
{
    needsRebuild = false;
    auto viewPos = cardsViewport.getViewPosition();

    cards.clear();

    for (auto t : controller->getSlots())
    {
        SlotCard* card = PracticeController::isAudioSlot (*t) ? (SlotCard*) new AudioCard (*this, *t)
                                                              : (SlotCard*) new InstrumentCard (*this, *t);
        cards.add (card);
        cardsHolder.addAndMakeVisible (card);
    }

    layoutCards();
    cardsViewport.setViewPosition (viewPos);

    if (masterStrip != nullptr)
        masterStrip->rebuild();

    if (keyboardMap != nullptr)
        keyboardMap->repaint();
}

void PracticeView::refreshCards()
{
    for (auto* c : cards)
        c->refresh();

    if (masterStrip != nullptr)
        masterStrip->rebuild();

    if (keyboardMap != nullptr)
        keyboardMap->repaint();
}

void PracticeView::layoutCards()
{
    const int gap = 10;
    int x = 0;

    for (auto* c : cards)
    {
        c->setBounds (x, 0, cardWidth, cardHeight);
        x += cardWidth + gap;
    }

    addCard->setBounds (x, 0, addCardWidth, cardHeight);
    x += addCardWidth;

    cardsHolder.setSize (jmax (x, cardsViewport.getMaximumVisibleWidth()), cardHeight);
}

void PracticeView::refreshTopBar()
{
    auto& edit = session.edit_();
    metronomeButton.setToggleState (controller->isMetronomeOn(), dontSendNotification);
    recordButton.setToggleState (controller->isRecording(), dontSendNotification);
    tempo->setValue (session.getTempo(), false);
    clickVolume.setValue (edit.getClickTrackVolume(), dontSendNotification);

    if (auto ts = edit.tempoSequence.getTimeSig (0))
        timeSig.setText (String (ts->numerator.get()) + "/" + String (ts->denominator.get()), dontSendNotification);
}

void PracticeView::timerCallback()
{
    for (auto* c : cards)
        c->updateLive();

    keyboardMap->updateLive();

    if (metronomeButton.getToggleState() != controller->isMetronomeOn())
        refreshTopBar();

    if (std::abs (tempo->getValue() - session.getTempo()) > 0.01)
        tempo->setValue (session.getTempo(), false);

    // beat lights
    int beat = -1;
    if (controller->isMetronomeOn())
    {
        auto& ts = session.edit_().tempoSequence.getTimeSigAt (te::TimePosition());
        const int beatsInBar = jmax (1, ts.numerator.get());
        const double beatLen = 4.0 / jmax (1, ts.denominator.get());     // in quarter notes
        beat = (int) std::floor (controller->getBeat() / beatLen + 1.0e-6) % beatsInBar;
    }

    if (beat != lastBeatShown)
    {
        lastBeatShown = beat;
        repaint (beatArea.expanded (4));
    }

    if (controller->isRecording())
    {
        recTime.setText (formatTime (controller->getRecordingSeconds()).upToLastOccurrenceOf (".", false, false), dontSendNotification);
        recTime.setColour (Label::textColourId, Col::north);
    }
    else if (recTime.getText() != "REC")
    {
        recTime.setText ("REC", dontSendNotification);
        recTime.setColour (Label::textColourId, Col::textFaint);
    }

    if (recordButton.getToggleState() != controller->isRecording())
        recordButton.setToggleState (controller->isRecording(), dontSendNotification);
}

void PracticeView::handleAsyncUpdate()
{
    if (needsRebuild)
        rebuildCards();
    else
        refreshCards();

    repaint();      // captions name the selected sound
}

void PracticeView::valueTreeChildAdded (ValueTree&, ValueTree& c)
{
    if (c.hasType (te::IDs::TRACK))
        needsRebuild = true;

    if (c.hasType (te::IDs::TRACK) || c.hasType (te::IDs::PLUGIN))
        triggerAsyncUpdate();
}

void PracticeView::valueTreeChildRemoved (ValueTree& p, ValueTree& c, int)
{
    valueTreeChildAdded (p, c);
}

void PracticeView::valueTreeChildOrderChanged (ValueTree&, int, int)
{
    needsRebuild = true;
    triggerAsyncUpdate();
}

void PracticeView::valueTreePropertyChanged (ValueTree& v, const Identifier&)
{
    if (v.hasType (te::IDs::TRACK) || v.hasType (te::IDs::PLUGIN))
        triggerAsyncUpdate();
}

//==============================================================================
void PracticeView::paint (Graphics& g)
{
    g.fillAll (Col::bg1);

    auto top = getLocalBounds().removeFromTop (60);
    g.setColour (Col::bg2);
    g.fillRect (top);
    g.setColour (Col::bg0);
    g.fillRect (top.removeFromBottom (1));

    // title
    auto title = Rectangle<int> (backButton.getRight() + 16, 8, 170, 44);
    g.setColour (Col::text);
    g.setFont (LodeLookAndFeel::font (19.0f, true));
    g.drawText ("Practice", title.removeFromTop (24), Justification::centredLeft);
    g.setColour (Col::textFaint);
    g.setFont (LodeLookAndFeel::font (11.0f));
    g.drawText ("no tracks, just play", title, Justification::centredLeft);

    // beat lights
    auto& ts = session.edit_().tempoSequence.getTimeSigAt (te::TimePosition());
    const int beats = jlimit (1, 16, ts.numerator.get());
    auto area = beatArea.toFloat();
    const float d = jmin (14.0f, area.getWidth() / beats - 3.0f);

    for (int i = 0; i < beats; ++i)
    {
        auto dot = Rectangle<float> (area.getX() + i * (d + 3.0f), area.getCentreY() - d / 2.0f, d, d);
        const bool on = i == lastBeatShown;
        g.setColour (on ? (i == 0 ? Col::north : Col::yellow) : Col::bg4);
        g.fillEllipse (dot);
    }

    g.setColour (Col::textFaint);
    g.setFont (LodeLookAndFeel::font (9.5f, true));
    g.drawText ("CLICK", clickVolume.getX(), clickVolume.getY() - 2, clickVolume.getWidth(), 12, Justification::centred);

    // section captions
    g.setColour (Col::textFaint);
    g.setFont (LodeLookAndFeel::font (10.5f, true));
    g.drawText ("SOUNDS", cardsViewport.getX(), cardsViewport.getY() - 18, 200, 16, Justification::centredLeft);
    g.drawText ("KEYBOARD", keyboardMap->getX(), keyboardMap->getY() - 18, 200, 16, Justification::centredLeft);

    if (auto t = getSelectedSlot())
        g.drawText ("SELECTED: " + t->getName().toUpperCase() + "  -  INSTRUMENT AND EFFECTS",
                    chain->getX(), chain->getY() - 18, 600, 16, Justification::centredLeft);
}

void PracticeView::resized()
{
    auto r = getLocalBounds();
    auto top = r.removeFromTop (60).reduced (10, 9);

    backButton.setBounds (top.removeFromLeft (jmin (260, (int) GlyphArrangement::getStringWidth (LodeLookAndFeel::font (13.0f), backButton.getButtonText()) + 36)));
    top.removeFromLeft (16 + 170);

    metronomeButton.setBounds (top.removeFromLeft (38));
    top.removeFromLeft (6);
    tempo->setBounds (top.removeFromLeft (76));
    top.removeFromLeft (4);
    tapButton.setBounds (top.removeFromLeft (44).reduced (0, 4));
    top.removeFromLeft (6);
    timeSig.setBounds (top.removeFromLeft (66).reduced (0, 4));
    top.removeFromLeft (8);
    clickVolume.setBounds (top.removeFromLeft (80));
    top.removeFromLeft (10);
    beatArea = top.removeFromLeft (100);

    masterMeter->setBounds (top.removeFromRight (120).reduced (0, 12));
    top.removeFromRight (10);
    keyboardButton.setBounds (top.removeFromRight (38));
    top.removeFromRight (14);
    saveButton.setBounds (top.removeFromRight (160));
    top.removeFromRight (10);
    recTime.setBounds (top.removeFromRight (54));
    recordButton.setBounds (top.removeFromRight (38));

    if (notice->isVisible())
        notice->setBounds (r.removeFromTop (36));

    r.reduce (12, 0);
    r.removeFromTop (22);
    cardsViewport.setBounds (r.removeFromTop (cardHeight + cardsViewport.getScrollBarThickness()));
    layoutCards();

    r.removeFromTop (22);
    keyboardMap->setBounds (r.removeFromTop (KeyboardMap::zoneArea + 58));

    auto full = getLocalBounds();
    masterStrip->setBounds (full.removeFromBottom (36));

    r.removeFromBottom (36);
    r.removeFromTop (24);
    chain->setBounds (r.withX (0).withWidth (getWidth()));
}

} // namespace lode
