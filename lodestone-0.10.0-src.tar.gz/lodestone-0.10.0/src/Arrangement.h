/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    The arrangement (timeline) view: ruler, track headers, clip lanes.
*/
#pragma once

#include "Session.h"
#include "Theme.h"

namespace lode
{

class ArrangementView;

//==============================================================================
/** Maps beats <-> pixels for the timeline (shared by ruler, lanes, editors). */
struct Timeline
{
    double pixelsPerBeat = 32.0;
    double scrollBeat = 0.0;

    float beatToX (double beat) const       { return (float) ((beat - scrollBeat) * pixelsPerBeat); }
    double xToBeat (double x) const         { return x / pixelsPerBeat + scrollBeat; }

    /** A grid step that keeps lines a sensible distance apart. */
    double gridStepFor (double minPixels, double beatsPerBar) const;
};

//==============================================================================
class ClipComponent : public juce::Component,
                      public juce::SettableTooltipClient
{
public:
    ClipComponent (ArrangementView&, te::Clip::Ptr);
    ~ClipComponent() override;

    te::Clip& getClip()     { return *clip; }
    te::Clip::Ptr clip;

    void paint (juce::Graphics&) override;
    void mouseMove (const juce::MouseEvent&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;

private:
    ArrangementView& owner;
    std::unique_ptr<te::SmartThumbnail> thumbnail;

    enum class DragMode { none, move, trimStart, trimEnd, loopEnd };
    DragMode dragMode = DragMode::none;

    struct DragStart
    {
        te::Clip::Ptr clip;
        double startBeat, endBeat, offsetBeats;
        int trackIndex;
    };
    std::vector<DragStart> dragStarts;
    bool duplicated = false;
    int trackDelta = 0;

    DragMode modeForPosition (juce::Point<int>) const;
    void drawMidi (juce::Graphics&, juce::Rectangle<int>);
    void drawAudio (juce::Graphics&, juce::Rectangle<int>);
    void showMenu();
};

//==============================================================================
class TrackHeader : public juce::Component,
                    private juce::Timer
{
public:
    TrackHeader (ArrangementView&, te::AudioTrack::Ptr);
    ~TrackHeader() override;

    te::AudioTrack::Ptr track;

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseMove (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void refresh();

private:
    ArrangementView& owner;
    juce::Label nameLabel;
    juce::TextButton muteButton { "M" }, soloButton { "S" }, armButton { "R" };
    juce::TextButton inputButton;
    juce::Slider volume;
    float midiActivity = 0.0f;
    bool resizing = false, reordering = false;
    int dragStartHeight = 0;

    void timerCallback() override;
    void showMenu();
    void showInputMenu();
};

//==============================================================================
class TimeRuler : public juce::Component
{
public:
    TimeRuler (ArrangementView&);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;

private:
    ArrangementView& owner;
    bool draggingLoop = false;
    double loopDragStart = 0.0;
};

//==============================================================================
class LaneArea : public juce::Component
{
public:
    LaneArea (ArrangementView&);

    void paint (juce::Graphics&) override;
    void paintOverChildren (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;

    juce::Rectangle<int> rubberBand;
    float playheadX = -1.0f;

private:
    ArrangementView& owner;
    juce::Point<int> dragOrigin;
};

//==============================================================================
class ArrangementView : public juce::Component,
                        public juce::DragAndDropTarget,
                        public juce::FileDragAndDropTarget,
                        private juce::ChangeListener,
                        private juce::ValueTree::Listener,
                        private juce::AsyncUpdater,
                        private juce::Timer,
                        private juce::ScrollBar::Listener
{
public:
    ArrangementView (Session&);
    ~ArrangementView() override;

    Session& session;
    te::Edit& edit;
    ViewState& view;
    Timeline timeline;

    std::function<void (te::Clip*)> onOpenClipEditor;
    std::function<void (te::AudioTrack*)> onOpenInstrument;
    std::function<void (const juce::File&)> onOpenProjectFile;

    void resized() override;
    void paint (juce::Graphics&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void mouseMagnify (const juce::MouseEvent&, float scaleFactor) override;

    // layout helpers
    struct Row { te::AudioTrack::Ptr track; int y = 0, height = 0; };
    const std::vector<Row>& getRows() const     { return rows; }
    int trackIndexAtY (int laneY) const;
    te::AudioTrack* trackAtY (int laneY) const;
    int rowYForTrack (te::Track*) const;
    int getTrackHeight (te::Track&) const;
    void setTrackHeight (te::Track&, int);

    double snap (double beat) const;
    double snapDivision() const;
    double beatsPerBar() const                  { return quarterNotesPerBar (edit); }

    void zoomBy (double factor, double anchorBeat);
    void scrollToBeat (double beat);
    void zoomToFit();
    void layoutClips();
    void rebuildAll();

    LaneArea& getLanes()                        { return lanes; }

    // DnD
    bool isInterestedInDragSource (const SourceDetails&) override;
    void itemDropped (const SourceDetails&) override;
    void itemDragMove (const SourceDetails&) override;
    void itemDragExit (const SourceDetails&) override;
    bool isInterestedInFileDrag (const juce::StringArray&) override;
    void filesDropped (const juce::StringArray&, int x, int y) override;

    void handleDrop (const juce::String& description, juce::Point<int> posInThis);
    void addFilesAt (const juce::StringArray& files, te::AudioTrack* track, double beat);

    static constexpr int headerWidth = 236, rulerHeight = 30, scrollbarSize = 12;

    bool isDraggingClips = false;

private:
    friend class LaneArea;
    friend class ClipComponent;
    friend class TrackHeader;
    friend class TimeRuler;

    TimeRuler ruler { *this };
    LaneArea lanes { *this };
    juce::Component headerHolder;
    juce::OwnedArray<TrackHeader> headers;
    juce::OwnedArray<ClipComponent> clipComps;
    juce::ScrollBar hScroll { false }, vScroll { true };
    juce::TextButton addTrackButton { "+ Track" };
    std::vector<Row> rows;
    int dropHighlightY = -1;
    bool needsRebuild = true, needsLayout = false;
    bool followPlayhead = true;

    void buildRows();
    void updateScrollBars();
    void showAddTrackMenu();

    void changeListenerCallback (juce::ChangeBroadcaster*) override;
    void valueTreePropertyChanged (juce::ValueTree&, const juce::Identifier&) override;
    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override;
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override;
    void valueTreeChildOrderChanged (juce::ValueTree&, int, int) override;
    void handleAsyncUpdate() override;
    void timerCallback() override;
    void scrollBarMoved (juce::ScrollBar*, double) override;
};

//==============================================================================
/** Shared clip editing operations (used by keyboard shortcuts and menus). */
namespace ClipActions
{
    void deleteSelected (Session&);
    void duplicateSelected (Session&);
    void splitSelectedAtPlayhead (Session&);
    void copySelected (Session&);
    void cutSelected (Session&);
    void paste (Session&);
    void selectAll (Session&);
    void nudgeSelected (Session&, double beats);
    void setLoopToSelection (Session&);
    void quantizeSelected (Session&, double division, float strength);
    void toggleMuteSelected (Session&);
    void renameSelected (Session&);
}

} // namespace lode
