/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Session: owns the current Edit and everything about "the open project" -
    files, tracks/instruments helpers, view state, MIDI input routing and
    autosave.
*/
#pragma once

#include "Utils.h"

namespace lode
{

class DrumMachinePlugin;
class SoundFontPlugin;

//==============================================================================
/** What instrument to put on a track. */
struct InstrumentSpec
{
    enum class Type { none, drums, soundfont, synth, sampler, external };

    Type type = Type::none;
    int bank = 0, program = 0;              // soundfont
    juce::String preset;                    // synth preset name
    juce::File file;                        // drum kit folder, sampler sample or sf2
    int rootNote = 60;                      // sampler
    juce::PluginDescription description;    // external

    static InstrumentSpec gm (int program, int bank = 0)    { InstrumentSpec s; s.type = Type::soundfont; s.program = program; s.bank = bank; return s; }
    static InstrumentSpec gmDrums (int kit = 0)              { return gm (kit, 128); }
    static InstrumentSpec drums (juce::File kitDir = {})     { InstrumentSpec s; s.type = Type::drums; s.file = kitDir; return s; }
    static InstrumentSpec synth (juce::String preset)        { InstrumentSpec s; s.type = Type::synth; s.preset = preset; return s; }
    static InstrumentSpec sampler (juce::File f, int root)   { InstrumentSpec s; s.type = Type::sampler; s.file = f; s.rootNote = root; return s; }
    static InstrumentSpec external (const juce::PluginDescription& d) { InstrumentSpec s; s.type = Type::external; s.description = d; return s; }
};

//==============================================================================
namespace SynthPresets
{
    juce::StringArray getNames();
    void apply (te::Plugin& fourOsc, const juce::String& presetName);
}

//==============================================================================
/** Per-project view settings, saved inside the project file. */
struct ViewState
{
    ViewState (te::Edit&);

    juce::ValueTree state;
    juce::CachedValue<double> pixelsPerBeat, scrollBeat, scrollY;
    juce::CachedValue<bool> snapOn;
    juce::CachedValue<double> snapDivision;     // in beats (0.25 = 1/16 note)
    juce::CachedValue<int> keyRoot;             // 0 = C
    juce::CachedValue<juce::String> scaleName;  // "Major", "Minor", ...
    juce::CachedValue<bool> scaleLock;
    juce::CachedValue<int> bottomPanelHeight;
    juce::CachedValue<int> defaultTrackHeight;
};

//==============================================================================
/** Decides which track each MIDI controller plays.

    Every physical MIDI input is either in "follow" mode (it plays whichever
    instrument track is selected - like GarageBand) or pinned to one track
    (e.g. the MPD218 always drives the Drums track while the keyboard follows
    the selection). Any number of controllers can play at once. */
class InputRouter
{
public:
    InputRouter (te::Engine&);

    void attachToEdit (te::Edit*);
    void enableAllDevices();
    void enableMidiDevices();

    struct DeviceInfo
    {
        juce::String id, name;
        bool isMidi = true;
        bool follows = true;
        te::AudioTrack* pinnedTrack = nullptr;
    };

    juce::Array<DeviceInfo> getMidiDevices();
    juce::Array<DeviceInfo> getAudioDevices();

    /** Pins a device to a track (or back to "follow selection" if track == nullptr). */
    void pinDevice (const juce::String& deviceID, te::AudioTrack* track);
    void setFollow (const juce::String& deviceID, bool follow);
    bool isFollowing (const juce::String& deviceID) const;

    /** Routes all following MIDI inputs to this track. */
    void selectedTrackChanged (te::AudioTrack*);

    /** Audio input assignment for audio tracks. */
    void setAudioInput (te::AudioTrack&, const juce::String& deviceID);   // empty = none
    juce::String getAudioInput (te::AudioTrack&);
    void setAudioMonitoring (te::AudioTrack&, bool);
    bool getAudioMonitoring (te::AudioTrack&);

    juce::StringArray getDevicesTargeting (te::AudioTrack&, bool midi);
    void armTrack (te::AudioTrack&, bool);
    bool isTrackArmed (te::AudioTrack&);

    te::AudioTrack* getFollowTrack() const      { return followTrack.get(); }

private:
    te::Engine& engine;
    te::Edit* edit = nullptr;
    te::SafeSelectable<te::AudioTrack> followTrack;

    te::InputDeviceInstance* findInstance (const juce::String& deviceID);
    juce::PropertiesFile& props();
};

//==============================================================================
class Session : public juce::ChangeBroadcaster,
                private juce::Timer,
                private juce::ChangeListener
{
public:
    Session (te::Engine&);
    ~Session() override;

    te::Engine& engine;

    te::Edit* getEdit() const                       { return edit.get(); }
    te::Edit& edit_()                               { return *edit; }
    te::SelectionManager& getSelectionManager()     { return selectionManager; }
    ViewState& getView()                            { return *view; }
    InputRouter& getInputRouter()                   { return inputRouter; }

    //==============================================================================
    void newProject (bool withStarterTracks = true);
    bool openProject (const juce::File&);
    bool save();
    bool saveAs (const juce::File& newFile);
    juce::File getProjectFile() const               { return projectFile; }
    juce::String getProjectName() const;
    bool isUntitled() const                         { return untitled; }
    bool hasUnsavedChanges() const;
    juce::StringArray getRecentFiles();
    void addRecentFile (const juce::File&);

    /** Replaces the current edit with one built elsewhere (e.g. an importer). */
    void adoptEdit (std::unique_ptr<te::Edit>, const juce::File& projectFile, bool untitled);

    //==============================================================================
    /** Practice mode swaps in a separate Edit that's only for playing: its tracks are
        the "sounds" your controllers play, and it's saved on its own. The project
        stays loaded in the background (undo history and all) and comes straight back
        when you leave. */
    bool isPracticeMode() const                     { return stash != nullptr; }
    bool enterPracticeMode();
    void leavePracticeMode();
    static juce::File getPracticeFile();
    juce::String getStashedProjectName() const;
    bool stashedProjectHasUnsavedChanges() const;
    bool stashedProjectIsUntitled() const;
    bool saveStashedProject();
    void savePracticeSetup();

    /** Routes controllers that appeared since the selection last changed. Cheap: call it often. */
    void refreshInputRouting();
    std::unique_ptr<te::Edit> createBlankEdit (const juce::File& file);
    juce::File createUntitledProjectFile (const juce::String& baseName = "Untitled");

    //==============================================================================
    te::AudioTrack* addTrack (TrackKind, const juce::String& name = {}, te::Track* after = nullptr);
    te::AudioTrack* addTrackWithInstrument (const InstrumentSpec&, const juce::String& name = {}, te::Track* after = nullptr);
    te::Plugin* setInstrument (te::AudioTrack&, const InstrumentSpec&);
    static te::Plugin* getInstrument (te::AudioTrack&);
    static DrumMachinePlugin* getDrumMachine (te::AudioTrack&);
    static SoundFontPlugin* getSoundFont (te::AudioTrack&);
    void deleteTrack (te::AudioTrack&);
    te::AudioTrack* duplicateTrack (te::AudioTrack&);
    juce::String makeUniqueTrackName (const juce::String& base);
    juce::Colour nextTrackColour();

    te::AudioTrack* getSelectedTrack();
    void selectTrack (te::AudioTrack*);
    te::Clip* getSelectedClip();
    juce::Array<te::Clip*> getSelectedClips();

    te::MidiClip* createMidiClip (te::AudioTrack&, double startBeat, double lengthBeats, bool select = true);
    te::WaveAudioClip* addAudioFile (te::AudioTrack&, const juce::File&, double startBeat);

    /** Plugins (effects) */
    te::Plugin::Ptr createPlugin (const juce::String& xmlType, const juce::PluginDescription& = {});
    te::Plugin::Ptr insertEffect (te::AudioTrack&, te::Plugin::Ptr, int index = -1);
    static int getFirstEffectIndex (te::AudioTrack&);
    static int getVolumePluginIndex (te::AudioTrack&);
    static int getInstrumentInsertIndex (te::AudioTrack&);   // after any key-zone plugins

    //==============================================================================
    // Transport
    void togglePlay();
    void stop();
    void toggleRecord();
    void goToStart();
    void setTempo (double bpm);
    double getTempo();
    void setTimeSignature (int num, int den);
    void tapTempo();
    double getPlayheadBeat();
    void setPlayheadBeat (double);

    //==============================================================================
    std::function<void (const juce::String&)> onStatusMessage;

    /** Called just before the current Edit is destroyed/replaced, so UI that
        references it can be torn down first. */
    std::function<void()> onBeforeEditReplaced;
    void status (const juce::String& s)             { if (onStatusMessage) onStatusMessage (s); }

private:
    std::unique_ptr<te::Edit> edit;
    te::SelectionManager selectionManager { engine };
    std::unique_ptr<ViewState> view;
    InputRouter inputRouter;
    juce::File projectFile;
    bool untitled = true;
    juce::Array<double> tapTimes;
    int colourCounter = 0;

    struct Stash
    {
        std::unique_ptr<te::Edit> edit;
        juce::File file;
        bool untitled = true;
    };

    std::unique_ptr<Stash> stash;
    std::map<juce::String, te::InputDevice::MonitorMode> savedMonitorModes;

    void releaseCurrentEdit();
    void installEdit (std::unique_ptr<te::Edit>, const juce::File&, bool untitled);
    void restoreMonitorModes();
    void editReplaced();
    void addStarterTracks();
    void timerCallback() override;          // autosave
    void changeListenerCallback (juce::ChangeBroadcaster*) override;   // selection
    juce::File getAutosaveFile() const;
};

} // namespace lode
