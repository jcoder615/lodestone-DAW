/*
    Lodestone - a friendly open-source DAW for Linux
    Copyright (C) 2026 Lodestone contributors
    SPDX-License-Identifier: AGPL-3.0-or-later
*/
#pragma once

#include "Common.h"

namespace lode
{
using namespace juce;

//==============================================================================
namespace Col
{
    inline const Colour bg0      { 0xff101216 };
    inline const Colour bg1      { 0xff16191f };
    inline const Colour bg2      { 0xff1d2129 };
    inline const Colour bg3      { 0xff262b35 };
    inline const Colour bg4      { 0xff313744 };
    inline const Colour line     { 0xff3a4150 };
    inline const Colour text     { 0xffe8eaef };
    inline const Colour textDim  { 0xff9ca3b0 };
    inline const Colour textFaint{ 0xff687080 };
    inline const Colour north    { 0xffff5a4f };   // the magnet's red pole
    inline const Colour south    { 0xff4aa3ff };   // ...and its blue one
    inline const Colour green    { 0xff3ecf8e };
    inline const Colour yellow   { 0xffffc94a };
    inline const Colour purple   { 0xffb48cff };
    inline const Colour orange   { 0xffff9f43 };

    inline Colour trackPalette (int i)
    {
        static const uint32 cols[] = { 0xffff6b5e, 0xffff9f43, 0xffffcf4a, 0xff9be15d, 0xff3ecf8e,
                                       0xff2ec4c4, 0xff4aa3ff, 0xff6c7bff, 0xffa77bff, 0xffe36bd8,
                                       0xffff7aa2, 0xffc9b18f };
        return Colour (cols[(size_t) (std::abs (i) % (int) std::size (cols))]);
    }
}

//==============================================================================
inline te::BeatPosition B (double b)        { return te::BeatPosition::fromBeats (b); }
inline te::BeatDuration BD (double b)       { return te::BeatDuration::fromBeats (b); }
inline te::TimePosition T (double s)        { return te::TimePosition::fromSeconds (s); }
inline te::TimeDuration TD (double s)       { return te::TimeDuration::fromSeconds (s); }

inline double timeToBeat (const te::Edit& e, te::TimePosition t)   { return e.tempoSequence.toBeats (t).inBeats(); }
inline te::TimePosition beatToTime (const te::Edit& e, double b)   { return e.tempoSequence.toTime (B (b)); }

inline double clipStartBeat (const te::Clip& c)         { return c.getStartBeat().inBeats(); }
inline double clipEndBeat (const te::Clip& c)           { return c.getEndBeat().inBeats(); }
inline double clipContentStartBeat (const te::Clip& c)  { return c.getContentStartBeat().inBeats(); }

inline int beatsPerBar (const te::Edit& e)
{
    auto& ts = e.tempoSequence.getTimeSigAt (te::TimePosition());
    return juce::jmax (1, (int) std::round (ts.numerator.get() * 4.0 / juce::jmax (1, ts.denominator.get())));
}

inline double quarterNotesPerBar (const te::Edit& e)
{
    auto& ts = e.tempoSequence.getTimeSigAt (te::TimePosition());
    return ts.numerator.get() * 4.0 / juce::jmax (1, ts.denominator.get());
}

inline double snapBeat (double beat, double division)
{
    if (division <= 0.0)
        return beat;

    return std::round (beat / division) * division;
}

inline double floorBeat (double beat, double division)
{
    if (division <= 0.0)
        return beat;

    return std::floor (beat / division + 1.0e-9) * division;
}

//==============================================================================
enum class TrackKind { instrument, drums, audio };

inline const Identifier kindProp ("lodeKind");

inline TrackKind getTrackKind (const te::Track& t)
{
    auto k = t.state.getProperty (kindProp).toString();

    if (k == "drums")   return TrackKind::drums;
    if (k == "audio")   return TrackKind::audio;
    return TrackKind::instrument;
}

inline void setTrackKind (te::Track& t, TrackKind k)
{
    t.state.setProperty (kindProp, k == TrackKind::drums ? "drums" : (k == TrackKind::audio ? "audio" : "instrument"), nullptr);
}

inline juce::Array<te::AudioTrack*> getUserTracks (te::Edit& e)
{
    return te::getAudioTracks (e);
}

//==============================================================================
inline String noteName (int note, bool withOctave = true)
{
    static const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    String s (names[((note % 12) + 12) % 12]);

    if (withOctave)
        s << (note / 12 - 1);

    return s;
}

inline bool isBlackKey (int note)
{
    auto n = ((note % 12) + 12) % 12;
    return n == 1 || n == 3 || n == 6 || n == 8 || n == 10;
}

inline String formatBarsBeats (double beat, int bpb)
{
    if (beat < 0) beat = 0;
    auto bar = (int) std::floor (beat / bpb);
    auto inBar = beat - bar * bpb;
    auto b = (int) std::floor (inBar);
    auto ticks = (int) std::floor ((inBar - b) * 960.0 + 0.5);
    if (ticks >= 960) { ticks = 0; ++b; }
    return String (bar + 1).paddedLeft ('0', 3) + "." + String (b + 1) + "." + String (ticks).paddedLeft ('0', 3);
}

inline String formatTime (double seconds)
{
    if (seconds < 0) seconds = 0;
    auto mins = (int) (seconds / 60.0);
    auto secs = seconds - mins * 60;
    return String (mins) + ":" + String (secs, 2).paddedLeft ('0', 5);
}

//==============================================================================
/** Where Lodestone keeps its shipped data (kits, importers, presets). */
inline File getDataDir()
{
    auto exe = File::getSpecialLocation (File::currentExecutableFile);

    // Installed layout: /usr/bin/lodestone + /usr/share/lodestone
    auto installed = exe.getParentDirectory().getParentDirectory().getChildFile ("share/lodestone");
    if (installed.isDirectory())
        return installed;

    // Development layout: build/Lodestone_artefacts/Release/lodestone -> ../../../resources
    for (auto d = exe.getParentDirectory(); d.getParentDirectory() != d; d = d.getParentDirectory())
        if (d.getChildFile ("resources/kits").isDirectory())
            return d.getChildFile ("resources");

    return File ("/usr/share/lodestone");
}

inline File getImporterDir()
{
    auto exe = File::getSpecialLocation (File::currentExecutableFile);
    auto installed = exe.getParentDirectory().getParentDirectory().getChildFile ("lib/lodestone/importers");
    if (installed.isDirectory())
        return installed;

    for (auto d = exe.getParentDirectory(); d.getParentDirectory() != d; d = d.getParentDirectory())
        if (d.getChildFile ("importers/lodestone_import").isDirectory())
            return d.getChildFile ("importers");

    return File ("/usr/lib/lodestone/importers");
}

inline File getUserDataDir()
{
    auto d = File::getSpecialLocation (File::userHomeDirectory).getChildFile (".local/share/lodestone");
    d.createDirectory();
    return d;
}

inline File getDefaultProjectsDir()
{
    auto music = File::getSpecialLocation (File::userMusicDirectory);
    if (! music.isDirectory())
        music = File::getSpecialLocation (File::userHomeDirectory);

    auto d = music.getChildFile ("Lodestone");
    d.createDirectory();
    return d;
}

inline String projectExtension()        { return ".lodestone"; }

//==============================================================================
/** True when running without a user (lodestone --render): alerts go to stderr. */
inline bool& headlessMode()     { static bool b = false; return b; }

/** A non-blocking message box (never spins a modal loop). */
inline void alert (MessageBoxIconType icon, const String& title, const String& message, const String& button = "OK")
{
    if (headlessMode())
    {
        std::cerr << title << ": " << message << std::endl;
        return;
    }

    AlertWindow::showAsync (MessageBoxOptions().withIconType (icon).withTitle (title)
                                .withMessage (message).withButton (button, 0),
                            [] (int) {});
}

} // namespace lode
