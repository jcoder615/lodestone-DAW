/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Clip editors: piano roll, drum step-sequencer and audio clip editor.
*/
#pragma once

#include "Session.h"
#include "Theme.h"
#include "MusicTheory.h"

namespace lode
{

//==============================================================================
class PianoRollEditor : public juce::Component,
                        private juce::ValueTree::Listener,
                        private juce::AsyncUpdater,
                        private juce::Timer,
                        private juce::ScrollBar::Listener
{
public:
    PianoRollEditor (Session&, te::MidiClip&);
    ~PianoRollEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

    te::MidiClip& getClip()     { return *clip; }

    // coordinate helpers (grid-local)
    float beatToX (double absBeat) const    { return (float) ((absBeat - scrollBeat) * pixelsPerBeat); }
    double xToBeat (float x) const          { return x / pixelsPerBeat + scrollBeat; }
    float noteToY (int note) const          { return (float) ((topNote - note) * noteHeight); }
    int yToNote (float y) const             { return topNote - (int) std::floor (y / noteHeight); }

    double contentStart() const;
    double snapDiv() const;
    double snap (double beat) const;
    const Theory::Scale& scale() const;

    juce::Array<te::MidiNote*> getNotes() const;
    bool isSelected (te::MidiNote* n) const        { return selection.contains (n); }
    void selectOnly (te::MidiNote*);
    void deleteSelected();
    void transposeSelected (int semitones, bool inScale);
    void nudgeSelected (double beats);
    void duplicateSelected();
    void quantize (float strength);
    void humanize();
    void legato();
    void arpeggiate();
    void previewNote (int note, int velocity = 100);

    Session& session;
    te::MidiClip::Ptr clip;
    ViewState& view;

    double pixelsPerBeat = 64.0, scrollBeat = 0.0;
    float noteHeight = 14.0f;
    int topNote = 84;
    double lastNoteLength = 0.25;
    int newVelocity = 100;
    int chordIndex = 0;
    bool drawTool = true;
    juce::Array<te::MidiNote*> selection;

private:
    class Keys;
    class Grid;
    class VelocityLane;
    class Toolbar;
    std::unique_ptr<Keys> keys;
    std::unique_ptr<Grid> grid;
    std::unique_ptr<VelocityLane> velocity;
    std::unique_ptr<Toolbar> toolbar;
    juce::ScrollBar hScroll { false }, vScroll { true };

    void updateScrollbars();
    void repaintVelocityLane();
    void scrollBarMoved (juce::ScrollBar*, double newRangeStart) override;
    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override       { triggerAsyncUpdate(); }
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override { triggerAsyncUpdate(); }
    void valueTreePropertyChanged (juce::ValueTree&, const juce::Identifier&) override { triggerAsyncUpdate(); }
    void handleAsyncUpdate() override;
    void timerCallback() override;

    friend class Grid;
    friend class VelocityLane;
    friend class Keys;
};

//==============================================================================
class DrumGridEditor : public juce::Component,
                       private juce::ValueTree::Listener,
                       private juce::AsyncUpdater,
                       private juce::Timer
{
public:
    DrumGridEditor (Session&, te::MidiClip&);
    ~DrumGridEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

    struct Row { int note; juce::String name; };

private:
    Session& session;
    te::MidiClip::Ptr clip;
    std::vector<Row> rows;
    double stepBeats = 0.25;
    int paintMode = 0;          // 1 = adding, -1 = erasing
    int lastPaintRow = -1, lastPaintStep = -1;

    juce::ComboBox stepBox, lengthBox;
    juce::Slider swing;
    juce::TextButton applySwing { "Apply swing" }, clearAll { "Clear" };
    juce::Label hint;

    static constexpr int headerW = 130, topH = 36, rowH = 24;

    void buildRows();
    int numSteps() const;
    juce::Rectangle<int> cellBounds (int row, int step) const;
    te::MidiNote* findNote (int note, int step) const;
    void setCell (int row, int step, bool on, int velocity);
    void showRowMenu (int row);
    void euclidDialog (int row);

    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override       { triggerAsyncUpdate(); }
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override { triggerAsyncUpdate(); }
    void valueTreePropertyChanged (juce::ValueTree&, const juce::Identifier&) override { triggerAsyncUpdate(); }
    void handleAsyncUpdate() override  { repaint(); }
    void timerCallback() override      { repaint (headerW, topH, getWidth() - headerW, getHeight() - topH); }
};

//==============================================================================
class AudioClipEditor : public juce::Component,
                        private juce::Timer
{
public:
    AudioClipEditor (Session&, te::WaveAudioClip&);
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    Session& session;
    te::WaveAudioClip::Ptr clip;
    te::SmartThumbnail thumbnail;
    juce::Slider gain, pitch;
    juce::ToggleButton reverse { "Reverse" }, autoTempo { "Follow tempo" };
    juce::Label info;
    void timerCallback() override { repaint(); }
};

//==============================================================================
/** Bottom-panel host for whichever clip editor fits the selected clip. */
class ClipEditorPanel : public juce::Component,
                        private juce::ChangeListener
{
public:
    ClipEditorPanel (Session&);
    ~ClipEditorPanel() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void showClip (te::Clip*, int preferredMode = -1);   // mode: 0 piano roll, 1 step grid
    te::Clip* getClip() const    { return currentClip.get(); }

private:
    Session& session;
    te::Clip::Ptr currentClip;
    std::unique_ptr<juce::Component> editor;
    juce::TextButton pianoRollButton { "Piano Roll" }, stepButton { "Step Sequencer" };
    int mode = 0;

    void changeListenerCallback (juce::ChangeBroadcaster*) override;
};

} // namespace lode
