/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "MainWindow.h"
#include "PracticeView.h"
#include "TransportBar.h"
#include "Browser.h"
#include "Arrangement.h"
#include "PianoRoll.h"
#include "InstrumentPanel.h"
#include "Mixer.h"
#include "ProjectIO.h"

namespace lode
{
using namespace juce;

//==============================================================================
class MainComponent::Resizer : public Component
{
public:
    Resizer (bool isVertical, std::function<void (int)> onDrag)
        : vertical (isVertical), callback (std::move (onDrag))
    {
        setMouseCursor (vertical ? MouseCursor::LeftRightResizeCursor : MouseCursor::UpDownResizeCursor);
    }

    void paint (Graphics& g) override
    {
        g.fillAll (isMouseOverOrDragging() ? Col::south.withAlpha (0.6f) : Col::bg0);
    }

    void mouseDown (const MouseEvent& e) override   { last = vertical ? e.getScreenX() : e.getScreenY(); }
    void mouseDrag (const MouseEvent& e) override
    {
        auto now = vertical ? e.getScreenX() : e.getScreenY();
        callback (now - last);
        last = now;
    }
    void mouseEnter (const MouseEvent&) override    { repaint(); }
    void mouseExit (const MouseEvent&) override     { repaint(); }

private:
    bool vertical;
    int last = 0;
    std::function<void (int)> callback;
};

//==============================================================================
// Dialog contents
//==============================================================================
namespace
{
    void launchDialog (const String& title, std::unique_ptr<Component> content, Component* centreAround, bool resizable = true)
    {
        DialogWindow::LaunchOptions o;
        o.dialogTitle = title;
        o.dialogBackgroundColour = Col::bg1;
        o.escapeKeyTriggersCloseButton = true;
        o.useNativeTitleBar = true;
        o.resizable = resizable;
        o.componentToCentreAround = centreAround;
        o.content.setOwned (content.release());
        o.launchAsync();
    }

    //==========================================================================
    class MidiDevicesComponent : public Component, private Timer
    {
    public:
        MidiDevicesComponent (Session& s) : session (s)
        {
            addAndMakeVisible (rescan);
            rescan.onClick = [this]
            {
                session.engine.getDeviceManager().rescanMidiDeviceList();
                Timer::callAfterDelay (800, [sp = SafePointer<MidiDevicesComponent> (this)] { if (sp != nullptr) { sp->session.getInputRouter().enableAllDevices(); sp->rebuild(); } });
            };

            addAndMakeVisible (info);
            info.setColour (Label::textColourId, Col::textDim);
            info.setFont (LodeLookAndFeel::font (13.0f));
            info.setText ("Every controller can play at once. \"Follow\" controllers play whichever instrument track is selected; "
                          "pin a controller (e.g. your MPD218) to one track so it always plays that, while your keyboard follows the selection.",
                          dontSendNotification);
            info.setJustificationType (Justification::topLeft);
            rebuild();
            startTimer (2000);
        }

        void timerCallback() override
        {
            if (session.getInputRouter().getMidiDevices().size() != rows.size())
                rebuild();
        }

        void rebuild()
        {
            rows.clear();
            auto& router = session.getInputRouter();

            if (session.isPracticeMode())
            {
                // practice routes controllers per sound; these follow/pin settings are the project's
                info.setText ("You're in Practice mode: choose which controllers play each sound on the sound's card "
                              "(PLAYS FROM). The settings here are for your projects.", dontSendNotification);

                for (auto& d : router.getMidiDevices())
                {
                    auto row = rows.add (new Row());
                    row->name.setText (d.name, dontSendNotification);
                    addAndMakeVisible (row->name);
                }

                resized();
                return;
            }

            for (auto& d : router.getMidiDevices())
            {
                auto row = rows.add (new Row());
                row->name.setText (d.name, dontSendNotification);
                row->mode.addItem ("Follows the selected track", 1);
                int id = 2;
                auto tracks = te::getAudioTracks (session.edit_());

                for (auto t : tracks)
                    if (getTrackKind (*t) != TrackKind::audio)
                        row->mode.addItem ("Always plays \"" + t->getName() + "\"", id++);

                if (d.follows)
                    row->mode.setSelectedId (1, dontSendNotification);
                else if (d.pinnedTrack != nullptr)
                    row->mode.setText ("Always plays \"" + d.pinnedTrack->getName() + "\"", dontSendNotification);

                row->mode.onChange = [this, deviceID = d.id, rowPtr = row, tracks]
                {
                    auto& r = session.getInputRouter();
                    if (rowPtr->mode.getSelectedId() == 1)
                    {
                        r.setFollow (deviceID, true);
                        return;
                    }

                    auto text = rowPtr->mode.getText().fromFirstOccurrenceOf ("\"", false, false).upToLastOccurrenceOf ("\"", false, false);
                    for (auto t : tracks)
                        if (t->getName() == text)
                            r.pinDevice (deviceID, t);
                };

                addAndMakeVisible (row->name);
                addAndMakeVisible (row->mode);
            }

            if (rows.isEmpty())
            {
                auto row = rows.add (new Row());
                row->name.setText ("No MIDI controllers found. Plug one in and press Rescan.", dontSendNotification);
                addAndMakeVisible (row->name);
            }

            resized();
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (14);
            info.setBounds (r.removeFromTop (54));
            r.removeFromTop (6);

            for (auto* row : rows)
            {
                auto line = r.removeFromTop (30);
                row->name.setBounds (line.removeFromLeft (line.getWidth() / 2));
                row->mode.setBounds (line.reduced (0, 2));
                r.removeFromTop (4);
            }

            rescan.setBounds (r.removeFromTop (30).removeFromLeft (180));
        }

    private:
        struct Row { Label name; ComboBox mode; };
        Session& session;
        OwnedArray<Row> rows;
        TextButton rescan { "Rescan MIDI devices" };
        Label info;
    };

    //==========================================================================
    class PluginsComponent : public Component
    {
    public:
        PluginsComponent (Session& s)
            : list (s.engine.getPluginManager().pluginFormatManager,
                    s.engine.getPluginManager().knownPluginList,
                    s.engine.getTemporaryFileManager().getTempFile ("PluginScanDeadMansPedal"),
                    std::addressof (s.engine.getPropertyStorage().getPropertiesFile()), true)
        {
            addAndMakeVisible (list);
            addAndMakeVisible (info);
            info.setFont (LodeLookAndFeel::font (12.5f));
            info.setColour (Label::textColourId, Col::textDim);

            StringArray formats;
            for (auto* f : s.engine.getPluginManager().pluginFormatManager.getFormats())
                formats.add (f->getName());

            info.setText ("Formats: " + formats.joinIntoString (", ") + ".  Click \"Options...\" > \"Scan for new or updated plugins\". "
                          "Windows VST3 plugins work via yabridge (they appear in ~/.vst3/yabridge). "
                          "VST2 and Audio Units can't be hosted (VST2 needs Steinberg's non-redistributable SDK; AU is macOS-only).",
                          dontSendNotification);
            info.setJustificationType (Justification::topLeft);
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (10);
            info.setBounds (r.removeFromTop (48));
            r.removeFromTop (6);
            list.setBounds (r);
        }

    private:
        PluginListComponent list;
        Label info;
    };

    //==========================================================================
    class SettingsComponent : public Component
    {
    public:
        SettingsComponent (Session& s, int tab)
            : tabs (TabbedButtonBar::TabsAtTop)
        {
            auto* audio = new AudioDeviceSelectorComponent (s.engine.getDeviceManager().deviceManager,
                                                            0, 256, 1, 256, false, false, true, false);
            tabs.addTab ("Audio", Col::bg1, audio, true);
            tabs.addTab ("MIDI Controllers", Col::bg1, new MidiDevicesComponent (s), true);
            tabs.addTab ("Plugins", Col::bg1, new PluginsComponent (s), true);
            tabs.setTabBarDepth (34);
            tabs.setCurrentTabIndex (jlimit (0, 2, tab));
            addAndMakeVisible (tabs);
            setSize (760, 600);
        }

        void resized() override     { tabs.setBounds (getLocalBounds()); }

    private:
        TabbedComponent tabs;
    };

    //==========================================================================
    class ExportComponent : public Component
    {
    public:
        ExportComponent (Session& s, int k, std::function<void (ProjectIO::AudioExportOptions)> onGo)
            : session (s), kind (k), go (std::move (onGo))
        {
            addAndMakeVisible (title);
            title.setFont (LodeLookAndFeel::font (16.0f, true));
            title.setText (kind == 1 ? "Export stems (one file per track)" : "Export your song", dontSendNotification);

            addAndMakeVisible (format);
            format.addItem ("WAV 16-bit (CD quality)", 1);
            format.addItem ("WAV 24-bit", 2);
            format.addItem ("WAV 32-bit float", 3);
            format.addItem ("FLAC (lossless, smaller)", 4);
            format.addItem ("OGG Vorbis (small, for sharing)", 5);
            format.setSelectedId (2);

            addAndMakeVisible (rate);
            for (int r : { 44100, 48000, 88200, 96000 })
                rate.addItem (String (r) + " Hz", r);
            rate.setSelectedId (44100);

            addAndMakeVisible (loopOnly);
            loopOnly.setToggleState (false, dontSendNotification);
            addAndMakeVisible (normalise);
            normalise.setToggleState (kind == 0, dontSendNotification);
            normalise.setVisible (kind == 0);

            addAndMakeVisible (exportButton);
            exportButton.setColour (TextButton::buttonColourId, Col::south.withAlpha (0.7f));
            exportButton.onClick = [this]
            {
                ProjectIO::AudioExportOptions o;
                auto f = format.getSelectedId();
                o.format = f == 4 ? "flac" : (f == 5 ? "ogg" : "wav");
                o.bitDepth = f == 1 ? 16 : (f == 3 ? 32 : 24);
                o.sampleRate = rate.getSelectedId();
                o.loopRangeOnly = loopOnly.getToggleState();
                o.normalise = normalise.getToggleState();
                o.normaliseLufs = -14.0f;

                if (auto dw = findParentComponentOfClass<DialogWindow>())
                    dw->exitModalState (0);

                go (o);
            };

            setSize (420, 250);
        }

        void paint (Graphics& g) override { g.fillAll (Col::bg1); }

        void resized() override
        {
            auto r = getLocalBounds().reduced (16);
            title.setBounds (r.removeFromTop (28));
            r.removeFromTop (8);
            format.setBounds (r.removeFromTop (28));
            r.removeFromTop (6);
            rate.setBounds (r.removeFromTop (28));
            r.removeFromTop (6);
            loopOnly.setBounds (r.removeFromTop (26));
            normalise.setBounds (r.removeFromTop (26));
            exportButton.setBounds (r.removeFromBottom (32).removeFromRight (140));
        }

    private:
        Session& session;
        int kind;
        std::function<void (ProjectIO::AudioExportOptions)> go;
        Label title;
        ComboBox format, rate;
        ToggleButton loopOnly { "Only the loop region" }, normalise { "Loudness-normalise to -14 LUFS (streaming level)" };
        TextButton exportButton { "Export..." };
    };

    //==========================================================================
    class CommandPalette : public Component,
                           private ListBoxModel
    {
    public:
        struct Entry
        {
            String name, detail;
            std::function<void()> action;
        };

        CommandPalette (Array<Entry> allEntries) : entries (std::move (allEntries))
        {
            addAndMakeVisible (search);
            search.setTextToShowWhenEmpty ("Type a command, instrument, effect or recent project...", Col::textFaint);
            search.setFont (LodeLookAndFeel::font (16.0f));
            search.onTextChange = [this] { filter(); };
            search.onReturnKey = [this] { run (list.getSelectedRow()); };
            search.onEscapeKey = [this] { close(); };

            addAndMakeVisible (list);
            list.setModel (this);
            list.setRowHeight (28);
            list.setColour (ListBox::backgroundColourId, Col::bg1);
            filter();
            setSize (620, 420);
        }

        void visibilityChanged() override
        {
            if (isVisible())
                search.grabKeyboardFocus();
        }

        bool keyPressed (const KeyPress& k) override
        {
            if (k == KeyPress::downKey)  { list.selectRow (jmin (getNumRows() - 1, list.getSelectedRow() + 1)); return true; }
            if (k == KeyPress::upKey)    { list.selectRow (jmax (0, list.getSelectedRow() - 1)); return true; }
            return false;
        }

        void paint (Graphics& g) override
        {
            g.setColour (Col::bg2);
            g.fillRoundedRectangle (getLocalBounds().toFloat(), 8.0f);
            g.setColour (Col::south.withAlpha (0.6f));
            g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (0.5f), 8.0f, 1.0f);
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (10);
            search.setBounds (r.removeFromTop (34));
            r.removeFromTop (6);
            list.setBounds (r);
        }

        std::function<void()> onClose;

    private:
        Array<Entry> entries;
        Array<int> shown;
        TextEditor search;
        ListBox list;

        static int score (const String& text, const String& query)
        {
            if (query.isEmpty()) return 1;
            auto t = text.toLowerCase(), q = query.toLowerCase();
            if (t.startsWith (q)) return 1000 - t.length();
            if (t.contains (q)) return 500 - t.indexOf (q);

            // subsequence match
            int ti = 0, s = 0;
            for (auto c : q)
            {
                auto found = t.indexOfChar (ti, c);
                if (found < 0) return 0;
                s += (found == ti) ? 5 : 1;
                ti = found + 1;
            }
            return s;
        }

        void filter()
        {
            std::vector<std::pair<int, int>> scored;
            auto q = search.getText().trim();

            for (int i = 0; i < entries.size(); ++i)
                if (auto s = score (entries[i].name, q); s > 0)
                    scored.push_back ({ s, i });

            std::stable_sort (scored.begin(), scored.end(), [] (auto& a, auto& b) { return a.first > b.first; });
            shown.clear();
            for (size_t i = 0; i < scored.size() && i < 200; ++i)
                shown.add (scored[i].second);

            list.updateContent();
            list.selectRow (0);
            list.repaint();
        }

        void run (int row)
        {
            if (! isPositiveAndBelow (row, shown.size()))
                return;

            auto action = entries[shown[row]].action;
            close();

            if (action)
                MessageManager::callAsync (action);
        }

        void close()
        {
            if (onClose)
                MessageManager::callAsync (onClose);
        }

        int getNumRows() override     { return shown.size(); }

        void paintListBoxItem (int row, Graphics& g, int w, int h, bool selected) override
        {
            if (! isPositiveAndBelow (row, shown.size()))
                return;

            auto e = entries[shown[row]];
            if (selected)
            {
                g.setColour (Col::south.withAlpha (0.35f));
                g.fillRoundedRectangle (Rectangle<float> (0, 0, (float) w, (float) h).reduced (2.0f, 1.0f), 4.0f);
            }

            g.setColour (Col::text);
            g.setFont (LodeLookAndFeel::font (14.0f));
            g.drawText (e.name, 10, 0, w - 160, h, Justification::centredLeft, true);
            g.setColour (Col::textFaint);
            g.setFont (LodeLookAndFeel::font (12.0f));
            g.drawText (e.detail, w - 160, 0, 150, h, Justification::centredRight, true);
        }

        void listBoxItemDoubleClicked (int row, const MouseEvent&) override    { run (row); }
        void returnKeyPressed (int row) override                                { run (row); }
    };
}

//==============================================================================
// MainComponent
//==============================================================================
static const char* typingKeys = "awsedftgyhujkolp;";

MainComponent::MainComponent (Session& s, LodeUIBehaviour& ui)
    : session (s), uiBehaviour (ui)
{
    setWantsKeyboardFocus (true);

    session.onStatusMessage = [this] (const String& m) { status (m); };
    uiBehaviour.onStatusMessage = [this] (const String& m) { status (m); };
    session.onBeforeEditReplaced = [this] { tearDownEditUI(); };
    session.addChangeListener (this);

    browser = std::make_unique<BrowserPanel> (session);
    browser->onOpenFile = [this] (const File& f) { openFile (f); };
    addAndMakeVisible (*browser);

    for (auto name : { "Editor", "Instrument", "Mixer" })
    {
        auto b = bottomTabs.add (new TextButton (name));
        b->setClickingTogglesState (true);
        b->setRadioGroupId (4242);
        b->setColour (TextButton::buttonColourId, Col::bg2);
        b->setColour (TextButton::buttonOnColourId, Col::bg4);
        auto index = bottomTabs.size() - 1;
        b->onClick = [this, index] { showBottomTab (index); };
        addAndMakeVisible (b);
    }

    vResizer = std::make_unique<Resizer> (true, [this] (int dx)
    {
        browserWidth = jlimit (180, 520, browserWidth + dx);
        resized();
    });
    addAndMakeVisible (*vResizer);

    hResizer = std::make_unique<Resizer> (false, [this] (int dy)
    {
        if (session.getEdit() != nullptr)
        {
            auto& v = session.getView();
            v.bottomPanelHeight = jlimit (120, jmax (200, getHeight() - 220), v.bottomPanelHeight.get() - dy);
            resized();
        }
    });
    addAndMakeVisible (*hResizer);

    addAndMakeVisible (statusLabel);
    statusLabel.setFont (LodeLookAndFeel::font (12.5f));
    statusLabel.setColour (Label::textColourId, Col::textDim);
    addAndMakeVisible (deviceLabel);
    deviceLabel.setFont (LodeLookAndFeel::font (12.0f));
    deviceLabel.setColour (Label::textColourId, Col::textFaint);
    deviceLabel.setJustificationType (Justification::centredRight);

    commandManager.registerAllCommandsForTarget (this);
    commandManager.setFirstCommandTarget (this);

    setupKeyboardDevice();
    buildEditUI();
    showBottomTab (0);
    startTimer (1000);
    setSize (1440, 900);
}

MainComponent::~MainComponent()
{
    session.removeChangeListener (this);
    session.onStatusMessage = nullptr;
    session.onBeforeEditReplaced = nullptr;
    uiBehaviour.onStatusMessage = nullptr;
    tearDownEditUI();
}

void MainComponent::setupKeyboardDevice()
{
    auto& dm = session.engine.getDeviceManager();
    auto find = [&dm]
    {
        for (auto& m : dm.getMidiInDevices())
            if (m->getName() == "Computer Keyboard")
                return m;
        return std::shared_ptr<te::MidiInputDevice>();
    };

    keyboardDevice = find();

    if (keyboardDevice == nullptr)
    {
        dm.createVirtualMidiDevice ("Computer Keyboard");   // fails harmlessly if it already exists
        dm.dispatchPendingUpdates();
        keyboardDevice = find();
    }

    if (keyboardDevice != nullptr)
    {
        keyboardDevice->setEnabled (true);
        keyboardDevice->setMonitorMode (te::InputDevice::MonitorMode::on);
        session.refreshInputRouting();
    }
}

void MainComponent::tearDownEditUI()
{
    practiceView.reset();
    transport.reset();
    arrangement.reset();
    clipEditor.reset();
    devicePanel.reset();
    mixer.reset();
    currentEdit = nullptr;
}

void MainComponent::buildEditUI()
{
    tearDownEditUI();
    currentEdit = session.getEdit();

    if (currentEdit == nullptr)
        return;

    if (session.isPracticeMode())
    {
        practiceView = std::make_unique<PracticeView> (session);
        practiceView->onBack = [this] { togglePractice(); };
        practiceView->onToggleKeyboard = [this] { commandManager.invokeDirectly (CommandIDs::musicalTyping, true); };
        practiceView->onOpenProject = [this] (const File& f) { openFile (f); };
        practiceView->setKeyboardActive (typingOn);
        addAndMakeVisible (*practiceView);

        for (auto* b : bottomTabs)
            b->setVisible (false);

        updateTitle();
        resized();
        grabKeyboardFocus();
        return;
    }

    for (auto* b : bottomTabs)
        b->setVisible (true);

    transport = std::make_unique<TransportBar> (session, commandManager);
    transport->onToggleBrowser = [this] { browserVisible = ! browserVisible; resized(); };
    transport->onToggleKeyboard = [this] { commandManager.invokeDirectly (CommandIDs::musicalTyping, true); };
    transport->setKeyboardActive (typingOn);
    addAndMakeVisible (*transport);

    arrangement = std::make_unique<ArrangementView> (session);
    arrangement->onOpenClipEditor = [this] (te::Clip* c)
    {
        session.getSelectionManager().selectOnly (c);
        if (clipEditor != nullptr)
            clipEditor->showClip (c);
        showBottomTab (0);
    };
    arrangement->onOpenInstrument = [this] (te::AudioTrack* t)
    {
        session.selectTrack (t);
        showBottomTab (1);
    };
    arrangement->onOpenProjectFile = [this] (const File& f) { openFile (f); };
    addAndMakeVisible (*arrangement);

    clipEditor = std::make_unique<ClipEditorPanel> (session);
    devicePanel = std::make_unique<DeviceChainPanel> (session);
    mixer = std::make_unique<MixerView> (session);
    mixer->onShowDevice = [this] (te::AudioTrack* t, te::Plugin* p)
    {
        session.selectTrack (t);
        showBottomTab (1);
        if (devicePanel != nullptr)
            devicePanel->selectDevice (p);
    };

    addChildComponent (*clipEditor);
    addChildComponent (*devicePanel);
    addChildComponent (*mixer);
    showBottomTab (bottomTab);

    updateTitle();
    resized();
}

void MainComponent::changeListenerCallback (ChangeBroadcaster*)
{
    if (session.getEdit() != currentEdit)
        buildEditUI();
    else
        updateTitle();
}

void MainComponent::updateTitle()
{
    if (auto w = findParentComponentOfClass<DocumentWindow>())
        w->setName (session.isPracticeMode() ? String ("Lodestone - Practice")
                                             : "Lodestone - " + session.getProjectName() + (session.hasUnsavedChanges() ? "  *" : ""));
}

void MainComponent::showBottomTab (int index)
{
    bottomTab = index;

    for (int i = 0; i < bottomTabs.size(); ++i)
        bottomTabs[i]->setToggleState (i == index, dontSendNotification);

    if (clipEditor)  clipEditor->setVisible (index == 0);
    if (devicePanel) devicePanel->setVisible (index == 1);
    if (mixer)       mixer->setVisible (index == 2);
}

void MainComponent::status (const String& m)
{
    statusLabel.setText (m, dontSendNotification);
    statusLabel.setColour (Label::textColourId, Col::text);
    statusTime = Time::getMillisecondCounter();
}

void MainComponent::timerCallback()
{
    if (keyboardDevice == nullptr)
        setupKeyboardDevice();

    session.refreshInputRouting();      // hot-plugged controllers play the selected track

    if (statusTime != 0 && Time::getMillisecondCounter() - statusTime > 7000)
    {
        statusLabel.setColour (Label::textColourId, Col::textFaint);
        statusTime = 0;
    }

    String dev;
    if (auto* d = session.engine.getDeviceManager().deviceManager.getCurrentAudioDevice())
        dev << d->getName() << "  " << String (d->getCurrentSampleRate() / 1000.0, 1) << " kHz  "
            << d->getCurrentBufferSizeSamples() << " samples ("
            << String (d->getCurrentBufferSizeSamples() * 1000.0 / jmax (1.0, d->getCurrentSampleRate()), 1) << " ms)";
    else
        dev << "No audio device - check Settings";

    auto midiCount = session.getInputRouter().getMidiDevices().size() - (keyboardDevice != nullptr ? 1 : 0);
    dev << "   |   " << midiCount << " MIDI controller" << (midiCount == 1 ? "" : "s");
    if (typingOn)
        dev << "   |   Typing keyboard: octave " << (typingOctave - 1) << ", velocity " << typingVelocity;
    deviceLabel.setText (dev, dontSendNotification);

    // keep Space etc. working: clicked buttons/combos shouldn't steal keyboard focus
    std::function<void (Component&)> fix = [&fix] (Component& c)
    {
        for (auto* child : c.getChildren())
        {
            if (dynamic_cast<Button*> (child) != nullptr || dynamic_cast<Slider*> (child) != nullptr
                 || dynamic_cast<ComboBox*> (child) != nullptr)
            {
                child->setWantsKeyboardFocus (false);
                child->setMouseClickGrabsKeyboardFocus (false);
            }
            fix (*child);
        }
    };
    fix (*this);

    updateTitle();
}

void MainComponent::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    g.setColour (Col::bg2);
    g.fillRect (getLocalBounds().removeFromBottom (24));

    if (session.getEdit() != nullptr && practiceView == nullptr)
    {
        auto tabsArea = bottomTabs.getFirst()->getBounds().getUnion (bottomTabs.getLast()->getBounds());
        g.setColour (Col::bg2);
        g.fillRect (0, tabsArea.getY() - 3, getWidth(), tabsArea.getHeight() + 6);
    }
}

void MainComponent::resized()
{
    auto r = getLocalBounds();
    auto statusBar = r.removeFromBottom (24).reduced (10, 2);
    deviceLabel.setBounds (statusBar.removeFromRight (statusBar.getWidth() / 2));
    statusLabel.setBounds (statusBar);

    if (practiceView != nullptr)
    {
        browser->setVisible (false);
        vResizer->setVisible (false);
        hResizer->setVisible (false);
        practiceView->setBounds (r);
        return;
    }

    hResizer->setVisible (true);

    if (transport != nullptr)
        transport->setBounds (r.removeFromTop (52));

    browser->setVisible (browserVisible);
    vResizer->setVisible (browserVisible);

    if (browserVisible)
    {
        browser->setBounds (r.removeFromLeft (browserWidth));
        vResizer->setBounds (r.removeFromLeft (4));
    }

    if (session.getEdit() == nullptr)
        return;

    auto bottomH = jlimit (120, jmax (120, r.getHeight() - 200), session.getView().bottomPanelHeight.get());
    auto bottom = r.removeFromBottom (bottomH);
    hResizer->setBounds (r.removeFromBottom (4));

    auto tabs = bottom.removeFromTop (30).reduced (6, 3);
    for (auto* b : bottomTabs)
    {
        b->setBounds (tabs.removeFromLeft (110));
        tabs.removeFromLeft (4);
    }

    for (auto* c : { (Component*) clipEditor.get(), (Component*) devicePanel.get(), (Component*) mixer.get() })
        if (c != nullptr)
            c->setBounds (bottom);

    if (arrangement != nullptr)
        arrangement->setBounds (r);
}

//==============================================================================
void MainComponent::sendTypingNote (int note, bool on)
{
    note = jlimit (0, 127, note);
    auto msg = on ? MidiMessage::noteOn (1, note, (uint8) typingVelocity) : MidiMessage::noteOff (1, note);
    msg.setTimeStamp (Time::getMillisecondCounterHiRes() * 0.001);

    if (auto v = dynamic_cast<te::VirtualMidiInputDevice*> (keyboardDevice.get()))
    {
        v->handleIncomingMidiMessage (msg, v->getMPESourceID());
        return;
    }

    if (auto t = session.getSelectedTrack())
        t->injectLiveMidiMessage (msg, te::MPESourceID {});
}

bool MainComponent::keyPressed (const KeyPress& key)
{
    if (! typingOn || key.getModifiers().isCommandDown() || key.getModifiers().isAltDown())
        return false;

    auto c = CharacterFunctions::toLowerCase (key.getTextCharacter());
    if (c == 0)
        c = CharacterFunctions::toLowerCase ((juce_wchar) key.getKeyCode());

    if (auto pos = String (typingKeys).indexOfChar (c); pos >= 0)
    {
        auto note = typingOctave * 12 + pos;
        if (typingNotesDown.insert (pos).second)
            sendTypingNote (note, true);
        return true;
    }

    if (c == 'z') { typingOctave = jmax (1, typingOctave - 1); timerCallback(); return true; }
    if (c == 'x') { typingOctave = jmin (9, typingOctave + 1); timerCallback(); return true; }
    if (c == 'c') { typingVelocity = jmax (10, typingVelocity - 15); timerCallback(); return true; }
    if (c == 'v') { typingVelocity = jmin (127, typingVelocity + 15); timerCallback(); return true; }

    return false;
}

bool MainComponent::keyStateChanged (bool)
{
    if (! typingOn || typingNotesDown.empty())
        return false;

    std::vector<int> released;
    for (auto pos : typingNotesDown)
    {
        auto ch = (int) typingKeys[pos];
        if (! KeyPress::isKeyCurrentlyDown (ch) && ! KeyPress::isKeyCurrentlyDown ((int) CharacterFunctions::toUpperCase ((juce_wchar) ch)))
            released.push_back (pos);
    }

    for (auto pos : released)
    {
        typingNotesDown.erase (pos);
        sendTypingNote (typingOctave * 12 + pos, false);
    }

    return ! released.empty();
}

//==============================================================================
void MainComponent::getAllCommands (Array<CommandID>& c)
{
    using namespace CommandIDs;
    c.addArray (std::initializer_list<CommandID> { newProject, openProject, save, saveAs, importFiles, importFolderProject,
                  exportAudio, exportStems, exportMidi, exportDawProject, quit,
                  undo, redo, cut, copy, paste, duplicate, deleteSelection, selectAll, split, quantize, renameClip, nudgeLeft, nudgeRight,
                  newInstrumentTrack, newDrumTrack, newAudioTrack, newSynthTrack, duplicateTrack, deleteTrack,
                  playStop, record, loop, metronome, goToStart, tapTempo, toggleSnap, loopSelection,
                  zoomIn, zoomOut, zoomFit, toggleBrowser, showEditor, showInstrument, showMixer,
                  commandPalette, musicalTyping, settings, scanPlugins, shortcuts, about, gettingStarted, practiceMode });
}

void MainComponent::getCommandInfo (CommandID id, ApplicationCommandInfo& info)
{
    using namespace CommandIDs;
    auto cmd = ModifierKeys::commandModifier;
    auto shift = ModifierKeys::shiftModifier;
    auto hasEdit = session.getEdit() != nullptr;

    switch (id)
    {
        case newProject:        info.setInfo ("New Project", "Start a new project", "File", 0); info.addDefaultKeypress ('n', cmd); break;
        case openProject:       info.setInfo ("Open...", "Open a Lodestone project, or import LMMS, FL Studio, GarageBand, DAWproject or MIDI", "File", 0); info.addDefaultKeypress ('o', cmd); break;
        case save:              info.setInfo ("Save", "Save the project", "File", 0); info.addDefaultKeypress ('s', cmd); break;
        case saveAs:            info.setInfo ("Save As...", "Save the project under a new name", "File", 0); info.addDefaultKeypress ('s', cmd | shift); break;
        case importFiles:       info.setInfo ("Import Audio / MIDI...", "Add audio or MIDI files to this project", "File", 0); info.addDefaultKeypress ('i', cmd); break;
        case importFolderProject: info.setInfo ("Import GarageBand / Logic Project...", "Import a .band or .logicx project folder", "File", 0); break;
        case exportAudio:       info.setInfo ("Export Song (WAV / FLAC / OGG)...", "Render the whole song to an audio file", "File", 0); info.addDefaultKeypress ('e', cmd); break;
        case exportStems:       info.setInfo ("Export Stems...", "Render each track to its own audio file", "File", 0); info.addDefaultKeypress ('e', cmd | shift); break;
        case exportMidi:        info.setInfo ("Export MIDI File...", "Save all the notes as a Standard MIDI File", "File", 0); break;
        case exportDawProject:  info.setInfo ("Export DAWproject...", "Open this project in Bitwig, Studio One or Cubase", "File", 0); break;
        case quit:              info.setInfo ("Quit", "Quit Lodestone", "File", 0); info.addDefaultKeypress ('q', cmd); break;

        case undo:              info.setInfo ("Undo", "Undo", "Edit", 0); info.addDefaultKeypress ('z', cmd); info.setActive (hasEdit); break;
        case redo:              info.setInfo ("Redo", "Redo", "Edit", 0); info.addDefaultKeypress ('z', cmd | shift); info.addDefaultKeypress ('y', cmd); info.setActive (hasEdit); break;
        case cut:               info.setInfo ("Cut", "Cut selected clips", "Edit", 0); info.addDefaultKeypress ('x', cmd); break;
        case copy:              info.setInfo ("Copy", "Copy selected clips", "Edit", 0); info.addDefaultKeypress ('c', cmd); break;
        case paste:             info.setInfo ("Paste", "Paste clips at the playhead on the selected track", "Edit", 0); info.addDefaultKeypress ('v', cmd); break;
        case duplicate:         info.setInfo ("Duplicate", "Duplicate the selection after itself", "Edit", 0); info.addDefaultKeypress ('d', cmd); break;
        case deleteSelection:   info.setInfo ("Delete", "Delete selected clips (or the selected track)", "Edit", 0);
                                info.addDefaultKeypress (KeyPress::deleteKey, 0); info.addDefaultKeypress (KeyPress::backspaceKey, 0); break;
        case selectAll:         info.setInfo ("Select All Clips", "Select every clip", "Edit", 0); info.addDefaultKeypress ('a', cmd); break;
        case split:             info.setInfo ("Split at Playhead", "Cut clips in two at the playhead", "Edit", 0); info.addDefaultKeypress ('s', 0); break;
        case quantize:          info.setInfo ("Quantize Clips", "Snap notes in the selected clips to the grid", "Edit", 0); info.addDefaultKeypress ('q', 0); break;
        case renameClip:        info.setInfo ("Rename Clip", "Rename the selected clips", "Edit", 0); info.addDefaultKeypress (KeyPress::F2Key, 0); break;
        case nudgeLeft:         info.setInfo ("Nudge Left", "Move selected clips one grid step earlier", "Edit", 0); info.addDefaultKeypress (KeyPress::leftKey, ModifierKeys::altModifier); break;
        case nudgeRight:        info.setInfo ("Nudge Right", "Move selected clips one grid step later", "Edit", 0); info.addDefaultKeypress (KeyPress::rightKey, ModifierKeys::altModifier); break;

        case newInstrumentTrack: info.setInfo ("New Instrument Track", "Add a piano track (change the sound later)", "Track", 0); info.addDefaultKeypress ('t', cmd | shift); break;
        case newDrumTrack:      info.setInfo ("New Drum Track", "Add a 16-pad drum machine track", "Track", 0); info.addDefaultKeypress ('d', cmd | shift); break;
        case newSynthTrack:     info.setInfo ("New Synth Track", "Add a synthesizer track", "Track", 0); break;
        case newAudioTrack:     info.setInfo ("New Audio Track", "Add a track for recording or audio files", "Track", 0); info.addDefaultKeypress ('a', cmd | shift); break;
        case duplicateTrack:    info.setInfo ("Duplicate Track", "Copy the selected track", "Track", 0); break;
        case deleteTrack:       info.setInfo ("Delete Track", "Delete the selected track", "Track", 0); break;

        case playStop:          info.setInfo ("Play / Stop", "Start or stop playback", "Transport", 0); info.addDefaultKeypress (KeyPress::spaceKey, 0); break;
        case record:            info.setInfo ("Record", "Record on armed (or the selected) track", "Transport", 0); info.addDefaultKeypress ('r', 0); break;
        case loop:              info.setInfo ("Loop On/Off", "Toggle the loop region", "Transport", 0); info.addDefaultKeypress ('l', 0); break;
        case metronome:         info.setInfo ("Metronome", "Toggle the click", "Transport", 0); info.addDefaultKeypress ('c', 0); break;
        case goToStart:         info.setInfo ("Go to Start", "Move the playhead to the start", "Transport", 0); info.addDefaultKeypress (KeyPress::homeKey, 0); info.addDefaultKeypress (KeyPress::returnKey, 0); break;
        case tapTempo:          info.setInfo ("Tap Tempo", "Tap repeatedly to set the tempo", "Transport", 0); info.addDefaultKeypress ('t', 0); break;
        case toggleSnap:        info.setInfo ("Snap to Grid", "Toggle the magnet", "Transport", 0); info.addDefaultKeypress ('g', 0); break;
        case loopSelection:     info.setInfo ("Loop Selection", "Set the loop region to the selected clips", "Transport", 0); info.addDefaultKeypress ('l', cmd); break;

        case zoomIn:            info.setInfo ("Zoom In", "Zoom in horizontally", "View", 0); info.addDefaultKeypress ('=', cmd); info.addDefaultKeypress ('+', cmd); break;
        case zoomOut:           info.setInfo ("Zoom Out", "Zoom out horizontally", "View", 0); info.addDefaultKeypress ('-', cmd); break;
        case zoomFit:           info.setInfo ("Zoom to Fit", "Show the whole song", "View", 0); info.addDefaultKeypress ('0', cmd); break;
        case toggleBrowser:     info.setInfo ("Show/Hide Browser", "Toggle the browser panel", "View", 0); info.addDefaultKeypress ('b', 0); break;
        case showEditor:        info.setInfo ("Show Editor", "Piano roll / step sequencer / audio editor", "View", 0); info.addDefaultKeypress ('e', 0); break;
        case showInstrument:    info.setInfo ("Show Instrument", "Instrument and effects of the selected track", "View", 0); info.addDefaultKeypress ('i', 0); break;
        case showMixer:         info.setInfo ("Show Mixer", "Faders, pan and effects for every track", "View", 0); info.addDefaultKeypress ('x', 0); break;

        case commandPalette:    info.setInfo ("Command Palette...", "Search every command, instrument and effect", "Tools", 0);
                                info.addDefaultKeypress ('p', cmd | shift); info.addDefaultKeypress (KeyPress::F1Key, 0); break;
        case musicalTyping:     info.setInfo ("Musical Typing", "Play notes with your computer keyboard (A-K = white keys, Z/X = octave)", "Tools", 0);
                                info.addDefaultKeypress ('k', cmd); info.setTicked (typingOn); break;
        case settings:          info.setInfo ("Settings...", "Audio device, MIDI controllers and plugins", "Tools", 0); info.addDefaultKeypress (',', cmd); break;
        case scanPlugins:       info.setInfo ("Scan for Plugins...", "Find your VST3, LV2 and LADSPA plugins", "Tools", 0); break;
        case shortcuts:         info.setInfo ("Keyboard Shortcuts", "List every shortcut", "Help", 0); break;
        case gettingStarted:    info.setInfo ("Getting Started", "A quick tour", "Help", 0); break;
        case about:             info.setInfo ("About Lodestone", "Version and credits", "Help", 0); break;
        case practiceMode:      info.setInfo ("Practice Mode", "Play your controllers and mic through any sound - no project, no tracks", "Tools", 0);
                                info.addDefaultKeypress ('p', cmd); info.setTicked (session.isPracticeMode()); break;
        default: break;
    }

    // in Practice mode the arrangement commands don't apply
    if (session.isPracticeMode())
    {
        static const std::set<CommandID> available { newProject, openProject, save, importFiles, importFolderProject, quit,
                                                     playStop, record, metronome, tapTempo, commandPalette, musicalTyping,
                                                     settings, scanPlugins, shortcuts, about, gettingStarted, practiceMode };
        if (available.count (id) == 0)
            info.setActive (false);

        if (id == playStop)     info.shortName = "Metronome Start / Stop";
        if (id == record)       info.shortName = "Record Practice";
        if (id == save)         info.shortName = "Save Project";
    }
}

void MainComponent::togglePractice()
{
    MessageManager::callAsync ([sp = SafePointer<MainComponent> (this)]
    {
        if (sp == nullptr)
            return;

        auto& s = sp->session;

        if (s.isPracticeMode())
        {
            s.leavePracticeMode();
            sp->status ("Back to \"" + s.getProjectName() + "\" - your practice setup is saved for next time");
        }
        else if (! s.enterPracticeMode())
        {
            sp->status ("Couldn't open Practice mode");
        }

        sp->commandManager.commandStatusChanged();
    });
}

void MainComponent::addTrackOfKind (int kind)
{
    session.edit_().getUndoManager().beginNewTransaction ("Add track");
    auto after = session.getSelectedTrack();
    te::AudioTrack* t = nullptr;

    switch (kind)
    {
        case 0: t = session.addTrackWithInstrument (InstrumentSpec::gm (0), {}, after); break;
        case 1: t = session.addTrackWithInstrument (InstrumentSpec::drums(), {}, after); break;
        case 2: t = session.addTrackWithInstrument (InstrumentSpec::synth ("Saw Lead"), {}, after); break;
        default: t = session.addTrack (TrackKind::audio, {}, after); break;
    }

    session.selectTrack (t);
}

bool MainComponent::perform (const InvocationInfo& info)
{
    using namespace CommandIDs;

    if (session.getEdit() == nullptr)
        return false;

    auto& edit = session.edit_();

    if (session.isPracticeMode())
    {
        switch (info.commandID)
        {
            case practiceMode:  togglePractice(); return true;
            case playStop:
            case metronome:     if (practiceView) practiceView->toggleMetronome(); return true;
            case record:        if (practiceView) practiceView->toggleRecording(); return true;
            case tapTempo:      session.tapTempo(); return true;
            case save:
                if (session.stashedProjectIsUntitled())
                    status ("Practice is saved automatically. To name your project, leave Practice (Ctrl+P) and press Ctrl+S.");
                else if (session.saveStashedProject())
                    status ("Saved \"" + session.getStashedProjectName() + "\"");
                session.savePracticeSetup();
                return true;

            case newProject: case openProject: case importFiles: case importFolderProject:
            {
                // these are about projects: go back to yours first, then do it
                auto id = info.commandID;
                MessageManager::callAsync ([sp = SafePointer<MainComponent> (this), id]
                {
                    if (sp == nullptr) return;
                    sp->session.leavePracticeMode();
                    sp->commandManager.invokeDirectly (id, true);
                });
                return true;
            }

            case quit: case commandPalette: case musicalTyping: case settings: case scanPlugins:
            case shortcuts: case gettingStarted: case about:
                break;      // as usual, below

            default:
                status ("Not available in Practice mode - press Ctrl+P to go back to your project");
                return true;
        }
    }

    switch (info.commandID)
    {
        case practiceMode:  togglePractice(); return true;
        case newProject:    confirmCloseIfUnsaved ([this] { session.newProject(); }); return true;
        case openProject:   doOpen(); return true;
        case save:          if (session.isUntitled()) doSaveAs(); else session.save(); return true;
        case saveAs:        doSaveAs(); return true;
        case importFiles:   doImport (false); return true;
        case importFolderProject: doImport (true); return true;
        case exportAudio:   doExport (0); return true;
        case exportStems:   doExport (1); return true;
        case exportMidi:    doExport (2); return true;
        case exportDawProject: doExport (3); return true;
        case quit:          JUCEApplication::getInstance()->systemRequestedQuit(); return true;

        case undo:          edit.undo(); status ("Undo"); return true;
        case redo:          edit.redo(); status ("Redo"); return true;
        case cut:           ClipActions::cutSelected (session); return true;
        case copy:          ClipActions::copySelected (session); return true;
        case paste:         ClipActions::paste (session); return true;
        case duplicate:     ClipActions::duplicateSelected (session); return true;
        case deleteSelection: ClipActions::deleteSelected (session); return true;
        case selectAll:     ClipActions::selectAll (session); return true;
        case split:         ClipActions::splitSelectedAtPlayhead (session); return true;
        case quantize:      ClipActions::quantizeSelected (session, session.getView().snapDivision.get(), 1.0f); return true;
        case renameClip:    ClipActions::renameSelected (session); return true;
        case nudgeLeft:     ClipActions::nudgeSelected (session, -session.getView().snapDivision.get()); return true;
        case nudgeRight:    ClipActions::nudgeSelected (session, session.getView().snapDivision.get()); return true;

        case newInstrumentTrack: addTrackOfKind (0); return true;
        case newDrumTrack:  addTrackOfKind (1); return true;
        case newSynthTrack: addTrackOfKind (2); return true;
        case newAudioTrack: addTrackOfKind (3); return true;
        case duplicateTrack: if (auto t = session.getSelectedTrack()) { edit.getUndoManager().beginNewTransaction(); session.duplicateTrack (*t); } return true;
        case deleteTrack:   if (auto t = session.getSelectedTrack()) { edit.getUndoManager().beginNewTransaction ("Delete track"); session.deleteTrack (*t); } return true;

        case playStop:      session.togglePlay(); return true;
        case record:        session.toggleRecord(); return true;
        case loop:          { auto& tc = edit.getTransport(); tc.looping = ! tc.looping.get(); } if (transport) transport->refresh(); return true;
        case metronome:     edit.clickTrackEnabled = ! edit.clickTrackEnabled.get(); if (transport) transport->refresh();
                            status (edit.clickTrackEnabled.get() ? "Metronome on" : "Metronome off"); return true;
        case goToStart:     session.goToStart(); return true;
        case tapTempo:      session.tapTempo(); if (transport) transport->refresh(); return true;
        case toggleSnap:    session.getView().snapOn = ! session.getView().snapOn.get(); if (transport) transport->refresh();
                            status (session.getView().snapOn.get() ? "Snap on" : "Snap off"); return true;
        case loopSelection: ClipActions::setLoopToSelection (session); return true;

        case zoomIn:        if (arrangement) arrangement->zoomBy (1.4, session.getPlayheadBeat()); return true;
        case zoomOut:       if (arrangement) arrangement->zoomBy (1.0 / 1.4, session.getPlayheadBeat()); return true;
        case zoomFit:       if (arrangement) arrangement->zoomToFit(); return true;
        case toggleBrowser: browserVisible = ! browserVisible; resized(); return true;
        case showEditor:    showBottomTab (0); return true;
        case showInstrument: showBottomTab (1); return true;
        case showMixer:     showBottomTab (2); return true;

        case commandPalette: showCommandPalette(); return true;
        case musicalTyping:
            typingOn = ! typingOn;
            if (transport) transport->setKeyboardActive (typingOn);
            if (practiceView) practiceView->setKeyboardActive (typingOn);
            status (typingOn ? "Musical typing ON: A W S E D F T G Y H U J K play notes, Z/X change octave, C/V velocity"
                                  : "Musical typing off - letter keys are shortcuts again");
            grabKeyboardFocus();
            commandManager.commandStatusChanged();
            return true;
        case settings:      showSettings (0); return true;
        case scanPlugins:   showSettings (2); return true;
        case shortcuts:     showShortcuts(); return true;
        case gettingStarted: showGettingStarted(); return true;
        case about:         showAbout(); return true;
        default: break;
    }

    return false;
}

StringArray MainComponent::getMenuBarNames()
{
    return { "File", "Edit", "Track", "Transport", "View", "Tools", "Help" };
}

PopupMenu MainComponent::getMenuForIndex (int index, const String&)
{
    using namespace CommandIDs;
    PopupMenu m;
    auto add = [&m, this] (CommandID id) { m.addCommandItem (&commandManager, id); };

    switch (index)
    {
        case 0:
        {
            add (newProject); add (openProject);

            PopupMenu recent;
            for (auto& f : session.getRecentFiles())
                recent.addItem (File (f).getFileNameWithoutExtension(), [this, f] { openFile (File (f)); });
            if (recent.getNumItems() == 0)
                recent.addItem ("(none yet)", false, false, [] {});
            m.addSubMenu ("Open Recent", recent);

            m.addSeparator(); add (save); add (saveAs);
            m.addSeparator(); add (importFiles); add (importFolderProject);
            m.addSeparator(); add (exportAudio); add (exportStems); add (exportMidi); add (exportDawProject);
            m.addSeparator(); add (quit);
            break;
        }
        case 1:
            add (undo); add (redo); m.addSeparator();
            add (cut); add (copy); add (paste); add (duplicate); add (deleteSelection); m.addSeparator();
            add (selectAll); add (split); add (quantize); add (renameClip); add (nudgeLeft); add (nudgeRight);
            break;
        case 2:
            add (newInstrumentTrack); add (newDrumTrack); add (newSynthTrack); add (newAudioTrack);
            m.addSeparator(); add (duplicateTrack); add (deleteTrack);
            break;
        case 3:
            add (playStop); add (record); add (goToStart); m.addSeparator();
            add (loop); add (loopSelection); add (metronome); add (tapTempo); add (toggleSnap);
            break;
        case 4:
            add (zoomIn); add (zoomOut); add (zoomFit); m.addSeparator();
            add (toggleBrowser); add (showEditor); add (showInstrument); add (showMixer);
            break;
        case 5:
            add (practiceMode); m.addSeparator();
            add (commandPalette); add (musicalTyping); m.addSeparator(); add (settings); add (scanPlugins);
            break;
        case 6:
            add (gettingStarted); add (shortcuts); m.addSeparator(); add (about);
            break;
        default: break;
    }

    return m;
}

//==============================================================================
bool MainComponent::confirmCloseIfUnsaved (std::function<void()> continuation)
{
    if (session.isPracticeMode())
        session.leavePracticeMode();     // saves the practice setup; the question below is about your project

    if (session.getEdit() == nullptr || ! session.hasUnsavedChanges())
    {
        // tidy away untouched untitled projects so ~/Music/Lodestone doesn't fill with empties
        if (session.getEdit() != nullptr && session.isUntitled())
        {
            bool hasClips = false;
            for (auto t : te::getAudioTracks (session.edit_()))
                if (! t->getClips().isEmpty())
                    hasClips = true;

            auto dir = session.getProjectFile().getParentDirectory();
            auto files = dir.findChildFiles (File::findFilesAndDirectories, true, "*", File::FollowSymlinks::no);
            bool onlyOurs = true;
            for (auto& f : files)
                if (f.getFileExtension() != ".lodestone" && ! f.getFileName().endsWith (".autosave"))
                    onlyOurs = false;

            if (! hasClips && onlyOurs && dir.isAChildOf (getDefaultProjectsDir()))
                dir.deleteRecursively();
        }

        continuation();
        return true;
    }

    auto options = MessageBoxOptions()
                       .withIconType (MessageBoxIconType::QuestionIcon)
                       .withTitle ("Save changes?")
                       .withMessage ("\"" + session.getProjectName() + "\" has unsaved changes.")
                       .withButton ("Save", 1)
                       .withButton ("Don't Save", 2)
                       .withButton ("Cancel", 0)
                       .withAssociatedComponent (this);

    AlertWindow::showAsync (options, [this, continuation] (int result)
    {
        if (result == 1)
        {
            if (session.isUntitled())
                doSaveAs (continuation);
            else if (session.save())
                continuation();
        }
        else if (result == 2)
        {
            session.edit_().resetChangedStatus();
            continuation();
        }
    });

    return false;
}

void MainComponent::openFile (const File& f)
{
    // always async: the caller may be a component that's about to be rebuilt
    MessageManager::callAsync ([this, f]
    {
        confirmCloseIfUnsaved ([this, f] { ProjectIO::openAnyFile (session, f); });
    });
}

void MainComponent::doOpen()
{
    chooser = std::make_unique<FileChooser> ("Open a project (Lodestone, LMMS, FL Studio, GarageBand, DAWproject, MIDI)",
                                             getDefaultProjectsDir(), ProjectIO::getOpenFileWildcard());
    chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles,
                          [this] (const FileChooser& fc)
                          {
                              auto f = fc.getResult();
                              if (f.exists())
                                  openFile (f);
                          });
}

void MainComponent::doImport (bool folders)
{
    if (folders)
    {
        chooser = std::make_unique<FileChooser> ("Choose a GarageBand (.band) or Logic (.logicx) project folder",
                                                 File::getSpecialLocation (File::userHomeDirectory), "*");
        chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectDirectories | FileBrowserComponent::canSelectFiles,
                              [this] (const FileChooser& fc)
                              {
                                  auto f = fc.getResult();
                                  if (f.exists())
                                      openFile (f);
                              });
        return;
    }

    chooser = std::make_unique<FileChooser> ("Import audio or MIDI files", File::getSpecialLocation (File::userMusicDirectory),
                                             "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3;*.mid;*.midi");
    chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles | FileBrowserComponent::canSelectMultipleItems,
                          [this] (const FileChooser& fc)
                          {
                              StringArray paths;
                              for (auto& f : fc.getResults())
                                  paths.add (f.getFullPathName());

                              if (! paths.isEmpty() && arrangement != nullptr)
                                  arrangement->addFilesAt (paths, session.getSelectedTrack(), session.getPlayheadBeat());
                          });
}

void MainComponent::doSaveAs (std::function<void()> after)
{
    chooser = std::make_unique<FileChooser> ("Save project as", getDefaultProjectsDir().getChildFile (session.getProjectName()), "*.lodestone");
    chooser->launchAsync (FileBrowserComponent::saveMode | FileBrowserComponent::canSelectFiles | FileBrowserComponent::warnAboutOverwriting,
                          [this, after] (const FileChooser& fc)
                          {
                              auto f = fc.getResult();
                              if (f == File())
                                  return;

                              if (session.saveAs (f) && after)
                                  after();
                          });
}

void MainComponent::doExport (int kind)
{
    auto& edit = session.edit_();

    if (kind == 2)
    {
        chooser = std::make_unique<FileChooser> ("Export MIDI", getDefaultProjectsDir().getChildFile (session.getProjectName() + ".mid"), "*.mid");
        chooser->launchAsync (FileBrowserComponent::saveMode | FileBrowserComponent::canSelectFiles | FileBrowserComponent::warnAboutOverwriting,
                              [this] (const FileChooser& fc)
                              {
                                  auto f = fc.getResult().withFileExtension ("mid");
                                  if (fc.getResult() != File())
                                      status (ProjectIO::exportMidi (session, f) ? "Exported " + f.getFileName() : String ("MIDI export failed"));
                              });
        return;
    }

    if (kind == 3)
    {
        chooser = std::make_unique<FileChooser> ("Export DAWproject", getDefaultProjectsDir().getChildFile (session.getProjectName() + ".dawproject"), "*.dawproject");
        chooser->launchAsync (FileBrowserComponent::saveMode | FileBrowserComponent::canSelectFiles | FileBrowserComponent::warnAboutOverwriting,
                              [this] (const FileChooser& fc)
                              {
                                  if (fc.getResult() == File())
                                      return;

                                  auto f = fc.getResult().withFileExtension ("dawproject");
                                  String error;
                                  status (ProjectIO::exportDawProject (session, f, error) ? "Exported " + f.getFileName() + " - open it in Bitwig, Studio One or Cubase"
                                                                                          : "DAWproject export failed: " + error);
                              });
        return;
    }

    if (edit.getLength() <= TD (0.01))
    {
        status ("Nothing to export yet - add some clips first");
        return;
    }

    launchDialog (kind == 1 ? "Export Stems" : "Export Song",
                  std::make_unique<ExportComponent> (session, kind, [this, kind] (ProjectIO::AudioExportOptions o)
                  {
                      auto ext = o.format == "flac" ? "flac" : (o.format == "ogg" ? "ogg" : "wav");

                      if (kind == 1)
                      {
                          chooser = std::make_unique<FileChooser> ("Choose a folder for the stems", getDefaultProjectsDir());
                          chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectDirectories,
                                                [this, o] (const FileChooser& fc)
                                                {
                                                    auto dir = fc.getResult();
                                                    if (dir == File())
                                                        return;

                                                    auto folder = dir.getChildFile (session.getProjectName() + " stems");
                                                    auto n = ProjectIO::exportStems (session, folder, o);
                                                    status ("Exported " + String (n) + " stems to " + folder.getFullPathName());
                                                });
                          return;
                      }

                      chooser = std::make_unique<FileChooser> ("Export song", getDefaultProjectsDir().getChildFile (session.getProjectName() + "." + ext), String ("*.") + ext);
                      chooser->launchAsync (FileBrowserComponent::saveMode | FileBrowserComponent::canSelectFiles | FileBrowserComponent::warnAboutOverwriting,
                                            [this, o, ext] (const FileChooser& fc)
                                            {
                                                if (fc.getResult() == File())
                                                    return;

                                                auto f = fc.getResult().withFileExtension (ext);
                                                status (ProjectIO::exportMixdown (session, f, o) ? "Exported " + f.getFullPathName() : String ("Export failed"));
                                            });
                  }),
                  this, false);
}

void MainComponent::showSettings (int tab)
{
    launchDialog ("Lodestone Settings", std::make_unique<SettingsComponent> (session, tab), this);
}

void MainComponent::showCommandPalette()
{
    Array<CommandPalette::Entry> entries;

    Array<CommandID> ids;
    getAllCommands (ids);
    for (auto id : ids)
    {
        if (id == CommandIDs::commandPalette)
            continue;

        ApplicationCommandInfo info (id);
        getCommandInfo (id, info);
        auto keys = commandManager.getKeyMappings()->getKeyPressesAssignedToCommand (id);
        entries.add ({ info.shortName, keys.isEmpty() ? info.categoryName : keys.getFirst().getTextDescriptionWithIcons(),
                       [this, id] { commandManager.invokeDirectly (id, false); } });
    }

    for (auto& e : BrowserItems::getAllEntries (session.engine))
    {
        auto isFx = BrowserItems::isEffect (e.description);
        entries.add ({ (isFx ? "Add effect: " : "New track: ") + e.name, e.category,
                       [this, d = e.description, isFx]
                       {
                           session.edit_().getUndoManager().beginNewTransaction ("Command palette");
                           BrowserItems::applyToTrack (session, d, isFx ? session.getSelectedTrack() : nullptr, true);
                       } });
    }

    for (auto& f : session.getRecentFiles())
        entries.add ({ "Open: " + File (f).getFileNameWithoutExtension(), "Recent project", [this, f] { openFile (File (f)); } });

    auto palette = std::make_shared<std::unique_ptr<CommandPalette>> (std::make_unique<CommandPalette> (entries));
    auto* p = palette->get();
    p->setBounds (getLocalBounds().withSizeKeepingCentre (640, 440).withY (90));
    p->onClose = [this, palette]
    {
        palette->reset();
        grabKeyboardFocus();
    };
    addAndMakeVisible (p);
    p->toFront (true);
    p->setVisible (true);
}

void MainComponent::showShortcuts()
{
    Array<CommandID> ids;
    getAllCommands (ids);
    String text;
    String lastCat;

    for (auto id : ids)
    {
        ApplicationCommandInfo info (id);
        getCommandInfo (id, info);
        auto keys = commandManager.getKeyMappings()->getKeyPressesAssignedToCommand (id);
        if (keys.isEmpty())
            continue;

        if (info.categoryName != lastCat)
        {
            text << "\n" << info.categoryName.toUpperCase() << "\n";
            lastCat = info.categoryName;
        }

        text << "  " << keys.getFirst().getTextDescription().paddedRight (' ', 18) << info.shortName << "\n";
    }

    text << "\nMOUSE\n"
         << "  Ctrl + wheel          Zoom the timeline / piano roll\n"
         << "  Shift + wheel         Scroll sideways\n"
         << "  Ctrl + drag clip      Duplicate it\n"
         << "  Shift + drag          Move without snapping\n"
         << "  Double-click track    New clip (instrument tracks)\n"
         << "  Right-click note      Delete it (piano roll)\n"
         << "\nMUSICAL TYPING (Ctrl+K)\n"
         << "  A W S E D F T G Y H U J K   notes (C to C)\n"
         << "  Z / X                       octave down / up\n"
         << "  C / V                       velocity down / up\n";

    auto editor = std::make_unique<TextEditor>();
    editor->setMultiLine (true);
    editor->setReadOnly (true);
    editor->setFont (FontOptions (Font::getDefaultMonospacedFontName(), 13.0f, Font::plain));
    editor->setText (text.trim());
    editor->setSize (560, 640);
    launchDialog ("Keyboard Shortcuts", std::move (editor), this);
}

void MainComponent::showGettingStarted()
{
    auto text = String (
        "Welcome to Lodestone!\n\n"
        "1. PLAY SOMETHING. Plug in your MIDI keyboard or pad controller - it plays the selected track straight away. "
        "No controller? Press Ctrl+K and use your computer keyboard.\n\n"
        "2. ADD SOUNDS. Use + Track, or drag anything from the browser on the left (drum kits, 128 General MIDI "
        "instruments, synth presets, your plugins) into the arrangement.\n\n"
        "3. MAKE CLIPS. Double-click an empty spot on an instrument track. Draw notes in the piano roll; drum tracks "
        "open the step sequencer (right-click a sound for Euclidean rhythms).\n\n"
        "4. RECORD. Press R. If nothing is armed, the selected track is armed for you. Set a count-in in the transport bar.\n\n"
        "5. DRUMS FROM MIDI. Drum tracks are a 16-pad sampler mapped like an MPD218's default preset (pad 1 = note 36). Hit 'Learn note' on a "
        "pad then hit your controller to remap. Hold 'Hold to Sample' to record your mic straight into a pad.\n\n"
        "6. BRING YOUR OLD PROJECTS. File > Open imports LMMS (.mmp/.mmpz), FL Studio (.flp), GarageBand (.band), "
        "Logic (.logicx), DAWproject and MIDI files.\n\n"
        "7. FINISH. File > Export Song renders WAV/FLAC/OGG; Export Stems gives one file per track.\n\n"
        "8. JUST PRACTICE. Ctrl+P (or Practice in the toolbar) opens Practice mode: pick which controller plays which "
        "sound - no tracks - with splits, layers, effects, your mic with a tuner, hold-to-sample, a metronome, a recorder "
        "and 'Save what I played' for when something good happens.\n\n"
        "Lost? Press F1 and type what you want to do.");

    auto editor = std::make_unique<TextEditor>();
    editor->setMultiLine (true);
    editor->setReadOnly (true);
    editor->setFont (LodeLookAndFeel::font (14.5f));
    editor->setText (text);
    editor->setSize (620, 560);
    launchDialog ("Getting Started", std::move (editor), this);
}

void MainComponent::showAbout()
{
    auto text = String ("Lodestone ") + LODESTONE_VERSION + "\n"
        "A friendly, open-source digital audio workstation for Linux.\n"
        "Licensed under the GNU AGPL v3 (or later).\n\n"
        "Built with:\n"
        "  Tracktion Engine (GPLv3) - audio engine\n"
        "  JUCE 9 (AGPLv3) - UI and plugin hosting (VST3, LV2, LADSPA)\n"
        "  Airwindows effects by Chris Johnson (MIT)\n"
        "  FluidSynth (LGPL-2.1) and the FluidR3 GM SoundFont (MIT)\n"
        "  SoundTouch (LGPL-2.1) and Signalsmith Stretch (MIT) - time stretching\n"
        "  logicx by Jon Kubis (MIT) - GarageBand/Logic project reading\n"
        "  DrumSynth by Paul Kellett, via LMMS (GPL-2.0+) - LMMS .ds drum sounds\n\n"
        "Drum kits are synthesized by Lodestone itself and are public domain (CC0).\n\n"
        "Engine: Tracktion Engine " + te::Engine::getVersion();

    alert (MessageBoxIconType::InfoIcon, "About Lodestone", text, "Rock on");
}

//==============================================================================
// MainWindow
//==============================================================================
MainWindow::MainWindow (Session& s, LodeUIBehaviour& ui)
    : DocumentWindow ("Lodestone", Col::bg1, DocumentWindow::allButtons)
{
    setUsingNativeTitleBar (true);
    main = std::make_unique<MainComponent> (s, ui);
    setMenuBar (main.get(), 26);
    setContentNonOwned (main.get(), true);
    addKeyListener (main->commandManager.getKeyMappings());
    setResizable (true, false);
    setResizeLimits (900, 600, 10000, 10000);

    auto area = Desktop::getInstance().getDisplays().getPrimaryDisplay() != nullptr
                    ? Desktop::getInstance().getDisplays().getPrimaryDisplay()->userBounds.toNearestInt()
                    : Rectangle<int> (0, 0, 1440, 900);
    setBounds (area.reduced (jmax (0, area.getWidth() - 1600) / 2, jmax (0, area.getHeight() - 1000) / 2).reduced (20));
    setVisible (true);
    main->grabKeyboardFocus();
}

MainWindow::~MainWindow()
{
    setMenuBar (nullptr);
    clearContentComponent();
    main.reset();
}

void MainWindow::closeButtonPressed()
{
    JUCEApplication::getInstance()->systemRequestedQuit();
}

} // namespace lode
