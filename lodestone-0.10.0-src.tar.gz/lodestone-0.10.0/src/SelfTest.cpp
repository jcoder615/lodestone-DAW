/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "SelfTest.h"
#include "MainWindow.h"
#include "PracticeView.h"
#include "DrumMachinePlugin.h"
#include "Practice.h"

namespace lode
{
using namespace juce;

namespace
{
    /** Runs a list of steps on the message thread; a step returns true when it's done. */
    class PracticeSelfTest : private Timer
    {
    public:
        PracticeSelfTest (MainComponent& m, std::function<void (int)> d)
            : main (m), session (m.session), done (std::move (d))
        {
            buildSteps();
            stepStart = now();
            startTimer (20);
        }

    private:
        MainComponent& main;
        Session& session;
        std::function<void (int)> done;
        std::vector<std::pair<String, std::function<bool()>>> steps;
        size_t current = 0;
        double stepStart = 0.0;
        int failures = 0, passes = 0;

        te::Edit* projectEdit = nullptr;
        int projectTracks = 0;
        te::SafeSelectable<te::AudioTrack> piano, synth, mic;   // weak: they belong to the practice edit
        double metronomeBeatBase = 0.0;
        int nextBeatNote = 0;
        std::vector<int> pendingOffs;
        bool heard440 = false;
        Array<te::EditItemID> projectKeyboardTargets;
        float bestHz = 0.0f;
        int masterHits = 0;
        float quietPeak = 0.0f;

        static double now()     { return Time::getMillisecondCounterHiRes() * 0.001; }
        double elapsed() const  { return now() - stepStart; }

        void check (bool ok, const String& what)
        {
            std::cout << (ok ? "  PASS  " : "  FAIL  ") << what << std::endl;
            (ok ? passes : failures)++;
        }

        PracticeController* pc()
        {
            auto v = main.getPracticeView();
            return v != nullptr ? &v->getController() : nullptr;
        }

        void key (int note, bool on, int vel = 100)
        {
            if (auto v = main.getPracticeView())
                v->playKey (note, on, vel);
        }

        te::AudioTrack* slotNamed (const String& prefix)
        {
            if (auto c = pc())
                for (auto t : c->getSlots())
                    if (t->getName().startsWith (prefix))
                        return t;
            return nullptr;
        }

        float masterPeak()
        {
            auto c = pc();
            auto tap = c != nullptr ? c->getMasterTap() : nullptr;
            return tap != nullptr ? tap->getPeakAndReset() : 0.0f;
        }

        void step (const String& name, std::function<bool()> fn)    { steps.push_back ({ name, std::move (fn) }); }
        void wait (double seconds)                                  { step ("wait", [this, seconds] { return elapsed() >= seconds; }); }

        void timerCallback() override
        {
            if (current >= steps.size())
            {
                stopTimer();
                std::cout << "\n" << passes << " passed, " << failures << " failed" << std::endl;
                auto cb = done;
                auto result = failures == 0 ? 0 : 1;
                MessageManager::callAsync ([cb, result] { cb (result); });
                delete this;
                return;
            }

            if (elapsed() > 25.0)
            {
                check (false, "step timed out: " + steps[current].first);
                ++current;
                stepStart = now();
                return;
            }

            if (steps[current].second())
            {
                ++current;
                stepStart = now();
            }
        }

        //==============================================================================
        void buildSteps()
        {
            step ("pure functions", [this]
            {
                const double sr = 48000.0;

                // tuner: guitar low E, A2, A4, a high C, and a voice-like harmonic-rich tone
                for (auto f : { 82.41f, 110.0f, 440.0f, 1046.5f })
                {
                    std::vector<float> x (4096);
                    for (size_t i = 0; i < x.size(); ++i)
                        x[i] = 0.5f * std::sin (MathConstants<float>::twoPi * f * (float) i / (float) sr)
                             + 0.2f * std::sin (MathConstants<float>::twoPi * 2.0f * f * (float) i / (float) sr)
                             + 0.1f * std::sin (MathConstants<float>::twoPi * 3.0f * f * (float) i / (float) sr);
                    float clarity = 0.0f;
                    auto hz = PitchDetector::detect (x.data(), (int) x.size(), sr, clarity);
                    check (std::abs (hz - f) / f < 0.003f && clarity > 0.9f,
                           "pitch of a " + String (f, 1) + " Hz tone: " + String (hz, 2) + " Hz (clarity " + String (clarity, 2) + ")");
                }

                {
                    std::vector<float> noise (4096);
                    Random r (1);
                    for (auto& v : noise) v = (r.nextFloat() - 0.5f) * 0.2f;
                    float clarity = 0.0f;
                    auto hz = PitchDetector::detect (noise.data(), (int) noise.size(), sr, clarity);
                    check (hz == 0.0f || clarity < 0.85f, "noise doesn't show a confident pitch");
                }

                // slicing: five drum-like hits at known places
                {
                    AudioBuffer<float> b (2, (int) (sr * 2.0));
                    b.clear();
                    Random r (2);
                    const double hits[] = { 0.0, 0.31, 0.62, 1.1, 1.5 };
                    for (auto h : hits)
                        for (int i = 0; i < (int) (sr * 0.15); ++i)
                        {
                            auto v = (r.nextFloat() - 0.5f) * std::exp (-(float) i / (float) (sr * 0.03));
                            b.setSample (0, (int) (h * sr) + i, v);
                            b.setSample (1, (int) (h * sr) + i, v);
                        }

                    auto starts = findSlicePoints (b, sr, 16);
                    String list;
                    bool allClose = starts.size() == 5;
                    for (int i = 0; i < starts.size(); ++i)
                    {
                        list << String (starts[i] * 2.0, 3) << " ";
                        if (i < 5) allClose = allClose && std::abs (starts[i] * 2.0 - hits[i]) < 0.015;
                    }
                    check (allClose, "slices land on the 5 hits: " + list);
                }

                // activity: room hiss with a sung bit in the middle
                {
                    AudioBuffer<float> b (2, (int) (sr * 4.0));
                    Random r (3);
                    for (int i = 0; i < b.getNumSamples(); ++i)
                    {
                        float v = (r.nextFloat() - 0.5f) * 0.004f;    // about -57 dBFS RMS
                        if (i > sr * 1.5 && i < sr * 2.5)
                            v += 0.3f * std::sin (MathConstants<float>::twoPi * 220.0f * (float) i / (float) sr);
                        b.setSample (0, i, v);
                        b.setSample (1, i, v);
                    }

                    auto a = findActivity (b, sr);
                    check (std::abs (a.getStart() / sr - 1.5) < 0.06 && std::abs (a.getEnd() / sr - 2.5) < 0.06,
                           "activity found under the hiss: " + String (a.getStart() / sr, 2) + "-" + String (a.getEnd() / sr, 2) + " s");

                    b.clear (0, (int) (sr * 1.5), (int) (sr * 1.0));   // just hiss now
                    for (int i = (int) (sr * 1.5); i < (int) (sr * 2.5); ++i)
                        for (int ch = 0; ch < 2; ++ch)
                            b.setSample (ch, i, (r.nextFloat() - 0.5f) * 0.004f);
                    check (findActivity (b, sr).isEmpty(), "plain room hiss isn't counted as playing");
                }

                return true;
            });

            step ("audio device", [this]
            {
                auto* d = session.engine.getDeviceManager().deviceManager.getCurrentAudioDevice();
                if (d == nullptr)
                    return elapsed() > 5.0 ? (check (false, "an audio device is open"), true) : false;

                std::cout << "Audio: " << d->getTypeName() << " / " << d->getName() << ", " << d->getCurrentSampleRate()
                          << " Hz, " << d->getCurrentBufferSizeSamples() << " samples, "
                          << d->getActiveInputChannels().countNumberOfSetBits() << " in / "
                          << d->getActiveOutputChannels().countNumberOfSetBits() << " out" << std::endl;
                check (true, "an audio device is open");
                return true;
            });

            step ("dirty the project, enter practice", [this]
            {
                if (elapsed() < 1.5) return false;
                projectEdit = session.getEdit();

                for (auto* inst : projectEdit->getAllInputDevices())
                {
                    std::cout << "        project input: " << inst->getInputDevice().getName() << " type " << (int) inst->getInputDevice().getDeviceType()
                              << " targets " << inst->getTargets().size() << std::endl;
                    if (inst->getInputDevice().getName() == "Computer Keyboard")
                        projectKeyboardTargets = inst->getTargets();
                }

                if (auto sel = session.getSelectedTrack())
                    std::cout << "        selected: " << sel->getName() << std::endl;

                session.addTrack (TrackKind::audio, "Self-test marker");
                projectTracks = te::getAudioTracks (*projectEdit).size();
                main.togglePractice();
                return true;
            });

            step ("practice is up", [this] { return session.isPracticeMode() && main.getPracticeView() != nullptr && elapsed() > 0.5; });

            step ("default sounds", [this]
            {
                auto c = pc();
                check (session.getEdit() != projectEdit, "practice uses its own edit");
                check (c->getSlots().size() >= 3, "default sounds exist (" + String (c->getSlots().size()) + ")");
                piano = slotNamed ("Grand Piano");
                mic = slotNamed ("Mic");
                check (piano != nullptr && PracticeController::getZone (*piano) != nullptr, "Grand Piano with a key zone");
                check (slotNamed ("Drums") != nullptr && Session::getDrumMachine (*slotNamed ("Drums")) != nullptr, "Drums with the drum machine");
                check (mic != nullptr && PracticeController::getTap (*mic) != nullptr, "Mic with an input tap");
                check (c->getMasterTap() != nullptr, "master tap on the master chain");

                bool routed = false;
                for (auto* inst : session.edit_().getAllInputDevices())
                    if (inst->getInputDevice().getName() == "Computer Keyboard" && piano != nullptr)
                        routed = inst->getTargets().contains (piano->itemID);
                check (routed, "the computer keyboard plays Grand Piano (no track selected or armed)");
                check (c->getCurrentInputChoice (*mic) >= 0, "Mic has an input: "
                         + (c->getCurrentInputChoice (*mic) >= 0 ? c->getInputChoices()[c->getCurrentInputChoice (*mic)].label : String ("none")));
                masterPeak();
                return true;
            });

            step ("plug in a pad controller", [this]
            {
                auto& dm = session.engine.getDeviceManager();
                dm.createVirtualMidiDevice ("MPD218 Test Pads");
                dm.dispatchPendingUpdates();
                return true;
            });
            step ("it lands on the drums", [this]
            {
                auto drums = slotNamed ("Drums");
                if (! pc()->getSlotControllers (*drums).contains ("MPD218 Test Pads"))
                    return elapsed() > 6.0 ? (check (false, "a new pad controller is put on Drums by itself"), true) : false;

                check (true, "a new pad controller is put on Drums by itself");
                check (! pc()->getSlotControllers (*piano).contains ("MPD218 Test Pads"), "...and not on the piano");

                bool routed = false;
                for (auto* inst : session.edit_().getAllInputDevices())
                    if (inst->getInputDevice().getName() == "MPD218 Test Pads")
                        routed = inst->getTargets().contains (drums->itemID) && ! inst->getTargets().contains (piano->itemID);
                check (routed, "...and routed there");

                for (auto& m : session.engine.getDeviceManager().getMidiInDevices())
                    if (m->getName() == "MPD218 Test Pads")
                        if (auto v = dynamic_cast<te::VirtualMidiInputDevice*> (m.get()))
                            v->handleIncomingMidiMessage (MidiMessage::noteOn (10, 36, (uint8) 110), v->getMPESourceID());
                return true;
            });
            step ("pad hit", [this]
            {
                if (elapsed() < 0.3) return false;
                check (pc()->getHeldKeys (*slotNamed ("Drums")).contains (36), "pad 1 (note 36, channel 10) hits the drums");
                check (! pc()->getHeldKeys (*piano).contains (36), "...and not the piano");

                for (auto& m : session.engine.getDeviceManager().getMidiInDevices())
                    if (m->getName() == "MPD218 Test Pads")
                        if (auto v = dynamic_cast<te::VirtualMidiInputDevice*> (m.get()))
                            v->handleIncomingMidiMessage (MidiMessage::noteOff (10, 36), v->getMPESourceID());
                return true;
            });

            step ("play a chord", [this] { key (60, true); key (64, true); key (67, true); return true; });
            step ("chord sounds", [this]
            {
                if (masterPeak() > 0.01f) ++masterHits;
                if (elapsed() < 0.6) return false;
                auto held = pc()->getHeldKeys (*piano);
                check (held.contains (60) && held.contains (64) && held.contains (67), "the zone saw C E G held");
                check (masterHits > 0, "the piano makes sound on the master");
                key (60, false); key (64, false); key (67, false);
                return true;
            });

            // ---- splits, layers, transpose
            step ("split the keyboard", [this]
            {
                auto c = pc();
                auto ctrls = c->getSlotControllers (*piano);
                synth = c->addInstrumentSlot (InstrumentSpec::synth ("Saw Lead"), "Lead", ctrls);
                check (synth != nullptr, "added a second sound on the same controllers");
                PracticeController::getZone (*piano)->setRange (0, 59);
                PracticeController::getZone (*synth)->setRange (60, 127);
                PracticeController::getZone (*synth)->setTranspose (12);
                return true;
            });
            wait (0.3);
            step ("play both halves", [this] { key (50, true); key (72, true); return true; });
            step ("each half plays its sound", [this]
            {
                if (elapsed() < 0.4) return false;
                auto p = pc()->getHeldKeys (*piano), s = pc()->getHeldKeys (*synth);
                check (p.contains (50) && ! p.contains (72), "the low key went to Grand Piano only");
                check (s.contains (72) && ! s.contains (50), "the high key went to Lead only");
                key (50, false); key (72, false);
                return true;
            });
            step ("keys released", [this]
            {
                if (elapsed() < 0.3) return false;
                check (pc()->getHeldKeys (*piano).isEmpty() && pc()->getHeldKeys (*synth).isEmpty(), "no stuck notes after release");
                // change the zone while a key is held, then release: still no stuck note
                key (55, true);
                return true;
            });
            step ("zone change while held", [this]
            {
                if (elapsed() < 0.2) return false;
                PracticeController::getZone (*piano)->setRange (0, 40);
                PracticeController::getZone (*piano)->setTranspose (5);
                return true;
            });
            step ("release after zone change", [this] { if (elapsed() < 0.2) return false; key (55, false); return true; });
            step ("no stuck note", [this]
            {
                if (elapsed() < 0.3) return false;
                check (pc()->getHeldKeys (*piano).isEmpty(), "note-off follows its note-on after a zone/transpose change");
                PracticeController::getZone (*piano)->setRange (0, 59);
                PracticeController::getZone (*piano)->setTranspose (0);
                return true;
            });

            // ---- metronome, recorder, and notes on the beat
            step ("metronome + recorder on", [this]
            {
                session.setTempo (120.0);
                pc()->setMetronome (true);
                check (pc()->startRecording(), "practice recorder starts");
                nextBeatNote = 0;
                return true;
            });
            step ("metronome runs", [this]
            {
                if (elapsed() < 2.0) return false;
                auto b = pc()->getBeat();
                check (pc()->isMetronomeOn(), "metronome transport is running");
                check (b > 3.0 && b < 5.0, "about 4 beats in 2 s at 120 BPM (" + String (b, 2) + ")");
                return true;
            });
            step ("play on beats 6..9", [this]
            {
                const double b = pc()->getBeat();

                for (auto it = pendingOffs.begin(); it != pendingOffs.end();)
                {
                    if (b > (*it >> 8) / 100.0) { key (*it & 0xff, false); it = pendingOffs.erase (it); }
                    else ++it;
                }

                if (nextBeatNote < 4 && b >= 6.0 + nextBeatNote)
                {
                    const int note = 48 + nextBeatNote;     // Grand Piano's half of the split
                    key (note, true, 90);
                    pendingOffs.push_back (note | (roundToInt ((b + 0.4) * 100.0) << 8));
                    ++nextBeatNote;
                }

                return nextBeatNote >= 4 && pendingOffs.empty() && b > 10.0;
            });
            step ("save the on-beat take", [this]
            {
                auto r = pc()->saveWhatIPlayed (4.0);
                check (r.ok, "saved: " + r.message);
                check (r.message.contains ("on the beat"), "the take is aligned to the metronome");

                if (r.ok)
                {
                    auto loaded = te::loadEditFromFile (session.engine, r.file);
                    check (loaded != nullptr, "the take project loads");

                    if (loaded != nullptr)
                    {
                        bool found = false;
                        for (auto t : te::getAudioTracks (*loaded))
                            for (auto c : t->getClips())
                                if (auto mc = dynamic_cast<te::MidiClip*> (c))
                                {
                                    auto& seq = mc->getSequence();
                                    String beats;
                                    double worst = 0.0;
                                    for (auto n : seq.getNotes())
                                    {
                                        auto b = n->getStartBeat().inBeats();
                                        beats << n->getNoteNumber() << "@" << String (b, 2) << " ";
                                        worst = jmax (worst, std::abs (b - std::round (b)));
                                    }

                                    if (seq.getNumNotes() == 4)
                                    {
                                        found = true;
                                        double firstBeat = 1.0e9;
                                        for (auto n : seq.getNotes())
                                            firstBeat = jmin (firstBeat, n->getStartBeat().inBeats());

                                        check (worst < 0.2, "notes land on the beat: " + beats);
                                        const double phase = std::fmod (firstBeat, 4.0);
                                        check (std::abs (phase - 2.0) < 0.2,
                                               "first note is on beat 3 of its bar, like it was against the click (beat "
                                                 + String (firstBeat, 2) + ")");
                                    }
                                }
                        check (found, "the take has the 4 notes I played");
                    }
                }
                return true;
            });
            step ("stop recorder + metronome", [this]
            {
                auto secs = pc()->getRecordingSeconds();
                auto f = pc()->stopRecording();
                pc()->setMetronome (false);
                check (f.existsAsFile(), "recording written: " + f.getFileName());
                check (secs > 4.0, "recording is " + String (secs, 1) + " s long");

                AudioFormatManager fm;
                fm.registerBasicFormats();
                if (auto reader = std::unique_ptr<AudioFormatReader> (fm.createReaderFor (f)))
                {
                    Range<float> ranges[2];
                    reader->readMaxLevels (0, reader->lengthInSamples, ranges, 2);
                    auto peak = jmax (std::abs (ranges[0].getStart()), std::abs (ranges[0].getEnd()));
                    check (peak > 0.01f, "the recording isn't silent (peak " + String (Decibels::gainToDecibels (peak), 1) + " dB)");
                }
                return true;
            });

            // ---- mic: tuner, sampling (needs the 440 Hz tone on input 1)
            step ("mic is receiving", [this]
            {
                auto tap = PracticeController::getTap (*mic);
                if (! tap->isReceivingAudio())
                    return elapsed() > 3.0 ? (check (false, "the mic input is being processed"), true) : false;

                check (true, "the mic input is being processed (monitoring off)");
                return true;
            });
            step ("tuner hears 440", [this]
            {
                auto tap = PracticeController::getTap (*mic);
                std::vector<float> buf (4096);
                tap->copyRecent (buf.data(), (int) buf.size());
                float clarity = 0.0f;
                auto hz = PitchDetector::detect (buf.data(), (int) buf.size(), tap->getSampleRate(), clarity);

                if (clarity > 0.9f && std::abs (hz - 440.0f) < std::abs (bestHz - 440.0f))
                    bestHz = hz;

                if (std::abs (hz - 440.0f) < 3.0f && clarity > 0.9f)
                    heard440 = true;

                if (! heard440 && elapsed() < 6.0)
                    return false;

                check (heard440, "the tuner reads A4 from the test tone (best " + String (bestHz, 1) + " Hz)");
                check (tap->getPeakAndReset() >= 0.0f, "meter readable");
                return true;
            });
            step ("monitoring off is silent", [this]
            {
                // the tone is on the mic input, but with monitoring off you don't hear it
                if (elapsed() < 0.1) { masterPeak(); quietPeak = 0.0f; return false; }
                quietPeak = jmax (quietPeak, masterPeak());
                if (elapsed() < 2.2) return false;
                check (quietPeak < 0.001f, "monitoring off: the mic isn't heard (master peak "
                                             + String (Decibels::gainToDecibels (quietPeak, -120.0f), 1) + " dB)");
                masterHits = 0;
                return true;
            });
            step ("monitor gate", [this]
            {
                pc()->setMonitoring (*mic, true);
                return true;
            });
            step ("monitor on is heard", [this]
            {
                if (masterPeak() > 0.05f) ++masterHits;
                if (elapsed() < 2.5) return false;
                check (masterHits > 0, "monitoring on: the mic reaches the master");
                pc()->setMonitoring (*mic, false);
                return true;
            });
            step ("hold to sample (keys)", [this] { check (pc()->startSampling (*mic), "sampling starts"); return true; });
            step ("release", [this]
            {
                if (elapsed() < 2.2) return false;
                pc()->noteSelected (synth.get());
                auto msg = pc()->stopSampling (*mic, false);
                std::cout << "        " << msg << std::endl;
                auto s = slotNamed ("Mic Sample");
                check (s != nullptr, "a Mic Sample sound was made");

                if (s != nullptr)
                {
                    auto sp = dynamic_cast<te::SamplerPlugin*> (Session::getInstrument (*s));
                    check (sp != nullptr && sp->getNumSounds() == 1, "it has the sample loaded");
                    if (sp != nullptr && sp->getNumSounds() > 0)
                        check (sp->getKeyNote (0) == 69, "root note found from the pitch: " + noteName (sp->getKeyNote (0)));

                    check (pc()->getSlotControllers (*s) == pc()->getSlotControllers (*synth), "it took over the controllers of the sound I'd selected");
                    check (synth->isMuted (false), "...and muted that one");
                }
                return true;
            });
            step ("hold to sample (pads)", [this] { pc()->startSampling (*mic); return true; });
            step ("release pads", [this]
            {
                if (elapsed() < 4.5) return false;
                auto msg = pc()->stopSampling (*mic, true);
                std::cout << "        " << msg << std::endl;
                auto s = slotNamed ("Chops");
                check (s != nullptr, "a Chops sound was made");
                if (auto dm = s != nullptr ? Session::getDrumMachine (*s) : nullptr)
                {
                    int pads = 0;
                    for (int i = 0; i < DrumMachinePlugin::numPads; ++i)
                        if (dm->padHasSample (i)) ++pads;
                    check (pads >= 2, String (pads) + " pads have slices");
                }
                return true;
            });

            // ---- the unaligned take: split + transpose + the mic audio
            step ("play split notes for the take", [this]
            {
                synth->setMute (false);
                key (52, true); key (76, true);
                return true;
            });
            step ("release split notes", [this] { if (elapsed() < 0.5) return false; key (52, false); key (76, false); return true; });
            step ("save the long take", [this]
            {
                if (elapsed() < 0.3) return false;
                auto r = pc()->saveWhatIPlayed (60.0);
                check (r.ok, "saved: " + r.message);

                if (auto loaded = r.ok ? te::loadEditFromFile (session.engine, r.file) : nullptr)
                {
                    bool transposed = false, gotAudio = false, gotPianoLow = false, plumbing = false;
                    for (auto t : te::getAudioTracks (*loaded))
                    {
                        for (auto c : t->getClips())
                        {
                            if (auto mc = dynamic_cast<te::MidiClip*> (c))
                                for (auto n : mc->getSequence().getNotes())
                                {
                                    if (t->getName() == "Lead" && n->getNoteNumber() == 88) transposed = true;
                                    if (t->getName() == "Grand Piano" && n->getNoteNumber() == 52) gotPianoLow = true;
                                }

                            if (auto wc = dynamic_cast<te::WaveAudioClip*> (c))
                                gotAudio = gotAudio || wc->getAudioFile().isValid();
                        }

                        for (auto p : t->pluginList)
                            if (isPracticeUtilityPlugin (p))
                                plumbing = true;
                    }

                    check (! plumbing, "no practice plumbing (zones, taps) in the saved project");

                    check (gotPianoLow, "Grand Piano's half of the split is in the take");
                    check (transposed, "Lead's note is saved transposed (+12)");
                    check (gotAudio, "the mic audio is in the take");
                }
                return true;
            });

            // ---- "the last thing I played": only what came after a pause
            step ("quiet the mic", [this]
            {
                auto choices = pc()->getInputChoices();
                for (auto& c : choices)
                    if (c.label == "Input 2")
                        pc()->setSlotInput (*mic, c);      // nothing on input 2 in this test
                return true;
            });
            step ("pause", [this] { return elapsed() > 7.5; });
            step ("a short phrase", [this] { key (45, true); return true; });
            step ("phrase note 2", [this] { if (elapsed() < 0.3) return false; key (45, false); key (47, true); return true; });
            step ("phrase end", [this] { if (elapsed() < 0.3) return false; key (47, false); return true; });
            step ("save the last phrase", [this]
            {
                if (elapsed() < 0.3) return false;
                auto r = pc()->saveWhatIPlayed (300.0, true);
                check (r.ok, "saved: " + r.message);

                if (auto loaded = r.ok ? te::loadEditFromFile (session.engine, r.file) : nullptr)
                {
                    int audio = 0, midiTracks = 0;
                    bool onlyThePhrase = true;
                    String pitches;
                    for (auto t : te::getAudioTracks (*loaded))
                        for (auto c : t->getClips())
                        {
                            if (auto mc = dynamic_cast<te::MidiClip*> (c))
                            {
                                ++midiTracks;
                                String these;
                                for (auto n : mc->getSequence().getNotes())
                                    these << n->getNoteNumber() << " ";
                                onlyThePhrase = onlyThePhrase && these.trim() == "45 47";
                                pitches << t->getName() << ": " << these << " ";
                            }

                            if (dynamic_cast<te::WaveAudioClip*> (c) != nullptr)
                                ++audio;
                        }

                    // Grand Piano and the Mic Sample layered on it both played the phrase
                    check (onlyThePhrase && midiTracks > 0, "only the phrase after the pause is kept (" + pitches.trim() + ")");
                    check (audio == 0, "the mic (silent since the pause) is left out");
                }
                return true;
            });

            // ---- back to the project, untouched
            step ("leave practice", [this] { main.togglePractice(); return true; });
            step ("project is back", [this]
            {
                if (session.isPracticeMode() || elapsed() < 0.5) return false;
                check (session.getEdit() == projectEdit, "the same project edit came back (undo history kept)");
                check (te::getAudioTracks (session.edit_()).size() == projectTracks, "with its tracks");
                check (session.hasUnsavedChanges(), "and its unsaved changes");

                Array<te::EditItemID> targets;
                for (auto* inst : session.edit_().getAllInputDevices())
                    if (inst->getInputDevice().getName() == "Computer Keyboard")
                        targets = inst->getTargets();
                auto describe = [this] (const Array<te::EditItemID>& ids)
                {
                    StringArray names;
                    for (auto id : ids)
                        if (auto t = te::findTrackForID (session.edit_(), id))
                            names.add (t->getName());
                        else
                            names.add (id.toString());
                    return "[" + names.joinIntoString (", ") + "]";
                };
                check (targets == projectKeyboardTargets && ! targets.isEmpty(),
                       "and its MIDI routing: keyboard plays " + describe (targets) + ", before " + describe (projectKeyboardTargets));
                main.togglePractice();
                return true;
            });
            step ("practice setup persisted", [this]
            {
                if (! session.isPracticeMode() || main.getPracticeView() == nullptr || elapsed() < 0.5) return false;
                check (slotNamed ("Lead") != nullptr && slotNamed ("Mic Sample") != nullptr, "sounds are still there next time");
                if (auto l = slotNamed ("Lead"))
                    check (PracticeController::getZone (*l)->getLow() == 60 && PracticeController::getZone (*l)->getTranspose() == 12,
                           "with their zones and transpose");
                return true;
            });
            step ("screenshot pause", [this] { return elapsed() > (SystemStats::getEnvironmentVariable ("LODE_SELFTEST_PAUSE", "0").getDoubleValue()); });
            step ("clean up", [this]
            {
                // leave the practice file as a fresh user would find it
                if (auto c = pc())
                    c->resetToDefaults();
                main.togglePractice();
                return true;
            });
            step ("left", [this] { return ! session.isPracticeMode() && elapsed() > 0.3; });
        }
    };
}

void startSelfTest (const String& name, MainComponent& main, std::function<void (int)> done)
{
    if (name == "practice")
    {
        new PracticeSelfTest (main, std::move (done));   // deletes itself
        return;
    }

    std::cerr << "unknown self-test: " << name << std::endl;
    done (2);
}

} // namespace lode
