/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Arrangement.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"
#include "Browser.h"
#include "ProjectIO.h"

namespace lode
{
using namespace juce;

//==============================================================================
double Timeline::gridStepFor (double minPixels, double bpb) const
{
    static const double fractions[] = { 1.0 / 32.0, 1.0 / 16.0, 1.0 / 8.0, 0.25, 0.5, 1.0 };

    for (auto f : fractions)
        if (f * pixelsPerBeat >= minPixels)
            return f;

    for (double bars = 1.0; bars < 4096.0; bars *= 2.0)
        if (bars * bpb * pixelsPerBeat >= minPixels)
            return bars * bpb;

    return 4096.0 * bpb;
}

static void drawGrid (Graphics& g, const Timeline& tl, Rectangle<int> area, double bpb, double snapDiv, int xOffset = 0)
{
    auto startBeat = tl.xToBeat (0);
    auto endBeat = tl.xToBeat (area.getWidth());

    // sub-division lines (snap grid)
    if (snapDiv > 0.0 && snapDiv * tl.pixelsPerBeat >= 7.0)
    {
        g.setColour (Colours::white.withAlpha (0.025f));
        for (auto b = std::floor (startBeat / snapDiv) * snapDiv; b <= endBeat; b += snapDiv)
            g.fillRect ((float) xOffset + tl.beatToX (b), (float) area.getY(), 1.0f, (float) area.getHeight());
    }

    // beat lines
    if (tl.pixelsPerBeat >= 10.0)
    {
        g.setColour (Colours::white.withAlpha (0.05f));
        for (auto b = std::floor (startBeat); b <= endBeat; b += 1.0)
            g.fillRect ((float) xOffset + tl.beatToX (b), (float) area.getY(), 1.0f, (float) area.getHeight());
    }

    // bar lines
    auto barStep = tl.gridStepFor (40.0, bpb);
    barStep = jmax (bpb, barStep);
    g.setColour (Colours::white.withAlpha (0.10f));
    for (auto b = std::floor (startBeat / barStep) * barStep; b <= endBeat; b += barStep)
        g.fillRect ((float) xOffset + tl.beatToX (b), (float) area.getY(), 1.0f, (float) area.getHeight());
}

//==============================================================================
// ClipComponent
//==============================================================================
ClipComponent::ClipComponent (ArrangementView& o, te::Clip::Ptr c)
    : clip (c), owner (o)
{
    setTooltip (c->getName());

    if (auto wac = dynamic_cast<te::WaveAudioClip*> (c.get()))
    {
        te::AudioFile af (wac->getPlaybackFile());
        if (af.getFile().existsAsFile() || ! wac->usesSourceFile())
            thumbnail = std::make_unique<te::SmartThumbnail> (o.edit.engine, af, *this, &o.edit);
    }
}

ClipComponent::~ClipComponent() = default;

ClipComponent::DragMode ClipComponent::modeForPosition (Point<int> p) const
{
    auto edge = jmin (8, getWidth() / 4);

    if (p.x >= getWidth() - edge)
        return DragMode::trimEnd;

    if (p.x <= edge)
        return DragMode::trimStart;

    return DragMode::move;
}

void ClipComponent::paint (Graphics& g)
{
    auto r = getLocalBounds();
    auto selected = owner.session.getSelectionManager().isSelected (clip.get());
    auto col = clip->getColour();

    if (clip->isMuted())
        col = col.withSaturation (0.0f).darker (0.3f);

    auto rf = r.toFloat().reduced (0.5f);
    g.setColour (col.withAlpha (0.30f).overlaidWith (Col::bg1.withAlpha (0.35f)));
    g.fillRoundedRectangle (rf, 4.0f);

    auto header = r.removeFromTop (jmin (16, getHeight() / 3));
    {
        Path hp;
        hp.addRoundedRectangle ((float) header.getX() + 0.5f, (float) header.getY() + 0.5f,
                                (float) header.getWidth() - 1.0f, (float) header.getHeight(), 4.0f, 4.0f,
                                true, true, false, false);
        g.setColour (col.withAlpha (0.9f));
        g.fillPath (hp);
    }

    g.setColour (col.getPerceivedBrightness() > 0.6f ? Colours::black.withAlpha (0.85f) : Colours::white);
    g.setFont (LodeLookAndFeel::font (11.5f, true));
    g.drawText (clip->getName(), header.reduced (5, 0), Justification::centredLeft, true);

    if (clip->isMidi())
        drawMidi (g, r.reduced (2, 2));
    else
        drawAudio (g, r.reduced (0, 1));

    g.setColour (selected ? Colours::white : col.brighter (0.2f).withAlpha (0.8f));
    g.drawRoundedRectangle (rf, 4.0f, selected ? 2.0f : 1.0f);
}

void ClipComponent::drawMidi (Graphics& g, Rectangle<int> area)
{
    auto mc = dynamic_cast<te::MidiClip*> (clip.get());
    if (mc == nullptr || area.getHeight() < 4)
        return;

    auto& seq = mc->getSequence();
    auto& notes = seq.getNotes();
    if (notes.isEmpty())
        return;

    int lo = 127, hi = 0;
    for (auto n : notes)
    {
        lo = jmin (lo, n->getNoteNumber());
        hi = jmax (hi, n->getNoteNumber());
    }

    lo -= 2; hi += 2;
    auto range = jmax (8, hi - lo);
    auto noteH = jlimit (1.5f, 6.0f, (float) area.getHeight() / (float) range);
    auto contentStart = clipContentStartBeat (*mc);
    auto clipStart = clipStartBeat (*mc), clipEnd = clipEndBeat (*mc);
    auto col = mc->getColour().brighter (0.6f);

    auto drawPass = [&] (double offset)
    {
        for (auto n : notes)
        {
            auto s = contentStart + offset + n->getStartBeat().inBeats();
            auto e = s + n->getLengthBeats().inBeats();
            if (e <= clipStart || s >= clipEnd)
                continue;

            s = jmax (s, clipStart);
            e = jmin (e, clipEnd);

            auto x1 = owner.timeline.beatToX (s) - (float) getX();
            auto x2 = owner.timeline.beatToX (e) - (float) getX();
            auto y = (float) area.getBottom() - (float) (n->getNoteNumber() - lo) / (float) range * (float) area.getHeight();

            g.setColour (col.withAlpha (0.45f + 0.55f * (float) n->getVelocity() / 127.0f));
            g.fillRect (x1, y - noteH * 0.5f, jmax (1.5f, x2 - x1 - 0.5f), noteH);
        }
    };

    if (mc->isLooping())
    {
        auto loopLen = mc->getLoopLengthBeats().inBeats();
        auto loopStart = mc->getLoopStartBeats().inBeats();
        if (loopLen > 0.01)
            for (double off = -loopStart; contentStart + off < clipEnd; off += loopLen)
                drawPass (off);
    }
    else
    {
        drawPass (0.0);
    }
}

void ClipComponent::drawAudio (Graphics& g, Rectangle<int> area)
{
    auto wac = dynamic_cast<te::WaveAudioClip*> (clip.get());
    if (wac == nullptr || thumbnail == nullptr)
        return;

    if (thumbnail->isGeneratingProxy())
    {
        g.setColour (Col::text.withAlpha (0.6f));
        g.setFont (LodeLookAndFeel::font (11.0f));
        g.drawText ("Preparing audio... " + String (roundToInt (thumbnail->getProxyProgress() * 100.0f)) + "%",
                    area, Justification::centred);
        return;
    }

    auto pos = wac->getPosition();
    auto speed = wac->getSpeedRatio();
    auto len = pos.getLength().inSeconds();

    te::TimeRange sourceRange;
    if (wac->usesTimeStretchedProxy() || wac->isLooping())
        sourceRange = { te::TimePosition(), TD (len) };
    else
        sourceRange = { T (pos.getOffset().inSeconds() * speed), TD (len * speed) };

    if (wac->getIsReversed())
        sourceRange = { T (jmax (0.0, thumbnail->getTotalLength() - sourceRange.getEnd().inSeconds())), sourceRange.getLength() };

    g.setColour (wac->getColour().brighter (0.7f).withAlpha (0.85f));
    auto gain = Decibels::decibelsToGain (wac->getGainDB());
    thumbnail->drawChannels (g, area, sourceRange, jlimit (0.2f, 4.0f, gain));
}

void ClipComponent::mouseMove (const MouseEvent& e)
{
    auto m = modeForPosition (e.getPosition());
    setMouseCursor (m == DragMode::move ? MouseCursor::NormalCursor : MouseCursor::LeftRightResizeCursor);
}

void ClipComponent::mouseDown (const MouseEvent& e)
{
    auto& sm = owner.session.getSelectionManager();

    if (e.mods.isPopupMenu())
    {
        if (! sm.isSelected (clip.get()))
            sm.selectOnly (clip.get());

        showMenu();
        return;
    }

    if (e.mods.isShiftDown())
    {
        if (sm.isSelected (clip.get()))
            sm.deselect (clip.get());
        else
            sm.addToSelection (clip.get());
    }
    else if (! sm.isSelected (clip.get()))
    {
        sm.selectOnly (clip.get());
    }

    owner.edit.getUndoManager().beginNewTransaction ("Edit clips");
    dragMode = modeForPosition (e.getPosition());
    duplicated = false;
    trackDelta = 0;
    dragStarts.clear();

    for (auto c : owner.session.getSelectedClips())
    {
        DragStart d;
        d.clip = c;
        d.startBeat = clipStartBeat (*c);
        d.endBeat = clipEndBeat (*c);
        d.offsetBeats = c->getOffsetInBeats().inBeats();
        d.trackIndex = 0;

        for (int i = 0; i < (int) owner.rows.size(); ++i)
            if (owner.rows[(size_t) i].track.get() == c->getTrack())
                d.trackIndex = i;

        dragStarts.push_back (d);
    }
}

void ClipComponent::mouseDrag (const MouseEvent& e)
{
    if (dragStarts.empty() || ! e.mouseWasDraggedSinceMouseDown())
        return;

    owner.isDraggingClips = true;

    const auto& tl = owner.timeline;
    auto deltaBeats = e.getDistanceFromDragStartX() / tl.pixelsPerBeat;
    auto noSnap = e.mods.isShiftDown();
    auto snapIt = [&] (double b) { return noSnap ? b : owner.snap (b); };

    // the clip under the mouse is the snapping reference
    const DragStart* primary = &dragStarts.front();
    for (auto& d : dragStarts)
        if (d.clip == clip)
            primary = &d;

    auto& edit = owner.edit;
    auto minLen = jmax (1.0 / 64.0, owner.snapDivision());

    if (dragMode == DragMode::move)
    {
        if (e.mods.isCtrlDown() && ! duplicated)
        {
            for (auto& d : dragStarts)
                te::duplicateClip (*d.clip);   // copies stay behind, originals move

            duplicated = true;
        }

        auto snappedStart = snapIt (primary->startBeat + deltaBeats);
        auto delta = snappedStart - primary->startBeat;

        // keep everything at or after zero
        for (auto& d : dragStarts)
            delta = jmax (delta, -d.startBeat);

        auto laneY = owner.lanes.getLocalPoint (this, e.getPosition()).y;
        auto targetRow = owner.trackIndexAtY (laneY);
        auto newTrackDelta = targetRow >= 0 ? targetRow - primary->trackIndex : trackDelta;

        for (auto& d : dragStarts)
            newTrackDelta = jlimit (-d.trackIndex, (int) owner.rows.size() - 1 - d.trackIndex, newTrackDelta);

        for (auto& d : dragStarts)
        {
            d.clip->setStart (beatToTime (edit, d.startBeat + delta), false, true);

            if (newTrackDelta != trackDelta)
            {
                auto idx = d.trackIndex + newTrackDelta;
                if (isPositiveAndBelow (idx, (int) owner.rows.size()))
                    d.clip->moveTo (*owner.rows[(size_t) idx].track);
            }
        }

        trackDelta = newTrackDelta;
    }
    else if (dragMode == DragMode::trimEnd)
    {
        for (auto& d : dragStarts)
        {
            auto newEnd = jmax (d.startBeat + minLen, snapIt (d.endBeat + deltaBeats));
            d.clip->setEnd (beatToTime (edit, newEnd), true);
        }
    }
    else if (dragMode == DragMode::trimStart)
    {
        for (auto& d : dragStarts)
        {
            auto newStart = snapIt (d.startBeat + deltaBeats);
            newStart = jmin (newStart, d.endBeat - minLen);
            newStart = jmax (newStart, 0.0);

            if (! d.clip->isMidi())
                newStart = jmax (newStart, d.startBeat - d.offsetBeats);   // can't reveal audio before the file starts

            d.clip->setStart (beatToTime (edit, newStart), true, false);
        }
    }

    owner.layoutClips();
}

void ClipComponent::mouseUp (const MouseEvent& e)
{
    auto wasDragging = owner.isDraggingClips;
    owner.isDraggingClips = false;
    dragStarts.clear();

    if (! wasDragging && ! e.mods.isShiftDown() && ! e.mods.isPopupMenu())
        owner.session.getSelectionManager().selectOnly (clip.get());

    owner.triggerAsyncUpdate();
}

void ClipComponent::mouseDoubleClick (const MouseEvent&)
{
    if (owner.onOpenClipEditor)
        owner.onOpenClipEditor (clip.get());
}

void ClipComponent::showMenu()
{
    auto& session = owner.session;
    PopupMenu m;
    auto c = clip;

    m.addItem ("Open in Editor", [this, c] { if (owner.onOpenClipEditor) owner.onOpenClipEditor (c.get()); });
    m.addItem ("Rename...", [&session] { ClipActions::renameSelected (session); });

    PopupMenu colours;
    for (int i = 0; i < 12; ++i)
    {
        auto col = Col::trackPalette (i);
        colours.addColouredItem (100 + i, "Colour " + String (i + 1), col, true, false, nullptr);
    }
    m.addSubMenu ("Colour", colours);
    m.addSeparator();
    m.addItem ("Duplicate", [&session] { ClipActions::duplicateSelected (session); });
    m.addItem ("Split at Playhead", [&session] { ClipActions::splitSelectedAtPlayhead (session); });
    m.addItem (c->isMuted() ? "Unmute" : "Mute", [&session] { ClipActions::toggleMuteSelected (session); });
    m.addItem ("Loop Region to Clip", [&session] { ClipActions::setLoopToSelection (session); });

    if (auto mc = dynamic_cast<te::MidiClip*> (c.get()))
    {
        m.addSeparator();
        m.addItem ("Quantize to 1/16", [&session] { ClipActions::quantizeSelected (session, 0.25, 1.0f); });
        m.addItem ("Quantize to 1/8", [&session] { ClipActions::quantizeSelected (session, 0.5, 1.0f); });

        PopupMenu loop;
        for (int n : { 2, 4, 8 })
            loop.addItem ("Repeat x" + String (n), [mc, n]
            {
                auto len = mc->getLengthInBeats().inBeats();
                mc->setLoopRangeBeats ({ B (0.0), BD (len) });
                mc->setEnd (mc->edit.tempoSequence.toTime (mc->getStartBeat() + BD (len * n)), true);
            });
        loop.addItem ("Stop Looping", [mc] { mc->disableLooping(); });
        m.addSubMenu ("Loop Clip", loop);
    }

    if (auto wac = dynamic_cast<te::WaveAudioClip*> (c.get()))
    {
        m.addSeparator();
        m.addItem ("Reverse", true, wac->getIsReversed(), [wac] { wac->setIsReversed (! wac->getIsReversed()); });
        m.addItem ("Follow Project Tempo", true, wac->getAutoTempo(), [wac] { wac->setAutoTempo (! wac->getAutoTempo()); });

        PopupMenu gain;
        for (float db : { 6.0f, 3.0f, 0.0f, -3.0f, -6.0f, -12.0f })
            gain.addItem ((db > 0 ? "+" : "") + String (db, 0) + " dB", true, std::abs (wac->getGainDB() - db) < 0.01f,
                          [wac, db] { wac->setGainDB (db); });
        m.addSubMenu ("Clip Gain", gain);

        PopupMenu pitch;
        for (int st : { 12, 7, 5, 2, 1, 0, -1, -2, -5, -7, -12 })
            pitch.addItem ((st > 0 ? "+" : "") + String (st) + " semitones", true, roundToInt (wac->getPitchChange()) == st,
                           [wac, st] { wac->setPitchChange ((float) st); });
        m.addSubMenu ("Transpose", pitch);

        PopupMenu fades;
        for (double s : { 0.0, 0.01, 0.1, 0.5, 2.0 })
        {
            fades.addItem ("Fade in " + String (s, 2) + " s", [wac, s] { wac->setFadeIn (TD (s)); });
        }
        fades.addSeparator();
        for (double s : { 0.0, 0.01, 0.1, 0.5, 2.0 })
            fades.addItem ("Fade out " + String (s, 2) + " s", [wac, s] { wac->setFadeOut (TD (s)); });
        m.addSubMenu ("Fades", fades);
    }

    m.addSeparator();
    m.addItem ("Delete", [&session] { ClipActions::deleteSelected (session); });

    SafePointer<ClipComponent> safe (this);
    m.showMenuAsync (PopupMenu::Options(), [safe, &session] (int result)
    {
        if (result >= 100 && result < 112)
        {
            session.edit_().getUndoManager().beginNewTransaction ("Clip colour");
            for (auto cl : session.getSelectedClips())
                cl->setColour (Col::trackPalette (result - 100));

            if (safe != nullptr)
                safe->repaint();
        }
    });
}

//==============================================================================
// TrackHeader
//==============================================================================
TrackHeader::TrackHeader (ArrangementView& o, te::AudioTrack::Ptr t)
    : track (t), owner (o)
{
    addAndMakeVisible (nameLabel);
    nameLabel.setFont (LodeLookAndFeel::font (13.5f, true));
    nameLabel.setColour (Label::textColourId, Col::text);
    nameLabel.setEditable (false, true);
    nameLabel.setInterceptsMouseClicks (false, false);
    nameLabel.onTextChange = [this]
    {
        owner.edit.getUndoManager().beginNewTransaction ("Rename track");
        track->setName (nameLabel.getText());
    };

    for (auto* b : { &muteButton, &soloButton, &armButton })
    {
        addAndMakeVisible (b);
        b->setClickingTogglesState (false);
    }

    muteButton.setTooltip ("Mute");
    soloButton.setTooltip ("Solo");
    armButton.setTooltip ("Record-arm");
    muteButton.setColour (TextButton::buttonOnColourId, Col::yellow.darker (0.2f));
    soloButton.setColour (TextButton::buttonOnColourId, Col::south);
    armButton.setColour (TextButton::buttonOnColourId, Col::north);

    muteButton.onClick = [this] { owner.edit.getUndoManager().beginNewTransaction(); track->setMute (! track->isMuted (false)); refresh(); };
    soloButton.onClick = [this] { owner.edit.getUndoManager().beginNewTransaction(); track->setSolo (! track->isSolo (false)); refresh(); };
    armButton.onClick = [this]
    {
        auto& router = owner.session.getInputRouter();

        if (getTrackKind (*track) == TrackKind::audio && router.getAudioInput (*track).isEmpty())
        {
            auto ins = router.getAudioDevices();
            if (! ins.isEmpty())
                router.setAudioInput (*track, ins.getFirst().id);
        }

        router.armTrack (*track, ! router.isTrackArmed (*track));
        refresh();
    };

    addAndMakeVisible (inputButton);
    inputButton.setColour (TextButton::buttonColourId, Col::bg2);
    inputButton.setColour (TextButton::textColourOffId, Col::textDim);
    inputButton.onClick = [this] { showInputMenu(); };

    addAndMakeVisible (volume);
    volume.setSliderStyle (Slider::LinearHorizontal);
    volume.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    volume.setRange (0.0, 1.0);
    volume.setDoubleClickReturnValue (true, te::decibelsToVolumeFaderPosition (0.0f));
    volume.setColour (Slider::trackColourId, track->getColour().withAlpha (0.8f));
    volume.onDragStart = [this] { owner.edit.getUndoManager().beginNewTransaction ("Volume"); };
    volume.onValueChange = [this]
    {
        if (auto vp = track->getVolumePlugin())
        {
            vp->setSliderPos ((float) volume.getValue());
            volume.setTooltip (String (vp->getVolumeDb(), 1) + " dB");
        }
    };

    refresh();
    startTimerHz (12);
}

TrackHeader::~TrackHeader() = default;

void TrackHeader::refresh()
{
    nameLabel.setText (track->getName(), dontSendNotification);
    muteButton.setToggleState (track->isMuted (false), dontSendNotification);
    soloButton.setToggleState (track->isSolo (false), dontSendNotification);
    armButton.setToggleState (owner.session.getInputRouter().isTrackArmed (*track), dontSendNotification);

    if (auto vp = track->getVolumePlugin())
        volume.setValue (vp->getSliderPos(), dontSendNotification);

    volume.setColour (Slider::trackColourId, track->getColour().withAlpha (0.8f));

    auto& router = owner.session.getInputRouter();
    String inputText;

    if (getTrackKind (*track) == TrackKind::audio)
    {
        auto id = router.getAudioInput (*track);
        inputText = id.isEmpty() ? "No input" : "In: " + router.getDevicesTargeting (*track, false).joinIntoString (", ");
    }
    else
    {
        auto devs = router.getDevicesTargeting (*track, true);
        inputText = devs.isEmpty() ? String ("MIDI: select to play") : "MIDI: " + devs.joinIntoString (", ");
    }

    inputButton.setButtonText (inputText);
    inputButton.setTooltip (inputText + "\nClick to choose which controller plays this track");
    repaint();
}

void TrackHeader::timerCallback()
{
    auto armed = owner.session.getInputRouter().isTrackArmed (*track);
    if (armed != armButton.getToggleState())
        refresh();
}

void TrackHeader::paint (Graphics& g)
{
    auto r = getLocalBounds();
    auto selected = owner.session.getSelectionManager().isSelected (track.get())
                    || owner.session.getSelectedTrack() == track.get();

    g.setColour (selected ? Col::bg3 : Col::bg2);
    g.fillRect (r);
    g.setColour (Col::bg0);
    g.fillRect (r.removeFromBottom (1));

    g.setColour (track->getColour());
    g.fillRect (r.removeFromLeft (5));

    // track type icon
    auto kind = getTrackKind (*track);
    auto iconArea = Rectangle<float> (12.0f, 8.0f, 18.0f, 18.0f);
    g.setColour (track->getColour().brighter (0.3f));
    g.fillPath (Draw::icon (kind == TrackKind::drums ? "drum" : (kind == TrackKind::audio ? "wave" : "piano"), iconArea));

    if (owner.session.getInputRouter().getFollowTrack() == track.get() && kind != TrackKind::audio)
    {
        g.setColour (Col::green);
        g.fillEllipse (getWidth() - 14.0f, 10.0f, 7.0f, 7.0f);
    }
}

void TrackHeader::resized()
{
    auto r = getLocalBounds().reduced (6, 4).withTrimmedLeft (30);
    auto top = r.removeFromTop (22);
    top.removeFromRight (10);
    armButton.setBounds (top.removeFromRight (22).reduced (1));
    soloButton.setBounds (top.removeFromRight (22).reduced (1));
    muteButton.setBounds (top.removeFromRight (22).reduced (1));
    nameLabel.setBounds (top.withTrimmedLeft (-4));

    auto h = getHeight();
    inputButton.setVisible (h >= 52);
    volume.setVisible (h >= 70);

    if (h >= 52)
    {
        r.removeFromTop (3);
        inputButton.setBounds (r.removeFromTop (18).withTrimmedLeft (-28));
    }

    if (h >= 70)
    {
        r.removeFromTop (2);
        volume.setBounds (r.removeFromTop (18).withTrimmedLeft (-28));
    }
}

void TrackHeader::mouseMove (const MouseEvent& e)
{
    setMouseCursor (e.y >= getHeight() - 5 ? MouseCursor::UpDownResizeCursor : MouseCursor::NormalCursor);
}

void TrackHeader::mouseDown (const MouseEvent& e)
{
    owner.session.selectTrack (track.get());

    if (e.mods.isPopupMenu())
    {
        showMenu();
        return;
    }

    resizing = e.y >= getHeight() - 5;
    reordering = false;
    dragStartHeight = getHeight();
}

void TrackHeader::mouseDrag (const MouseEvent& e)
{
    if (resizing)
    {
        owner.setTrackHeight (*track, jlimit (40, 300, dragStartHeight + e.getDistanceFromDragStartY()));
        return;
    }

    if (std::abs (e.getDistanceFromDragStartY()) > 8)
    {
        reordering = true;
        owner.dropHighlightY = owner.headerHolder.getLocalPoint (this, e.getPosition()).y;
        owner.lanes.repaint();
        owner.headerHolder.repaint();
    }
}

void TrackHeader::mouseUp (const MouseEvent& e)
{
    if (reordering)
    {
        auto y = owner.lanes.getLocalPoint (this, e.getPosition()).y;
        auto target = owner.trackIndexAtY (y);
        auto& rows = owner.getRows();

        if (target < 0)
            target = y < 0 ? 0 : (int) rows.size() - 1;

        int current = -1;
        for (int i = 0; i < (int) rows.size(); ++i)
            if (rows[(size_t) i].track == track)
                current = i;

        if (current >= 0 && target != current && isPositiveAndBelow (target, (int) rows.size()))
        {
            owner.edit.getUndoManager().beginNewTransaction ("Move track");
            auto targetTrack = rows[(size_t) target].track;
            owner.edit.moveTrack (track, te::TrackInsertPoint (*targetTrack, target < current));
        }
    }

    resizing = reordering = false;
    owner.dropHighlightY = -1;
    owner.lanes.repaint();
}

void TrackHeader::mouseDoubleClick (const MouseEvent& e)
{
    if (nameLabel.getBounds().contains (e.getPosition()))
        nameLabel.showEditor();
    else if (owner.onOpenInstrument)
        owner.onOpenInstrument (track.get());
}

void TrackHeader::showInputMenu()
{
    auto& router = owner.session.getInputRouter();
    PopupMenu m;
    auto t = track;

    if (getTrackKind (*track) == TrackKind::audio)
    {
        auto current = router.getAudioInput (*track);
        m.addSectionHeader ("Audio input");
        m.addItem ("None", true, current.isEmpty(), [&router, t] { router.setAudioInput (*t, {}); });

        for (auto& d : router.getAudioDevices())
            m.addItem (d.name, true, d.id == current, [&router, t, id = d.id] { router.setAudioInput (*t, id); });

        m.addSeparator();
        m.addItem ("Monitor input (hear yourself)", ! current.isEmpty(), router.getAudioMonitoring (*track),
                   [&router, t] { router.setAudioMonitoring (*t, ! router.getAudioMonitoring (*t)); });
    }
    else
    {
        m.addSectionHeader ("MIDI controllers playing this track");
        auto devices = router.getMidiDevices();

        if (devices.isEmpty())
            m.addItem ("No MIDI controllers found - plug one in!", false, false, [] {});

        for (auto& d : devices)
        {
            auto onThis = d.pinnedTrack == track.get();
            String label = d.name;
            if (d.follows) label << "  (follows selection)";
            else if (d.pinnedTrack != nullptr && ! onThis) label << "  (on " << d.pinnedTrack->getName() << ")";

            PopupMenu sub;
            sub.addItem ("Always play this track", true, onThis && ! d.follows, [&router, t, id = d.id] { router.pinDevice (id, t.get()); });
            sub.addItem ("Follow the selected track", true, d.follows, [&router, id = d.id] { router.setFollow (id, true); });
            m.addSubMenu (label, sub, true, nullptr, onThis);
        }

        m.addSeparator();
        m.addItem ("Computer keyboard plays the selected track (A-K keys)", false, true, [] {});
    }

    SafePointer<TrackHeader> safe (this);
    m.showMenuAsync (PopupMenu::Options().withTargetComponent (&inputButton),
                     [safe] (int) { if (safe != nullptr) safe->refresh(); });
}

void TrackHeader::showMenu()
{
    auto& session = owner.session;
    PopupMenu m;
    te::AudioTrack::Ptr t = track;

    m.addItem ("Rename", [this] { nameLabel.showEditor(); });

    PopupMenu colours;
    for (int i = 0; i < 12; ++i)
        colours.addColouredItem (100 + i, "Colour " + String (i + 1), Col::trackPalette (i), true, track->getColour() == Col::trackPalette (i));
    m.addSubMenu ("Colour", colours);

    if (getTrackKind (*track) != TrackKind::audio)
        m.addItem ("Show Instrument", [this] { if (owner.onOpenInstrument) owner.onOpenInstrument (track.get()); });

    m.addSeparator();
    m.addItem ("Duplicate Track", [&session, t] { session.edit_().getUndoManager().beginNewTransaction(); session.duplicateTrack (*t); });
    m.addItem ("Delete Track", [&session, t] { session.edit_().getUndoManager().beginNewTransaction ("Delete track"); session.deleteTrack (*t); });

    PopupMenu heights;
    for (auto [name, h] : std::initializer_list<std::pair<const char*, int>> { { "Small", 44 }, { "Medium", 64 }, { "Large", 96 }, { "Huge", 160 } })
        heights.addItem (name, [this, h] { owner.setTrackHeight (*track, h); });
    m.addSubMenu ("Height", heights);

    SafePointer<TrackHeader> safe (this);
    m.showMenuAsync (PopupMenu::Options(), [safe, t, &session] (int result)
    {
        if (result >= 100 && result < 112)
        {
            session.edit_().getUndoManager().beginNewTransaction ("Track colour");
            t->setColour (Col::trackPalette (result - 100));
            if (safe != nullptr) safe->refresh();
        }
    });
}

//==============================================================================
// TimeRuler
//==============================================================================
TimeRuler::TimeRuler (ArrangementView& o) : owner (o)
{
    setMouseCursor (MouseCursor::IBeamCursor);
}

void TimeRuler::paint (Graphics& g)
{
    auto r = getLocalBounds();
    g.fillAll (Col::bg2);

    const auto& tl = owner.timeline;
    auto bpb = owner.beatsPerBar();
    auto& transport = owner.edit.getTransport();

    // loop strip
    auto loopRange = transport.getLoopRange();
    auto ls = timeToBeat (owner.edit, loopRange.getStart()), le = timeToBeat (owner.edit, loopRange.getEnd());
    if (le > ls)
    {
        auto x1 = tl.beatToX (ls), x2 = tl.beatToX (le);
        g.setColour (transport.looping ? Col::south.withAlpha (0.55f) : Col::textFaint.withAlpha (0.35f));
        g.fillRoundedRectangle (x1, 2.0f, x2 - x1, 9.0f, 3.0f);
    }

    // bar numbers
    auto step = jmax (bpb, tl.gridStepFor (48.0, bpb));
    auto startBeat = std::floor (tl.xToBeat (0) / step) * step;
    auto endBeat = tl.xToBeat (getWidth());
    g.setFont (LodeLookAndFeel::font (11.5f));

    for (auto b = startBeat; b <= endBeat; b += step)
    {
        auto x = tl.beatToX (b);
        g.setColour (Col::textDim);
        g.fillRect (x, 14.0f, 1.0f, (float) getHeight() - 14.0f);
        g.drawText (String ((int) std::round (b / bpb) + 1), (int) x + 3, 12, 40, 16, Justification::centredLeft);

        // beat ticks within the bar step
        if (tl.pixelsPerBeat * 1.0 >= 8.0 && step <= bpb * 1.01)
        {
            g.setColour (Col::textFaint);
            for (int i = 1; i < (int) std::round (bpb); ++i)
                g.fillRect (tl.beatToX (b + i), (float) getHeight() - 6.0f, 1.0f, 6.0f);
        }
    }

    // playhead
    auto px = tl.beatToX (timeToBeat (owner.edit, transport.getPosition()));
    Path tri;
    tri.addTriangle (px - 6.0f, (float) getHeight() - 10.0f, px + 6.0f, (float) getHeight() - 10.0f, px, (float) getHeight());
    g.setColour (Col::north);
    g.fillPath (tri);

    g.setColour (Col::bg0);
    g.fillRect (r.removeFromBottom (1));
}

void TimeRuler::mouseDown (const MouseEvent& e)
{
    auto beat = owner.timeline.xToBeat (e.x);

    if (e.mods.isPopupMenu())
    {
        PopupMenu m;
        auto& tc = owner.edit.getTransport();
        m.addItem ("Loop on/off", [&tc] { tc.looping = ! tc.looping.get(); });
        m.addItem ("Set loop to selected clips", [this] { ClipActions::setLoopToSelection (owner.session); });
        m.addItem ("Zoom to fit project", [this] { owner.zoomToFit(); });
        m.showMenuAsync ({});
        return;
    }

    draggingLoop = e.y < 13;

    if (draggingLoop)
    {
        loopDragStart = owner.snap (beat);
    }
    else
    {
        owner.edit.getTransport().setUserDragging (true);
        owner.session.setPlayheadBeat (owner.view.snapOn.get() ? owner.snap (beat) : beat);
    }
}

void TimeRuler::mouseDrag (const MouseEvent& e)
{
    auto beat = jmax (0.0, owner.timeline.xToBeat (e.x));

    if (draggingLoop)
    {
        auto b = owner.snap (beat);
        auto s = jmin (b, loopDragStart), en = jmax (b, loopDragStart);
        if (en - s < owner.snapDivision())
            en = s + jmax (owner.snapDivision(), 0.25);

        auto& tc = owner.edit.getTransport();
        tc.setLoopRange ({ beatToTime (owner.edit, s), beatToTime (owner.edit, en) });
        tc.looping = true;
    }
    else
    {
        owner.session.setPlayheadBeat (owner.view.snapOn.get() && ! e.mods.isShiftDown() ? owner.snap (beat) : beat);
    }

    repaint();
    owner.lanes.repaint();
}

void TimeRuler::mouseUp (const MouseEvent&)
{
    owner.edit.getTransport().setUserDragging (false);
    draggingLoop = false;
}

void TimeRuler::mouseDoubleClick (const MouseEvent&)
{
    auto& tc = owner.edit.getTransport();
    tc.looping = ! tc.looping.get();
    repaint();
}

//==============================================================================
// LaneArea
//==============================================================================
LaneArea::LaneArea (ArrangementView& o) : owner (o)
{
    setOpaque (true);
}

void LaneArea::paint (Graphics& g)
{
    g.fillAll (Col::bg1);

    auto scrollY = roundToInt (owner.view.scrollY.get());
    auto sel = owner.session.getSelectedTrack();

    for (auto& row : owner.rows)
    {
        auto y = row.y - scrollY;
        if (y > getHeight() || y + row.height < 0)
            continue;

        auto kind = getTrackKind (*row.track);
        g.setColour (row.track.get() == sel ? Col::bg2.brighter (0.04f) : (kind == TrackKind::audio ? Col::bg1.brighter (0.015f) : Col::bg1));
        g.fillRect (0, y, getWidth(), row.height);
        g.setColour (Col::bg0);
        g.fillRect (0, y + row.height - 1, getWidth(), 1);
    }

    drawGrid (g, owner.timeline, getLocalBounds(), owner.beatsPerBar(),
              owner.view.snapOn.get() ? owner.snapDivision() : 0.0);

    // loop region
    auto& tc = owner.edit.getTransport();
    if (tc.looping.get())
    {
        auto lr = tc.getLoopRange();
        auto x1 = owner.timeline.beatToX (timeToBeat (owner.edit, lr.getStart()));
        auto x2 = owner.timeline.beatToX (timeToBeat (owner.edit, lr.getEnd()));
        g.setColour (Col::south.withAlpha (0.05f));
        g.fillRect (x1, 0.0f, x2 - x1, (float) getHeight());
        g.setColour (Col::south.withAlpha (0.35f));
        g.fillRect (x1, 0.0f, 1.0f, (float) getHeight());
        g.fillRect (x2, 0.0f, 1.0f, (float) getHeight());
    }

    if (owner.rows.empty())
    {
        g.setColour (Col::textDim);
        g.setFont (LodeLookAndFeel::font (16.0f));
        g.drawFittedText ("No tracks yet.\nDrag an instrument, drum kit, audio or MIDI file here,\nor press  + Track  above.",
                          getLocalBounds().reduced (40), Justification::centred, 4);
    }
}

void LaneArea::paintOverChildren (Graphics& g)
{
    // recording overlay
    auto& tc = owner.edit.getTransport();
    if (tc.isRecording())
    {
        auto startBeat = timeToBeat (owner.edit, tc.getTimeWhenStarted());
        auto nowBeat = timeToBeat (owner.edit, tc.getPosition());
        auto scrollY = roundToInt (owner.view.scrollY.get());

        for (auto& row : owner.rows)
            if (owner.session.getInputRouter().isTrackArmed (*row.track))
            {
                auto x1 = owner.timeline.beatToX (startBeat), x2 = owner.timeline.beatToX (nowBeat);
                g.setColour (Col::north.withAlpha (0.25f));
                g.fillRect (x1, (float) (row.y - scrollY + 1), jmax (0.0f, x2 - x1), (float) row.height - 2.0f);
            }
    }

    if (owner.dropHighlightY >= 0)
    {
        g.setColour (Col::south);
        g.fillRect (0, owner.dropHighlightY - 1, getWidth(), 2);
    }

    if (! rubberBand.isEmpty())
    {
        g.setColour (Col::south.withAlpha (0.15f));
        g.fillRect (rubberBand);
        g.setColour (Col::south.withAlpha (0.7f));
        g.drawRect (rubberBand);
    }

    if (playheadX >= 0.0f)
    {
        g.setColour (Col::north);
        g.fillRect (playheadX - 0.5f, 0.0f, 1.5f, (float) getHeight());
    }
}

void LaneArea::mouseDown (const MouseEvent& e)
{
    auto& sm = owner.session.getSelectionManager();
    dragOrigin = e.getPosition();
    rubberBand = {};

    auto track = owner.trackAtY (e.y);

    if (e.mods.isPopupMenu())
    {
        PopupMenu m;
        auto beat = owner.snap (owner.timeline.xToBeat (e.x));

        if (track != nullptr && getTrackKind (*track) != TrackKind::audio)
            m.addItem ("New MIDI clip here", [this, track, beat]
            {
                owner.edit.getUndoManager().beginNewTransaction ("New clip");
                auto bpb = owner.beatsPerBar();
                if (auto c = owner.session.createMidiClip (*track, floorBeat (beat, bpb), bpb))
                    if (owner.onOpenClipEditor) owner.onOpenClipEditor (c);
            });

        if (track != nullptr && getTrackKind (*track) == TrackKind::audio)
            m.addItem ("Import audio here...", [this, track, beat]
            {
                auto chooser = std::make_shared<FileChooser> ("Import audio", File(), "*.wav;*.aif;*.aiff;*.flac;*.ogg;*.mp3");
                chooser->launchAsync (FileBrowserComponent::openMode | FileBrowserComponent::canSelectFiles,
                                      [this, chooser, track, beat] (const FileChooser& fc)
                                      {
                                          if (fc.getResult().existsAsFile())
                                              owner.addFilesAt ({ fc.getResult().getFullPathName() }, track, beat);
                                      });
            });

        m.addItem ("Paste", [this] { ClipActions::paste (owner.session); });
        m.addItem ("Select all clips", [this] { ClipActions::selectAll (owner.session); });
        m.showMenuAsync ({});
        return;
    }

    if (! e.mods.isShiftDown())
    {
        sm.deselectAll();
        if (track != nullptr)
            owner.session.selectTrack (track);
    }
}

void LaneArea::mouseDrag (const MouseEvent& e)
{
    rubberBand = Rectangle<int>::leftTopRightBottom (jmin (dragOrigin.x, e.x), jmin (dragOrigin.y, e.y),
                                                     jmax (dragOrigin.x, e.x), jmax (dragOrigin.y, e.y));

    auto& sm = owner.session.getSelectionManager();
    bool first = ! e.mods.isShiftDown();

    for (auto* cc : owner.clipComps)
        if (cc->isVisible() && cc->getBounds().intersects (rubberBand))
        {
            if (first) { sm.selectOnly (cc->clip.get()); first = false; }
            else       sm.addToSelection (cc->clip.get());
        }

    if (first && ! e.mods.isShiftDown())
        sm.deselectAll();

    repaint();
}

void LaneArea::mouseUp (const MouseEvent&)
{
    rubberBand = {};
    repaint();
}

void LaneArea::mouseDoubleClick (const MouseEvent& e)
{
    auto track = owner.trackAtY (e.y);
    if (track == nullptr)
    {
        owner.showAddTrackMenu();
        return;
    }

    auto beat = owner.timeline.xToBeat (e.x);

    if (getTrackKind (*track) == TrackKind::audio)
        return;

    owner.edit.getUndoManager().beginNewTransaction ("New clip");
    auto bpb = owner.beatsPerBar();
    if (auto c = owner.session.createMidiClip (*track, floorBeat (beat, bpb), bpb))
        if (owner.onOpenClipEditor)
            owner.onOpenClipEditor (c);
}

//==============================================================================
// ArrangementView
//==============================================================================
ArrangementView::ArrangementView (Session& s)
    : session (s), edit (*s.getEdit()), view (s.getView())
{
    timeline.pixelsPerBeat = view.pixelsPerBeat.get();
    timeline.scrollBeat = view.scrollBeat.get();

    addAndMakeVisible (ruler);
    addAndMakeVisible (lanes);
    addAndMakeVisible (headerHolder);
    addAndMakeVisible (hScroll);
    addAndMakeVisible (vScroll);
    addAndMakeVisible (addTrackButton);

    addTrackButton.setColour (TextButton::buttonColourId, Col::bg3);
    addTrackButton.setTooltip ("Add a track (instrument, drums or audio)");
    addTrackButton.onClick = [this] { showAddTrackMenu(); };

    hScroll.addListener (this);
    vScroll.addListener (this);
    hScroll.setAutoHide (false);
    vScroll.setAutoHide (false);

    edit.state.addListener (this);
    session.getSelectionManager().addChangeListener (this);
    edit.getTransport().addChangeListener (this);

    rebuildAll();
    startTimerHz (30);
}

ArrangementView::~ArrangementView()
{
    edit.state.removeListener (this);
    session.getSelectionManager().removeChangeListener (this);
    edit.getTransport().removeChangeListener (this);
}

void ArrangementView::paint (Graphics& g)
{
    g.fillAll (Col::bg2);
}

void ArrangementView::resized()
{
    auto r = getLocalBounds();
    auto top = r.removeFromTop (rulerHeight);
    addTrackButton.setBounds (top.removeFromLeft (headerWidth).reduced (6, 4));
    ruler.setBounds (top.withTrimmedRight (scrollbarSize));

    auto bottom = r.removeFromBottom (scrollbarSize);
    hScroll.setBounds (bottom.withTrimmedLeft (headerWidth).withTrimmedRight (scrollbarSize));
    vScroll.setBounds (r.removeFromRight (scrollbarSize));
    headerHolder.setBounds (r.removeFromLeft (headerWidth));
    lanes.setBounds (r);

    layoutClips();
}

int ArrangementView::getTrackHeight (te::Track& t) const
{
    return jlimit (40, 300, (int) t.state.getProperty ("lodeHeight", view.defaultTrackHeight.get()));
}

void ArrangementView::setTrackHeight (te::Track& t, int h)
{
    t.state.setProperty ("lodeHeight", h, nullptr);
    buildRows();
    layoutClips();
}

void ArrangementView::buildRows()
{
    rows.clear();
    int y = 0;

    for (auto t : te::getAudioTracks (edit))
    {
        Row r;
        r.track = t;
        r.y = y;
        r.height = getTrackHeight (*t);
        y += r.height;
        rows.push_back (r);
    }
}

int ArrangementView::trackIndexAtY (int laneY) const
{
    auto y = laneY + roundToInt (view.scrollY.get());

    for (int i = 0; i < (int) rows.size(); ++i)
        if (y >= rows[(size_t) i].y && y < rows[(size_t) i].y + rows[(size_t) i].height)
            return i;

    return -1;
}

te::AudioTrack* ArrangementView::trackAtY (int laneY) const
{
    auto i = trackIndexAtY (laneY);
    return i >= 0 ? rows[(size_t) i].track.get() : nullptr;
}

int ArrangementView::rowYForTrack (te::Track* t) const
{
    for (auto& r : rows)
        if (r.track.get() == t)
            return r.y - roundToInt (view.scrollY.get());

    return -1;
}

double ArrangementView::snapDivision() const
{
    return view.snapDivision.get();
}

double ArrangementView::snap (double beat) const
{
    if (! view.snapOn.get())
        return beat;

    auto div = snapDivision();

    // when zoomed far out, snap to something you can actually see
    auto visible = timeline.gridStepFor (6.0, beatsPerBar());
    div = jmax (div, visible);
    return snapBeat (beat, div);
}

void ArrangementView::rebuildAll()
{
    needsRebuild = false;
    buildRows();

    headers.clear();
    for (auto& r : rows)
    {
        auto h = headers.add (new TrackHeader (*this, r.track));
        headerHolder.addAndMakeVisible (h);
    }

    clipComps.clear();
    for (auto& r : rows)
        for (auto c : r.track->getClips())
        {
            auto cc = clipComps.add (new ClipComponent (*this, c));
            lanes.addAndMakeVisible (cc);
        }

    layoutClips();
}

void ArrangementView::layoutClips()
{
    auto scrollY = roundToInt (view.scrollY.get());

    for (int i = 0; i < headers.size(); ++i)
    {
        auto& r = rows[(size_t) i];
        headers[i]->setBounds (0, r.y - scrollY, headerWidth, r.height);
    }

    for (auto* cc : clipComps)
    {
        auto* track = cc->clip->getTrack();
        auto y = rowYForTrack (track);

        if (y < -1000 || track == nullptr || cc->clip->getParent() == nullptr)
        {
            cc->setVisible (false);
            continue;
        }

        int h = getTrackHeight (*track);
        auto x1 = timeline.beatToX (clipStartBeat (*cc->clip));
        auto x2 = timeline.beatToX (clipEndBeat (*cc->clip));

        auto visible = x2 >= -10.0f && x1 <= (float) lanes.getWidth() + 10.0f && y + h >= 0 && y <= lanes.getHeight();
        cc->setVisible (visible);

        if (visible)
        {
            // clamp huge widths so we don't make gigantic components
            auto cx1 = jmax (-20.0f, x1), cx2 = jmin ((float) lanes.getWidth() + 20.0f, x2);
            cc->setBounds (roundToInt (cx1), y + 1, jmax (4, roundToInt (cx2 - cx1)), h - 2);
        }
    }

    updateScrollBars();
    lanes.repaint();
    ruler.repaint();
}

void ArrangementView::updateScrollBars()
{
    auto lengthBeats = timeToBeat (edit, te::TimePosition() + edit.getLength());
    auto visibleBeats = lanes.getWidth() / timeline.pixelsPerBeat;
    auto total = jmax (lengthBeats + beatsPerBar() * 16.0, timeline.scrollBeat + visibleBeats);

    hScroll.setRangeLimits (0.0, total, dontSendNotification);
    hScroll.setCurrentRange (timeline.scrollBeat, visibleBeats, dontSendNotification);

    auto contentH = rows.empty() ? 0 : rows.back().y + rows.back().height;
    vScroll.setRangeLimits (0.0, jmax ((double) contentH + 120.0, (double) lanes.getHeight()), dontSendNotification);
    vScroll.setCurrentRange (view.scrollY.get(), lanes.getHeight(), dontSendNotification);
}

void ArrangementView::scrollBarMoved (ScrollBar* bar, double newStart)
{
    if (bar == &hScroll)
    {
        timeline.scrollBeat = jmax (0.0, newStart);
        view.scrollBeat = timeline.scrollBeat;
        followPlayhead = false;
    }
    else
    {
        view.scrollY = jmax (0.0, newStart);
    }

    layoutClips();
}

void ArrangementView::zoomBy (double factor, double anchorBeat)
{
    auto anchorX = timeline.beatToX (anchorBeat);
    timeline.pixelsPerBeat = jlimit (1.0, 600.0, timeline.pixelsPerBeat * factor);
    timeline.scrollBeat = jmax (0.0, anchorBeat - anchorX / timeline.pixelsPerBeat);
    view.pixelsPerBeat = timeline.pixelsPerBeat;
    view.scrollBeat = timeline.scrollBeat;
    layoutClips();
}

void ArrangementView::scrollToBeat (double beat)
{
    timeline.scrollBeat = jmax (0.0, beat);
    view.scrollBeat = timeline.scrollBeat;
    layoutClips();
}

void ArrangementView::zoomToFit()
{
    auto lengthBeats = jmax (beatsPerBar() * 8.0, timeToBeat (edit, te::TimePosition() + edit.getLength()) + beatsPerBar());
    timeline.pixelsPerBeat = jlimit (1.0, 600.0, (lanes.getWidth() - 20) / lengthBeats);
    timeline.scrollBeat = 0.0;
    view.pixelsPerBeat = timeline.pixelsPerBeat;
    view.scrollBeat = 0.0;
    layoutClips();
}

void ArrangementView::mouseWheelMove (const MouseEvent& e, const MouseWheelDetails& w)
{
    auto pos = lanes.getLocalPoint (e.eventComponent, e.getPosition());

    if (e.mods.isCtrlDown() || e.mods.isCommandDown())
    {
        zoomBy (std::pow (1.15, (w.deltaY > 0 ? 1.0 : -1.0)), timeline.xToBeat (pos.x));
        return;
    }

    if (e.mods.isShiftDown() || std::abs (w.deltaX) > std::abs (w.deltaY))
    {
        auto d = (std::abs (w.deltaX) > std::abs (w.deltaY) ? w.deltaX : w.deltaY);
        scrollToBeat (timeline.scrollBeat - d * 300.0 / timeline.pixelsPerBeat);
        followPlayhead = false;
        return;
    }

    auto contentH = rows.empty() ? 0 : rows.back().y + rows.back().height;
    view.scrollY = jlimit (0.0, jmax (0.0, (double) contentH + 120.0 - lanes.getHeight()),
                           view.scrollY.get() - w.deltaY * 200.0);
    layoutClips();
}

void ArrangementView::mouseMagnify (const MouseEvent& e, float scale)
{
    auto pos = lanes.getLocalPoint (e.eventComponent, e.getPosition());
    zoomBy (scale, timeline.xToBeat (pos.x));
}

void ArrangementView::timerCallback()
{
    auto& tc = edit.getTransport();
    auto beat = timeToBeat (edit, tc.getPosition());
    auto x = timeline.beatToX (beat);

    if (tc.isPlaying() && followPlayhead && ! tc.isUserDragging())
    {
        auto w = (float) lanes.getWidth();
        if (x > w * 0.92f || x < 0.0f)
        {
            scrollToBeat (beat - (w * 0.08f) / timeline.pixelsPerBeat);
            x = timeline.beatToX (beat);
        }
    }

    if (! tc.isPlaying())
        followPlayhead = true;

    if (std::abs (x - lanes.playheadX) > 0.5f || tc.isRecording())
    {
        auto old = lanes.playheadX;
        lanes.playheadX = x;

        if (tc.isRecording())
            lanes.repaint();
        else
        {
            lanes.repaint (Rectangle<int> (roundToInt (old) - 2, 0, 5, lanes.getHeight()));
            lanes.repaint (Rectangle<int> (roundToInt (x) - 2, 0, 5, lanes.getHeight()));
        }

        ruler.repaint();
    }
}

void ArrangementView::showAddTrackMenu()
{
    PopupMenu m;
    auto after = session.getSelectedTrack();

    m.addItem ("Drum Kit (pads + step sequencer)", [this, after]
    {
        edit.getUndoManager().beginNewTransaction ("Add track");
        session.selectTrack (session.addTrackWithInstrument (InstrumentSpec::drums(), {}, after));
    });

    PopupMenu gm;
    for (int fam = 0; fam < 16; ++fam)
    {
        PopupMenu sub;
        for (int p = fam * 8; p < fam * 8 + 8; ++p)
            sub.addItem (SoundFonts::gmProgramName (p), [this, p, after]
            {
                edit.getUndoManager().beginNewTransaction ("Add track");
                session.selectTrack (session.addTrackWithInstrument (InstrumentSpec::gm (p), {}, after));
            });
        gm.addSubMenu (SoundFonts::gmFamilyName (fam), sub);
    }
    gm.addSeparator();
    gm.addItem ("General MIDI Drum Kit", [this, after]
    {
        edit.getUndoManager().beginNewTransaction ("Add track");
        session.selectTrack (session.addTrackWithInstrument (InstrumentSpec::gmDrums(), "GM Drums", after));
    });
    m.addSubMenu ("Instrument (piano, strings, guitar...)", gm);

    PopupMenu synths;
    for (auto& name : SynthPresets::getNames())
        synths.addItem (name, [this, name, after]
        {
            edit.getUndoManager().beginNewTransaction ("Add track");
            session.selectTrack (session.addTrackWithInstrument (InstrumentSpec::synth (name), {}, after));
        });
    m.addSubMenu ("Synth", synths);

    m.addItem ("Audio (record a mic or guitar, or drop in audio files)", [this, after]
    {
        edit.getUndoManager().beginNewTransaction ("Add track");
        session.selectTrack (session.addTrack (TrackKind::audio, {}, after));
    });

    m.showMenuAsync (PopupMenu::Options().withTargetComponent (&addTrackButton));
}

//==============================================================================
void ArrangementView::changeListenerCallback (ChangeBroadcaster* source)
{
    if (source == &session.getSelectionManager())
    {
        for (auto* cc : clipComps)
            cc->repaint();

        for (auto* h : headers)
            h->repaint();

        lanes.repaint();
    }
    else
    {
        ruler.repaint();
        lanes.repaint();
    }
}

static bool isNoteOrSequenceTree (const ValueTree& v)
{
    return v.hasType (te::IDs::NOTE) || v.hasType (te::IDs::SEQUENCE) || v.hasType (te::IDs::CONTROL);
}

void ArrangementView::valueTreePropertyChanged (ValueTree& v, const Identifier& id)
{
    if (te::Clip::isClipState (v))
    {
        needsLayout = true;
        triggerAsyncUpdate();
    }
    else if (te::TrackList::isTrack (v))
    {
        if (id == te::IDs::name || id == te::IDs::colour || id == te::IDs::mute || id == te::IDs::solo)
            for (auto* h : headers)
                if (h->track->state == v)
                    h->refresh();

        if (id == te::IDs::colour)
            for (auto* cc : clipComps)
                cc->repaint();
    }
    else if (isNoteOrSequenceTree (v))
    {
        needsLayout = true;
        triggerAsyncUpdate();
    }
    else if (v.hasType (te::IDs::TRANSPORT) && (id == te::IDs::looping || id == te::IDs::loopPoint1 || id == te::IDs::loopPoint2))
    {
        ruler.repaint();
        lanes.repaint();
    }
    else if (v.hasType (te::IDs::TEMPO) || v.hasType (te::IDs::TIMESIG))
    {
        needsLayout = true;
        triggerAsyncUpdate();
    }
    else if (v.hasType (te::IDs::INPUTDEVICEDESTINATION) || v.hasType (te::IDs::INPUTDEVICE))
    {
        for (auto* h : headers)
            h->refresh();
    }
}

void ArrangementView::valueTreeChildAdded (ValueTree&, ValueTree& c)
{
    if (te::TrackList::isTrack (c) || te::Clip::isClipState (c))
    {
        needsRebuild = true;
        triggerAsyncUpdate();
    }
    else if (isNoteOrSequenceTree (c))
    {
        needsLayout = true;
        triggerAsyncUpdate();
    }
    else if (c.hasType (te::IDs::INPUTDEVICEDESTINATION))
    {
        for (auto* h : headers)
            h->refresh();
    }
}

void ArrangementView::valueTreeChildRemoved (ValueTree&, ValueTree& c, int)
{
    valueTreeChildAdded (c, c);
}

void ArrangementView::valueTreeChildOrderChanged (ValueTree& parent, int, int)
{
    if (parent.hasType (te::IDs::EDIT))
    {
        needsRebuild = true;
        triggerAsyncUpdate();
    }
}

void ArrangementView::handleAsyncUpdate()
{
    if (needsRebuild && ! isDraggingClips)
    {
        rebuildAll();
        needsLayout = false;
        return;
    }

    if (needsLayout || needsRebuild)
    {
        needsLayout = false;
        buildRows();
        layoutClips();

        for (auto* cc : clipComps)
            cc->repaint();
    }
}

//==============================================================================
bool ArrangementView::isInterestedInDragSource (const SourceDetails& d)
{
    return d.description.toString().isNotEmpty();
}

void ArrangementView::itemDragMove (const SourceDetails& d)
{
    auto p = lanes.getLocalPoint (this, d.localPosition);
    auto idx = trackIndexAtY (p.y);
    dropHighlightY = idx >= 0 ? rowYForTrack (rows[(size_t) idx].track.get()) + rows[(size_t) idx].height / 2
                              : (rows.empty() ? 0 : rows.back().y + rows.back().height - roundToInt (view.scrollY.get()));
    lanes.repaint();
}

void ArrangementView::itemDragExit (const SourceDetails&)
{
    dropHighlightY = -1;
    lanes.repaint();
}

void ArrangementView::itemDropped (const SourceDetails& d)
{
    dropHighlightY = -1;
    handleDrop (d.description.toString(), d.localPosition);
    lanes.repaint();
}

bool ArrangementView::isInterestedInFileDrag (const StringArray&)
{
    return true;
}

void ArrangementView::filesDropped (const StringArray& files, int x, int y)
{
    auto p = lanes.getLocalPoint (this, Point<int> (x, y));
    auto track = trackAtY (p.y);
    auto beat = jmax (0.0, snap (timeline.xToBeat (p.x)));
    addFilesAt (files, track, beat);
}

void ArrangementView::addFilesAt (const StringArray& files, te::AudioTrack* track, double beat)
{
    edit.getUndoManager().beginNewTransaction ("Add files");

    for (auto& path : files)
    {
        File f (path);
        auto ext = f.getFileExtension().toLowerCase();

        if (ProjectIO::isProjectFile (f))
        {
            if (onOpenProjectFile)
                onOpenProjectFile (f);
            return;
        }

        if (ext == ".mid" || ext == ".midi")
        {
            ProjectIO::importMidiFileIntoEdit (session, f, beat, track);
            continue;
        }

        if (edit.engine.getAudioFileFormatManager().readFormatManager.findFormatForFileExtension (ext) != nullptr)
        {
            auto target = track;
            if (target == nullptr || getTrackKind (*target) != TrackKind::audio)
                target = session.addTrack (TrackKind::audio, f.getFileNameWithoutExtension());

            if (target != nullptr)
                session.addAudioFile (*target, f, beat);

            track = nullptr;   // subsequent files get their own tracks
            continue;
        }

        session.status ("Don't know what to do with " + f.getFileName());
    }
}

void ArrangementView::handleDrop (const String& description, Point<int> posInThis)
{
    auto p = lanes.getLocalPoint (this, posInThis);
    auto track = trackAtY (p.y);
    auto beat = jmax (0.0, snap (timeline.xToBeat (p.x)));

    if (description.startsWith ("file:"))
    {
        addFilesAt (StringArray::fromLines (description.fromFirstOccurrenceOf ("file:", false, false)), track, beat);
        return;
    }

    edit.getUndoManager().beginNewTransaction ("Drop");
    BrowserItems::applyToTrack (session, description, track, true);
}

//==============================================================================
namespace ClipActions
{
    void deleteSelected (Session& s)
    {
        auto clips = s.getSelectedClips();
        s.edit_().getUndoManager().beginNewTransaction ("Delete");

        if (! clips.isEmpty())
        {
            s.getSelectionManager().deselectAll();
            for (auto c : clips)
                c->removeFromParent();
            return;
        }

        if (auto t = s.getSelectionManager().getFirstItemOfType<te::AudioTrack>())
            s.deleteTrack (*t);
    }

    void duplicateSelected (Session& s)
    {
        auto clips = s.getSelectedClips();
        if (clips.isEmpty())
        {
            if (auto t = s.getSelectionManager().getFirstItemOfType<te::AudioTrack>())
            {
                s.edit_().getUndoManager().beginNewTransaction ("Duplicate track");
                s.duplicateTrack (*t);
            }
            return;
        }

        auto& edit = s.edit_();
        edit.getUndoManager().beginNewTransaction ("Duplicate");
        double minStart = 1.0e9, maxEnd = 0.0;
        for (auto c : clips)
        {
            minStart = jmin (minStart, clipStartBeat (*c));
            maxEnd = jmax (maxEnd, clipEndBeat (*c));
        }

        auto shift = maxEnd - minStart;
        auto& sm = s.getSelectionManager();
        sm.deselectAll();

        for (auto c : clips)
            if (auto copy = te::duplicateClip (*c))
            {
                copy->setStart (beatToTime (edit, clipStartBeat (*c) + shift), false, true);
                sm.addToSelection (copy.get());
            }
    }

    void splitSelectedAtPlayhead (Session& s)
    {
        auto& edit = s.edit_();
        auto t = edit.getTransport().getPosition();
        auto clips = s.getSelectedClips();

        if (clips.isEmpty())
            if (auto track = s.getSelectedTrack())
                for (auto c : track->getClips())
                    clips.add (c);

        edit.getUndoManager().beginNewTransaction ("Split");
        for (auto c : clips)
        {
            auto pos = c->getPosition();
            if (t > pos.getStart() && t < pos.getEnd())
                if (auto ct = c->getClipTrack())
                    ct->splitClip (*c, t);
        }
    }

    void copySelected (Session& s)
    {
        auto clips = s.getSelectedClips();
        if (clips.isEmpty())
            return;

        auto content = std::make_unique<te::Clipboard::Clips>();
        content->addSelectedClips (s.getSelectionManager().getSelectedObjects(),
                                   te::getTimeRangeForSelectedItems (s.getSelectionManager().getSelectedObjects()),
                                   te::Clipboard::Clips::AutomationLocked::no);
        te::Clipboard::getInstance()->setContent (std::move (content));
        s.status ("Copied " + String (clips.size()) + " clip(s)");
    }

    void cutSelected (Session& s)
    {
        copySelected (s);
        deleteSelected (s);
    }

    void paste (Session& s)
    {
        auto& edit = s.edit_();
        auto* content = te::Clipboard::getInstance()->getContentWithType<te::Clipboard::Clips>();
        if (content == nullptr)
            return;

        auto track = s.getSelectedTrack();
        if (track == nullptr)
            track = te::getAudioTracks (edit).getFirst();
        if (track == nullptr)
            return;

        edit.getUndoManager().beginNewTransaction ("Paste");
        te::EditInsertPoint insertPoint (edit);
        te::Clipboard::ContentType::EditPastingOptions options (edit, insertPoint, &s.getSelectionManager());
        options.startTrack = track;
        options.startTime = edit.getTransport().getPosition();
        content->pasteIntoEdit (options);
    }

    void selectAll (Session& s)
    {
        auto& sm = s.getSelectionManager();
        sm.deselectAll();
        for (auto t : te::getAudioTracks (s.edit_()))
            for (auto c : t->getClips())
                sm.addToSelection (c);
    }

    void nudgeSelected (Session& s, double beats)
    {
        auto& edit = s.edit_();
        edit.getUndoManager().beginNewTransaction ("Nudge");
        for (auto c : s.getSelectedClips())
            c->setStart (beatToTime (edit, jmax (0.0, clipStartBeat (*c) + beats)), false, true);
    }

    void setLoopToSelection (Session& s)
    {
        auto clips = s.getSelectedClips();
        if (clips.isEmpty())
            return;

        auto range = te::getTimeRangeForSelectedItems (s.getSelectionManager().getSelectedObjects());
        auto& tc = s.edit_().getTransport();
        tc.setLoopRange (range);
        tc.looping = true;
    }

    void quantizeSelected (Session& s, double division, float strength)
    {
        auto& edit = s.edit_();
        edit.getUndoManager().beginNewTransaction ("Quantize");
        auto um = &edit.getUndoManager();

        for (auto c : s.getSelectedClips())
            if (auto mc = dynamic_cast<te::MidiClip*> (c))
                for (auto n : mc->getSequence().getNotes())
                {
                    auto st = n->getStartBeat().inBeats();
                    auto q = st + (snapBeat (st, division) - st) * strength;
                    n->setStartAndLength (B (q), n->getLengthBeats(), um);
                }
    }

    void toggleMuteSelected (Session& s)
    {
        s.edit_().getUndoManager().beginNewTransaction ("Mute clips");
        for (auto c : s.getSelectedClips())
            c->setMuted (! c->isMuted());
    }

    void renameSelected (Session& s)
    {
        auto clips = s.getSelectedClips();
        if (clips.isEmpty())
            return;

        auto* aw = new AlertWindow ("Rename clip", "New name:", MessageBoxIconType::NoIcon);
        aw->addTextEditor ("name", clips.getFirst()->getName());
        aw->addButton ("Rename", 1, KeyPress (KeyPress::returnKey));
        aw->addButton ("Cancel", 0, KeyPress (KeyPress::escapeKey));

        te::Clip::Ptr first = clips.getFirst();
        aw->enterModalState (true, ModalCallbackFunction::create ([aw, &s] (int result)
        {
            if (result == 1)
            {
                auto name = aw->getTextEditorContents ("name");
                s.edit_().getUndoManager().beginNewTransaction ("Rename");
                for (auto c : s.getSelectedClips())
                    c->setName (name);
            }
        }), true);
    }
}

} // namespace lode
