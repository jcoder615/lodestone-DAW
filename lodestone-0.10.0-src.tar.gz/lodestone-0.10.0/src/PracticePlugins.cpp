/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "PracticePlugins.h"

namespace lode
{
using namespace juce;

bool isPracticeUtilityPlugin (const te::Plugin* p)
{
    return dynamic_cast<const KeyZonePlugin*> (p) != nullptr
        || dynamic_cast<const InputTapPlugin*> (p) != nullptr
        || dynamic_cast<const MasterTapPlugin*> (p) != nullptr;
}

//==============================================================================
// KeyZonePlugin
//==============================================================================
const char* KeyZonePlugin::xmlTypeName = "lodestoneKeyZone";
const Identifier KeyZonePlugin::lowID ("low"), KeyZonePlugin::highID ("high"),
                 KeyZonePlugin::transposeID ("transpose"), KeyZonePlugin::channelID ("channel");

KeyZonePlugin::KeyZonePlugin (te::PluginCreationInfo info) : Plugin (info)
{
    scratch.reserve (256);
    updateAtomics();
}

KeyZonePlugin::~KeyZonePlugin()
{
    notifyListenersOfDeletion();
}

int KeyZonePlugin::getLow() const          { return jlimit (0, 127, (int) state.getProperty (lowID, 0)); }
int KeyZonePlugin::getHigh() const         { return jlimit (0, 127, (int) state.getProperty (highID, 127)); }
int KeyZonePlugin::getTranspose() const    { return jlimit (-48, 48, (int) state.getProperty (transposeID, 0)); }
int KeyZonePlugin::getChannel() const      { return jlimit (0, 16, (int) state.getProperty (channelID, 0)); }

void KeyZonePlugin::setRange (int low, int high)
{
    low = jlimit (0, 127, low);
    high = jlimit (0, 127, high);
    if (low > high)
        std::swap (low, high);

    state.setProperty (lowID, low, nullptr);
    state.setProperty (highID, high, nullptr);
}

void KeyZonePlugin::setTranspose (int s)   { state.setProperty (transposeID, jlimit (-48, 48, s), nullptr); }
void KeyZonePlugin::setChannel (int c)     { state.setProperty (channelID, jlimit (0, 16, c), nullptr); }

void KeyZonePlugin::valueTreeChanged()
{
    Plugin::valueTreeChanged();
    updateAtomics();
}

void KeyZonePlugin::updateAtomics()
{
    lo = getLow();
    hi = getHigh();
    shift = getTranspose();
    chan = getChannel();
}

void KeyZonePlugin::restorePluginStateFromValueTree (const ValueTree& v)
{
    for (auto id : { lowID, highID, transposeID, channelID })
        if (v.hasProperty (id))
            state.setProperty (id, v.getProperty (id), nullptr);

    updateAtomics();
}

void KeyZonePlugin::initialise (const te::PluginInitialisationInfo&)
{
    sounding.fill (0);
}

void KeyZonePlugin::midiPanic()
{
    sounding.fill (0);
}

void KeyZonePlugin::push (const MidiMessage& m, double time, int inNote, bool passed) noexcept
{
    ZoneEvent e;
    e.time = time;
    e.inNote = (int8) inNote;
    e.passed = passed;

    auto* raw = m.getRawData();
    for (int i = 0; i < jmin (3, m.getRawDataSize()); ++i)
        e.bytes[i] = raw[i];

    events.push (e);
}

void KeyZonePlugin::applyToBuffer (const te::PluginRenderContext& fc)
{
    auto* midi = fc.bufferForMidiMessages;
    if (midi == nullptr)
        return;

    if (midi->isAllNotesOff)
        sounding.fill (0);

    if (midi->isEmpty())
        return;

    const double blockTime = engine.getDeviceManager().getCurrentStreamTime() + fc.midiBufferOffset;
    const int l = lo.load(), h = hi.load(), t = shift.load(), c = chan.load();

    scratch.clear();

    for (auto& m : *midi)
    {
        const double when = blockTime + m.getTimeStamp();
        const int ch = m.getChannel();     // 0 for non-channel messages
        const bool channelOK = c == 0 || ch == 0 || ch == c;

        if (m.isNoteOn())
        {
            const int key = m.getNoteNumber();
            const int out = key + t;
            const bool pass = channelOK && key >= l && key <= h && out >= 0 && out <= 127;
            auto& slot = sounding[(size_t) ((jmax (1, ch) - 1) * 128 + key)];

            if (pass)
            {
                if (slot != 0)  // retriggered while still sounding: close the old one first
                {
                    auto off = te::MidiMessageWithSource (MidiMessage::noteOff (jmax (1, ch), slot - 1), m.mpeSourceID);
                    off.setTimeStamp (m.getTimeStamp());
                    scratch.add (off);
                }

                auto copy = m;
                copy.setNoteNumber (out);
                scratch.add (copy);
                slot = (int16) (out + 1);
                push (copy, when, key, true);
            }
            else
            {
                push (m, when, key, false);
            }
        }
        else if (m.isNoteOff())
        {
            const int key = m.getNoteNumber();
            auto& slot = sounding[(size_t) ((jmax (1, ch) - 1) * 128 + key)];

            // note-offs follow the note-on's mapping, so changing the zone or transpose
            // while a key is held can never leave a note stuck
            if (slot != 0)
            {
                auto copy = m;
                copy.setNoteNumber (slot - 1);
                scratch.add (copy);
                slot = 0;
                push (copy, when, key, true);
            }
            else
            {
                push (m, when, key, false);
            }
        }
        else if (channelOK)
        {
            scratch.add (m);

            if (m.isController() || m.isPitchWheel() || m.isChannelPressure())
                push (m, when, -1, true);
        }
    }

    scratch.isAllNotesOff = midi->isAllNotesOff;
    midi->swapWith (scratch);
}

//==============================================================================
// InputTapPlugin
//==============================================================================
const char* InputTapPlugin::xmlTypeName = "lodestoneInputTap";
const Identifier InputTapPlugin::inputChannelID ("inputChannel"), InputTapPlugin::monitorID ("monitor");

InputTapPlugin::InputTapPlugin (te::PluginCreationInfo info) : Plugin (info)
{
    updateAtomics();
}

InputTapPlugin::~InputTapPlugin()
{
    notifyListenersOfDeletion();
}

int InputTapPlugin::getInputChannel() const     { return jlimit (-1, 1, (int) state.getProperty (inputChannelID, 0)); }
void InputTapPlugin::setInputChannel (int c)    { state.setProperty (inputChannelID, jlimit (-1, 1, c), nullptr); }
bool InputTapPlugin::isMonitoring() const       { return state.getProperty (monitorID, false); }
void InputTapPlugin::setMonitoring (bool b)     { state.setProperty (monitorID, b, nullptr); }

void InputTapPlugin::valueTreeChanged()
{
    Plugin::valueTreeChanged();
    updateAtomics();
}

void InputTapPlugin::updateAtomics()
{
    mode = getInputChannel();
    gate = isMonitoring();
}

void InputTapPlugin::restorePluginStateFromValueTree (const ValueTree& v)
{
    for (auto id : { inputChannelID, monitorID })
        if (v.hasProperty (id))
            state.setProperty (id, v.getProperty (id), nullptr);

    updateAtomics();
}

void InputTapPlugin::initialise (const te::PluginInitialisationInfo& info)
{
    sampleRate = info.sampleRate;
    expectedTime = -1.0;
}

bool InputTapPlugin::isReceivingAudio() const
{
    return Time::getMillisecondCounter() - lastProcessMs.load() < 500;
}

int InputTapPlugin::copyRecent (float* dest, int num) const
{
    num = jmin (num, analysisSize);
    const auto end = analysisWrite.load (std::memory_order_acquire);

    for (int i = 0; i < num; ++i)
        dest[i] = analysis[(size_t) ((end - (uint32) num + (uint32) i) & (uint32) (analysisSize - 1))];

    return num;
}

double InputTapPlugin::getSampledSeconds() const noexcept
{
    return samplePos.load() / jmax (1.0, sampleRate.load());
}

void InputTapPlugin::startSampling()
{
    if (sampleBuffer.getNumSamples() == 0)
        sampleBuffer.setSize (2, (int) (30.0 * jmax (48000.0, sampleRate.load(), engine.getDeviceManager().getSampleRate())));

    samplePos.store (0);
    sampling.store (true, std::memory_order_release);
}

AudioBuffer<float> InputTapPlugin::stopSampling()
{
    sampling.store (false, std::memory_order_release);
    const int n = jmin (samplePos.load (std::memory_order_acquire), sampleBuffer.getNumSamples());

    AudioBuffer<float> out (2, jmax (0, n));
    for (int ch = 0; ch < 2 && n > 0; ++ch)
        out.copyFrom (ch, 0, sampleBuffer, ch, 0, n);

    return out;
}

void InputTapPlugin::enableCapture()
{
    if (ringFrames.load() > 0)
        return;

    // sized for the device's actual rate (the plugin may not be initialised yet)
    auto rate = jmax (sampleRate.load(), engine.getDeviceManager().getSampleRate());
    auto frames = (int64) (captureSeconds * jmax (44100.0, rate));
    ring.assign ((size_t) frames * 2, 0);
    ringWritten.store (0);
    ringFrames.store (frames, std::memory_order_release);
}

bool InputTapPlugin::copyCapture (double fromTime, double toTime, AudioBuffer<float>& dest, double& actualStart) const
{
    const auto cap = ringFrames.load (std::memory_order_acquire);
    if (cap <= 0)
        return false;

    const auto written = ringWritten.load (std::memory_order_acquire);
    const auto t0 = ringStartTime.load();
    const auto sr = jmax (1.0, sampleRate.load());

    // stay half a second clear of the write head
    const auto available = jmin (written, cap - (int64) (sr * 0.5));
    const auto oldest = written - available;

    auto f0 = jmax (oldest, (int64) std::ceil ((fromTime - t0) * sr));
    auto f1 = jmin (written, (int64) std::floor ((toTime - t0) * sr));

    if (f1 - f0 < 64)
        return false;

    dest.setSize (2, (int) (f1 - f0));
    auto* l = dest.getWritePointer (0);
    auto* r = dest.getWritePointer (1);

    for (int64 f = f0; f < f1; ++f)
    {
        auto idx = (size_t) ((f % cap) * 2);
        l[f - f0] = ring[idx] / 32768.0f;
        r[f - f0] = ring[idx + 1] / 32768.0f;
    }

    actualStart = t0 + f0 / sr;
    return true;
}

void InputTapPlugin::applyToBuffer (const te::PluginRenderContext& fc)
{
    if (fc.destBuffer == nullptr || fc.bufferNumSamples <= 0)
        return;

    auto& buf = *fc.destBuffer;
    const int start = fc.bufferStartSample, num = fc.bufferNumSamples;
    const int nch = buf.getNumChannels();
    const int m = mode.load();

    lastProcessMs = Time::getMillisecondCounter();

    // put a mono source in the middle
    if (nch >= 2)
    {
        if (m == 0)       buf.copyFrom (1, start, buf, 0, start, num);
        else if (m == 1)  buf.copyFrom (0, start, buf, 1, start, num);
    }

    const float* l = buf.getReadPointer (0, start);
    const float* r = nch > 1 ? buf.getReadPointer (1, start) : l;

    // tuner feed + meter
    {
        float pk = 0.0f;
        auto w = analysisWrite.load (std::memory_order_relaxed);

        for (int i = 0; i < num; ++i)
        {
            const float s = 0.5f * (l[i] + r[i]);
            analysis[(size_t) ((w + (uint32) i) & (uint32) (analysisSize - 1))] = s;
            pk = jmax (pk, std::abs (l[i]), std::abs (r[i]));
        }

        analysisWrite.store (w + (uint32) num, std::memory_order_release);

        if (pk > peak.load (std::memory_order_relaxed))
            peak.store (pk, std::memory_order_relaxed);
    }

    // hold-to-sample
    if (sampling.load (std::memory_order_acquire))
    {
        auto pos = samplePos.load();
        const int n = jmin (num, sampleBuffer.getNumSamples() - pos);

        if (n > 0)
        {
            sampleBuffer.copyFrom (0, pos, l, n);
            sampleBuffer.copyFrom (1, pos, r, n);
            samplePos.compare_exchange_strong (pos, pos + n);   // fails harmlessly if a new take was started meanwhile
        }
    }

    // rolling capture (written whether or not you're monitoring: plenty of people
    // listen through the interface's direct monitoring)
    if (const auto cap = ringFrames.load (std::memory_order_acquire); cap > 0)
    {
        const double sr = jmax (1.0, sampleRate.load());
        const double now = engine.getDeviceManager().getCurrentStreamTime();

        if (expectedTime < 0.0 || std::abs (now - expectedTime) > 0.002)
        {
            ringWritten.store (0, std::memory_order_release);
            ringStartTime.store (now);
        }

        expectedTime = now + num / sr;

        auto written = ringWritten.load (std::memory_order_relaxed);
        auto pos = written % cap;

        for (int i = 0; i < num; ++i)
        {
            auto idx = (size_t) (pos * 2);
            ring[idx]     = (int16) jlimit (-32767, 32767, (int) std::lrint (l[i] * 32767.0f));
            ring[idx + 1] = (int16) jlimit (-32767, 32767, (int) std::lrint (r[i] * 32767.0f));

            if (++pos == cap)
                pos = 0;
        }

        ringWritten.store (written + num, std::memory_order_release);
    }

    // monitoring off: the tuner, meter, sampler and capture still hear it - you don't
    if (! gate.load())
        buf.clear (start, num);
}

//==============================================================================
// MasterTapPlugin
//==============================================================================
const char* MasterTapPlugin::xmlTypeName = "lodestoneMasterTap";

MasterTapPlugin::MasterTapPlugin (te::PluginCreationInfo info) : Plugin (info) {}

MasterTapPlugin::~MasterTapPlugin()
{
    setWriter (nullptr);
    notifyListenersOfDeletion();
}

void MasterTapPlugin::initialise (const te::PluginInitialisationInfo& info)
{
    sampleRate = info.sampleRate;
    expectedStream = expectedEdit = -1.0;
}

void MasterTapPlugin::setWriter (AudioFormatWriter::ThreadedWriter* w)
{
    const SpinLock::ScopedLockType sl (writerLock);
    writer = w;
    samplesWritten = 0;
}

void MasterTapPlugin::applyToBuffer (const te::PluginRenderContext& fc)
{
    const double sr = jmax (1.0, sampleRate.load());
    const double now = engine.getDeviceManager().getCurrentStreamTime();
    const double dur = fc.bufferNumSamples / sr;
    const bool playing = fc.isPlaying;
    const double editT = fc.editTime.getStart().inSeconds();

    const bool jump = playing != lastPlaying || expectedStream < 0.0
                       || std::abs (now - expectedStream) > 0.001
                       || (playing && std::abs (editT - expectedEdit) > 0.001);

    if (jump)
        marks.push ({ now, editT, playing });

    lastPlaying = playing;
    expectedStream = now + dur;
    expectedEdit = editT + dur;
    latestStreamTime.store (now + dur);

    if (fc.destBuffer == nullptr || fc.bufferNumSamples <= 0)
        return;

    auto& buf = *fc.destBuffer;
    const int start = fc.bufferStartSample, num = fc.bufferNumSamples;
    const int nch = buf.getNumChannels();

    if (nch == 0)
        return;

    const float* chans[2] = { buf.getReadPointer (0, start), buf.getReadPointer (jmin (1, nch - 1), start) };

    float pk = 0.0f;
    for (int ch = 0; ch < 2; ++ch)
        pk = jmax (pk, FloatVectorOperations::findMaximum (chans[ch], num), -FloatVectorOperations::findMinimum (chans[ch], num));

    if (pk > peak.load (std::memory_order_relaxed))
        peak.store (pk, std::memory_order_relaxed);

    const SpinLock::ScopedTryLockType sl (writerLock);

    if (sl.isLocked() && writer != nullptr)
        if (writer->write (chans, num))
            samplesWritten += num;
}

} // namespace lode
