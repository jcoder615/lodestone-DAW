/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    A General MIDI / SoundFont (.sf2) instrument built on FluidSynth.
    It's what makes imported MIDI, GarageBand, FL and LMMS projects sound
    like *something* the moment they open.
*/
#pragma once

#include "Utils.h"

typedef struct _fluid_hashtable_t fluid_settings_t;
typedef struct _fluid_synth_t fluid_synth_t;

namespace lode
{

struct SoundFontPreset
{
    int bank = 0, program = 0;
    juce::String name;
};

namespace SoundFonts
{
    juce::File getDefaultSoundFont();
    juce::Array<juce::File> findInstalled();
    const juce::Array<SoundFontPreset>& getPresets (const juce::File& sf2);
    juce::String gmProgramName (int program);
    juce::String gmFamilyName (int family);       // 0..15
}

//==============================================================================
class SoundFontPlugin : public te::Plugin,
                        private juce::AsyncUpdater
{
public:
    SoundFontPlugin (te::PluginCreationInfo);
    ~SoundFontPlugin() override;

    static const char* getPluginName()                  { return NEEDS_TRANS ("SoundFont Player"); }
    static const char* xmlTypeName;

    juce::String getName() const override;
    juce::String getPluginType() override               { return xmlTypeName; }
    juce::String getShortName (int) override            { return "SF2"; }
    juce::String getSelectableDescription() override    { return "SoundFont Player"; }
    juce::String getVendor() override                   { return "Lodestone"; }

    bool isSynth() override                             { return true; }
    bool takesMidiInput() override                      { return true; }
    bool takesAudioInput() override                     { return true; }
    bool producesAudioWhenNoAudioInput() override       { return true; }
    bool noTail() override                              { return false; }
    double getTailLength() const override               { return 3.0; }
    int getNumOutputChannelsGivenInputs (int) override  { return 2; }
    BusLayout getBusses() const override                { return BusLayout::singleStereoInOut(); }

    void initialise (const te::PluginInitialisationInfo&) override;
    void deinitialise() override;
    void midiPanic() override;
    void applyToBuffer (const te::PluginRenderContext&) override;
    bool hasNameForMidiNoteNumber (int note, int midiChannel, juce::String& name) override;
    void restorePluginStateFromValueTree (const juce::ValueTree&) override;
    std::unique_ptr<EditorComponent> createEditor() override;   // defined in InstrumentPanel.cpp

    //==============================================================================
    void setSoundFont (const juce::File&);
    void setProgram (int bank, int program);
    juce::File getSoundFontFile() const     { return juce::File (sf2Path.get()); }
    int getBank() const                     { return bank.get(); }
    int getProgram() const                  { return program.get(); }
    bool isDrumKit() const                  { return bank.get() == 128; }
    juce::String getPresetName() const;

    juce::CachedValue<juce::String> sf2Path;
    juce::CachedValue<int> bank, program;
    juce::CachedValue<float> gainValue, reverbValue, chorusValue;
    te::AutomatableParameter::Ptr gainParam, reverbParam, chorusParam;

private:
    fluid_settings_t* settings = nullptr;
    fluid_synth_t* synth = nullptr;
    int sfontId = -1;
    juce::String loadedPath;
    double sampleRate = 0.0;
    juce::CriticalSection synthLock;
    juce::AudioBuffer<float> scratch;
    int lastBank = -1, lastProgram = -1;
    float lastReverb = -1.0f, lastChorus = -1.0f;

    void createSynth (double sampleRate);
    void destroySynth();
    void loadSoundFontIfNeeded();
    void applyProgram();
    int channel() const                     { return isDrumKit() ? 9 : 0; }

    void valueTreeChanged() override                    { Plugin::valueTreeChanged(); triggerAsyncUpdate(); }
    void handleAsyncUpdate() override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SoundFontPlugin)
};

} // namespace lode
