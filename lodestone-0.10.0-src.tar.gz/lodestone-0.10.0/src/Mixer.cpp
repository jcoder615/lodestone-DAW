/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Mixer.h"
#include "InstrumentPanel.h"

namespace lode
{
using namespace juce;

//==============================================================================
te::LevelMeterPlugin* findMasterMeter (te::Edit& edit)
{
    auto& list = edit.getMasterPluginList();

    for (auto p : list)
        if (auto lm = dynamic_cast<te::LevelMeterPlugin*> (p))
            return lm;

    if (auto p = edit.getPluginCache().createNewPlugin (te::LevelMeterPlugin::xmlTypeName, {}))
    {
        list.insertPlugin (p, list.size(), nullptr);
        return dynamic_cast<te::LevelMeterPlugin*> (p.get());
    }

    return nullptr;
}

LevelMeter::LevelMeter (te::LevelMeterPlugin* p, bool v) : vertical (v)
{
    setSource (p);
    startTimerHz (30);
}

LevelMeter::~LevelMeter()
{
    setSource (nullptr);
}

void LevelMeter::setSource (te::LevelMeterPlugin* p)
{
    if (auto old = dynamic_cast<te::LevelMeterPlugin*> (meterPlugin.get()))
        old->measurer.removeClient (client);

    meterPlugin = p;

    if (p != nullptr)
        p->measurer.addClient (client);
}

void LevelMeter::timerCallback()
{
    if (meterPlugin == nullptr)
        return;

    auto l = client.getAndClearAudioLevel (0).dB;
    auto r = client.getAndClearAudioLevel (1).dB;

    if (client.getNumChannelsUsed() < 2)
        r = l;

    // fall back smoothly
    levelL = jmax (l, levelL - 1.6f);
    levelR = jmax (r, levelR - 1.6f);

    auto peak = jmax (levelL, levelR);
    if (peak >= peakHold)
    {
        peakHold = peak;
        peakHoldFrames = 45;
    }
    else if (--peakHoldFrames <= 0)
    {
        peakHold = jmax (-100.0f, peakHold - 1.0f);
    }

    repaint();
}

void LevelMeter::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    Draw::meter (g, r, levelL, levelR, vertical);

    if (peakHold > -60.0f && vertical)
    {
        auto p = std::pow (jlimit (0.0f, 1.0f, (peakHold + 60.0f) / 66.0f), 1.6f);
        auto y = r.getBottom() - r.getHeight() * p;
        g.setColour (peakHold > -0.1f ? Col::north : Col::text.withAlpha (0.7f));
        g.fillRect (r.getX(), y, r.getWidth(), 1.5f);
    }
}

//==============================================================================
ChannelStrip::ChannelStrip (Session& s, te::AudioTrack* t)
    : track (t), session (s)
{
    auto& edit = session.edit_();

    addAndMakeVisible (name);
    name.setJustificationType (Justification::centred);
    name.setFont (LodeLookAndFeel::font (12.5f, true));
    name.setInterceptsMouseClicks (false, false);

    if (track != nullptr)
        volumePlugin = track->getVolumePlugin();
    else
        volumePlugin = edit.getMasterVolumePlugin().get();

    addAndMakeVisible (pan);
    pan.setSliderStyle (Slider::RotaryHorizontalVerticalDrag);
    pan.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    pan.setRange (-1.0, 1.0);
    pan.setDoubleClickReturnValue (true, 0.0);
    pan.setPopupDisplayEnabled (true, true, nullptr);
    pan.textFromValueFunction = [] (double v) { return std::abs (v) < 0.01 ? String ("Center") : (v < 0 ? "L " : "R ") + String (roundToInt (std::abs (v) * 100)); };
    pan.onDragStart = [&edit] { edit.getUndoManager().beginNewTransaction ("Pan"); };
    pan.onValueChange = [this]
    {
        if (auto vp = dynamic_cast<te::VolumeAndPanPlugin*> (volumePlugin.get()))
            vp->setPan ((float) pan.getValue());
    };

    addAndMakeVisible (fader);
    fader.setSliderStyle (Slider::LinearVertical);
    fader.setTextBoxStyle (Slider::NoTextBox, false, 0, 0);
    fader.setRange (0.0, 1.0);
    fader.setDoubleClickReturnValue (true, te::decibelsToVolumeFaderPosition (0.0f));
    fader.onDragStart = [&edit] { edit.getUndoManager().beginNewTransaction ("Volume"); };
    fader.onValueChange = [this]
    {
        if (auto vp = dynamic_cast<te::VolumeAndPanPlugin*> (volumePlugin.get()))
        {
            vp->setSliderPos ((float) fader.getValue());
            auto db = vp->getVolumeDb();
            dbLabel.setText (db <= -99.0f ? String ("-inf") : String (db, 1), dontSendNotification);
        }
    };

    addAndMakeVisible (dbLabel);
    dbLabel.setJustificationType (Justification::centred);
    dbLabel.setFont (LodeLookAndFeel::font (11.0f));
    dbLabel.setColour (Label::textColourId, Col::textDim);
    dbLabel.setEditable (false, true);
    dbLabel.onTextChange = [this]
    {
        if (auto vp = dynamic_cast<te::VolumeAndPanPlugin*> (volumePlugin.get()))
        {
            vp->setVolumeDb (jlimit (-100.0f, 6.0f, dbLabel.getText().getFloatValue()));
            refresh();
        }
    };

    if (track != nullptr)
    {
        for (auto* b : { &mute, &solo, &arm })
            addAndMakeVisible (b);

        mute.setColour (TextButton::buttonOnColourId, Col::yellow.darker (0.2f));
        solo.setColour (TextButton::buttonOnColourId, Col::south);
        arm.setColour (TextButton::buttonOnColourId, Col::north);

        mute.onClick = [this] { track->setMute (! track->isMuted (false)); refresh(); };
        solo.onClick = [this] { track->setSolo (! track->isSolo (false)); refresh(); };
        arm.onClick = [this]
        {
            auto& router = session.getInputRouter();
            router.armTrack (*track, ! router.isTrackArmed (*track));
            refresh();
        };

        addAndMakeVisible (addFx);
        addFx.setColour (TextButton::buttonColourId, Col::bg2);
        addFx.onClick = [this] { showAddEffectMenu (session, *track, &addFx); };

        meter = std::make_unique<LevelMeter> (track->getLevelMeterPlugin());
    }
    else
    {
        addAndMakeVisible (addFx);
        addFx.setColour (TextButton::buttonColourId, Col::bg2);
        addFx.onClick = [this] { showAddMasterEffectMenu (session, &addFx); };
        meter = std::make_unique<LevelMeter> (findMasterMeter (edit));
    }

    addAndMakeVisible (*meter);
    buildSlots();
    refresh();
}

ChannelStrip::~ChannelStrip() = default;

void ChannelStrip::buildSlots()
{
    slots.clear();

    auto& list = track != nullptr ? track->pluginList : session.edit_().getMasterPluginList();

    for (auto p : list)
    {
        if (dynamic_cast<te::VolumeAndPanPlugin*> (p) != nullptr || dynamic_cast<te::LevelMeterPlugin*> (p) != nullptr)
            continue;

        auto b = slots.add (new TextButton (p->getName()));
        b->setColour (TextButton::buttonColourId, (p->isSynth() && track != nullptr) ? track->getColour().withAlpha (0.4f) : Col::bg3);
        b->setColour (TextButton::textColourOffId, p->isEnabled() ? Col::text : Col::textFaint);
        b->setTooltip (p->getName() + (p->isEnabled() ? "" : " (bypassed)"));

        te::Plugin::Ptr plugin = p;
        b->onClick = [this, plugin]
        {
            if (ModifierKeys::currentModifiers.isPopupMenu())
            {
                PopupMenu m;
                m.addItem ("Open window", [plugin] { plugin->showWindowExplicitly(); });
                m.addItem (plugin->isEnabled() ? "Bypass" : "Enable", [this, plugin] { plugin->setEnabled (! plugin->isEnabled()); buildSlots(); resized(); });
                m.addItem ("Remove", [plugin] { plugin->deleteFromParent(); });
                m.showMenuAsync ({});
            }
            else if (track == nullptr)
            {
                plugin->showWindowExplicitly();      // master effects have no Instrument panel
            }
            else if (onShowDevice)
            {
                onShowDevice (track.get(), plugin.get());
            }
        };

        addAndMakeVisible (b);
    }
}

void ChannelStrip::refresh()
{
    if (auto vp = dynamic_cast<te::VolumeAndPanPlugin*> (volumePlugin.get()))
    {
        fader.setValue (vp->getSliderPos(), dontSendNotification);
        pan.setValue (vp->getPan(), dontSendNotification);
        auto db = vp->getVolumeDb();
        dbLabel.setText (db <= -99.0f ? String ("-inf") : String (db, 1), dontSendNotification);
    }

    if (track != nullptr)
    {
        name.setText (track->getName(), dontSendNotification);
        mute.setToggleState (track->isMuted (false), dontSendNotification);
        solo.setToggleState (track->isSolo (false), dontSendNotification);
        arm.setToggleState (session.getInputRouter().isTrackArmed (*track), dontSendNotification);
        fader.setColour (Slider::trackColourId, track->getColour());
        pan.setColour (Slider::rotarySliderFillColourId, track->getColour());
    }
    else
    {
        name.setText ("MASTER", dontSendNotification);
        fader.setColour (Slider::trackColourId, Col::north);
    }

    repaint();
}

void ChannelStrip::paint (Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (2.0f, 0.0f);
    auto selected = track != nullptr && session.getSelectedTrack() == track.get();
    g.setColour (selected ? Col::bg3 : Col::bg2);
    g.fillRoundedRectangle (r, 5.0f);

    g.setColour (track != nullptr ? track->getColour() : Col::north);
    g.fillRoundedRectangle (r.removeFromTop (5.0f), 2.0f);
}

void ChannelStrip::resized()
{
    auto r = getLocalBounds().reduced (6, 4);
    r.removeFromTop (4);
    name.setBounds (r.removeFromTop (20));
    r.removeFromTop (4);

    {
        auto slotH = 20;
        for (auto* s : slots)
        {
            s->setBounds (r.removeFromTop (slotH));
            r.removeFromTop (2);
        }
        addFx.setBounds (r.removeFromTop (slotH));
        r.removeFromTop (6);
    }

    pan.setBounds (r.removeFromTop (44).withSizeKeepingCentre (44, 44));
    r.removeFromTop (2);

    auto bottom = r.removeFromBottom (24);
    if (track != nullptr)
    {
        auto w = bottom.getWidth() / 3;
        mute.setBounds (bottom.removeFromLeft (w).reduced (1));
        solo.setBounds (bottom.removeFromLeft (w).reduced (1));
        arm.setBounds (bottom.reduced (1));
    }

    dbLabel.setBounds (r.removeFromBottom (18));
    auto meterArea = r.removeFromRight (14);
    meter->setBounds (meterArea.reduced (0, 6));
    fader.setBounds (r);
}

void ChannelStrip::mouseDown (const MouseEvent&)
{
    if (track != nullptr)
        session.selectTrack (track.get());
}

//==============================================================================
MixerView::MixerView (Session& s) : session (s)
{
    addAndMakeVisible (viewport);
    viewport.setViewedComponent (&stripHolder, false);
    viewport.setScrollBarsShown (false, true);

    session.edit_().state.addListener (this);
    session.getSelectionManager().addChangeListener (this);
    rebuild();
}

MixerView::~MixerView()
{
    session.edit_().state.removeListener (this);
    session.getSelectionManager().removeChangeListener (this);
}

void MixerView::rebuild()
{
    strips.clear();
    master.reset();

    for (auto t : te::getAudioTracks (session.edit_()))
    {
        auto strip = strips.add (new ChannelStrip (session, t));
        strip->onShowDevice = [this] (te::AudioTrack* tr, te::Plugin* p) { if (onShowDevice) onShowDevice (tr, p); };
        stripHolder.addAndMakeVisible (strip);
    }

    master = std::make_unique<ChannelStrip> (session, nullptr);
    addAndMakeVisible (*master);
    resized();
}

void MixerView::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
}

void MixerView::resized()
{
    auto r = getLocalBounds().reduced (4);
    const int stripW = 96;

    if (master != nullptr)
        master->setBounds (r.removeFromRight (stripW + 8));

    r.removeFromRight (6);
    viewport.setBounds (r);

    auto h = r.getHeight() - (strips.size() * stripW > r.getWidth() ? viewport.getScrollBarThickness() : 0);
    stripHolder.setSize (jmax (r.getWidth(), strips.size() * stripW), h);

    for (int i = 0; i < strips.size(); ++i)
        strips[i]->setBounds (i * stripW, 0, stripW, h);
}

void MixerView::valueTreeChildAdded (ValueTree&, ValueTree& c)
{
    if (te::TrackList::isTrack (c) || c.hasType (te::IDs::PLUGIN))
    {
        needsRebuild = true;
        triggerAsyncUpdate();
    }
}

void MixerView::valueTreeChildRemoved (ValueTree& p, ValueTree& c, int)
{
    valueTreeChildAdded (p, c);
}

void MixerView::valueTreeChildOrderChanged (ValueTree&, int, int)
{
    needsRebuild = true;
    triggerAsyncUpdate();
}

void MixerView::valueTreePropertyChanged (ValueTree& v, const Identifier& id)
{
    if (te::TrackList::isTrack (v) && (id == te::IDs::name || id == te::IDs::colour || id == te::IDs::mute || id == te::IDs::solo))
        triggerAsyncUpdate();
    else if (v.hasType (te::IDs::PLUGIN) && id == te::IDs::enabled)
    {
        needsRebuild = true;          // slot buttons show bypass state
        triggerAsyncUpdate();
    }
    else if (v.hasType (te::IDs::PLUGIN) && (id == te::IDs::volume || id == te::IDs::pan))
        triggerAsyncUpdate();
}

void MixerView::handleAsyncUpdate()
{
    if (needsRebuild)
    {
        needsRebuild = false;
        rebuild();
        return;
    }

    for (auto* s : strips)
        s->refresh();

    if (master != nullptr)
        master->refresh();
}

void MixerView::changeListenerCallback (ChangeBroadcaster*)
{
    for (auto* s : strips)
        s->repaint();
}

} // namespace lode
