/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "ProjectIO.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"

namespace lode::ProjectIO
{
using namespace juce;

//==============================================================================
static String extOf (const File& f)     { return f.getFileExtension().toLowerCase(); }

bool isProjectFile (const File& f)
{
    auto e = extOf (f);
    return e == ".lodestone" || e == ".mmp" || e == ".mmpz" || e == ".flp" || e == ".band"
        || e == ".logicx" || e == ".dawproject" || e == ".mid" || e == ".midi"
        || e == ".zip"       // zipped .band/.logicx bundles and FL Studio "zipped loop packages"
        || e == ".lif";
}

String getOpenFileWildcard()
{
    return "*.lodestone;*.mmp;*.mmpz;*.flp;*.band;*.logicx;*.dawproject;*.mid;*.midi;*.zip";
}

//==============================================================================
/** Runs a lambda on a background thread with a modal progress window. */
struct BusyTask : public ThreadWithProgressWindow
{
    BusyTask (const String& title, std::function<void()> f)
        : ThreadWithProgressWindow (title, true, false), fn (std::move (f)) {}

    void run() override
    {
        setProgress (-1.0);
        fn();
    }

    std::function<void()> fn;
};

static void runBusy (const String& title, std::function<void()> fn)
{
    if (headlessMode())
    {
        fn();
        return;
    }

    BusyTask task (title, std::move (fn));
    task.runThread();
}

void runTaskWithProgress (te::ThreadPoolJobWithProgress& job)
{
    if (headlessMode())
    {
        while (job.runJob() != ThreadPoolJob::jobHasFinished)
        {}
        return;
    }

    struct Runner : public ThreadWithProgressWindow
    {
        Runner (te::ThreadPoolJobWithProgress& j)
            : ThreadWithProgressWindow (j.getJobName(), true, j.canCancel()), job (j) {}

        void run() override
        {
            while (! threadShouldExit())
            {
                if (job.runJob() == ThreadPoolJob::jobHasFinished)
                    break;

                setProgress (job.getCurrentTaskProgress());
            }

            if (threadShouldExit())
                job.signalJobShouldExit();
        }

        te::ThreadPoolJobWithProgress& job;
    };

    Runner r (job);
    r.runThread();
}

//==============================================================================
static InstrumentSpec guessInstrumentFromName (const String& rawName, bool& isDrums)
{
    auto n = rawName.toLowerCase();
    isDrums = false;

    auto has = [&n] (std::initializer_list<const char*> words)
    {
        for (auto w : words)
            if (n.contains (w))
                return true;
        return false;
    };

    if (has ({ "drum", "kit", "beat", "perc", "808", "909", "kick", "snare", "hat", "hihat", "cymbal", "tom", "clap", "groove" }))
    {
        isDrums = true;
        return InstrumentSpec::gmDrums();
    }

    if (has ({ "rhodes", "e-piano", "epiano", "electric piano", "wurli", "ep " })) return InstrumentSpec::gm (4);
    if (has ({ "organ", "hammond", "b3", "leslie" }))                              return InstrumentSpec::gm (16);
    if (has ({ "piano", "keys", "grand", "steinway" }))                            return InstrumentSpec::gm (0);
    if (has ({ "clav" }))                                                          return InstrumentSpec::gm (7);
    if (has ({ "vibe", "vibraphone", "marimba", "mallet" }))                       return InstrumentSpec::gm (11);
    if (has ({ "bell", "glock", "celesta", "music box" }))                         return InstrumentSpec::gm (9);
    if (has ({ "acoustic guitar", "nylon", "folk guitar" }))                       return InstrumentSpec::gm (25);
    if (has ({ "dist", "overdrive", "crunch", "metal" }) && has ({ "guitar", "gtr" })) return InstrumentSpec::gm (30);
    if (has ({ "guitar", "gtr", "strat", "tele" }))                                return InstrumentSpec::gm (27);
    if (has ({ "sub" }) && has ({ "bass" }))                                       return InstrumentSpec::synth ("Sub Bass");
    if (has ({ "acid", "303" }))                                                   return InstrumentSpec::synth ("Acid Bass");
    if (has ({ "synth bass", "synthbass", "reese", "wobble" }))                    return InstrumentSpec::gm (38);
    if (has ({ "upright", "double bass", "contrabass" }))                          return InstrumentSpec::gm (32);
    if (has ({ "bass" }))                                                          return InstrumentSpec::gm (33);
    if (has ({ "violin", "viola", "cello", "string", "orchestra", "ensemble" }))   return InstrumentSpec::gm (48);
    if (has ({ "choir", "vox", "voice", "vocal", "aah", "ooh" }))                  return InstrumentSpec::gm (52);
    if (has ({ "trumpet", "brass", "horn", "trombone", "tuba" }))                  return InstrumentSpec::gm (61);
    if (has ({ "sax" }))                                                           return InstrumentSpec::gm (65);
    if (has ({ "flute", "piccolo", "recorder" }))                                  return InstrumentSpec::gm (73);
    if (has ({ "clarinet", "oboe", "bassoon" }))                                   return InstrumentSpec::gm (71);
    if (has ({ "harp" }))                                                          return InstrumentSpec::gm (46);
    if (has ({ "pluck", "pizz" }))                                                 return InstrumentSpec::synth ("Pluck");
    if (has ({ "supersaw", "trance" }))                                            return InstrumentSpec::synth ("Supersaw");
    if (has ({ "pad", "atmos", "ambient", "warm" }))                               return InstrumentSpec::synth ("Warm Pad");
    if (has ({ "chip", "8bit", "8-bit", "nes", "gameboy" }))                       return InstrumentSpec::synth ("Chiptune");
    if (has ({ "lead", "saw", "synth", "osc", "arp", "sytrus", "serum", "vital", "massive", "harmor" })) return InstrumentSpec::synth ("Saw Lead");

    return InstrumentSpec::gm (0);
}

static InstrumentSpec specFromLIF (Session& s, const var& inst, const String& trackName, bool& isDrums, StringArray& warnings)
{
    auto type = inst.getProperty ("type", "").toString();
    isDrums = false;

    if (type == "gm" || type == "sf2")
    {
        auto spec = InstrumentSpec::gm ((int) inst.getProperty ("program", 0), (int) inst.getProperty ("bank", 0));
        if (type == "sf2")
        {
            File sf (inst.getProperty ("file", "").toString());
            if (sf.existsAsFile())
                spec.file = sf;
            else
                warnings.add (trackName + ": SoundFont " + sf.getFileName() + " not found - using the General MIDI set");
        }
        isDrums = spec.bank == 128;
        return spec;
    }

    if (type == "drumkit")
    {
        isDrums = true;
        File kitDir (inst.getProperty ("kitDir", "").toString());
        return InstrumentSpec::drums (kitDir.isDirectory() ? kitDir : File());
    }

    if (type == "synth")
        return InstrumentSpec::synth (inst.getProperty ("preset", "Saw Lead").toString());

    if (type == "sampler")
    {
        File f (inst.getProperty ("file", "").toString());
        if (f.existsAsFile())
            return InstrumentSpec::sampler (f, (int) inst.getProperty ("root", 60));

        warnings.add (trackName + ": sample " + f.getFileName() + " not found");
    }

    if (type == "plugin")
    {
        auto wanted = inst.getProperty ("name", "").toString();
        for (auto& pd : s.engine.getPluginManager().knownPluginList.getTypes())
            if (pd.name.equalsIgnoreCase (wanted) || (wanted.length() > 3 && pd.name.containsIgnoreCase (wanted)))
                return InstrumentSpec::external (pd);

        warnings.add (trackName + ": plugin \"" + wanted + "\" isn't installed - substituted a built-in instrument");

        if (inst.hasProperty ("fallback"))
            return specFromLIF (s, inst.getProperty ("fallback", var()), trackName, isDrums, warnings);
    }

    return guessInstrumentFromName (trackName, isDrums);
}

static Colour parseColour (const var& v, Colour fallback)
{
    auto s = v.toString().trim();
    if (s.startsWith ("#") && s.length() >= 7)
        return Colour::fromString ("ff" + s.substring (1, 7));
    return fallback;
}

void addLIFToCurrentEdit (Session& s, const var& lif, double beatOffset, te::AudioTrack* targetTrack, StringArray& warnings)
{
    auto& edit = s.edit_();
    auto* tracks = lif.getProperty ("tracks", var()).getArray();
    if (tracks == nullptr)
        return;

    File baseDir (lif.getProperty ("baseDir", "").toString());
    te::AudioTrack* after = targetTrack;

    // a single MIDI track dropped onto an instrument track goes straight into it
    auto useTarget = targetTrack != nullptr && tracks->size() == 1 && getTrackKind (*targetTrack) != TrackKind::audio;

    for (auto& lt : *tracks)
    {
        auto name = lt.getProperty ("name", "Track").toString();
        auto kindStr = lt.getProperty ("kind", "instrument").toString();
        te::AudioTrack* track = nullptr;

        if (useTarget)
        {
            track = targetTrack;
        }
        else if (kindStr == "audio")
        {
            track = s.addTrack (TrackKind::audio, name, after);
        }
        else
        {
            bool isDrums = false;
            auto spec = specFromLIF (s, lt.getProperty ("instrument", var()), name, isDrums, warnings);
            track = s.addTrackWithInstrument (spec, name, after);

            if (track != nullptr)
            {
                if (kindStr == "drums" || isDrums)
                    setTrackKind (*track, TrackKind::drums);

                auto inst = lt.getProperty ("instrument", var());
                if (inst.getProperty ("type", "").toString() == "drumkit" && inst.hasProperty ("pads"))
                    if (auto dm = Session::getDrumMachine (*track))
                    {
                        auto kit = new DynamicObject();
                        kit->setProperty ("name", inst.getProperty ("name", name));
                        kit->setProperty ("pads", inst.getProperty ("pads", var()));
                        dm->loadKitDescription (var (kit), baseDir);
                    }
            }
        }

        if (track == nullptr)
            continue;

        after = track;

        if (! useTarget)
        {
            if (lt.hasProperty ("color"))
                track->setColour (parseColour (lt.getProperty ("color", ""), track->getColour()));

            if (auto vp = track->getVolumePlugin())
            {
                vp->setVolumeDb (jlimit (-60.0f, 6.0f, (float) lt.getProperty ("volumeDb", 0.0)));
                vp->setPan (jlimit (-1.0f, 1.0f, (float) lt.getProperty ("pan", 0.0)));
            }

            if ((bool) lt.getProperty ("mute", false)) track->setMute (true);
            if ((bool) lt.getProperty ("solo", false)) track->setSolo (true);
        }

        if (auto* clips = lt.getProperty ("clips", var()).getArray())
        {
            for (auto& c : *clips)
            {
                auto type = c.getProperty ("type", "midi").toString();
                auto start = beatOffset + (double) c.getProperty ("start", 0.0);

                if (type == "midi")
                {
                    auto length = jmax (0.25, (double) c.getProperty ("length", 4.0));
                    auto mc = s.createMidiClip (*track, start, length, false);
                    if (mc == nullptr)
                        continue;

                    if (c.hasProperty ("name"))
                        mc->setName (c.getProperty ("name", "").toString());

                    if (c.hasProperty ("color"))
                        mc->setColour (parseColour (c.getProperty ("color", ""), track->getColour()));

                    if ((bool) c.getProperty ("mute", false))
                        mc->setMuted (true);

                    auto& seq = mc->getSequence();
                    if (auto* notes = c.getProperty ("notes", var()).getArray())
                        for (auto& n : *notes)
                        {
                            if (auto* a = n.getArray(); a != nullptr && a->size() >= 4)
                            {
                                auto beat = (double) (*a)[0];
                                auto len = jmax (1.0 / 64.0, (double) (*a)[1]);
                                auto pitch = jlimit (0, 127, (int) (*a)[2]);
                                auto vel = jlimit (1, 127, (int) (*a)[3]);

                                if (beat >= -0.001 && beat < length)
                                    seq.addNote (pitch, B (jmax (0.0, beat)), BD (jmin (len, length - beat + 8.0)), vel, 0, nullptr);
                            }
                        }
                }
                else if (type == "audio")
                {
                    File f (c.getProperty ("file", "").toString());
                    if (! f.existsAsFile())
                    {
                        warnings.add (track->getName() + ": missing audio file " + f.getFileName());
                        continue;
                    }

                    auto clip = s.addAudioFile (*track, f, start);
                    if (clip == nullptr)
                    {
                        warnings.add (track->getName() + ": couldn't read " + f.getFileName());
                        continue;
                    }

                    if (c.hasProperty ("name"))
                        clip->setName (c.getProperty ("name", "").toString());

                    auto offset = (double) c.getProperty ("offsetSeconds", 0.0);
                    if (offset > 0.0)
                        clip->setOffset (TD (offset));

                    if (c.hasProperty ("length"))
                    {
                        auto lenBeats = (double) c.getProperty ("length", 0.0);
                        if (lenBeats > 0.0)
                            clip->setLength (beatToTime (edit, start + lenBeats) - beatToTime (edit, start), true);
                    }
                    else if (c.hasProperty ("lengthSeconds"))
                    {
                        auto ls = (double) c.getProperty ("lengthSeconds", 0.0);
                        if (ls > 0.0)
                            clip->setLength (TD (ls), true);
                    }

                    if (c.hasProperty ("gainDb"))
                        clip->setGainDB ((float) c.getProperty ("gainDb", 0.0));

                    if ((bool) c.getProperty ("mute", false))
                        clip->setMuted (true);

                    if (auto fi = (double) c.getProperty ("fadeInSeconds", 0.0); fi > 0.0)
                        clip->setFadeIn (TD (fi));
                    if (auto fo = (double) c.getProperty ("fadeOutSeconds", 0.0); fo > 0.0)
                        clip->setFadeOut (TD (fo));
                }
            }
        }

        useTarget = false;
    }
}

StringArray buildNewProjectFromLIF (Session& s, const var& lif, const File& file)
{
    StringArray warnings;

    if (auto* w = lif.getProperty ("warnings", var()).getArray())
        for (auto& x : *w)
            warnings.add (x.toString());

    s.adoptEdit (s.createBlankEdit (file), file, false);
    s.save();      // the file must exist before media is referenced (relative paths)
    auto& edit = s.edit_();

    auto bpm = (double) lif.getProperty ("tempo", 120.0);
    s.setTempo (bpm > 10.0 ? bpm : 120.0);

    if (auto* ts = lif.getProperty ("timeSig", var()).getArray(); ts != nullptr && ts->size() >= 2)
        s.setTimeSignature ((int) (*ts)[0], (int) (*ts)[1]);

    if (auto* tm = lif.getProperty ("tempoMap", var()).getArray())
    {
        int changes = 0;
        for (auto& p : *tm)
            if (auto* a = p.getArray(); a != nullptr && a->size() >= 2 && (double) (*a)[0] > 0.0)
                if (changes++ < 256)
                    edit.tempoSequence.insertTempo (B ((double) (*a)[0]), jlimit (20.0, 400.0, (double) (*a)[1]), 0.0f);
    }

    addLIFToCurrentEdit (s, lif, 0.0, nullptr, warnings);

    if (lif.hasProperty ("masterVolumeDb"))
        if (auto mv = edit.getMasterVolumePlugin())
            mv->setVolumeDb (jlimit (-60.0f, 6.0f, (float) lif.getProperty ("masterVolumeDb", 0.0)));

    // an imported mix arrives without its mastering effects: a transparent-until-0dB clipper
    // keeps it from distorting (it's an ordinary effect in the master chain, easy to remove)
    if ((bool) lif.getProperty ("masterSafetyClip", false))
        if (auto clip = edit.getPluginCache().createNewPlugin ("airwindows_cliponly", {}))
        {
            edit.getMasterPluginList().insertPlugin (clip, 0, nullptr);
            warnings.add ("Added a safety clipper (Airwindows \"Clip Only\") to the master so the mix can't distort - "
                          "remove it in the Mixer if you'd rather use your own limiter");
        }

    if (auto* loop = lif.getProperty ("loop", var()).getArray(); loop != nullptr && loop->size() >= 2)
    {
        auto a = (double) (*loop)[0], b = (double) (*loop)[1];
        if (b > a)
            edit.getTransport().setLoopRange ({ beatToTime (edit, a), beatToTime (edit, b) });
    }

    if (auto first = te::getAudioTracks (edit).getFirst())
        s.selectTrack (first);

    edit.getUndoManager().clearUndoHistory();
    s.save();
    s.sendChangeMessage();
    return warnings;
}

//==============================================================================
var readMidiFile (const File& f, String& error)
{
    FileInputStream in (f);
    MidiFile mf;

    if (! in.openedOk() || ! mf.readFrom (in))
    {
        error = "Couldn't read MIDI file " + f.getFileName();
        return {};
    }

    double tpq = mf.getTimeFormat();
    bool smpte = tpq <= 0;

    if (smpte)
    {
        mf.convertTimestampTicksToSeconds();
        tpq = 0.5;   // seconds -> beats at 120 BPM
    }

    auto lif = new DynamicObject();
    lif->setProperty ("format", "lodestone-interchange");
    lif->setProperty ("name", f.getFileNameWithoutExtension());

    MidiMessageSequence tempos, sigs;
    mf.findAllTempoEvents (tempos);
    mf.findAllTimeSigEvents (sigs);

    double bpm = 120.0;
    Array<var> tempoMap;
    for (int i = 0; i < tempos.getNumEvents(); ++i)
    {
        auto& m = tempos.getEventPointer (i)->message;
        auto spq = m.getTempoSecondsPerQuarterNote();
        if (spq <= 0) continue;

        auto t = 60.0 / spq;
        auto beat = m.getTimeStamp() / tpq;
        if (i == 0 || beat < 0.001) bpm = t;
        tempoMap.add (Array<var> { beat, t });
    }

    if (! smpte)
    {
        lif->setProperty ("tempo", bpm);
        lif->setProperty ("tempoMap", tempoMap);
    }

    int num = 4, den = 4;
    if (sigs.getNumEvents() > 0)
        sigs.getEventPointer (0)->message.getTimeSignatureInfo (num, den);
    lif->setProperty ("timeSig", Array<var> { num, den });

    auto bpb = num * 4.0 / jmax (1, den);
    Array<var> tracks;

    for (int ti = 0; ti < mf.getNumTracks(); ++ti)
    {
        auto seq = *mf.getTrack (ti);
        seq.updateMatchedPairs();

        String trackName;
        std::map<int, int> programs;
        std::map<int, Array<var>> notesByChannel;
        std::map<int, std::pair<double, double>> extents;

        for (int i = 0; i < seq.getNumEvents(); ++i)
        {
            auto* e = seq.getEventPointer (i);
            auto& m = e->message;

            if (m.isTrackNameEvent() && trackName.isEmpty())
                trackName = m.getTextFromTextMetaEvent().trim();
            else if (m.isProgramChange() && programs.count (m.getChannel()) == 0)
                programs[m.getChannel()] = m.getProgramChangeNumber();
            else if (m.isNoteOn())
            {
                auto start = m.getTimeStamp() / tpq;
                auto end = e->noteOffObject != nullptr ? e->noteOffObject->message.getTimeStamp() / tpq : start + 0.25;
                auto ch = m.getChannel();

                notesByChannel[ch].add (Array<var> { start, jmax (1.0 / 64.0, end - start), m.getNoteNumber(), (int) m.getVelocity() });

                auto& ex = extents.try_emplace (ch, start, end).first->second;
                ex.first = jmin (ex.first, start);
                ex.second = jmax (ex.second, end);
            }
        }

        for (auto& [ch, notes] : notesByChannel)
        {
            auto [minStart, maxEnd] = extents[ch];
            auto clipStart = std::floor (minStart / bpb) * bpb;
            auto clipEnd = std::ceil ((maxEnd + 0.001) / bpb) * bpb;

            for (auto& n : notes)
                (*n.getArray()).set (0, (double) (*n.getArray())[0] - clipStart);

            auto t = new DynamicObject();
            auto name = trackName.isNotEmpty() ? trackName : String ("Track " + String (ti + 1));
            if (notesByChannel.size() > 1)
                name << " (ch " << ch << ")";

            auto isDrums = ch == 10;
            t->setProperty ("name", name);
            t->setProperty ("kind", isDrums ? "drums" : "instrument");

            auto inst = new DynamicObject();
            inst->setProperty ("type", "gm");
            inst->setProperty ("bank", isDrums ? 128 : 0);

            if (programs.count (ch) > 0)
                inst->setProperty ("program", isDrums ? 0 : programs[ch]);
            else if (! isDrums)
            {
                bool drumsGuess = false;
                auto guess = guessInstrumentFromName (name, drumsGuess);
                if (guess.type == InstrumentSpec::Type::soundfont)
                    inst->setProperty ("program", guess.program);
                else
                    inst->setProperty ("program", 0);
            }

            t->setProperty ("instrument", var (inst));

            auto clip = new DynamicObject();
            clip->setProperty ("type", "midi");
            clip->setProperty ("start", clipStart);
            clip->setProperty ("length", jmax (bpb, clipEnd - clipStart));
            clip->setProperty ("name", name);
            clip->setProperty ("notes", notes);
            t->setProperty ("clips", Array<var> { var (clip) });
            tracks.add (var (t));
        }
    }

    lif->setProperty ("tracks", tracks);

    if (tracks.isEmpty())
        error = "That MIDI file doesn't contain any notes";

    return var (lif);
}

//==============================================================================
// DAWproject
//==============================================================================
static double attrD (const XmlElement* e, const char* name, double def = 0.0)
{
    return e != nullptr && e->hasAttribute (name) ? e->getDoubleAttribute (name, def) : def;
}

static void collectTracks (const XmlElement& parent, std::vector<const XmlElement*>& out)
{
    for (auto* t : parent.getChildWithTagNameIterator ("Track"))
    {
        auto ct = t->getStringAttribute ("contentType");
        bool hasNested = t->getChildByName ("Track") != nullptr;

        if (! hasNested || ct.contains ("notes") || ct.contains ("audio"))
            if (t->getChildByName ("Channel") == nullptr
                 || t->getChildByName ("Channel")->getStringAttribute ("role") != "master")
                out.push_back (t);

        if (hasNested)
            collectTracks (*t, out);
    }
}

var readDawProject (const File& f, const File& extractDir, String& error)
{
    ZipFile zip (f);
    auto projectIndex = zip.getIndexOfFileName ("project.xml");

    if (projectIndex < 0)
    {
        error = "Not a DAWproject file (no project.xml inside)";
        return {};
    }

    std::unique_ptr<InputStream> in (zip.createStreamForEntry (projectIndex));
    auto xml = in != nullptr ? parseXML (in->readEntireStreamAsString()) : nullptr;

    if (xml == nullptr)
    {
        error = "Couldn't parse project.xml";
        return {};
    }

    extractDir.createDirectory();

    auto lif = new DynamicObject();
    Array<var> warnings;
    lif->setProperty ("name", f.getFileNameWithoutExtension());

    double bpm = 120.0;
    if (auto* transport = xml->getChildByName ("Transport"))
    {
        bpm = attrD (transport->getChildByName ("Tempo"), "value", 120.0);
        if (auto* ts = transport->getChildByName ("TimeSignature"))
            lif->setProperty ("timeSig", Array<var> { ts->getIntAttribute ("numerator", 4), ts->getIntAttribute ("denominator", 4) });
    }
    lif->setProperty ("tempo", bpm);
    auto secondsToBeats = bpm / 60.0;

    // tracks
    std::vector<const XmlElement*> trackElems;
    if (auto* structure = xml->getChildByName ("Structure"))
        collectTracks (*structure, trackElems);

    std::map<String, DynamicObject*> trackById;
    Array<var> tracks;

    for (auto* te_ : trackElems)
    {
        auto t = new DynamicObject();
        auto name = te_->getStringAttribute ("name", "Track");
        auto ct = te_->getStringAttribute ("contentType");
        t->setProperty ("name", name);
        t->setProperty ("kind", ct.contains ("notes") ? "instrument" : "audio");
        t->setProperty ("color", te_->getStringAttribute ("color"));

        if (auto* ch = te_->getChildByName ("Channel"))
        {
            if (auto* vol = ch->getChildByName ("Volume"))
            {
                auto v = attrD (vol, "value", 1.0);
                auto unit = vol->getStringAttribute ("unit", "linear");
                t->setProperty ("volumeDb", unit == "decibel" ? v : Decibels::gainToDecibels (jmax (0.0001, v)));
            }

            if (auto* pan = ch->getChildByName ("Pan"))
            {
                auto v = attrD (pan, "value", 0.5);
                t->setProperty ("pan", pan->getStringAttribute ("unit", "normalized") == "normalized" ? v * 2.0 - 1.0 : v);
            }

            if (auto* mute = ch->getChildByName ("Mute"))
                t->setProperty ("mute", mute->getBoolAttribute ("value", false));

            t->setProperty ("solo", ch->getBoolAttribute ("solo", false));

            if (auto* devices = ch->getChildByName ("Devices"))
                for (auto* d : devices->getChildIterator())
                    if (d->getStringAttribute ("deviceRole") == "instrument")
                    {
                        auto inst = new DynamicObject();
                        inst->setProperty ("type", "plugin");
                        inst->setProperty ("name", d->getStringAttribute ("deviceName", d->getStringAttribute ("name")));
                        inst->setProperty ("format", d->getTagName());
                        t->setProperty ("instrument", var (inst));
                        break;
                    }
        }

        t->setProperty ("clips", Array<var>());
        trackById[te_->getStringAttribute ("id")] = t;
        tracks.add (var (t));
    }

    // extracts an audio file from the zip (or resolves an external path)
    auto extractAudio = [&] (const XmlElement& fileElem) -> String
    {
        auto path = fileElem.getStringAttribute ("path");

        if (fileElem.getBoolAttribute ("external", false))
            return File::isAbsolutePath (path) ? path : f.getSiblingFile (path).getFullPathName();

        auto index = zip.getIndexOfFileName (path);
        if (index < 0)
            return {};

        auto dest = extractDir.getChildFile (File::createLegalFileName (File (path).getFileName()));
        if (! dest.existsAsFile())
        {
            std::unique_ptr<InputStream> s (zip.createStreamForEntry (index));
            if (s != nullptr)
            {
                FileOutputStream out (dest);
                if (out.openedOk())
                    out.writeFromInputStream (*s, -1);
            }
        }
        return dest.getFullPathName();
    };

    // clips: walk the arrangement lanes, carrying timeUnit and absolute offsets
    std::function<void (const XmlElement&, DynamicObject*, bool, double)> walk;
    walk = [&] (const XmlElement& e, DynamicObject* currentTrack, bool unitIsSeconds, double timeOffsetBeats)
    {
        if (e.hasAttribute ("timeUnit"))
            unitIsSeconds = e.getStringAttribute ("timeUnit") == "seconds";

        if (e.hasTagName ("Lanes") && e.hasAttribute ("track"))
            if (auto it = trackById.find (e.getStringAttribute ("track")); it != trackById.end())
                currentTrack = it->second;

        if (e.hasTagName ("Clip") && currentTrack != nullptr)
        {
            auto toBeats = [&] (double v) { return unitIsSeconds ? v * secondsToBeats : v; };
            auto start = timeOffsetBeats + toBeats (attrD (&e, "time"));
            auto duration = toBeats (attrD (&e, "duration", 4.0));
            auto contentSeconds = e.hasAttribute ("contentTimeUnit") ? e.getStringAttribute ("contentTimeUnit") == "seconds" : unitIsSeconds;
            auto playStart = attrD (&e, "playStart");

            auto* clipArr = currentTrack->getProperty ("clips").getArray();

            if (auto* notes = e.getChildByName ("Notes"))
            {
                auto c = new DynamicObject();
                c->setProperty ("type", "midi");
                c->setProperty ("start", start);
                c->setProperty ("length", duration);
                c->setProperty ("name", e.getStringAttribute ("name"));
                Array<var> ns;
                auto toContentBeats = [&] (double v) { return contentSeconds ? v * secondsToBeats : v; };
                auto loopStart = e.hasAttribute ("loopStart") ? toContentBeats (attrD (&e, "loopStart")) : -1.0;
                auto loopEnd = e.hasAttribute ("loopEnd") ? toContentBeats (attrD (&e, "loopEnd")) : -1.0;
                auto ps = toContentBeats (playStart);

                auto addNotes = [&] (double shift)
                {
                    for (auto* n : notes->getChildWithTagNameIterator ("Note"))
                    {
                        auto nt = toContentBeats (attrD (n, "time")) - ps + shift;
                        if (nt < -0.0001 || nt >= duration) continue;
                        auto vel = attrD (n, "vel", 0.8);
                        ns.add (Array<var> { nt, toContentBeats (attrD (n, "duration", 0.25)), n->getIntAttribute ("key", 60),
                                             jlimit (1, 127, roundToInt ((vel <= 1.0 ? vel * 127.0 : vel))) });
                    }
                };

                if (loopEnd > loopStart && loopStart >= 0.0 && (loopEnd - loopStart) > 0.01)
                    for (double shift = 0.0; shift < duration; shift += loopEnd - loopStart)
                        addNotes (shift);
                else
                    addNotes (0.0);

                c->setProperty ("notes", ns);
                clipArr->add (var (c));
                return;
            }

            // audio (possibly wrapped in Warps / nested Clips)
            const XmlElement* audio = nullptr;
            std::function<void (const XmlElement&)> findAudio = [&] (const XmlElement& x)
            {
                if (audio != nullptr) return;
                if (x.hasTagName ("Audio")) { audio = &x; return; }
                for (auto* ch : x.getChildIterator())
                    findAudio (*ch);
            };
            findAudio (e);

            if (audio != nullptr)
            {
                if (auto* fileElem = audio->getChildByName ("File"))
                {
                    auto path = extractAudio (*fileElem);
                    if (path.isNotEmpty())
                    {
                        auto c = new DynamicObject();
                        c->setProperty ("type", "audio");
                        c->setProperty ("start", start);
                        c->setProperty ("length", duration);
                        c->setProperty ("file", path);
                        c->setProperty ("name", e.getStringAttribute ("name"));
                        auto offsetSeconds = contentSeconds ? playStart : playStart / secondsToBeats;
                        c->setProperty ("offsetSeconds", jmax (0.0, offsetSeconds));
                        clipArr->add (var (c));

                        if (currentTrack->getProperty ("kind").toString() != "audio")
                            warnings.add (currentTrack->getProperty ("name").toString() + ": audio clip on an instrument track was kept");
                    }
                }
                return;
            }

            // a clip that contains clips (container): recurse with the offset
            for (auto* ch : e.getChildIterator())
                if (ch->hasTagName ("Clips"))
                    walk (*ch, currentTrack, unitIsSeconds, start - (contentSeconds ? playStart * secondsToBeats : playStart));
            return;
        }

        for (auto* ch : e.getChildIterator())
            walk (*ch, currentTrack, unitIsSeconds, timeOffsetBeats);
    };

    if (auto* arr = xml->getChildByName ("Arrangement"))
        walk (*arr, nullptr, false, 0.0);

    // markers
    Array<var> markers;
    if (auto* arr = xml->getChildByName ("Arrangement"))
        if (auto* m = arr->getChildByName ("Markers"))
            for (auto* mk : m->getChildWithTagNameIterator ("Marker"))
                markers.add (Array<var> { attrD (mk, "time"), mk->getStringAttribute ("name") });

    lif->setProperty ("markers", markers);
    lif->setProperty ("tracks", tracks);
    lif->setProperty ("warnings", warnings);
    lif->setProperty ("baseDir", extractDir.getFullPathName());
    return var (lif);
}

//==============================================================================
var runPythonImporter (const File& source, const File& workDir, String& error)
{
    auto script = getImporterDir().getChildFile ("run_import.py");
    if (! script.existsAsFile())
    {
        error = "Lodestone's importers are missing (" + script.getFullPathName() + ")";
        return {};
    }

    workDir.createDirectory();

    ChildProcess proc;
    StringArray args { "python3", "-I", script.getFullPathName(), source.getFullPathName(), "--workdir", workDir.getFullPathName() };

    if (! proc.start (args, ChildProcess::wantStdOut))
    {
        error = "Couldn't run python3 - is it installed?";
        return {};
    }

    auto output = proc.readAllProcessOutput();
    proc.waitForProcessToFinish (60000);

    auto json = output.fromFirstOccurrenceOf ("===LIF-BEGIN===", false, false)
                      .upToFirstOccurrenceOf ("===LIF-END===", false, false);

    if (json.trim().isEmpty())
    {
        error = output.fromFirstOccurrenceOf ("===ERROR===", false, false).trim();
        if (error.isEmpty())
            error = "The importer didn't return anything:\n" + output.getLastCharacters (600);
        return {};
    }

    var result;
    auto parse = JSON::parse (json, result);
    if (parse.failed())
    {
        error = "Importer output wasn't valid: " + parse.getErrorMessage();
        return {};
    }

    return result;
}

//==============================================================================
static void showWarnings (const String& title, const StringArray& warnings)
{
    if (warnings.isEmpty())
        return;

    StringArray shown;
    for (int i = 0; i < jmin (18, warnings.size()); ++i)
        shown.add ("- " + warnings[i]);

    if (warnings.size() > 18)
        shown.add ("...and " + String (warnings.size() - 18) + " more");

    alert (MessageBoxIconType::InfoIcon, title, shown.joinIntoString ("\n"));
}

void openAnyFile (Session& s, const File& f)
{
    auto ext = extOf (f);

    if (ext == ".lodestone")
    {
        if (! s.openProject (f))
            alert (MessageBoxIconType::WarningIcon, "Couldn't open project", f.getFullPathName());
        return;
    }

    var lif;
    String error;
    auto projectName = f.getFileNameWithoutExtension().upToLastOccurrenceOf (".band", false, true)
                                                      .upToLastOccurrenceOf (".logicx", false, true);
    if (projectName.isEmpty())
        projectName = f.getFileNameWithoutExtension();

    // the new project's folder exists before the import runs, so imported media is
    // written straight into it and nothing needs relocating afterwards
    auto projectFile = s.createUntitledProjectFile (File::createLegalFileName (projectName));
    auto mediaDir = projectFile.getParentDirectory().getChildFile ("Imported Audio");

    String formatName = "project";

    if (ext == ".mid" || ext == ".midi")
    {
        formatName = "MIDI file";
        lif = readMidiFile (f, error);
    }
    else if (ext == ".lif")
    {
        // Lodestone Interchange Format written by hand or by another tool (see importers/lodestone_import/lif.py)
        formatName = "LIF file";
        auto r = JSON::parse (f.loadFileAsString(), lif);
        if (r.failed())
            error = "Not a valid LIF file: " + r.getErrorMessage();
    }
    else if (ext == ".dawproject")
    {
        formatName = "DAWproject";
        runBusy ("Reading DAWproject...", [&] { lif = readDawProject (f, mediaDir, error); });
    }
    else
    {
        formatName = ext == ".flp" ? "FL Studio project"
                   : (ext == ".mmp" || ext == ".mmpz") ? "LMMS project"
                   : ext == ".logicx" ? "Logic Pro project"
                   : ext == ".zip" ? "zipped project" : "GarageBand project";

        runBusy ("Importing " + formatName + "...", [&] { lif = runPythonImporter (f, mediaDir, error); });
    }

    if (! lif.isObject())
    {
        projectFile.getParentDirectory().deleteRecursively();

        alert (MessageBoxIconType::WarningIcon, "Couldn't import " + f.getFileName(),
               error.isNotEmpty() ? error : String ("Unknown error"));
        return;
    }

    if (mediaDir.isDirectory() && mediaDir.getNumberOfChildFiles (File::findFilesAndDirectories) == 0)
        mediaDir.deleteFile();

    auto warnings = buildNewProjectFromLIF (s, lif, projectFile);

    // Imports arrive without their compressors/limiters, so dense mixes can sum far past 0 dB.
    // Render once, and if it peaks too hot, pull every track down by the same amount.
    if (ext != ".lif")
    {
        float peak = -100.0f;
        runBusy ("Checking levels...", [&] { peak = measurePeakDb (s); });

        if (peak > -1.0f)
        {
            auto trim = jlimit (-30.0f, 0.0f, -1.0f - peak);
            for (auto t : te::getAudioTracks (s.edit_()))
                if (auto vp = t->getVolumePlugin())
                    vp->setVolumeDb (jmax (-60.0f, vp->getVolumeDb() + trim));

            warnings.add ("Without its original effects the mix peaked at " + String (peak, 1) + " dB, so every track was turned down by "
                          + String (-trim, 1) + " dB (the balance between tracks is unchanged)");
            s.edit_().getUndoManager().clearUndoHistory();
            s.save();
        }
    }

    s.status ("Imported " + formatName + " \"" + f.getFileName() + "\"");
    showWarnings ("Imported " + f.getFileName(), warnings);
}

void importMidiFileIntoEdit (Session& s, const File& f, double beat, te::AudioTrack* track)
{
    String error;
    auto lif = readMidiFile (f, error);

    if (! lif.isObject())
    {
        s.status (error);
        return;
    }

    StringArray warnings;
    s.edit_().getUndoManager().beginNewTransaction ("Import MIDI");
    addLIFToCurrentEdit (s, lif, beat, track, warnings);
    s.status ("Imported " + f.getFileName());
}

//==============================================================================
// Exports
//==============================================================================
static juce::AudioFormat* formatFor (te::Engine& e, const String& name)
{
    auto& fm = e.getAudioFileFormatManager();
    if (name == "flac") return fm.getFlacFormat();
    if (name == "ogg")  return fm.getOggFormat();
    return fm.getWavFormat();
}

static te::Renderer::Parameters makeParams (Session& s, const File& dest, const AudioExportOptions& o)
{
    auto& edit = s.edit_();
    te::Renderer::Parameters p (edit);
    p.destFile = dest;
    p.audioFormat = formatFor (s.engine, o.format);
    p.bitDepth = o.format == "ogg" ? 16 : o.bitDepth;
    p.sampleRateForAudio = o.sampleRate;
    p.blockSizeForAudio = 512;
    p.usePlugins = true;
    p.useMasterPlugins = true;
    p.canRenderInMono = false;
    p.ditheringEnabled = o.bitDepth < 32 && o.format != "ogg";
    p.endAllowance = TD (o.tailSeconds);
    p.checkNodesForAudio = false;

    if (o.loopRangeOnly && edit.getTransport().getLoopRange().getLength() > TD (0.01))
        p.time = edit.getTransport().getLoopRange();
    else
        p.time = { te::TimePosition(), edit.getLength() };

    if (o.normalise)
    {
        p.shouldNormaliseByLUFS = true;
        p.normaliseToLevelDb = o.normaliseLufs;
        p.limitTruePeak = true;
    }

    if (o.format == "ogg" && p.audioFormat != nullptr)
    {
        auto q = p.audioFormat->getQualityOptions();
        p.quality = jmax (0, q.size() - 3);
    }

    return p;
}

float measurePeakDb (Session& s)
{
    auto& edit = s.edit_();
    if (edit.getLength() <= TD (0.01))
        return -100.0f;

    // measure what the tracks produce, not what the safety clipper lets through
    Array<te::Plugin*> bypassed;
    for (auto p : edit.getMasterPluginList())
        if (p->getPluginType() == "airwindows_cliponly" && p->isEnabled())
        {
            p->setEnabled (false);
            bypassed.add (p);
        }

    auto tmp = File::createTempFile (".wav");
    AudioExportOptions o;
    o.bitDepth = 32;              // float WAV keeps overs above 0 dBFS measurable
    o.tailSeconds = 1.0;
    auto p = makeParams (s, tmp, o);
    p.tracksToDo = te::toBitSet (te::getAllTracks (edit));
    p.ditheringEnabled = false;
    te::Renderer::renderToFile ("Checking levels", p);

    float peak = -100.0f;
    if (std::unique_ptr<AudioFormatReader> reader (s.engine.getAudioFileFormatManager().readFormatManager.createReaderFor (tmp)); reader != nullptr)
    {
        Range<float> levels[2];
        auto chans = (int) jmin (2u, reader->numChannels);
        reader->readMaxLevels (0, reader->lengthInSamples, levels, chans);
        float m = 0.0f;
        for (int c = 0; c < chans; ++c)
            m = jmax (m, std::abs (levels[c].getStart()), std::abs (levels[c].getEnd()));
        peak = Decibels::gainToDecibels (m, -100.0f);
    }

    tmp.deleteFile();
    for (auto p : bypassed)
        p->setEnabled (true);

    return peak;
}

bool exportMixdown (Session& s, const File& file, const AudioExportOptions& o)
{
    auto& edit = s.edit_();
    if (edit.getLength() <= TD (0.01))
        return false;

    auto p = makeParams (s, file, o);
    p.tracksToDo = te::toBitSet (te::getAllTracks (edit));
    file.deleteFile();
    auto out = te::Renderer::renderToFile ("Exporting " + file.getFileName(), p);
    return out.existsAsFile();
}

int exportStems (Session& s, const File& folder, const AudioExportOptions& o)
{
    auto& edit = s.edit_();
    folder.createDirectory();
    int count = 0, index = 1;

    for (auto t : te::getAudioTracks (edit))
    {
        if (t->getClips().isEmpty())
            continue;

        auto name = String (index++).paddedLeft ('0', 2) + " " + File::createLegalFileName (t->getName());
        auto dest = folder.getChildFile (name).withFileExtension (o.format == "flac" ? "flac" : (o.format == "ogg" ? "ogg" : "wav"));
        dest.deleteFile();

        auto p = makeParams (s, dest, o);
        p.useMasterPlugins = false;
        p.shouldNormaliseByLUFS = false;
        p.tracksToDo = te::toBitSet (juce::Array<te::Track*> { t });

        if (te::Renderer::renderToFile ("Stem: " + t->getName(), p).existsAsFile())
            ++count;
    }

    return count;
}

bool exportMidi (Session& s, const File& file)
{
    auto& edit = s.edit_();
    const int tpq = 960;
    MidiFile mf;
    mf.setTicksPerQuarterNote (tpq);

    MidiMessageSequence meta;
    meta.addEvent (MidiMessage::tempoMetaEvent (roundToInt (60000000.0 / s.getTempo())), 0);
    if (auto ts = edit.tempoSequence.getTimeSig (0))
        meta.addEvent (MidiMessage::timeSignatureMetaEvent (ts->numerator.get(), ts->denominator.get()), 0);
    meta.addEvent (MidiMessage::textMetaEvent (3, s.getProjectName()), 0);
    mf.addTrack (meta);

    int melodicChannel = 1;

    for (auto t : te::getAudioTracks (edit))
    {
        MidiMessageSequence seq;
        auto isDrums = getTrackKind (*t) == TrackKind::drums;
        auto channel = isDrums ? 10 : melodicChannel;
        bool any = false;

        seq.addEvent (MidiMessage::textMetaEvent (3, t->getName()), 0);

        if (auto sf = Session::getSoundFont (*t); sf != nullptr && ! isDrums)
            seq.addEvent (MidiMessage::programChange (channel, sf->getProgram()), 0);

        for (auto c : t->getClips())
        {
            auto mc = dynamic_cast<te::MidiClip*> (c);
            if (mc == nullptr || mc->isMuted())
                continue;

            auto clipStart = clipStartBeat (*mc), clipEnd = clipEndBeat (*mc);
            auto contentStart = clipContentStartBeat (*mc);

            for (auto n : mc->getSequence().getNotes())
            {
                auto st = contentStart + n->getStartBeat().inBeats();
                auto en = st + n->getLengthBeats().inBeats();
                if (en <= clipStart || st >= clipEnd)
                    continue;

                st = jmax (st, clipStart);
                en = jmin (en, clipEnd);
                seq.addEvent (MidiMessage::noteOn (channel, n->getNoteNumber(), (uint8) n->getVelocity()), st * tpq);
                seq.addEvent (MidiMessage::noteOff (channel, n->getNoteNumber()), en * tpq);
                any = true;
            }
        }

        if (any)
        {
            seq.sort();
            seq.updateMatchedPairs();
            mf.addTrack (seq);

            if (! isDrums && ++melodicChannel == 10)
                ++melodicChannel;
            if (melodicChannel > 16)
                melodicChannel = 1;
        }
    }

    file.deleteFile();
    FileOutputStream out (file);
    return out.openedOk() && mf.writeTo (out, 1);
}

bool exportDawProject (Session& s, const File& file, String& error)
{
    auto& edit = s.edit_();
    int nextId = 0;
    auto newId = [&nextId] { return "id" + String (nextId++); };

    XmlElement project ("Project");
    project.setAttribute ("version", "1.0");

    auto* app = project.createNewChildElement ("Application");
    app->setAttribute ("name", "Lodestone");
    app->setAttribute ("version", LODESTONE_VERSION);

    auto* transport = project.createNewChildElement ("Transport");
    auto* tempo = transport->createNewChildElement ("Tempo");
    tempo->setAttribute ("max", 666.0);
    tempo->setAttribute ("min", 20.0);
    tempo->setAttribute ("unit", "bpm");
    tempo->setAttribute ("value", s.getTempo());
    tempo->setAttribute ("id", newId());
    tempo->setAttribute ("name", "Tempo");

    auto* tsElem = transport->createNewChildElement ("TimeSignature");
    auto ts = edit.tempoSequence.getTimeSig (0);
    tsElem->setAttribute ("denominator", ts != nullptr ? ts->denominator.get() : 4);
    tsElem->setAttribute ("numerator", ts != nullptr ? ts->numerator.get() : 4);
    tsElem->setAttribute ("id", newId());

    auto* structure = project.createNewChildElement ("Structure");
    auto masterChannelId = String ("id_master");

    auto addChannel = [&] (XmlElement& trackElem, const String& role, float volDb, float pan, bool mute, bool solo,
                           const String& channelId, te::Plugin* instrument)
    {
        auto* ch = trackElem.createNewChildElement ("Channel");
        ch->setAttribute ("audioChannels", 2);
        if (role != "master")
            ch->setAttribute ("destination", masterChannelId);
        ch->setAttribute ("role", role);
        ch->setAttribute ("solo", solo ? "true" : "false");
        ch->setAttribute ("id", channelId);

        if (auto ext = dynamic_cast<te::ExternalPlugin*> (instrument))
        {
            auto* devices = ch->createNewChildElement ("Devices");
            auto desc = ext->desc;
            auto tag = desc.pluginFormatName == "VST3" ? "Vst3Plugin" : (desc.pluginFormatName == "LV2" ? "Plugin" : "Plugin");
            auto* d = devices->createNewChildElement (tag);
            d->setAttribute ("deviceID", desc.fileOrIdentifier);
            d->setAttribute ("deviceName", desc.name);
            d->setAttribute ("deviceRole", "instrument");
            d->setAttribute ("loaded", "true");
            d->setAttribute ("id", newId());
            d->setAttribute ("name", desc.name);
        }

        auto* m = ch->createNewChildElement ("Mute");
        m->setAttribute ("value", mute ? "true" : "false");
        m->setAttribute ("id", newId());
        m->setAttribute ("name", "Mute");

        auto* p = ch->createNewChildElement ("Pan");
        p->setAttribute ("max", 1.0);
        p->setAttribute ("min", 0.0);
        p->setAttribute ("unit", "normalized");
        p->setAttribute ("value", (pan + 1.0f) * 0.5f);
        p->setAttribute ("id", newId());
        p->setAttribute ("name", "Pan");

        auto* v = ch->createNewChildElement ("Volume");
        v->setAttribute ("max", 2.0);
        v->setAttribute ("min", 0.0);
        v->setAttribute ("unit", "linear");
        v->setAttribute ("value", Decibels::decibelsToGain (volDb));
        v->setAttribute ("id", newId());
        v->setAttribute ("name", "Volume");
    };

    std::vector<std::pair<te::AudioTrack*, String>> trackIds;
    StringArray audioToPack;
    std::map<String, String> packedNames;

    for (auto t : te::getAudioTracks (edit))
    {
        auto* tr = structure->createNewChildElement ("Track");
        auto isAudio = getTrackKind (*t) == TrackKind::audio;
        auto id = newId();
        tr->setAttribute ("contentType", isAudio ? "audio" : "notes");
        tr->setAttribute ("loaded", "true");
        tr->setAttribute ("id", id);
        tr->setAttribute ("name", t->getName());
        tr->setAttribute ("color", "#" + t->getColour().toDisplayString (false).toLowerCase());

        auto vp = t->getVolumePlugin();
        addChannel (*tr, "regular", vp != nullptr ? vp->getVolumeDb() : 0.0f, vp != nullptr ? vp->getPan() : 0.0f,
                    t->isMuted (false), t->isSolo (false), newId(), Session::getInstrument (*t));

        if (auto inst = Session::getInstrument (*t); inst != nullptr && dynamic_cast<te::ExternalPlugin*> (inst) == nullptr)
            tr->setAttribute ("comment", "Lodestone instrument: " + inst->getName());

        trackIds.push_back ({ t, id });
    }

    {
        auto* master = structure->createNewChildElement ("Track");
        master->setAttribute ("contentType", "audio notes");
        master->setAttribute ("loaded", "true");
        master->setAttribute ("id", newId());
        master->setAttribute ("name", "Master");
        auto mv = edit.getMasterVolumePlugin();
        addChannel (*master, "master", mv != nullptr ? mv->getVolumeDb() : 0.0f, 0.0f, false, false, masterChannelId, nullptr);
    }

    auto* arrangement = project.createNewChildElement ("Arrangement");
    arrangement->setAttribute ("id", newId());
    auto* lanes = arrangement->createNewChildElement ("Lanes");
    lanes->setAttribute ("timeUnit", "beats");
    lanes->setAttribute ("id", newId());

    for (auto& [t, id] : trackIds)
    {
        auto* tl = lanes->createNewChildElement ("Lanes");
        tl->setAttribute ("track", id);
        tl->setAttribute ("id", newId());
        auto* clipsElem = tl->createNewChildElement ("Clips");
        clipsElem->setAttribute ("id", newId());

        for (auto c : t->getClips())
        {
            auto* ce = clipsElem->createNewChildElement ("Clip");
            ce->setAttribute ("time", clipStartBeat (*c));
            ce->setAttribute ("duration", c->getLengthInBeats().inBeats());
            ce->setAttribute ("name", c->getName());
            if (c->isMuted())
                ce->setAttribute ("enable", "false");

            if (auto mc = dynamic_cast<te::MidiClip*> (c))
            {
                ce->setAttribute ("playStart", mc->getOffsetInBeats().inBeats());
                auto* notes = ce->createNewChildElement ("Notes");
                notes->setAttribute ("id", newId());

                for (auto n : mc->getSequence().getNotes())
                {
                    auto* ne = notes->createNewChildElement ("Note");
                    ne->setAttribute ("time", n->getStartBeat().inBeats());
                    ne->setAttribute ("duration", n->getLengthBeats().inBeats());
                    ne->setAttribute ("channel", getTrackKind (*t) == TrackKind::drums ? 9 : 0);
                    ne->setAttribute ("key", n->getNoteNumber());
                    ne->setAttribute ("vel", n->getVelocity() / 127.0);
                    ne->setAttribute ("rel", n->getVelocity() / 127.0);
                }
            }
            else if (auto wac = dynamic_cast<te::WaveAudioClip*> (c))
            {
                auto src = wac->getOriginalFile();
                if (! src.existsAsFile())
                    continue;

                auto key = src.getFullPathName();
                if (packedNames.count (key) == 0)
                {
                    auto name = "audio/" + File::createLegalFileName (src.getFileName());
                    int n = 2;
                    for (auto& [k, v] : packedNames)
                        if (v == name)
                            name = "audio/" + src.getFileNameWithoutExtension() + " " + String (n++) + src.getFileExtension();
                    packedNames[key] = name;
                    audioToPack.add (key);
                }

                ce->setAttribute ("contentTimeUnit", "seconds");
                ce->setAttribute ("playStart", wac->getPosition().getOffset().inSeconds());
                ce->setAttribute ("fadeTimeUnit", "seconds");
                ce->setAttribute ("fadeInTime", wac->getFadeIn().inSeconds());
                ce->setAttribute ("fadeOutTime", wac->getFadeOut().inSeconds());

                te::AudioFile af (s.engine, src);
                auto* audio = ce->createNewChildElement ("Audio");
                audio->setAttribute ("algorithm", "raw");
                audio->setAttribute ("channels", jmax (1, af.getNumChannels()));
                audio->setAttribute ("duration", af.getLength());
                audio->setAttribute ("sampleRate", roundToInt (af.getSampleRate()));
                audio->setAttribute ("id", newId());
                auto* fe = audio->createNewChildElement ("File");
                fe->setAttribute ("path", packedNames[key]);
            }
        }
    }

    project.createNewChildElement ("Scenes");

    XmlElement meta ("MetaData");
    meta.createNewChildElement ("Title")->addTextElement (s.getProjectName());
    meta.createNewChildElement ("Comment")->addTextElement ("Exported from Lodestone");

    XmlElement::TextFormat xmlFormat;
    xmlFormat.newLineChars = "\n";
    auto projectText = project.toString (xmlFormat);
    auto metaText = meta.toString (xmlFormat);

    ZipFile::Builder builder;
    builder.addEntry (std::make_unique<MemoryInputStream> (projectText.toRawUTF8(), projectText.getNumBytesAsUTF8(), true), 9, "project.xml", Time::getCurrentTime());
    builder.addEntry (std::make_unique<MemoryInputStream> (metaText.toRawUTF8(), metaText.getNumBytesAsUTF8(), true), 9, "metadata.xml", Time::getCurrentTime());

    for (auto& path : audioToPack)
        builder.addFile (File (path), 6, packedNames[path]);

    file.deleteFile();
    FileOutputStream out (file);
    if (! out.openedOk())
    {
        error = "Couldn't write " + file.getFullPathName();
        return false;
    }

    double progress = 0.0;
    if (! builder.writeToStream (out, &progress))
    {
        error = "Failed while writing the zip";
        return false;
    }

    return true;
}

} // namespace lode::ProjectIO
