/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#pragma once

#include "Session.h"
#include "Theme.h"

namespace lode
{

/** Peak meter fed from a track's (or the master's) LevelMeterPlugin. */
class LevelMeter : public juce::Component,
                   public juce::SettableTooltipClient,
                   private juce::Timer
{
public:
    LevelMeter (te::LevelMeterPlugin*, bool vertical = true);
    ~LevelMeter() override;

    void paint (juce::Graphics&) override;
    void setSource (te::LevelMeterPlugin*);

private:
    te::Plugin::Ptr meterPlugin;
    te::LevelMeasurer::Client client;
    float levelL = -100.0f, levelR = -100.0f, peakHold = -100.0f;
    int peakHoldFrames = 0;
    bool vertical;

    void timerCallback() override;
};

te::LevelMeterPlugin* findMasterMeter (te::Edit&);

//==============================================================================
class ChannelStrip : public juce::Component
{
public:
    ChannelStrip (Session&, te::AudioTrack* track);   // nullptr = master
    ~ChannelStrip() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void refresh();

    std::function<void (te::AudioTrack*, te::Plugin*)> onShowDevice;

    te::AudioTrack::Ptr track;

private:
    Session& session;
    te::Plugin::Ptr volumePlugin;
    juce::Label name;
    juce::OwnedArray<juce::TextButton> slots;
    juce::TextButton addFx { "+ fx" };
    juce::Slider pan, fader;
    juce::Label dbLabel;
    juce::TextButton mute { "M" }, solo { "S" }, arm { "R" };
    std::unique_ptr<LevelMeter> meter;

    void buildSlots();
};

//==============================================================================
class MixerView : public juce::Component,
                  private juce::ValueTree::Listener,
                  private juce::AsyncUpdater,
                  private juce::ChangeListener
{
public:
    MixerView (Session&);
    ~MixerView() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    std::function<void (te::AudioTrack*, te::Plugin*)> onShowDevice;

private:
    Session& session;
    juce::Viewport viewport;
    juce::Component stripHolder;
    juce::OwnedArray<ChannelStrip> strips;
    std::unique_ptr<ChannelStrip> master;

    void rebuild();
    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override;
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override;
    void valueTreeChildOrderChanged (juce::ValueTree&, int, int) override;
    void valueTreePropertyChanged (juce::ValueTree&, const juce::Identifier&) override;
    void handleAsyncUpdate() override;
    void changeListenerCallback (juce::ChangeBroadcaster*) override;

    bool needsRebuild = false;
};

} // namespace lode
