/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "SoundFontPlugin.h"
#include "DrumMachinePlugin.h"
#include <fluidsynth.h>

namespace lode
{
using namespace juce;

const char* SoundFontPlugin::xmlTypeName = "lodestoneSoundFont";

//==============================================================================
namespace SoundFonts
{
    static void silenceFluidLogging()
    {
        static bool done = false;
        if (! done)
        {
            done = true;
            fluid_set_log_function (FLUID_WARN, nullptr, nullptr);
            fluid_set_log_function (FLUID_INFO, nullptr, nullptr);
            fluid_set_log_function (FLUID_DBG, nullptr, nullptr);
        }
    }

    Array<File> findInstalled()
    {
        Array<File> result;
        auto home = File::getSpecialLocation (File::userHomeDirectory);

        for (auto dir : { File ("/usr/share/sounds/sf2"), File ("/usr/share/soundfonts"), File ("/usr/local/share/soundfonts"),
                          home.getChildFile (".local/share/soundfonts"), home.getChildFile (".local/share/lodestone/soundfonts"),
                          home.getChildFile (".sounds") })
        {
            if (! dir.isDirectory())
                continue;

            for (auto& f : dir.findChildFiles (File::findFiles, false, "*.sf2;*.SF2;*.sf3"))
            {
                bool dup = false;
                for (auto& r : result)
                    if (r.getLinkedTarget() == f.getLinkedTarget())
                        dup = true;

                if (! dup)
                    result.add (f);
            }
        }

        return result;
    }

    File getDefaultSoundFont()
    {
        for (auto f : { File ("/usr/share/sounds/sf2/FluidR3_GM.sf2"), File ("/usr/share/soundfonts/FluidR3_GM.sf2"),
                        File ("/usr/share/sounds/sf2/default-GM.sf2"), File ("/usr/share/soundfonts/default.sf2"),
                        File ("/usr/share/sounds/sf2/TimGM6mb.sf2") })
            if (f.existsAsFile())
                return f;

        auto all = findInstalled();
        return all.isEmpty() ? File() : all.getFirst();
    }

    const Array<SoundFontPreset>& getPresets (const File& sf2)
    {
        static std::map<String, Array<SoundFontPreset>> cache;
        static CriticalSection lock;
        const ScopedLock sl (lock);

        auto key = sf2.getFullPathName();
        if (auto it = cache.find (key); it != cache.end())
            return it->second;

        auto& list = cache[key];
        silenceFluidLogging();

        if (! sf2.existsAsFile())
            return list;

        auto* s = new_fluid_settings();
        fluid_settings_setint (s, "synth.dynamic-sample-loading", 1);
        auto* syn = new_fluid_synth (s);

        auto id = fluid_synth_sfload (syn, sf2.getFullPathName().toRawUTF8(), 0);
        if (id >= 0)
        {
            if (auto* sf = fluid_synth_get_sfont_by_id (syn, id))
            {
                fluid_sfont_iteration_start (sf);
                while (auto* p = fluid_sfont_iteration_next (sf))
                {
                    SoundFontPreset pr;
                    pr.bank = fluid_preset_get_banknum (p);
                    pr.program = fluid_preset_get_num (p);
                    pr.name = String (CharPointer_UTF8 (fluid_preset_get_name (p))).trim();
                    list.add (pr);
                }
            }
        }

        delete_fluid_synth (syn);
        delete_fluid_settings (s);

        std::sort (list.begin(), list.end(), [] (auto& a, auto& b)
                   { return a.bank != b.bank ? a.bank < b.bank : a.program < b.program; });
        return list;
    }

    String gmProgramName (int p)
    {
        static const char* names[128] = {
            "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano", "Electric Piano 1",
            "Electric Piano 2", "Harpsichord", "Clavinet", "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba",
            "Xylophone", "Tubular Bells", "Dulcimer", "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ",
            "Reed Organ", "Accordion", "Harmonica", "Tango Accordion", "Acoustic Guitar (nylon)", "Acoustic Guitar (steel)",
            "Electric Guitar (jazz)", "Electric Guitar (clean)", "Electric Guitar (muted)", "Overdriven Guitar",
            "Distortion Guitar", "Guitar Harmonics", "Acoustic Bass", "Electric Bass (finger)", "Electric Bass (pick)",
            "Fretless Bass", "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello",
            "Contrabass", "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani", "String Ensemble 1",
            "String Ensemble 2", "Synth Strings 1", "Synth Strings 2", "Choir Aahs", "Voice Oohs", "Synth Voice",
            "Orchestra Hit", "Trumpet", "Trombone", "Tuba", "Muted Trumpet", "French Horn", "Brass Section", "Synth Brass 1",
            "Synth Brass 2", "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe", "English Horn", "Bassoon",
            "Clarinet", "Piccolo", "Flute", "Recorder", "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
            "Lead 1 (square)", "Lead 2 (sawtooth)", "Lead 3 (calliope)", "Lead 4 (chiff)", "Lead 5 (charang)",
            "Lead 6 (voice)", "Lead 7 (fifths)", "Lead 8 (bass + lead)", "Pad 1 (new age)", "Pad 2 (warm)",
            "Pad 3 (polysynth)", "Pad 4 (choir)", "Pad 5 (bowed)", "Pad 6 (metallic)", "Pad 7 (halo)", "Pad 8 (sweep)",
            "FX 1 (rain)", "FX 2 (soundtrack)", "FX 3 (crystal)", "FX 4 (atmosphere)", "FX 5 (brightness)",
            "FX 6 (goblins)", "FX 7 (echoes)", "FX 8 (sci-fi)", "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba",
            "Bagpipe", "Fiddle", "Shanai", "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock", "Taiko Drum",
            "Melodic Tom", "Synth Drum", "Reverse Cymbal", "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird Tweet",
            "Telephone Ring", "Helicopter", "Applause", "Gunshot" };

        return isPositiveAndBelow (p, 128) ? String (names[p]) : String ("Program " + String (p));
    }

    String gmFamilyName (int f)
    {
        static const char* fam[16] = { "Piano", "Chromatic Percussion", "Organ", "Guitar", "Bass", "Strings",
                                       "Ensemble", "Brass", "Reed", "Pipe", "Synth Lead", "Synth Pad",
                                       "Synth Effects", "Ethnic", "Percussive", "Sound Effects" };
        return isPositiveAndBelow (f, 16) ? String (fam[f]) : String();
    }
}

//==============================================================================
SoundFontPlugin::SoundFontPlugin (te::PluginCreationInfo info)
    : Plugin (info)
{
    SoundFonts::silenceFluidLogging();
    auto um = getUndoManager();

    sf2Path.referTo (state, "sf2", um, SoundFonts::getDefaultSoundFont().getFullPathName());
    bank.referTo (state, "bank", um, 0);
    program.referTo (state, "program", um, 0);
    gainValue.referTo (state, "gainDb", um, 0.0f);
    reverbValue.referTo (state, "reverb", um, 0.25f);
    chorusValue.referTo (state, "chorus", um, 0.0f);

    gainParam = addParam ("gain", TRANS ("Volume"), { -60.0f, 12.0f },
                          [] (float v) { return String (v, 1) + " dB"; },
                          [] (const String& s) { return s.getFloatValue(); });
    reverbParam = addParam ("reverb", TRANS ("Reverb"), { 0.0f, 1.0f });
    chorusParam = addParam ("chorus", TRANS ("Chorus"), { 0.0f, 1.0f });

    gainParam->attachToCurrentValue (gainValue);
    reverbParam->attachToCurrentValue (reverbValue);
    chorusParam->attachToCurrentValue (chorusValue);

}

SoundFontPlugin::~SoundFontPlugin()
{
    notifyListenersOfDeletion();

    gainParam->detachFromCurrentValue();
    reverbParam->detachFromCurrentValue();
    chorusParam->detachFromCurrentValue();

    destroySynth();
}

String SoundFontPlugin::getName() const
{
    auto n = getPresetName();
    return n.isNotEmpty() ? n : String ("SoundFont Player");
}

String SoundFontPlugin::getPresetName() const
{
    auto& presets = SoundFonts::getPresets (File (sf2Path.get()));

    for (auto& p : presets)
        if (p.bank == bank.get() && p.program == program.get())
            return p.name;

    if (bank.get() == 128)
        return "Drum Kit";

    return SoundFonts::gmProgramName (program.get());
}

void SoundFontPlugin::createSynth (double newRate)
{
    destroySynth();

    const ScopedLock sl (synthLock);
    settings = new_fluid_settings();
    fluid_settings_setnum (settings, "synth.sample-rate", newRate);
    fluid_settings_setint (settings, "synth.dynamic-sample-loading", 1);
    fluid_settings_setint (settings, "synth.polyphony", 256);
    fluid_settings_setnum (settings, "synth.gain", 0.6);
    fluid_settings_setint (settings, "synth.reverb.active", 1);
    fluid_settings_setint (settings, "synth.chorus.active", 1);
    fluid_settings_setint (settings, "synth.cpu-cores", 1);

    synth = new_fluid_synth (settings);
    sampleRate = newRate;
    sfontId = -1;
    loadedPath = {};
    lastBank = lastProgram = -1;
    lastReverb = lastChorus = -1.0f;
}

void SoundFontPlugin::destroySynth()
{
    const ScopedLock sl (synthLock);

    if (synth != nullptr)
        delete_fluid_synth (synth);

    if (settings != nullptr)
        delete_fluid_settings (settings);

    synth = nullptr;
    settings = nullptr;
    sfontId = -1;
    loadedPath = {};
}

void SoundFontPlugin::loadSoundFontIfNeeded()
{
    if (synth == nullptr)
        return;

    auto path = sf2Path.get();
    if (path.isEmpty() || ! File (path).existsAsFile())
        path = SoundFonts::getDefaultSoundFont().getFullPathName();

    if (path == loadedPath && sfontId >= 0)
        return;

    const ScopedLock sl (synthLock);

    if (sfontId >= 0)
        fluid_synth_sfunload (synth, sfontId, 1);

    sfontId = path.isNotEmpty() ? fluid_synth_sfload (synth, path.toRawUTF8(), 0) : -1;
    loadedPath = path;
    lastBank = lastProgram = -1;
}

void SoundFontPlugin::applyProgram()
{
    if (synth == nullptr || sfontId < 0)
        return;

    if (lastBank == bank.get() && lastProgram == program.get())
        return;

    const ScopedLock sl (synthLock);
    fluid_synth_all_sounds_off (synth, -1);

    auto b = bank.get(), p = program.get();
    if (fluid_synth_program_select (synth, channel(), sfontId, (unsigned int) b, (unsigned int) p) != FLUID_OK)
    {
        // fall back to the closest thing the font has
        if (b == 128)
            fluid_synth_program_select (synth, 9, sfontId, 128, 0);
        else
            fluid_synth_program_select (synth, 0, sfontId, 0, (unsigned int) jlimit (0, 127, p));
    }

    lastBank = b;
    lastProgram = p;
}

void SoundFontPlugin::setSoundFont (const File& f)
{
    sf2Path = f.getFullPathName();
}

void SoundFontPlugin::setProgram (int newBank, int newProgram)
{
    bank = newBank;
    program = newProgram;
}

void SoundFontPlugin::handleAsyncUpdate()
{
    loadSoundFontIfNeeded();
    applyProgram();
}

void SoundFontPlugin::initialise (const te::PluginInitialisationInfo& info)
{
    if (synth == nullptr || std::abs (sampleRate - info.sampleRate) > 0.5)
        createSynth (info.sampleRate);

    loadSoundFontIfNeeded();
    applyProgram();
}

void SoundFontPlugin::deinitialise() {}

void SoundFontPlugin::midiPanic()
{
    const ScopedLock sl (synthLock);
    if (synth != nullptr)
        fluid_synth_all_sounds_off (synth, -1);
}

void SoundFontPlugin::applyToBuffer (const te::PluginRenderContext& fc)
{
    if (fc.destBuffer == nullptr)
        return;

    SCOPED_REALTIME_CHECK

    auto& dest = *fc.destBuffer;
    const int start = fc.bufferStartSample, num = fc.bufferNumSamples;

    for (int ch = 2; ch < dest.getNumChannels(); ++ch)
        dest.clear (ch, start, num);

    const ScopedTryLock sl (synthLock);
    if (! sl.isLocked() || synth == nullptr || num <= 0)
        return;

    if (scratch.getNumSamples() < num)
        scratch.setSize (2, num, false, false, true);

    const int chan = channel();

    auto reverb = reverbParam->getCurrentValue();
    auto chorus = chorusParam->getCurrentValue();
    if (std::abs (reverb - lastReverb) > 0.001f)
    {
        fluid_synth_cc (synth, chan, 91, jlimit (0, 127, roundToInt (reverb * 127.0f)));
        lastReverb = reverb;
    }
    if (std::abs (chorus - lastChorus) > 0.001f)
    {
        fluid_synth_cc (synth, chan, 93, jlimit (0, 127, roundToInt (chorus * 127.0f)));
        lastChorus = chorus;
    }

    int pos = 0;
    auto render = [&] (int upTo)
    {
        if (upTo > pos)
        {
            fluid_synth_write_float (synth, upTo - pos,
                                     scratch.getWritePointer (0), pos, 1,
                                     scratch.getWritePointer (1), pos, 1);
            pos = upTo;
        }
    };

    if (fc.bufferForMidiMessages != nullptr)
    {
        if (fc.bufferForMidiMessages->isAllNotesOff)
            fluid_synth_all_notes_off (synth, chan);

        for (auto& m : *fc.bufferForMidiMessages)
        {
            auto t = jlimit (start, start + num - 1, roundToInt (m.getTimeStamp() * sampleRate)) - start;
            render (t);

            if (m.isNoteOn())
                fluid_synth_noteon (synth, chan, m.getNoteNumber(), m.getVelocity());
            else if (m.isNoteOff())
                fluid_synth_noteoff (synth, chan, m.getNoteNumber());
            else if (m.isController())
                fluid_synth_cc (synth, chan, m.getControllerNumber(), m.getControllerValue());
            else if (m.isPitchWheel())
                fluid_synth_pitch_bend (synth, chan, m.getPitchWheelValue());
            else if (m.isChannelPressure())
                fluid_synth_channel_pressure (synth, chan, m.getChannelPressureValue());
            else if (m.isAftertouch())
                fluid_synth_key_pressure (synth, chan, m.getNoteNumber(), m.getAfterTouchValue());
            else if (m.isAllNotesOff())
                fluid_synth_all_notes_off (synth, chan);
            else if (m.isAllSoundOff())
                fluid_synth_all_sounds_off (synth, chan);
        }
    }

    render (num);

    auto gain = Decibels::decibelsToGain (gainParam->getCurrentValue());
    if (dest.getNumChannels() >= 2)
    {
        dest.addFrom (0, start, scratch, 0, 0, num, gain);
        dest.addFrom (1, start, scratch, 1, 0, num, gain);
    }
    else if (dest.getNumChannels() == 1)
    {
        dest.addFrom (0, start, scratch, 0, 0, num, gain * 0.5f);
        dest.addFrom (0, start, scratch, 1, 0, num, gain * 0.5f);
    }
}

bool SoundFontPlugin::hasNameForMidiNoteNumber (int note, int, String& name)
{
    if (! isDrumKit())
        return false;

    name = DrumKits::gmDrumName (note);
    return true;
}

void SoundFontPlugin::restorePluginStateFromValueTree (const ValueTree& v)
{
    te::copyPropertiesToCachedValues (v, sf2Path, bank, program, gainValue, reverbValue, chorusValue);
    triggerAsyncUpdate();
}

} // namespace lode
