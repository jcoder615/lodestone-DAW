/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Practice mode: plug in a controller and play. No project, no tracks.

    The practice setup is its own small Edit (Session::enterPracticeMode). Each
    "sound" in it is a track the UI never shows as one:

      - an instrument sound: KeyZone -> instrument -> your effects -> fader
      - an audio-input sound (the mic): InputTap -> your effects -> fader

    Controllers are assigned to sounds by device name, so one keyboard can play
    two sounds at once (a layer), two key ranges of it can play different sounds
    (a split), and the pad controller can stay on the drums.
*/
#pragma once

#include "Session.h"
#include "PracticePlugins.h"

namespace lode
{

namespace PracticeIDs
{
    inline const juce::Identifier slot ("practiceSlot");                // on a track: this track is a sound
    inline const juce::Identifier audio ("practiceAudio");              // ...an audio-input sound
    inline const juce::Identifier controllers ("practiceControllers");  // newline-separated MIDI device names
    inline const juce::Identifier inputDevice ("practiceInputDevice");  // wave input device ID
    inline const juce::Identifier sampled ("practiceSampled");          // "keys" / "pads": made by sampling
    inline const juce::Identifier settings ("LODEPRACTICE");            // child of the edit state
    inline const juce::Identifier knownControllers ("knownControllers");
}

/** YIN pitch detection: the tuner, and finding the root note of a sample. */
namespace PitchDetector
{
    /** Returns the fundamental in Hz, or 0 if there isn't a clear one.
        clarity: 0..1, how periodic the signal is. */
    float detect (const float* samples, int numSamples, double sampleRate, float& clarity);

    /** Pitch of the loudest steady part of a buffer (for setting a sample's root note). */
    float detectInBuffer (const juce::AudioBuffer<float>&, double sampleRate, float& clarity);
}

/** The part of a recording that's clearly above its own noise floor ({} if none). */
juce::Range<int> findActivity (const juce::AudioBuffer<float>&, double sampleRate,
                               double frameSeconds = 0.05, double minActiveSeconds = 0.25);

/** Trims silence, normalises to -1 dBFS, adds tiny fades and writes a 24-bit WAV.
    Returns the file, or {} if there was nothing above the noise floor. */
juce::File saveSampleTake (const juce::AudioBuffer<float>&, double sampleRate,
                           const juce::File& folder, const juce::String& baseName);

/** Where to cut a sample into pads: start positions (0..1), first one always 0. */
juce::Array<float> findSlicePoints (const juce::AudioBuffer<float>&, double sampleRate, int maxSlices);

//==============================================================================
class PracticeController : private juce::Timer,
                           private juce::ChangeListener
{
public:
    explicit PracticeController (Session&);
    ~PracticeController() override;

    Session& session;
    te::Edit& edit;

    //==============================================================================
    // Sounds
    juce::Array<te::AudioTrack*> getSlots() const;
    static bool isSlot (const te::AudioTrack&);
    static bool isAudioSlot (const te::AudioTrack&);
    static KeyZonePlugin* getZone (const te::AudioTrack&);
    static InputTapPlugin* getTap (const te::AudioTrack&);

    te::AudioTrack* addInstrumentSlot (const InstrumentSpec&, const juce::String& name, const juce::StringArray& controllers);
    te::AudioTrack* addAudioSlot (const juce::String& name = {});
    te::AudioTrack* duplicateSlot (te::AudioTrack&);
    void deleteSlot (te::AudioTrack&);
    void setSlotSound (te::AudioTrack&, const juce::String& browserDescription);
    juce::String getSoundName (te::AudioTrack&) const;
    void resetToDefaults();

    /** The instrument sound you last clicked (a new sample takes over its controllers). */
    void noteSelected (te::AudioTrack*);

    //==============================================================================
    // Controllers
    struct Controller
    {
        juce::String name;
        bool connected = true, looksLikePads = false;
    };

    juce::Array<Controller> getControllers() const;
    juce::StringArray getSlotControllers (const te::AudioTrack&) const;
    void setSlotControllers (te::AudioTrack&, const juce::StringArray&);
    void toggleSlotController (te::AudioTrack&, const juce::String& name);
    juce::String describeControllers (const te::AudioTrack&) const;
    static bool looksLikePads (const juce::String& deviceName);

    //==============================================================================
    // Audio inputs
    struct InputChoice
    {
        juce::String label, deviceID;
        int channel = 0;    // within the device: 0, 1, or -1 = both (stereo)
    };

    juce::Array<InputChoice> getInputChoices() const;
    int getCurrentInputChoice (const te::AudioTrack&) const;     // index into getInputChoices(), -1 = none
    void setSlotInput (te::AudioTrack&, const InputChoice&);
    void setMonitoring (te::AudioTrack&, bool);
    bool isMonitoring (const te::AudioTrack&) const;

    //==============================================================================
    // What's being played right now (cards, keyboard map, range learning)
    juce::Array<int> getHeldKeys (const te::AudioTrack&) const;
    bool isSounding (const te::AudioTrack&) const;
    void startLearningRange (te::AudioTrack&);
    void cancelLearning();
    te::AudioTrack* getLearningSlot() const         { return learning.get(); }
    bool isLearningSecondKey() const                { return learnStage == 1; }

    //==============================================================================
    // Metronome
    bool isMetronomeOn() const;
    void setMetronome (bool);
    double getBeat() const;                         // beats since the metronome started

    //==============================================================================
    // Practice recorder (everything you hear except the click, to a WAV)
    bool isRecording() const                        { return writer != nullptr; }
    bool startRecording();
    juce::File stopRecording();
    double getRecordingSeconds() const;
    juce::File getLastRecording() const             { return recordingFile; }
    static juce::File getRecordingsFolder();

    //==============================================================================
    // "Save what I played": the last few minutes become a new project
    struct TakeResult
    {
        juce::File file;
        juce::String message;
        bool ok = false;
    };

    /** lastPhraseOnly: keep only what came after the last pause of a few seconds. */
    TakeResult saveWhatIPlayed (double seconds, bool lastPhraseOnly = false);

    //==============================================================================
    // Hold-to-sample
    bool startSampling (te::AudioTrack& audioSlot);
    juce::String stopSampling (te::AudioTrack& audioSlot, bool chopToPads);
    te::AudioTrack* getSamplingSlot() const         { return samplingSlot.get(); }

    //==============================================================================
    std::function<void()> onSlotsChanged, onDevicesChanged;
    MasterTapPlugin* getMasterTap() const;
    void refreshDevices (bool autoAssignNewControllers);

private:
    struct SlotHistory
    {
        std::deque<ZoneEvent> events;       // what came out of the zone, in time order
        std::map<int, int> held;            // key -> velocity
        juce::uint32 lastNoteMs = 0;
    };

    std::map<te::EditItemID, SlotHistory> history;
    std::vector<MasterTapPlugin::TransportMark> marks;
    te::SafeSelectable<te::AudioTrack> learning, samplingSlot, lastInstrumentSlot;
    int learnStage = 0, learnFirst = -1;
    int tick = 0;

    juce::TimeSliceThread writerThread { "Practice recorder" };
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> writer;
    juce::File recordingFile;
    double recordingRate = 48000.0;

    juce::StringArray lastDeviceNames;

    void ensureSetup();
    void ensureMasterTap();
    void ensureSlotPlugins (te::AudioTrack&);
    void createDefaultSlots();
    void applyRouting();
    juce::StringArray getConnectedControllerNames() const;
    juce::ValueTree getSettings();
    te::AudioTrack* findMainKeysSlot() const;
    te::AudioTrack* findMainPadsSlot() const;
    void drainEvents();
    void status (const juce::String& s)             { session.status (s); }

    void timerCallback() override;
    void changeListenerCallback (juce::ChangeBroadcaster*) override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PracticeController)
};

} // namespace lode
