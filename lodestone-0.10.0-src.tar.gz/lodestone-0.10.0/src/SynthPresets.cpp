/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Starter presets for the built-in 4-oscillator synth (Tracktion's FourOsc).
    Oscillator waves: 0 none, 1 sine, 2 square, 3 saw, 4 triangle, 5 noise.
    filterType: 0 off, 1 low-pass, 2 high-pass, 3 band-pass, 4 notch.
    filterFreq is a MIDI-note-style value (69 = 440 Hz, 135 = ~20 kHz).
*/
#include "Session.h"

namespace lode
{
using namespace juce;

namespace SynthPresets
{
    using Props = std::vector<std::pair<const char*, var>>;

    static const Props& base()
    {
        static const Props p = {
            { "waveShape1", 3 }, { "waveShape2", 0 }, { "waveShape3", 0 }, { "waveShape4", 0 },
            { "level1", 0.0f }, { "level2", 0.0f }, { "level3", 0.0f }, { "level4", 0.0f },
            { "tune1", 0.0f }, { "tune2", 0.0f }, { "tune3", 0.0f }, { "tune4", 0.0f },
            { "fineTune1", 0.0f }, { "fineTune2", 0.0f }, { "fineTune3", 0.0f }, { "fineTune4", 0.0f },
            { "voices1", 1 }, { "voices2", 1 }, { "voices3", 1 }, { "voices4", 1 },
            { "detune1", 0.0f }, { "detune2", 0.0f }, { "detune3", 0.0f }, { "detune4", 0.0f },
            { "spread1", 0.0f }, { "spread2", 0.0f }, { "spread3", 0.0f }, { "spread4", 0.0f },
            { "pulseWidth1", 0.5f }, { "pulseWidth2", 0.5f },
            { "ampAttack", 0.005f }, { "ampDecay", 0.2f }, { "ampSustain", 80.0f }, { "ampRelease", 0.2f }, { "ampVelocity", 80.0f },
            { "filterType", 1 }, { "filterSlope", 12 }, { "filterFreq", 110.0f }, { "filterResonance", 10.0f },
            { "filterAmount", 0.0f }, { "filterKey", 30.0f }, { "filterVelocity", 20.0f },
            { "filterAttack", 0.01f }, { "filterDecay", 0.3f }, { "filterSustain", 50.0f }, { "filterRelease", 0.3f },
            { "distortionOn", false }, { "distortion", 0.0f },
            { "reverbOn", false }, { "reverbSize", 0.5f }, { "reverbDamping", 0.5f }, { "reverbWidth", 1.0f }, { "reverbMix", 0.0f },
            { "delayOn", false }, { "delay", 0.75f }, { "delayFeedback", -12.0f }, { "delayCrossfeed", -100.0f }, { "delayMix", 0.0f },
            { "chorusOn", false }, { "chosusSpeed", 1.0f }, { "chorusDepth", 3.0f }, { "chrousWidth", 0.6f }, { "chorusMix", 0.0f },
            { "voiceMode", 2 }, { "voices", 32 }, { "legato", 0.0f }, { "masterLevel", -6.0f }
        };
        return p;
    }

    static const std::vector<std::pair<String, Props>>& presets()
    {
        static const std::vector<std::pair<String, Props>> list = {
            { "Saw Lead", { { "waveShape1", 3 }, { "waveShape2", 3 }, { "fineTune2", 9.0f }, { "level2", -4.0f },
                            { "voices1", 3 }, { "detune1", 0.12f }, { "spread1", 60.0f },
                            { "filterFreq", 100.0f }, { "filterResonance", 22.0f }, { "filterAmount", 0.25f },
                            { "filterDecay", 0.4f }, { "filterSustain", 40.0f },
                            { "ampAttack", 0.004f }, { "ampSustain", 85.0f }, { "ampRelease", 0.25f },
                            { "delayOn", true }, { "delayMix", 0.15f } } },

            { "Square Lead", { { "waveShape1", 2 }, { "waveShape2", 2 }, { "tune2", -12.0f }, { "level2", -10.0f },
                               { "filterFreq", 96.0f }, { "filterResonance", 15.0f },
                               { "ampAttack", 0.008f }, { "ampSustain", 90.0f }, { "ampRelease", 0.18f } } },

            { "Supersaw", { { "waveShape1", 3 }, { "voices1", 7 }, { "detune1", 0.28f }, { "spread1", 100.0f },
                            { "waveShape2", 3 }, { "voices2", 5 }, { "detune2", 0.25f }, { "spread2", 90.0f },
                            { "tune2", 12.0f }, { "level2", -10.0f },
                            { "filterFreq", 112.0f }, { "ampAttack", 0.01f }, { "ampSustain", 90.0f }, { "ampRelease", 0.45f },
                            { "chorusOn", true }, { "chorusMix", 0.2f }, { "reverbOn", true }, { "reverbMix", 0.22f },
                            { "masterLevel", -9.0f } } },

            { "Sub Bass", { { "waveShape1", 1 }, { "waveShape2", 2 }, { "tune2", 12.0f }, { "level2", -26.0f },
                            { "filterFreq", 78.0f }, { "ampAttack", 0.004f }, { "ampDecay", 0.2f },
                            { "ampSustain", 100.0f }, { "ampRelease", 0.08f }, { "voiceMode", 1 }, { "legato", 0.03f } } },

            { "Acid Bass", { { "waveShape1", 3 }, { "filterFreq", 58.0f }, { "filterResonance", 78.0f },
                             { "filterAmount", 0.6f }, { "filterDecay", 0.22f }, { "filterSustain", 0.0f },
                             { "filterVelocity", 60.0f }, { "ampAttack", 0.003f }, { "ampDecay", 0.3f },
                             { "ampSustain", 70.0f }, { "ampRelease", 0.07f }, { "voiceMode", 1 }, { "legato", 0.05f },
                             { "distortionOn", true }, { "distortion", 0.3f } } },

            { "Reese Bass", { { "waveShape1", 3 }, { "voices1", 4 }, { "detune1", 0.22f }, { "spread1", 40.0f },
                              { "waveShape2", 3 }, { "tune2", -12.0f }, { "level2", -6.0f },
                              { "filterFreq", 76.0f }, { "filterResonance", 12.0f },
                              { "ampSustain", 100.0f }, { "ampRelease", 0.1f }, { "voiceMode", 1 } } },

            { "Warm Pad", { { "waveShape1", 3 }, { "voices1", 5 }, { "detune1", 0.18f }, { "spread1", 80.0f },
                            { "level1", -3.0f }, { "waveShape2", 4 }, { "tune2", 12.0f }, { "level2", -12.0f },
                            { "filterFreq", 80.0f }, { "filterResonance", 8.0f },
                            { "ampAttack", 0.9f }, { "ampDecay", 1.0f }, { "ampSustain", 85.0f }, { "ampRelease", 1.6f },
                            { "chorusOn", true }, { "chorusMix", 0.4f }, { "reverbOn", true }, { "reverbSize", 0.8f },
                            { "reverbMix", 0.35f }, { "masterLevel", -8.0f } } },

            { "String Pad", { { "waveShape1", 3 }, { "voices1", 4 }, { "detune1", 0.1f }, { "spread1", 70.0f },
                              { "waveShape2", 3 }, { "voices2", 3 }, { "detune2", 0.1f }, { "tune2", 12.0f }, { "level2", -12.0f },
                              { "filterFreq", 90.0f }, { "filterResonance", 5.0f },
                              { "ampAttack", 0.35f }, { "ampDecay", 0.5f }, { "ampSustain", 90.0f }, { "ampRelease", 0.8f },
                              { "chorusOn", true }, { "chorusMix", 0.3f }, { "reverbOn", true }, { "reverbMix", 0.3f },
                              { "masterLevel", -8.0f } } },

            { "Pluck", { { "waveShape1", 3 }, { "waveShape2", 2 }, { "tune2", 12.0f }, { "level2", -12.0f },
                         { "filterFreq", 70.0f }, { "filterResonance", 30.0f }, { "filterAmount", 0.55f },
                         { "filterDecay", 0.18f }, { "filterSustain", 0.0f },
                         { "ampAttack", 0.002f }, { "ampDecay", 0.35f }, { "ampSustain", 0.0f }, { "ampRelease", 0.25f },
                         { "delayOn", true }, { "delayMix", 0.2f }, { "reverbOn", true }, { "reverbMix", 0.2f } } },

            { "Bell", { { "waveShape1", 1 }, { "waveShape2", 1 }, { "tune2", 19.0f }, { "level2", -8.0f },
                        { "waveShape3", 1 }, { "tune3", 28.0f }, { "level3", -16.0f },
                        { "filterType", 0 }, { "ampAttack", 0.002f }, { "ampDecay", 1.6f }, { "ampSustain", 0.0f },
                        { "ampRelease", 1.5f }, { "reverbOn", true }, { "reverbMix", 0.3f } } },

            { "Organ", { { "waveShape1", 1 }, { "waveShape2", 1 }, { "tune2", 12.0f }, { "level2", -4.0f },
                         { "waveShape3", 1 }, { "tune3", 19.0f }, { "level3", -10.0f },
                         { "waveShape4", 1 }, { "tune4", 24.0f }, { "level4", -12.0f },
                         { "filterType", 0 }, { "ampAttack", 0.004f }, { "ampDecay", 0.05f }, { "ampSustain", 100.0f },
                         { "ampRelease", 0.06f }, { "chorusOn", true }, { "chorusMix", 0.35f }, { "chosusSpeed", 5.5f },
                         { "masterLevel", -9.0f } } },

            { "Brass", { { "waveShape1", 3 }, { "voices1", 2 }, { "detune1", 0.06f }, { "waveShape2", 3 }, { "fineTune2", 6.0f },
                         { "filterFreq", 78.0f }, { "filterResonance", 10.0f }, { "filterAmount", 0.35f },
                         { "filterAttack", 0.07f }, { "filterDecay", 0.3f }, { "filterSustain", 60.0f },
                         { "ampAttack", 0.05f }, { "ampDecay", 0.2f }, { "ampSustain", 85.0f }, { "ampRelease", 0.2f } } },

            { "Soft Keys", { { "waveShape1", 1 }, { "waveShape2", 4 }, { "tune2", 12.0f }, { "level2", -14.0f },
                             { "filterType", 0 }, { "ampAttack", 0.003f }, { "ampDecay", 1.2f }, { "ampSustain", 30.0f },
                             { "ampRelease", 0.5f }, { "chorusOn", true }, { "chorusMix", 0.35f },
                             { "reverbOn", true }, { "reverbMix", 0.2f } } },

            { "Chiptune", { { "waveShape1", 2 }, { "pulseWidth1", 0.25f }, { "filterType", 0 },
                            { "ampAttack", 0.001f }, { "ampDecay", 0.05f }, { "ampSustain", 80.0f }, { "ampRelease", 0.04f } } },

            { "Init (Sine)", { { "waveShape1", 1 }, { "filterType", 0 } } },
        };
        return list;
    }

    StringArray getNames()
    {
        StringArray names;
        for (auto& p : presets())
            names.add (p.first);
        return names;
    }

    void apply (te::Plugin& plugin, const String& name)
    {
        for (auto& [prop, value] : base())
            plugin.state.setProperty (prop, value, nullptr);

        for (auto& p : presets())
            if (p.first.equalsIgnoreCase (name))
                for (auto& [prop, value] : p.second)
                    plugin.state.setProperty (prop, value, nullptr);

        plugin.state.setProperty ("lodePreset", name, nullptr);
        plugin.restorePluginStateFromValueTree (plugin.state.createCopy());
    }
}

} // namespace lode
