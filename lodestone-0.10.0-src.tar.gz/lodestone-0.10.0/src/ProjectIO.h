/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    Opening, importing and exporting.

    Every foreign format is first converted to the "Lodestone Interchange
    Format" (LIF) - a small JSON description of tracks, instruments, clips,
    notes and audio - and then built into an Edit by one shared builder.
      - MIDI files and DAWproject: parsed here in C++
      - LMMS, FL Studio, GarageBand/Logic: parsed by the Python importers in
        importers/lodestone_import (run as a child process)
*/
#pragma once

#include "Session.h"

namespace lode::ProjectIO
{
    bool isProjectFile (const juce::File&);          // things we "open" rather than drop in
    juce::String getOpenFileWildcard();

    /** Opens a .lodestone project or imports anything else into a new project. */
    void openAnyFile (Session&, const juce::File&);

    /** Builds a new project from LIF. Returns a summary of anything approximated. */
    juce::StringArray buildNewProjectFromLIF (Session&, const juce::var& lif, const juce::File& projectFile);

    /** Adds LIF tracks/clips into the current project at a beat offset. */
    void addLIFToCurrentEdit (Session&, const juce::var& lif, double beatOffset, te::AudioTrack* targetTrack,
                              juce::StringArray& warnings);

    // Format readers -> LIF
    juce::var readMidiFile (const juce::File&, juce::String& error);
    juce::var readDawProject (const juce::File&, const juce::File& extractDir, juce::String& error);
    juce::var runPythonImporter (const juce::File& source, const juce::File& workDir, juce::String& error);

    void importMidiFileIntoEdit (Session&, const juce::File&, double beat, te::AudioTrack* track);

    // Exports
    struct AudioExportOptions
    {
        juce::String format = "wav";        // wav, flac, ogg
        int bitDepth = 24;
        double sampleRate = 44100.0;
        bool loopRangeOnly = false;
        bool normalise = false;
        float normaliseLufs = -14.0f;
        double tailSeconds = 2.0;
    };

    bool exportMixdown (Session&, const juce::File&, const AudioExportOptions&);

    /** Renders the edit offline (bypassing the safety clipper) and returns its sample peak in dB. */
    float measurePeakDb (Session&);
    int exportStems (Session&, const juce::File& folder, const AudioExportOptions&);
    bool exportMidi (Session&, const juce::File&);
    bool exportDawProject (Session&, const juce::File&, juce::String& error);

    /** Runs a TE background task with a progress window (used by UIBehaviour). */
    void runTaskWithProgress (te::ThreadPoolJobWithProgress&);
}
