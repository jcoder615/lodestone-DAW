/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#include "Browser.h"
#include "DrumMachinePlugin.h"
#include "SoundFontPlugin.h"
#include "AirWindowsList.h"
#include "ProjectIO.h"

namespace lode
{
using namespace juce;

//==============================================================================
namespace BrowserItems
{
    static String kindOf (const String& d)      { return d.upToFirstOccurrenceOf ("|", false, false); }
    static String payload (const String& d)     { return d.fromFirstOccurrenceOf ("|", false, false); }

    static String pluginToString (const PluginDescription& pd)
    {
        if (auto xml = pd.createXml())
            return xml->toString (XmlElement::TextFormat().singleLine().withoutHeader());
        return {};
    }

    static PluginDescription pluginFromString (const String& s)
    {
        PluginDescription pd;
        if (auto xml = parseXML (s))
            pd.loadFromXml (*xml);
        return pd;
    }

    bool isInstrument (const String& d)
    {
        auto k = kindOf (d);
        return k == "kit" || k == "gm" || k == "sf2" || k == "synth" || k == "sampler" || k == "plugin";
    }

    bool isEffect (const String& d)
    {
        auto k = kindOf (d);
        return k == "fx" || k == "fxplugin";
    }

    InstrumentSpec toInstrumentSpec (const String& d)
    {
        auto k = kindOf (d);
        auto p = payload (d);
        StringArray parts;
        parts.addTokens (p, "|", {});

        if (k == "kit")     return InstrumentSpec::drums (File (p));
        if (k == "gm")      return InstrumentSpec::gm (parts[1].getIntValue(), parts[0].getIntValue());
        if (k == "synth")   return InstrumentSpec::synth (p);
        if (k == "sampler") return InstrumentSpec::sampler (File (p), 60);
        if (k == "plugin")  return InstrumentSpec::external (pluginFromString (p));

        if (k == "sf2")
        {
            auto spec = InstrumentSpec::gm (parts[2].getIntValue(), parts[1].getIntValue());
            spec.file = File (parts[0]);
            return spec;
        }

        return {};
    }

    String displayName (const String& d)
    {
        auto k = kindOf (d);
        auto p = payload (d);

        if (k == "kit")     return File (p).getFileName();
        if (k == "synth")   return p;
        if (k == "gm")
        {
            StringArray parts;
            parts.addTokens (p, "|", {});
            return parts[0].getIntValue() == 128 ? String ("GM Drums") : SoundFonts::gmProgramName (parts[1].getIntValue());
        }
        if (k == "plugin" || k == "fxplugin") return pluginFromString (p).name;
        if (k == "fx")
        {
            for (auto& a : airWindowsList)
                if (p == a.xmlType)
                    return a.name;
            return p;
        }

        return p;
    }

    te::Plugin::Ptr createEffect (Session& s, const String& d)
    {
        auto k = kindOf (d);
        if (k == "fx")       return s.createPlugin (payload (d));
        if (k == "fxplugin") return s.createPlugin (te::ExternalPlugin::xmlTypeName, pluginFromString (payload (d)));
        return {};
    }

    bool applyToTrack (Session& s, const String& d, te::AudioTrack* track, bool createTrackIfNeeded)
    {
        if (isInstrument (d))
        {
            auto spec = toInstrumentSpec (d);

            if (track != nullptr && getTrackKind (*track) != TrackKind::audio)
            {
                s.setInstrument (*track, spec);
                track->setName (s.makeUniqueTrackName (displayName (d)));
                s.status ("Instrument on \"" + track->getName() + "\" is now " + displayName (d));
                s.selectTrack (track);
                return true;
            }

            if (createTrackIfNeeded || track == nullptr || getTrackKind (*track) == TrackKind::audio)
            {
                auto t = s.addTrackWithInstrument (spec, displayName (d), track);
                s.selectTrack (t);
                return t != nullptr;
            }

            return false;
        }

        if (isEffect (d))
        {
            if (track == nullptr)
                track = s.getSelectedTrack();

            if (track == nullptr)
            {
                s.status ("Select a track first, then add the effect");
                return false;
            }

            if (auto p = createEffect (s, d))
            {
                s.insertEffect (*track, p);
                s.status ("Added " + p->getName() + " to " + track->getName());
                return true;
            }

            s.status ("Couldn't load " + displayName (d));
            return false;
        }

        return false;
    }

    Array<Entry> getAllEntries (te::Engine& engine)
    {
        Array<Entry> list;

        for (auto& k : DrumKits::findAll())
            list.add ({ k.name + " (drum kit)", "kit|" + k.location.getFullPathName(), "Drum Kits" });

        list.add ({ "General MIDI Drum Kit", "gm|128|0", "Drum Kits" });

        for (int p = 0; p < 128; ++p)
            list.add ({ SoundFonts::gmProgramName (p), "gm|0|" + String (p), SoundFonts::gmFamilyName (p / 8) });

        for (auto& n : SynthPresets::getNames())
            list.add ({ n + " (synth)", "synth|" + n, "Synths" });

        list.add ({ "Empty Sampler", "sampler|", "Sampler" });

        for (auto& pd : engine.getPluginManager().knownPluginList.getTypes())
            list.add ({ pd.name + " (" + pd.pluginFormatName + ")",
                        String (pd.isInstrument ? "plugin|" : "fxplugin|") + pluginToString (pd),
                        pd.isInstrument ? "Plugin Instruments" : "Plugin Effects" });

        for (auto [name, type] : std::initializer_list<std::pair<const char*, const char*>> {
                 { "Reverb", te::ReverbPlugin::xmlTypeName }, { "Delay", te::DelayPlugin::xmlTypeName },
                 { "Chorus", te::ChorusPlugin::xmlTypeName }, { "Phaser", te::PhaserPlugin::xmlTypeName },
                 { "Compressor", te::CompressorPlugin::xmlTypeName }, { "EQ (4-band)", te::EqualiserPlugin::xmlTypeName },
                 { "Low/High-pass Filter", te::LowPassPlugin::xmlTypeName }, { "Pitch Shifter", te::PitchShiftPlugin::xmlTypeName } })
            list.add ({ name, String ("fx|") + type, "Effects" });

        for (auto& a : airWindowsList)
            list.add ({ String (a.name) + " (Airwindows)", String ("fx|") + a.xmlType, "Airwindows" });

        return list;
    }
}

//==============================================================================
PreviewPlayer::PreviewPlayer (te::Engine& e) : engine (e)
{
    sourcePlayer.setSource (&transport);
    engine.getDeviceManager().deviceManager.addAudioCallback (&sourcePlayer);
}

PreviewPlayer::~PreviewPlayer()
{
    engine.getDeviceManager().deviceManager.removeAudioCallback (&sourcePlayer);
    transport.setSource (nullptr);
    sourcePlayer.setSource (nullptr);
}

void PreviewPlayer::play (const File& f)
{
    stop();
    std::unique_ptr<AudioFormatReader> reader (engine.getAudioFileFormatManager().readFormatManager.createReaderFor (f));

    if (reader == nullptr)
        return;

    auto sr = reader->sampleRate;
    readerSource = std::make_unique<AudioFormatReaderSource> (reader.release(), true);
    transport.setSource (readerSource.get(), 0, nullptr, sr);
    transport.setGain (0.8f);
    transport.start();
}

void PreviewPlayer::stop()
{
    transport.stop();
    transport.setSource (nullptr);
    readerSource.reset();
}

bool PreviewPlayer::isPlaying() const     { return transport.isPlaying(); }

//==============================================================================
struct BrowserPanel::Item : public TreeViewItem
{
    Item (BrowserPanel& o, const String& n, const String& d = {}, const String& sub = {})
        : owner (o), name (n), description (d), subtitle (sub) {}

    bool mightContainSubItems() override        { return description.isEmpty(); }
    int getItemHeight() const override          { return 24; }
    String getUniqueName() const override       { return name + description; }
    var getDragSourceDescription() override     { return description; }
    bool customComponentUsesTreeViewMouseHandler() const override { return false; }

    void paintItem (Graphics& g, int w, int h) override
    {
        auto r = Rectangle<int> (0, 0, w, h);

        if (isSelected())
        {
            g.setColour (Col::south.withAlpha (0.28f));
            g.fillRoundedRectangle (r.toFloat().reduced (1.0f), 4.0f);
        }

        auto isGroup = description.isEmpty();
        g.setColour (isGroup ? Col::text : Col::text.withAlpha (0.92f));
        g.setFont (LodeLookAndFeel::font (isGroup ? 13.5f : 13.0f, isGroup));

        auto textArea = r.reduced (4, 0);
        if (subtitle.isNotEmpty())
        {
            g.setColour (Col::textFaint);
            g.setFont (LodeLookAndFeel::font (11.0f));
            g.drawText (subtitle, textArea, Justification::centredRight, true);
            textArea.removeFromRight (jmin (90, (int) GlyphArrangement::getStringWidth (LodeLookAndFeel::font (11.0f), subtitle) + 6));
            g.setColour (Col::text.withAlpha (0.92f));
            g.setFont (LodeLookAndFeel::font (isGroup ? 13.5f : 13.0f, isGroup));
        }

        g.drawText (name, textArea, Justification::centredLeft, true);
    }

    void itemClicked (const MouseEvent& e) override
    {
        if (description.isEmpty() && ! e.mods.isPopupMenu())
            setOpen (! isOpen());
    }

    void itemDoubleClicked (const MouseEvent&) override
    {
        if (description.isEmpty())
            return;

        auto& s = owner.session;
        s.edit_().getUndoManager().beginNewTransaction ("Browser");
        BrowserItems::applyToTrack (s, description, s.getSelectedTrack(), false);
    }

    BrowserPanel& owner;
    String name, description, subtitle;
};

//==============================================================================
BrowserPanel::BrowserPanel (Session& s)
    : session (s), preview (s.engine)
{
    for (auto name : { "Sounds", "Effects", "Plugins", "Files" })
    {
        auto b = tabButtons.add (new TextButton (name));
        b->setClickingTogglesState (true);
        b->setRadioGroupId (1001);
        b->setColour (TextButton::buttonColourId, Col::bg2);
        b->setColour (TextButton::buttonOnColourId, Col::bg4);
        addAndMakeVisible (b);
        auto index = tabButtons.size() - 1;
        b->onClick = [this, index] { showTab (index); };
    }

    addAndMakeVisible (search);
    search.setTextToShowWhenEmpty ("Search sounds, effects, plugins...", Col::textFaint);
    search.setFont (LodeLookAndFeel::font (13.0f));
    search.onTextChange = [this] { rebuildTree(); };
    search.onEscapeKey = [this] { search.clear(); rebuildTree(); };

    addAndMakeVisible (tree);
    tree.setRootItemVisible (false);
    tree.setIndentSize (14);
    tree.setDefaultOpenness (false);
    tree.setColour (TreeView::backgroundColourId, Col::bg1);

    fileThread.startThread (Thread::Priority::low);
    addChildComponent (fileTree);
    fileTree.addListener (this);
    fileTree.setDragAndDropDescription ("filetree");
    fileTree.setColour (FileTreeComponent::backgroundColourId, Col::bg1);
    fileTree.setItemHeight (22);

    addChildComponent (places);
    auto home = File::getSpecialLocation (File::userHomeDirectory);
    struct Place { const char* name; File dir; };
    std::vector<Place> placeList = { { "Home", home },
                                     { "Music", File::getSpecialLocation (File::userMusicDirectory) },
                                     { "Lodestone Projects", getDefaultProjectsDir() },
                                     { "Desktop", File::getSpecialLocation (File::userDesktopDirectory) },
                                     { "Downloads", home.getChildFile ("Downloads") },
                                     { "LMMS projects", home.getChildFile ("lmms/projects") },
                                     { "LMMS samples", File ("/usr/share/lmms/samples") },
                                     { "Lodestone drum kits", getDataDir().getChildFile ("kits") } };

    int id = 1;
    for (auto& p : placeList)
        if (p.dir.isDirectory())
            places.addItem (p.name, id++), places.getProperties().set (String (id - 1), p.dir.getFullPathName());

    places.onChange = [this]
    {
        auto path = places.getProperties()[String (places.getSelectedId())].toString();
        if (path.isNotEmpty())
            fileList.setDirectory (File (path), true, true);
    };
    places.setSelectedId (1, sendNotification);

    addChildComponent (previewToggle);
    previewToggle.setToggleState (true, dontSendNotification);
    previewToggle.onClick = [this] { if (! previewToggle.getToggleState()) preview.stop(); };

    addAndMakeVisible (hint);
    hint.setFont (LodeLookAndFeel::font (11.5f));
    hint.setColour (Label::textColourId, Col::textFaint);
    hint.setJustificationType (Justification::centredLeft);

    tabButtons[0]->setToggleState (true, dontSendNotification);
    showTab (0);
}

BrowserPanel::~BrowserPanel()
{
    preview.stop();
    fileTree.removeListener (this);
    tree.setRootItem (nullptr);
    fileThread.stopThread (2000);
}

void BrowserPanel::paint (Graphics& g)
{
    g.fillAll (Col::bg1);
    g.setColour (Col::bg0);
    g.fillRect (getWidth() - 1, 0, 1, getHeight());
}

void BrowserPanel::resized()
{
    auto r = getLocalBounds().reduced (6).withTrimmedRight (1);
    auto tabs = r.removeFromTop (28);
    auto w = tabs.getWidth() / tabButtons.size();
    for (auto* b : tabButtons)
        b->setBounds (tabs.removeFromLeft (w).reduced (1, 0));

    r.removeFromTop (6);
    hint.setBounds (r.removeFromBottom (34));

    if (currentTab == 3)
    {
        auto row = r.removeFromTop (26);
        previewToggle.setBounds (row.removeFromRight (84));
        places.setBounds (row.withTrimmedRight (4));
        r.removeFromTop (4);
        fileTree.setBounds (r);
    }
    else
    {
        search.setBounds (r.removeFromTop (26));
        r.removeFromTop (4);
        tree.setBounds (r);
    }
}

void BrowserPanel::showTab (int index)
{
    currentTab = index;

    for (int i = 0; i < tabButtons.size(); ++i)
        tabButtons[i]->setToggleState (i == index, dontSendNotification);

    auto files = index == 3;
    fileTree.setVisible (files);
    places.setVisible (files);
    previewToggle.setVisible (files);
    tree.setVisible (! files);
    search.setVisible (! files);

    static const char* hints[] = {
        "Double-click to put a sound on the selected track,\nor drag it into the arrangement for a new track.",
        "Double-click to add to the selected track,\nor drag onto any track.",
        "Your VST3 / LV2 / LADSPA plugins. Rescan in\nTools > Scan for Plugins.",
        "Drag audio, MIDI or projects (LMMS, FL, GarageBand,\nDAWproject) into the arrangement." };
    hint.setText (hints[jlimit (0, 3, index)], dontSendNotification);

    if (! files)
        rebuildTree();
    else
        preview.stop();

    resized();
}

void BrowserPanel::refresh()
{
    rebuildTree();
}

void BrowserPanel::rebuildTree()
{
    tree.setRootItem (nullptr);
    root = std::make_unique<Item> (*this, "root");
    auto filter = search.getText().trim();

    auto entries = BrowserItems::getAllEntries (session.engine);

    auto wantedForTab = [this] (const BrowserItems::Entry& e)
    {
        auto isFx = BrowserItems::isEffect (e.description);
        auto isPlugin = e.description.startsWith ("plugin|") || e.description.startsWith ("fxplugin|");

        switch (currentTab)
        {
            case 0:  return ! isFx && ! isPlugin;
            case 1:  return isFx && ! isPlugin;
            case 2:  return isPlugin;
            default: return false;
        }
    };

    if (filter.isNotEmpty())
    {
        // flat search across everything
        int count = 0;
        for (auto& e : entries)
            if (e.name.containsIgnoreCase (filter) || e.category.containsIgnoreCase (filter))
            {
                root->addSubItem (new Item (*this, e.name, e.description, e.category));
                if (++count > 400) break;
            }
    }
    else
    {
        std::map<String, Item*> groups;
        StringArray order;

        for (auto& e : entries)
        {
            if (! wantedForTab (e))
                continue;

            auto groupName = e.category;
            if (currentTab == 0 && e.description.startsWith ("gm|0|"))
                groupName = "Instruments: " + groupName;

            if (groups.find (groupName) == groups.end())
            {
                auto g = new Item (*this, groupName);
                groups[groupName] = g;
                order.add (groupName);
                root->addSubItem (g);
            }

            auto displayName = e.name.upToLastOccurrenceOf (" (", false, false);
            if (displayName.isEmpty() || e.category == "Plugin Instruments" || e.category == "Plugin Effects")
                displayName = e.name;

            if (currentTab == 1 && e.category == "Airwindows")
            {
                // group Airwindows by their category
                for (auto& a : airWindowsList)
                    if (e.description == String ("fx|") + a.xmlType)
                    {
                        auto sub = "Airwindows: " + String (a.category).substring (0, 1).toUpperCase() + String (a.category).substring (1);
                        if (groups.find (sub) == groups.end())
                        {
                            auto g = new Item (*this, sub);
                            groups[sub] = g;
                            root->addSubItem (g);
                        }
                        groups[sub]->addSubItem (new Item (*this, a.name, e.description));
                    }
                continue;
            }

            groups[groupName]->addSubItem (new Item (*this, displayName, e.description));
        }

        // drop the empty generic "Airwindows" group
        for (int i = root->getNumSubItems(); --i >= 0;)
            if (root->getSubItem (i)->getNumSubItems() == 0)
                root->removeSubItem (i);

        if (currentTab == 2 && root->getNumSubItems() == 0)
            root->addSubItem (new Item (*this, "No plugins scanned yet - use Tools > Scan for Plugins"));

        if (root->getNumSubItems() > 0)
            root->getSubItem (0)->setOpen (true);
    }

    tree.setRootItem (root.get());
}

Array<File> BrowserPanel::getSelectedFiles() const
{
    Array<File> files;
    for (int i = 0; i < fileTree.getNumSelectedFiles(); ++i)
        files.add (fileTree.getSelectedFile (i));
    return files;
}

void BrowserPanel::selectionChanged() {}

void BrowserPanel::fileClicked (const File& f, const MouseEvent&)
{
    if (! previewToggle.getToggleState() || f.isDirectory())
        return;

    auto ext = f.getFileExtension().toLowerCase();
    if (session.engine.getAudioFileFormatManager().readFormatManager.findFormatForFileExtension (ext) != nullptr)
        preview.play (f);
    else
        preview.stop();
}

void BrowserPanel::fileDoubleClicked (const File& f)
{
    preview.stop();

    if (f.isDirectory() && ! ProjectIO::isProjectFile (f))
        return;

    if (onOpenFile)
        onOpenFile (f);
}

} // namespace lode
