/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later

    The Practice screen: a card per sound (which controllers play it, which keys,
    transpose, volume, effects), audio-input cards with a meter, tuner and
    hold-to-sample, a keyboard map of the splits, the metronome, the practice
    recorder and "Save what I played".
*/
#pragma once

#include "Practice.h"
#include "Theme.h"

namespace lode
{

class DeviceChainPanel;
class LevelMeter;
class DragNumber;

class PracticeView : public juce::Component,
                     private juce::Timer,
                     private juce::ValueTree::Listener,
                     private juce::AsyncUpdater
{
public:
    PracticeView (Session&);
    ~PracticeView() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override     { takeFocusBack(); }

    /** Clicking around Practice gives the keyboard back to the shortcuts (Space, R, T...),
        even after typing in a search box. */
    void takeFocusBack();

    void toggleMetronome();
    void toggleRecording();
    void showSaveMenu (juce::Component* target);
    void setKeyboardActive (bool);

    std::function<void()> onBack, onToggleKeyboard;
    std::function<void (const juce::File&)> onOpenProject;

    PracticeController& getController()     { return *controller; }

    /** Shows a message under the top bar, with optional buttons. */
    void showNotice (const juce::String& message, juce::StringArray buttons = {},
                     std::function<void (int)> onButton = {}, bool isError = false);

    // used by the cards
    void selectSlot (te::AudioTrack*);
    te::AudioTrack* getSelectedSlot() const;
    void playKey (int note, bool on, int velocity = 100);

private:
    class SlotCard;
    class InstrumentCard;
    class AudioCard;
    class AddCard;
    class KeyboardMap;
    class MasterStrip;
    class NoticeBar;

    Session& session;
    std::unique_ptr<PracticeController> controller;

    // top bar
    juce::TextButton backButton, saveButton { "Save what I played" }, resetButton;
    IconButton metronomeButton { "metronome", "Metronome on/off (Space)" },
               recordButton { "record", "Record everything you play to a WAV file (R)" },
               keyboardButton { "keyboard", "Play with your computer keyboard: A W S E D F T G Y H U J K (Ctrl+K)" };
    std::unique_ptr<DragNumber> tempo;
    juce::TextButton tapButton { "TAP" };
    juce::ComboBox timeSig;
    juce::Slider clickVolume;
    juce::Label recTime;
    std::unique_ptr<LevelMeter> masterMeter;

    std::unique_ptr<NoticeBar> notice;
    juce::Viewport cardsViewport;
    juce::Component cardsHolder;
    juce::OwnedArray<SlotCard> cards;
    std::unique_ptr<AddCard> addCard;
    std::unique_ptr<KeyboardMap> keyboardMap;
    std::unique_ptr<MasterStrip> masterStrip;
    std::unique_ptr<DeviceChainPanel> chain;

    int lastBeatShown = -1;
    juce::Rectangle<int> beatArea;

    void rebuildCards();
    void refreshCards();
    void refreshTopBar();
    void layoutCards();
    void timerCallback() override;
    void handleAsyncUpdate() override;

    bool needsRebuild = false;
    void valueTreeChildAdded (juce::ValueTree&, juce::ValueTree&) override;
    void valueTreeChildRemoved (juce::ValueTree&, juce::ValueTree&, int) override;
    void valueTreeChildOrderChanged (juce::ValueTree&, int, int) override;
    void valueTreePropertyChanged (juce::ValueTree&, const juce::Identifier&) override;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PracticeView)
};

} // namespace lode
