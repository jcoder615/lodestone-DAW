/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
*/
#pragma once

#include "Session.h"
#include "Theme.h"

namespace lode
{

class TransportBar;
class BrowserPanel;
class ArrangementView;
class ClipEditorPanel;
class DeviceChainPanel;
class MixerView;
class LodeUIBehaviour;
class PracticeView;

namespace CommandIDs
{
    enum
    {
        newProject = 0x2000, openProject, save, saveAs, importFiles, importFolderProject,
        exportAudio, exportStems, exportMidi, exportDawProject, quit,

        undo = 0x2100, redo, cut, copy, paste, duplicate, deleteSelection, selectAll,
        split, quantize, renameClip, nudgeLeft, nudgeRight,

        newInstrumentTrack = 0x2200, newDrumTrack, newAudioTrack, newSynthTrack, duplicateTrack, deleteTrack,

        playStop = 0x2300, record, loop, metronome, goToStart, tapTempo, toggleSnap, loopSelection,

        zoomIn = 0x2400, zoomOut, zoomFit, toggleBrowser, showEditor, showInstrument, showMixer,

        commandPalette = 0x2500, musicalTyping, settings, scanPlugins, shortcuts, about, gettingStarted, practiceMode
    };
}

//==============================================================================
class MainComponent : public juce::Component,
                      public juce::DragAndDropContainer,
                      public juce::ApplicationCommandTarget,
                      public juce::MenuBarModel,
                      private juce::ChangeListener,
                      private juce::Timer
{
public:
    MainComponent (Session&, LodeUIBehaviour&);
    ~MainComponent() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;
    bool keyStateChanged (bool isKeyDown) override;

    // ApplicationCommandTarget
    juce::ApplicationCommandTarget* getNextCommandTarget() override     { return nullptr; }
    void getAllCommands (juce::Array<juce::CommandID>&) override;
    void getCommandInfo (juce::CommandID, juce::ApplicationCommandInfo&) override;
    bool perform (const InvocationInfo&) override;

    // MenuBarModel
    juce::StringArray getMenuBarNames() override;
    juce::PopupMenu getMenuForIndex (int, const juce::String&) override;
    void menuItemSelected (int, int) override {}

    juce::ApplicationCommandManager commandManager;

    void openFile (const juce::File&);
    void status (const juce::String&);
    void togglePractice();              // deferred: safe to call from anywhere
    PracticeView* getPracticeView()     { return practiceView.get(); }
    bool confirmCloseIfUnsaved (std::function<void()> continuation);
    void showBottomTab (int);

    Session& session;

private:
    LodeUIBehaviour& uiBehaviour;
    te::Edit* currentEdit = nullptr;

    std::unique_ptr<TransportBar> transport;
    std::unique_ptr<BrowserPanel> browser;
    std::unique_ptr<ArrangementView> arrangement;
    std::unique_ptr<ClipEditorPanel> clipEditor;
    std::unique_ptr<DeviceChainPanel> devicePanel;
    std::unique_ptr<MixerView> mixer;
    std::unique_ptr<PracticeView> practiceView;

    juce::OwnedArray<juce::TextButton> bottomTabs;
    int bottomTab = 0;
    bool browserVisible = true;
    int browserWidth = 270;

    class Resizer;
    std::unique_ptr<Resizer> vResizer, hResizer;

    juce::Label statusLabel, deviceLabel;
    juce::uint32 statusTime = 0;

    // musical typing
    bool typingOn = false;
    int typingOctave = 5, typingVelocity = 100;
    std::set<int> typingNotesDown;
    std::shared_ptr<te::MidiInputDevice> keyboardDevice;

    std::unique_ptr<juce::FileChooser> chooser;

    void buildEditUI();
    void tearDownEditUI();
    void changeListenerCallback (juce::ChangeBroadcaster*) override;
    void timerCallback() override;
    void updateTitle();
    void setupKeyboardDevice();
    void sendTypingNote (int note, bool on);

    void doOpen();
    void doImport (bool folders);
    void doSaveAs (std::function<void()> after = {});
    void doExport (int kind);
    void showSettings (int tab = 0);
    void showCommandPalette();
    void showShortcuts();
    void showAbout();
    void showGettingStarted();
    void addTrackOfKind (int kind);
};

//==============================================================================
class MainWindow : public juce::DocumentWindow
{
public:
    MainWindow (Session&, LodeUIBehaviour&);
    ~MainWindow() override;

    void closeButtonPressed() override;
    MainComponent& getMainComponent()   { return *main; }

private:
    std::unique_ptr<MainComponent> main;
};

} // namespace lode
