/*
    Lodestone - SPDX-License-Identifier: AGPL-3.0-or-later
    Scales, chords and the little bits of theory the editors use.
*/
#pragma once

#include "Utils.h"

namespace lode::Theory
{

struct Scale
{
    const char* name;
    std::vector<int> steps;   // semitone offsets from the root
};

inline const std::vector<Scale>& scales()
{
    static const std::vector<Scale> s = {
        { "Major",            { 0, 2, 4, 5, 7, 9, 11 } },
        { "Minor",            { 0, 2, 3, 5, 7, 8, 10 } },
        { "Harmonic Minor",   { 0, 2, 3, 5, 7, 8, 11 } },
        { "Melodic Minor",    { 0, 2, 3, 5, 7, 9, 11 } },
        { "Dorian",           { 0, 2, 3, 5, 7, 9, 10 } },
        { "Phrygian",         { 0, 1, 3, 5, 7, 8, 10 } },
        { "Lydian",           { 0, 2, 4, 6, 7, 9, 11 } },
        { "Mixolydian",       { 0, 2, 4, 5, 7, 9, 10 } },
        { "Locrian",          { 0, 1, 3, 5, 6, 8, 10 } },
        { "Major Pentatonic", { 0, 2, 4, 7, 9 } },
        { "Minor Pentatonic", { 0, 3, 5, 7, 10 } },
        { "Blues",            { 0, 3, 5, 6, 7, 10 } },
        { "Whole Tone",       { 0, 2, 4, 6, 8, 10 } },
        { "Chromatic",        { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 } },
    };
    return s;
}

inline const Scale& findScale (const juce::String& name)
{
    for (auto& s : scales())
        if (name == s.name)
            return s;

    return scales().front();
}

inline bool isInScale (int note, int root, const Scale& scale)
{
    auto rel = ((note - root) % 12 + 12) % 12;
    return std::find (scale.steps.begin(), scale.steps.end(), rel) != scale.steps.end();
}

inline int snapToScale (int note, int root, const Scale& scale)
{
    for (int d = 0; d < 12; ++d)
    {
        if (isInScale (note - d, root, scale)) return note - d;
        if (isInScale (note + d, root, scale)) return note + d;
    }
    return note;
}

/** Index of a note within the scale (degree), and octave-aware stepping. */
inline int scaleStep (int note, int root, const Scale& scale, int steps)
{
    note = snapToScale (note, root, scale);
    int dir = steps > 0 ? 1 : -1;

    for (int i = 0; i < std::abs (steps); ++i)
    {
        do { note += dir; } while (! isInScale (note, root, scale));
    }

    return note;
}

struct Chord
{
    const char* name;
    std::vector<int> intervals;    // semitones; empty = diatonic triad from the scale
    bool diatonic = false;
    int diatonicNotes = 3;
};

inline const std::vector<Chord>& chords()
{
    static const std::vector<Chord> c = {
        { "Single note",     { 0 } },
        { "Diatonic triad",  {}, true, 3 },
        { "Diatonic 7th",    {}, true, 4 },
        { "Major",           { 0, 4, 7 } },
        { "Minor",           { 0, 3, 7 } },
        { "Power (5th)",     { 0, 7, 12 } },
        { "Sus2",            { 0, 2, 7 } },
        { "Sus4",            { 0, 5, 7 } },
        { "Dominant 7",      { 0, 4, 7, 10 } },
        { "Major 7",         { 0, 4, 7, 11 } },
        { "Minor 7",         { 0, 3, 7, 10 } },
        { "Diminished",      { 0, 3, 6 } },
        { "Augmented",       { 0, 4, 8 } },
        { "Add 9",           { 0, 4, 7, 14 } },
        { "Octave",          { 0, 12 } },
    };
    return c;
}

inline std::vector<int> buildChord (int rootNote, const Chord& chord, int keyRoot, const Scale& scale)
{
    std::vector<int> notes;

    if (chord.diatonic)
    {
        auto n = snapToScale (rootNote, keyRoot, scale);
        for (int i = 0; i < chord.diatonicNotes; ++i)
        {
            notes.push_back (n);
            n = scaleStep (n, keyRoot, scale, 2);   // stack thirds within the scale
        }
    }
    else
    {
        for (auto i : chord.intervals)
            notes.push_back (rootNote + i);
    }

    for (auto& n : notes)
        n = juce::jlimit (0, 127, n);

    return notes;
}

/** Bjorklund/Euclidean rhythm: k pulses spread as evenly as possible over n steps. */
inline std::vector<bool> euclid (int pulses, int steps, int rotation = 0)
{
    std::vector<bool> pattern ((size_t) juce::jmax (1, steps), false);
    if (steps <= 0) return pattern;
    pulses = juce::jlimit (0, steps, pulses);

    // bucket method - gives the same necklaces as Bjorklund's algorithm
    int bucket = 0;
    for (int i = 0; i < steps; ++i)
    {
        bucket += pulses;
        if (bucket >= steps)
        {
            bucket -= steps;
            pattern[(size_t) i] = true;
        }
    }

    // rotate so the first pulse lands on step 0, then apply the user rotation
    std::vector<bool> out ((size_t) steps);
    int firstPulse = 0;
    for (int i = 0; i < steps; ++i)
        if (pattern[(size_t) i]) { firstPulse = i; break; }

    for (int i = 0; i < steps; ++i)
        out[(size_t) i] = pattern[(size_t) (((i + firstPulse - rotation) % steps + steps) % steps)];

    return out;
}

inline juce::StringArray keyNames()
{
    return { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
}

} // namespace lode::Theory
