#!/usr/bin/env python3
"""
Lodestone - synthesizes the bundled drum kits (released as CC0).

Every sound is generated from oscillators, noise and filters, so the kits
carry no third-party sample licences. Output: resources/kits/<kit>/kit.json + WAVs.

Pads mostly follow the General MIDI drum map from note 36 upward (pad 15 swaps the
6th tom for something more useful), which is also what an Akai MPD218 sends from
bank A by default: pad 1 = kick, pad 3 = snare, pad 7 = closed hat, etc.

Usage: python3 scripts/make_kits.py [output_dir]
"""
import json
import os
import sys
import wave

import numpy as np
from scipy import signal

SR = 44100
rng = np.random.default_rng(1234)


# ---------------------------------------------------------------- helpers
def t_axis(seconds):
    return np.arange(int(SR * seconds)) / SR


def env_exp(t, tau, attack=0.0005):
    e = np.exp(-t / tau)
    if attack > 0:
        e *= np.clip(t / attack, 0, 1)
    return e


def noise(n):
    return rng.uniform(-1, 1, n)


def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, min(hi, SR / 2 - 100)], btype="bandpass", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def hp(x, f, order=2):
    return signal.sosfilt(signal.butter(order, f, btype="highpass", fs=SR, output="sos"), x)


def lp(x, f, order=2):
    return signal.sosfilt(signal.butter(order, min(f, SR / 2 - 100), btype="lowpass", fs=SR, output="sos"), x)


def sine_sweep(t, f_start, f_end, tau):
    f = f_end + (f_start - f_end) * np.exp(-t / tau)
    phase = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(phase)


def square(t, f):
    return np.sign(np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)))


def metallic(t, freqs=(205.3, 304.4, 369.6, 522.7, 540.0, 800.0)):
    # the six detuned square oscillators of the TR-808 cymbal/hat circuit
    return sum(square(t, f) for f in freqs) / len(freqs)


def soft_clip(x, drive=1.0):
    return np.tanh(x * drive) / np.tanh(drive)


def finish(x, peak_db=-1.0, fade_ms=8.0):
    x = np.asarray(x, dtype=np.float64)
    n_fade = int(SR * fade_ms / 1000)
    if n_fade > 0 and len(x) > n_fade:
        x[-n_fade:] *= np.linspace(1, 0, n_fade)
    # trim trailing silence
    thresh = 10 ** (-70 / 20) * np.max(np.abs(x))
    idx = np.nonzero(np.abs(x) > thresh)[0]
    if len(idx):
        x = x[: min(len(x), idx[-1] + int(SR * 0.01))]
    peak = np.max(np.abs(x)) or 1.0
    return x / peak * (10 ** (peak_db / 20))


def write_wav(path, x):
    x = np.clip(x, -1, 1)
    ints = np.round(x * 8388607).astype("<i4")
    raw = ints.view(np.uint8).reshape(-1, 4)[:, :3].tobytes()
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(3)
        w.setframerate(SR)
        w.writeframes(raw)


# ---------------------------------------------------------------- 808-style voices
def kick808(boom=0.45, f0=150.0, f1=47.0, click=0.25, drive=1.6):
    t = t_axis(boom * 5)
    body = sine_sweep(t, f0, f1, 0.035) * env_exp(t, boom)
    c = hp(noise(len(t)), 1500) * env_exp(t, 0.0025) * click
    return soft_clip(body + c, drive)


def snare808(tone=(180.0, 330.0), tone_tau=0.06, noise_tau=0.11, snappy=0.7, bright=1.0):
    t = t_axis(0.6)
    body = (np.sin(2 * np.pi * tone[0] * t) * 0.6 + np.sin(2 * np.pi * tone[1] * t) * 0.4) * env_exp(t, tone_tau)
    n = hp(noise(len(t)), 1200 * bright) * env_exp(t, noise_tau) * snappy
    n = lp(n, 9000 * bright)
    return soft_clip(body * 0.8 + n, 1.3)


def clap808():
    t = t_axis(0.5)
    n = bp(noise(len(t)), 900, 2600)
    e = np.zeros_like(t)
    for start in (0.0, 0.011, 0.022, 0.031):
        tt = np.clip(t - start, 0, None)
        e = np.maximum(e, np.where(t >= start, np.exp(-tt / 0.006), 0))
    tail = np.where(t >= 0.031, np.exp(-np.clip(t - 0.031, 0, None) / 0.12), 0) * 0.6
    return soft_clip(n * (e + tail) * 1.4, 1.2)


def rim808():
    t = t_axis(0.12)
    x = (np.sin(2 * np.pi * 1700 * t) * 0.6 + np.sin(2 * np.pi * 480 * t) * 0.5) * env_exp(t, 0.008)
    x += hp(noise(len(t)), 3000) * env_exp(t, 0.002) * 0.5
    return x


def hat808(tau=0.035, lo=7000, level_noise=0.25):
    t = t_axis(max(0.15, tau * 7))
    m = metallic(t) + noise(len(t)) * level_noise
    m = bp(m, lo, 15000, order=3)
    return m * env_exp(t, tau, attack=0.0003)


def cymbal808(tau=1.1, lo=4500):
    t = t_axis(tau * 5)
    m = metallic(t) * 0.8 + noise(len(t)) * 0.5
    m = hp(m, lo, order=3)
    env = env_exp(t, tau) * 0.7 + env_exp(t, 0.05) * 0.5
    return m * env


def ride():
    t = t_axis(3.0)
    partials = [(3150, 1.0), (4580, 0.7), (5240, 0.5), (6100, 0.4), (7900, 0.3), (512 * 2.0, 0.35)]
    bell = sum(a * np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) for f, a in partials)
    wash = hp(metallic(t, (318.0, 456.0, 587.0, 743.0, 845.0, 1123.0)) + noise(len(t)) * 0.3, 6000)
    return bell * env_exp(t, 0.6) * 0.25 + wash * env_exp(t, 0.9) * 0.6


def tom808(f0, tau=0.28):
    t = t_axis(tau * 5)
    body = sine_sweep(t, f0 * 1.35, f0, 0.04) * env_exp(t, tau)
    body += lp(noise(len(t)), 2000) * env_exp(t, 0.01) * 0.15
    return soft_clip(body, 1.2)


def cowbell808():
    t = t_axis(0.6)
    x = square(t, 540) + square(t, 800)
    x = bp(x, 450, 2600, order=2)
    return x * (env_exp(t, 0.02) * 0.6 + env_exp(t, 0.18) * 0.4)


# ---------------------------------------------------------------- 909-style "Punch" voices
def kick909():
    t = t_axis(0.9)
    body = sine_sweep(t, 230, 55, 0.025) * env_exp(t, 0.22)
    c = bp(noise(len(t)), 2000, 9000) * env_exp(t, 0.004) * 0.6
    return soft_clip(body * 1.1 + c, 2.4)


def snare909():
    t = t_axis(0.45)
    body = sine_sweep(t, 260, 190, 0.02) * env_exp(t, 0.045)
    n = bp(noise(len(t)), 1800, 12000) * env_exp(t, 0.16)
    return soft_clip(body * 0.7 + n * 0.9, 1.6)


def hat909(tau):
    t = t_axis(max(0.15, tau * 7))
    n = noise(len(t)) * 0.7 + metallic(t, (263.0, 400.0, 421.0, 474.0, 587.0, 845.0)) * 0.6
    return hp(n, 8000, order=4) * env_exp(t, tau, attack=0.0002)


# ---------------------------------------------------------------- hand percussion
def drum_hand(f0, tau, slap=0.2):
    t = t_axis(tau * 6)
    x = sine_sweep(t, f0 * 1.15, f0, 0.015) * env_exp(t, tau)
    x += np.sin(2 * np.pi * f0 * 2.3 * t) * env_exp(t, tau * 0.3) * 0.25
    x += bp(noise(len(t)), 1500, 6000) * env_exp(t, 0.006) * slap
    return soft_clip(x, 1.2)


def shaker(length=0.16):
    t = t_axis(length + 0.05)
    attack = np.clip(t / 0.03, 0, 1)
    e = attack * np.exp(-np.clip(t - 0.03, 0, None) / (length / 3))
    return bp(noise(len(t)), 4500, 11000, order=3) * e


def tambourine():
    t = t_axis(0.6)
    jingles = sum(np.sin(2 * np.pi * f * t + rng.uniform(0, 6.28)) for f in (5600, 6400, 7100, 8300, 9100))
    hits = np.zeros_like(t)
    for start in (0.0, 0.007, 0.015):
        hits = np.maximum(hits, np.where(t >= start, np.exp(-np.clip(t - start, 0, None) / 0.09), 0))
    x = (jingles * 0.4 + hp(noise(len(t)), 6000)) * hits
    return x


def clave():
    t = t_axis(0.15)
    return np.sin(2 * np.pi * 2500 * t) * env_exp(t, 0.022)


def woodblock(f=1050):
    t = t_axis(0.18)
    return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 1.58 * t)) * env_exp(t, 0.03)


def triangle():
    t = t_axis(3.0)
    partials = [(3020, 1.0), (4810, 0.5), (6670, 0.35), (8400, 0.25)]
    x = sum(a * np.sin(2 * np.pi * f * t) for f, a in partials)
    return x * env_exp(t, 0.9, attack=0.001)


def agogo(f):
    t = t_axis(0.8)
    x = np.sin(2 * np.pi * f * t) + 0.45 * np.sin(2 * np.pi * f * 2.76 * t) + 0.2 * np.sin(2 * np.pi * f * 5.4 * t)
    return x * env_exp(t, 0.18)


def guiro():
    t = t_axis(0.35)
    teeth = (np.sin(2 * np.pi * 55 * t) > 0.6).astype(float)
    env = np.clip(t / 0.02, 0, 1) * np.exp(-np.clip(t - 0.25, 0, None) / 0.02)
    return bp(noise(len(t)), 2000, 7000) * teeth * env


def timbale(f=420):
    t = t_axis(1.0)
    x = sine_sweep(t, f * 1.1, f, 0.01) * env_exp(t, 0.35)
    x += np.sin(2 * np.pi * f * 2.15 * t) * env_exp(t, 0.12) * 0.3
    x += hp(noise(len(t)), 2500) * env_exp(t, 0.03) * 0.4
    return x


def snap():
    t = t_axis(0.2)
    return bp(noise(len(t)), 1800, 3800, order=3) * env_exp(t, 0.012) + np.sin(2 * np.pi * 1200 * t) * env_exp(t, 0.004) * 0.3


# ---------------------------------------------------------------- processing for Lo-Fi
def lofi(x, bits=9, hold=3, cutoff=6500):
    x = lp(x, cutoff, order=4)
    x = np.repeat(x[::hold], hold)[: len(x)]
    q = 2 ** (bits - 1)
    x = np.round(x * q) / q
    x = soft_clip(x, 1.8)
    return lp(x, cutoff * 1.1)


# ---------------------------------------------------------------- kit definitions
GM_NAMES = {36: "Kick", 37: "Rim", 38: "Snare", 39: "Clap", 40: "Snare 2", 41: "Low Floor Tom",
            42: "Closed Hat", 43: "High Floor Tom", 44: "Pedal Hat", 45: "Low Tom", 46: "Open Hat",
            47: "Low-Mid Tom", 48: "Hi-Mid Tom", 49: "Crash", 50: "High Tom", 51: "Ride"}


def velocity_layers(make, n=3):
    """Softer hits are darker - the way real drums (and good sample kits) behave."""
    layers = []
    edges = np.linspace(0, 1, n + 1)
    for i in range(n):
        x = make()
        brightness = 0.35 + 0.65 * (i + 1) / n
        x = lp(x, 1200 + 17000 * brightness ** 2)
        layers.append((x, float(edges[i]), float(edges[i + 1])))
    return layers


def kit_808():
    return [
        dict(note=36, name="Kick", make=lambda: kick808(), layers=3),
        dict(note=37, name="Rim", make=rim808),
        dict(note=38, name="Snare", make=lambda: snare808(), layers=3),
        dict(note=39, name="Clap", make=clap808),
        dict(note=40, name="Snare (tight)", make=lambda: snare808(tone=(220, 380), tone_tau=0.04, noise_tau=0.07, snappy=0.9, bright=1.3)),
        dict(note=41, name="Low Tom", make=lambda: tom808(82)),
        dict(note=42, name="Closed Hat", make=lambda: hat808(0.035), choke=1, layers=3, pan=-0.15),
        dict(note=43, name="Mid-Low Tom", make=lambda: tom808(100)),
        dict(note=44, name="Pedal Hat", make=lambda: hat808(0.018, lo=6000), choke=1, pan=-0.15),
        dict(note=45, name="Mid Tom", make=lambda: tom808(122)),
        dict(note=46, name="Open Hat", make=lambda: hat808(0.32), choke=1, pan=-0.15),
        dict(note=47, name="Mid-High Tom", make=lambda: tom808(148)),
        dict(note=48, name="High Tom", make=lambda: tom808(180)),
        dict(note=49, name="Crash", make=lambda: cymbal808(1.1), pan=0.25),
        dict(note=50, name="Cowbell", make=cowbell808),
        dict(note=51, name="Ride", make=ride, pan=0.3),
    ]


def kit_punch():
    return [
        dict(note=36, name="Kick", make=kick909, layers=3),
        dict(note=37, name="Rim", make=lambda: rim808() * 0.9),
        dict(note=38, name="Snare", make=snare909, layers=3),
        dict(note=39, name="Clap", make=lambda: soft_clip(clap808() * 1.3, 2.0)),
        dict(note=40, name="Snare (fat)", make=lambda: snare808(tone=(160, 260), tone_tau=0.09, noise_tau=0.2, snappy=0.8)),
        dict(note=41, name="Low Tom", make=lambda: tom808(95, 0.22)),
        dict(note=42, name="Closed Hat", make=lambda: hat909(0.04), choke=1, layers=3, pan=-0.2),
        dict(note=43, name="Mid-Low Tom", make=lambda: tom808(115, 0.22)),
        dict(note=44, name="Pedal Hat", make=lambda: hat909(0.02), choke=1, pan=-0.2),
        dict(note=45, name="Mid Tom", make=lambda: tom808(138, 0.2)),
        dict(note=46, name="Open Hat", make=lambda: hat909(0.28), choke=1, pan=-0.2),
        dict(note=47, name="Mid-High Tom", make=lambda: tom808(165, 0.2)),
        dict(note=48, name="High Tom", make=lambda: tom808(200, 0.18)),
        dict(note=49, name="Crash", make=lambda: cymbal808(1.4, lo=3500), pan=0.25),
        dict(note=50, name="Shaker", make=shaker),
        dict(note=51, name="Ride", make=ride, pan=0.3),
    ]


def kit_lofi():
    base = kit_808()
    tweaks = {36: lambda: kick808(boom=0.35, f0=120, f1=52, click=0.1, drive=2.2)}
    out = []
    for p in base:
        make = tweaks.get(p["note"], p["make"])
        q = dict(p)
        q["make"] = (lambda m: (lambda: lofi(m())))(make)
        q.pop("layers", None)
        out.append(q)
    out[9] = dict(note=45, name="Vinyl Snap", make=lambda: lofi(snap(), bits=8))
    return out


def kit_percussion():
    return [
        dict(note=36, name="Low Conga", make=lambda: drum_hand(196, 0.16)),
        dict(note=37, name="Mid Conga", make=lambda: drum_hand(262, 0.13)),
        dict(note=38, name="High Conga", make=lambda: drum_hand(330, 0.11, slap=0.35)),
        dict(note=39, name="Low Bongo", make=lambda: drum_hand(392, 0.08)),
        dict(note=40, name="High Bongo", make=lambda: drum_hand(523, 0.06)),
        dict(note=41, name="Cowbell", make=cowbell808),
        dict(note=42, name="Shaker", make=shaker, layers=2),
        dict(note=43, name="Tambourine", make=tambourine),
        dict(note=44, name="Clave", make=clave),
        dict(note=45, name="Woodblock", make=woodblock),
        dict(note=46, name="Triangle", make=triangle, choke=2),
        dict(note=47, name="Agogo Low", make=lambda: agogo(620)),
        dict(note=48, name="Agogo High", make=lambda: agogo(930)),
        dict(note=49, name="Guiro", make=guiro),
        dict(note=50, name="Timbale", make=timbale),
        dict(note=51, name="Finger Snap", make=snap),
    ]


KITS = [
    ("808", "808", kit_808),
    ("punch", "Punch", kit_punch),
    ("lofi", "Lo-Fi Dust", kit_lofi),
    ("percussion", "Hand Percussion", kit_percussion),
]


def build(out_root):
    for folder, title, maker in KITS:
        kit_dir = os.path.join(out_root, folder)
        os.makedirs(kit_dir, exist_ok=True)
        pads = []
        for i, p in enumerate(maker()):
            safe = p["name"].lower().replace(" ", "_").replace("(", "").replace(")", "").replace("-", "_")
            entry = dict(name=p["name"], note=p["note"])
            for key in ("choke", "pan"):
                if key in p:
                    entry[key] = p[key]
            n_layers = p.get("layers", 1)
            if n_layers > 1:
                entry["layers"] = []
                for li, (x, lo, hi) in enumerate(velocity_layers(p["make"], n_layers)):
                    fname = f"{i + 1:02d}_{safe}_v{li + 1}.wav"
                    write_wav(os.path.join(kit_dir, fname), finish(x, peak_db=-1.0 - 2.5 * (n_layers - 1 - li)))
                    entry["layers"].append(dict(file=fname, minVel=round(lo, 3), maxVel=round(hi, 3)))
            else:
                fname = f"{i + 1:02d}_{safe}.wav"
                write_wav(os.path.join(kit_dir, fname), finish(p["make"]()))
                entry["file"] = fname
            pads.append(entry)

        kit = dict(name=title, author="Lodestone (synthesized)", license="CC0-1.0", pads=pads)
        with open(os.path.join(kit_dir, "kit.json"), "w") as f:
            json.dump(kit, f, indent=2)
        print(f"{title}: {len(pads)} pads -> {kit_dir}")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "resources", "kits")
    build(os.path.abspath(out))
