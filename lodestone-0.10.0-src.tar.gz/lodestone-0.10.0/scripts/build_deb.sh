#!/bin/bash
# Builds Lodestone and packages it as a .deb (Debian/Ubuntu/Linux Mint).
#
#   scripts/build_deb.sh            -> dist/lodestone_<version>_<arch>.deb
#
# Needs: cmake ninja-build g++ pkg-config libfluidsynth-dev libasound2-dev libfreetype-dev
#        libfontconfig1-dev libx11-dev libxrandr-dev libxinerama-dev libxcursor-dev
#        librsvg2-bin dpkg-dev python3 (python3-numpy + python3-scipy only to regenerate kits)
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
VERSION=$(sed -n 's/^project(Lodestone VERSION \([0-9.]*\).*/\1/p' "$ROOT/CMakeLists.txt")
ARCH=$(dpkg --print-architecture)
BUILD="$ROOT/build"
NAME="lodestone_${VERSION}_${ARCH}"
STAGE="$ROOT/dist/$NAME"

echo "== Lodestone $VERSION ($ARCH)"

# ---- 1. compile
if [ ! -f "$BUILD/build.ninja" ]; then
    cmake -S "$ROOT" -B "$BUILD" -G Ninja -DCMAKE_BUILD_TYPE=Release
fi
cmake --build "$BUILD" --target Lodestone -- -j"$(nproc)"

# ---- 2. drum kits (synthesized, CC0)
if [ ! -f "$ROOT/resources/kits/808/kit.json" ]; then
    python3 "$ROOT/scripts/make_kits.py"
fi

# ---- 3. stage the file tree
rm -rf "$STAGE"
mkdir -p "$STAGE/DEBIAN" "$STAGE/usr/bin" "$STAGE/usr/share/lodestone" "$STAGE/usr/lib/lodestone" \
         "$STAGE/usr/share/applications" "$STAGE/usr/share/mime/packages" "$STAGE/usr/share/metainfo" \
         "$STAGE/usr/share/man/man1" "$STAGE/usr/share/doc/lodestone" "$STAGE/usr/share/icons/hicolor/scalable/apps"

install -m 755 "$BUILD/Lodestone_artefacts/Release/lodestone" "$STAGE/usr/bin/lodestone"
strip --strip-unneeded "$STAGE/usr/bin/lodestone"

cp -r "$ROOT/resources/kits" "$STAGE/usr/share/lodestone/kits"

mkdir -p "$STAGE/usr/lib/lodestone/importers"
(cd "$ROOT/importers" && find . -type f -name '*.py' -o -type f -name 'LICENSE' | while read -r f; do
    install -D -m 644 "$f" "$STAGE/usr/lib/lodestone/importers/$f"
done)
chmod 755 "$STAGE/usr/lib/lodestone/importers/run_import.py"

install -m 644 "$ROOT/packaging/lodestone.desktop" "$STAGE/usr/share/applications/lodestone.desktop"
install -m 644 "$ROOT/packaging/lodestone-mime.xml" "$STAGE/usr/share/mime/packages/lodestone.xml"
install -m 644 "$ROOT/packaging/io.github.lodestone.metainfo.xml" "$STAGE/usr/share/metainfo/io.github.lodestone.metainfo.xml"
gzip -9n -c "$ROOT/packaging/lodestone.1" > "$STAGE/usr/share/man/man1/lodestone.1.gz"

install -m 644 "$ROOT/packaging/lodestone.svg" "$STAGE/usr/share/icons/hicolor/scalable/apps/lodestone.svg"
for s in 16 22 24 32 48 64 128 256 512; do
    d="$STAGE/usr/share/icons/hicolor/${s}x${s}/apps"
    mkdir -p "$d"
    rsvg-convert -w "$s" -h "$s" "$ROOT/packaging/lodestone.svg" -o "$d/lodestone.png"
done

install -m 644 "$ROOT/packaging/copyright" "$STAGE/usr/share/doc/lodestone/copyright"
install -m 644 "$ROOT/LICENSE.md" "$STAGE/usr/share/doc/lodestone/LICENSE.md"
install -m 644 "$ROOT/README.md" "$STAGE/usr/share/doc/lodestone/README.md"
{
    printf 'lodestone (%s) unstable; urgency=low\n\n' "$VERSION"
    printf '  * Practice mode (Ctrl+P / --practice): controllers -> sounds without tracks,\n'
    printf '    splits, layers, transpose, per-sound and master effects, audio inputs with\n'
    printf '    meter, tuner and hold-to-sample (keys or chopped pads), metronome, recorder\n'
    printf '    and "Save what I played".\n'
    printf '  * Controllers that appear after startup (and the computer keyboard) now play\n'
    printf '    the selected track straight away.\n\n'
    printf ' -- Lodestone <lodestone@localhost>  %s\n\n' "$(date -R)"
    printf 'lodestone (0.9.0) unstable; urgency=low\n\n  * First release.\n\n -- Lodestone <lodestone@localhost>  %s\n' "$(date -R)"
} | gzip -9n > "$STAGE/usr/share/doc/lodestone/changelog.gz"

find "$STAGE/usr" -type d -exec chmod 755 {} +
find "$STAGE/usr/share" -type f -exec chmod 644 {} +

# ---- 4. control file (library dependencies computed from the binary)
TMP=$(mktemp -d)
mkdir -p "$TMP/debian"
printf 'Source: lodestone\n\nPackage: lodestone\nArchitecture: any\n' > "$TMP/debian/control"
SHLIBS=$(cd "$TMP" && dpkg-shlibdeps -O -e"$STAGE/usr/bin/lodestone" 2>/dev/null | sed -n 's/^shlibs:Depends=//p')
rm -rf "$TMP"

cat > "$STAGE/DEBIAN/control" <<EOF
Package: lodestone
Version: $VERSION
Architecture: $ARCH
Maintainer: Lodestone <lodestone@localhost>
Installed-Size: $(du -sk "$STAGE/usr" | cut -f1)
Depends: $SHLIBS, python3 (>= 3.10), fluid-soundfont-gm | timgm6mb-soundfont | musescore-general-soundfont-small
Recommends: ffmpeg
Suggests: lmms, lsp-plugins-lv2, x42-plugins, calf-plugins, zynaddsubfx-lv2, jackd2
Section: sound
Priority: optional
Description: friendly digital audio workstation that opens LMMS/FL Studio projects
 Lodestone is an open-source DAW built on Tracktion Engine. Record audio and
 MIDI, play every connected MIDI controller at once (pin a pad controller like
 an Akai MPD218 to the drum track), program beats on a 16-pad drum machine or
 step sequencer, draw notes in a scale-aware piano roll, and mix with 186
 Airwindows effects or your own VST3/LV2/LADSPA plugins.
 .
 It imports LMMS (.mmp/.mmpz) and FL Studio (.flp) projects, has experimental
 GarageBand (.band) and Logic Pro (.logicx) import, and reads/writes
 DAWproject and MIDI. Songs export to WAV, FLAC, OGG or per-track stems.
EOF

# ---- 5. build the package
mkdir -p "$ROOT/dist"
dpkg-deb --root-owner-group -Zxz --build "$STAGE" "$ROOT/dist/$NAME.deb"
echo "== built dist/$NAME.deb ($(du -h "$ROOT/dist/$NAME.deb" | cut -f1))"
