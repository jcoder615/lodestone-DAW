#!/bin/bash
# Fetches the exact Tracktion Engine + JUCE versions Lodestone is built against into
# third_party/tracktion_engine and applies Lodestone's patches. Run once before building.
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
DEST="$ROOT/third_party/tracktion_engine"
TE_COMMIT=be4a6a0c94cc59ebe6f7a0a02373567cb2c01cfb      # Tracktion Engine 3.5 line
JUCE_COMMIT=7ff644f65d7daa1428c34b9738ebb5c449dc9172    # JUCE 9.0.x (Tracktion's submodule pin)

if [ -L "$DEST" ] || [ -d "$DEST/modules/juce/modules" ]; then
    echo "third_party/tracktion_engine already present"
else
    mkdir -p "$ROOT/third_party"
    git clone --filter=blob:none https://github.com/Tracktion/tracktion_engine.git "$DEST"
    git -C "$DEST" checkout "$TE_COMMIT"
    git -C "$DEST" submodule update --init --depth 1 modules/juce || {
        git -C "$DEST/modules/juce" fetch --depth 1 origin "$JUCE_COMMIT"
        git -C "$DEST/modules/juce" checkout "$JUCE_COMMIT"
    }
fi

for p in "$ROOT"/patches/*.patch; do
    if git -C "$DEST/modules/juce" apply --check "$p" 2>/dev/null; then
        git -C "$DEST/modules/juce" apply "$p"
        echo "applied $(basename "$p")"
    else
        echo "skipped $(basename "$p") (already applied?)"
    fi
done
